# 权利与许可边界

## 源码与工具

本次重新实现的代码未由作者指定开源许可，不默认授权公开再分发。随仓协议工具单独保留其 MIT LICENSE；第三方框架分别遵守原许可。

## 参考图像

参考 https://lattetemplate.framer.website/ ，原模板作者 Toni Järvinen，2026-10-20 读取。公开图像保存在 public/templates/latte/images，逐项来源、字节数和 SHA256 见 sources.json。可访问和“免费模板”字样都不等于已获得素材再分发许可。未完成授权核验或替换前，仅供本地研究和效果评审，listed=false，不部署、出售或公开分发。未声明拥有原品牌商标权。

## 字体

Poppins 采用 SIL OFL，见 fonts/Poppins-OFL.txt。MiSans 采用小米字体协议，官方来源见 fonts/misans/LICENSE-SOURCE.md。字体本地托管，许可与权利声明随资源保留。

## 演示内容

菜单、价格、评分、门店信息为示例，不构成真实业务背书。新闻保留参考站五篇主题，使用重新编写的中英文文案，不冒充原作者逐字文章或经营声明。联系表单不发送、不持久化、不预约。
