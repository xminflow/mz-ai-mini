import type {SiteTemplate} from '../../types';
export const latteTemplate:SiteTemplate={...{
  "id": "latte",
  "name": "Latte · 咖啡与烘焙",
  "localizedNames": {
    "en": "Latte · Café & bakery"
  },
  "sceneId": "corporate-site",
  "listed": false,
  "tags": [
    "咖啡餐饮",
    "奶油暖色",
    "交错相册",
    "中英文",
    "PC / iPad / H5"
  ],
  "summary": "奶油色咖啡馆整站，包含照片轮播、四类菜单、五篇咖啡手记、门店联系与本地演示表单。",
  "accentColor": "#8b6845",
  "cover": "/templates/latte/screenshots/desktop-home.webp",
  "screenshots": [
    {
      "src": "/templates/latte/screenshots/desktop-home.webp",
      "alt": "Latte desktop home",
      "device": "desktop",
      "width": 1440,
      "height": 1000
    },
    {
      "src": "/templates/latte/screenshots/desktop-menu.webp",
      "alt": "Latte desktop menu",
      "device": "desktop",
      "width": 1440,
      "height": 1000
    },
    {
      "src": "/templates/latte/screenshots/desktop-news.webp",
      "alt": "Latte desktop news",
      "device": "desktop",
      "width": 1440,
      "height": 1000
    },
    {
      "src": "/templates/latte/screenshots/desktop-contact.webp",
      "alt": "Latte desktop contact",
      "device": "desktop",
      "width": 1440,
      "height": 1000
    },
    {
      "src": "/templates/latte/screenshots/tablet-home.webp",
      "alt": "Latte tablet home",
      "device": "tablet",
      "width": 834,
      "height": 1180
    },
    {
      "src": "/templates/latte/screenshots/tablet-menu.webp",
      "alt": "Latte tablet menu",
      "device": "tablet",
      "width": 834,
      "height": 1180
    },
    {
      "src": "/templates/latte/screenshots/tablet-news.webp",
      "alt": "Latte tablet news",
      "device": "tablet",
      "width": 834,
      "height": 1180
    },
    {
      "src": "/templates/latte/screenshots/tablet-contact.webp",
      "alt": "Latte tablet contact",
      "device": "tablet",
      "width": 834,
      "height": 1180
    },
    {
      "src": "/templates/latte/screenshots/mobile-home.webp",
      "alt": "Latte mobile home",
      "device": "mobile",
      "width": 390,
      "height": 844
    },
    {
      "src": "/templates/latte/screenshots/mobile-menu.webp",
      "alt": "Latte mobile menu",
      "device": "mobile",
      "width": 390,
      "height": 844
    },
    {
      "src": "/templates/latte/screenshots/mobile-news.webp",
      "alt": "Latte mobile news",
      "device": "mobile",
      "width": 390,
      "height": 844
    },
    {
      "src": "/templates/latte/screenshots/mobile-contact.webp",
      "alt": "Latte mobile contact",
      "device": "mobile",
      "width": 390,
      "height": 844
    }
  ]
},surfaces:[{id:'site',name:'咖啡馆官网',platform:'pc',locales:['zh','en'],pages:[
{slug:"",title:"首页",localizedTitles:{en:"Home"},load:()=>import('./pages/HomePage')},
{slug:"news",title:"咖啡手记",localizedTitles:{en:"News"},load:()=>import('./pages/NewsPage')},
{slug:"news/exploring-the-world-of-coffee-origins",title:"咖啡产地",localizedTitles:{en:"Coffee origins"},load:()=>import('./pages/ArticlePage')},
{slug:"news/5-ways-to-elevate-your-coffee-experience-at-home",title:"在家冲煮",localizedTitles:{en:"Home brewing"},load:()=>import('./pages/ArticlePage')},
{slug:"news/eco-friendly-practices-at-latte-haven",title:"可持续日常",localizedTitles:{en:"Sustainability"},load:()=>import('./pages/ArticlePage')},
{slug:"news/the-art-of-the-perfect-latte",title:"拿铁艺术",localizedTitles:{en:"Latte art"},load:()=>import('./pages/ArticlePage')},
{slug:"news/seasonal-specials-at-latte-haven-summer-edition",title:"夏日特饮",localizedTitles:{en:"Summer specials"},load:()=>import('./pages/ArticlePage')},
{slug:"contact",title:"来店坐坐",localizedTitles:{en:"Visit us"},load:()=>import('./pages/ContactPage')},
{slug:"privacy-policy",title:"隐私政策",localizedTitles:{en:"Privacy policy"},load:()=>import('./pages/PolicyPage')},
{slug:"cookies",title:"Cookie 说明",localizedTitles:{en:"Cookies"},load:()=>import('./pages/PolicyPage')},
{slug:"terms-and-conditions",title:"使用条款",localizedTitles:{en:"Terms & conditions"},load:()=>import('./pages/PolicyPage')}
]}]};
