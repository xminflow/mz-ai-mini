'use client';
import type { SiteTemplatePageProps } from '../../../types';
import { Shell } from '../components/Shell';
import { VisitSection } from '../components/VisitSection';
import { ContactForm } from '../components/ContactForm';
import { text, ui } from '../content';
export default function ContactPage({ basePath, locale = 'zh' }: SiteTemplatePageProps) { return <Shell basePath={basePath} locale={locale} visit={false}><div className="latte-inner latte-container"><header className="latte-contact-head"><span className="latte-eyebrow">{locale === 'zh' ? '一杯咖啡的距离' : 'Just a coffee away'}</span><h1>{text(ui.contact, locale)}</h1><p>{locale === 'zh' ? '找一张喜欢的桌子 把时间留给自己' : 'Find your favourite table. Make a little time for yourself.'}</p></header></div><VisitSection basePath={basePath} locale={locale}/><section className="latte-container latte-contact-section"><ContactForm locale={locale}/><aside className="latte-map" aria-label={locale === 'zh' ? '示意位置图，并非真实导航地图' : 'Illustrative location, not a navigation map'}><div className="latte-map-grid"><span className="latte-map-pin">●</span><strong>{locale === 'zh' ? '在这里 遇见一杯好咖啡' : 'A good cup starts here'}</strong><p>123 Latte Lane</p></div><p>{locale === 'zh' ? '示意地址 · 不调用第三方地图' : 'Sample location · no third-party map service'}</p></aside></section></Shell>; }
