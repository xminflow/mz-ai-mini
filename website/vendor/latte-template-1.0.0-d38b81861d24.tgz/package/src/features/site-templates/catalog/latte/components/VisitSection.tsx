'use client';
import Link from 'next/link';
import type { SiteTemplatePageProps } from '../../../types';
import { brand } from '../config/brand';
import { photos } from '../data';
import { text, ui } from '../content';
import { useLatteHost } from '../host';
export function VisitSection({ basePath, locale = 'zh' }: SiteTemplatePageProps) {
  const name = useLatteHost().brandName?.[locale] ?? brand.name[locale];
  return <section className="latte-visit latte-container" id="visit"><div className="latte-visit-photo"><img src={photos.cafe} alt={locale === 'zh' ? '洒满阳光的咖啡馆座位' : 'Sunlit tables inside the café'} loading="lazy"/></div><div className="latte-visit-copy"><span className="latte-eyebrow">{name}</span><h2>{text(ui.about, locale)}</h2><p>{text(ui.aboutBody, locale)}</p><p>{text(ui.welcome, locale)}</p><div className="latte-address"><strong>{text(ui.location, locale)}</strong><p>{brand.address[locale]}</p></div><Link className="latte-button" href={`${basePath}/#menu`}>{text(ui.explore, locale)}</Link></div></section>;
}
