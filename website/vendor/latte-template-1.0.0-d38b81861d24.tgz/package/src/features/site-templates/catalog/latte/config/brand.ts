export const brand = {
  name: { zh: 'Latte 咖啡', en: 'Latte Haven' },
  logo: '/templates/latte/images/V5tIwQyz2S0O66AuNJHLQeGtQ.png',
  year: 2026,
  phone: '(555) 987-6543',
  address: { zh: 'Latte Lane 123 号 · Food City（示例地址）', en: '123 Latte Lane, Food City (sample address)' },
};
