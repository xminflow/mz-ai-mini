'use client';
import Link from 'next/link';
import type { SiteTemplatePageProps } from '../../../types';
import { Shell, Reveal } from '../components/Shell';
import { Gallery } from '../components/Gallery';
import { MenuSection } from '../components/MenuSection';
import { NewsSection } from '../components/NewsCards';
import { text, ui } from '../content';
export default function HomePage({ basePath, locale = 'zh' }: SiteTemplatePageProps) { return <Shell basePath={basePath} locale={locale}><section className="latte-hero"><Reveal><div className="latte-rating"><span>{locale === 'zh' ? '咖啡好评' : 'Coffee rating'}</span><span aria-label={locale === 'zh' ? '五星' : 'Five stars'}>★★★★★</span><strong>(4.9)</strong></div><h1>{text(ui.title, locale)}</h1><p>{text(ui.intro, locale)}</p><Link className="latte-button" href={`${basePath}/#menu`}>{text(ui.explore, locale)}</Link></Reveal></section><Gallery locale={locale}/><MenuSection locale={locale}/><NewsSection basePath={basePath} locale={locale}/></Shell>; }
