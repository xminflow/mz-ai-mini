'use client';
import { useRef, useState, type KeyboardEvent } from 'react';
import { motion } from 'framer-motion';
import { gallery } from '../data';
import { text, ui } from '../content';
import type { TemplateLocale } from '../../../types';
export function Gallery({ locale }: { locale: TemplateLocale }) {
  const [index, setIndex] = useState(Math.min(2, gallery.length - 1));
  const touch = useRef<number | null>(null);
  const move = (step: number) => { if (gallery.length) setIndex(current => (current + step + gallery.length) % gallery.length); };
  const key = (e: KeyboardEvent) => { if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') { e.preventDefault(); move(e.key === 'ArrowLeft' ? -1 : 1); } };
  if (!gallery.length) return null;
  return <section className="latte-gallery" aria-roledescription={locale === 'zh' ? '轮播' : 'carousel'} aria-label={locale === 'zh' ? '咖啡与门店相册' : 'Coffee and café gallery'} tabIndex={0} onKeyDown={key} onTouchStart={e => { touch.current = e.touches[0].clientX; }} onTouchEnd={e => { if (touch.current !== null) { const delta = e.changedTouches[0].clientX - touch.current; if (Math.abs(delta) > 40) move(delta > 0 ? -1 : 1); } touch.current = null; }}>
    <div className="latte-gallery-track">{[-2, -1, 0, 1, 2].map(offset => { const photo = gallery[(index + offset + gallery.length) % gallery.length]; return <motion.div className={`latte-gallery-photo offset-${Math.abs(offset)}`} key={offset} animate={{ scale: offset === 0 ? 1 : Math.abs(offset) === 1 ? .86 : .7 }} transition={{ duration: .45 }}><img src={photo.src} alt={text(photo.alt, locale)} draggable={false}/></motion.div>; })}</div>
    {gallery.length > 1 && <div className="latte-gallery-controls"><button type="button" onClick={() => move(-1)} aria-label={text(ui.previous, locale)}>‹</button><button type="button" onClick={() => move(1)} aria-label={text(ui.next, locale)}>›</button></div>}
    <span className="latte-sr" aria-live="polite">{index + 1} / {gallery.length} — {text(gallery[index].alt, locale)}</span>
  </section>;
}
