'use client';
import { usePathname } from 'next/navigation';
import type { SiteTemplatePageProps } from '../../../types';
import { Shell } from '../components/Shell';
import { policies, text } from '../content';
export default function PolicyPage({ basePath, locale = 'zh' }: SiteTemplatePageProps) { const slug = (usePathname() ?? '').split('/').filter(Boolean).at(-1) ?? ''; const policy = policies[slug as keyof typeof policies]; return <Shell basePath={basePath} locale={locale} visit={false}><article className="latte-policy latte-container"><h1>{policy ? text(policy.title, locale) : (locale === 'zh' ? '政策未找到' : 'Policy not found')}</h1>{policy?.sections.map(([title, body]) => <section key={title.en}><h2>{text(title, locale)}</h2><p>{text(body, locale)}</p></section>)}</article></Shell>; }
