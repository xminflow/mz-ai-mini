'use client';
import { menu } from '../data';
import { text, ui } from '../content';
import type { TemplateLocale } from '../../../types';
import { Reveal } from './Shell';
export function MenuSection({ locale }: { locale: TemplateLocale }) { return <section className="latte-container latte-menu-section" id="menu"><h2 className="latte-section-title">{text(ui.ourMenu, locale)}</h2><p className="latte-demo-note">{locale === 'zh' ? '示例菜单与价格 · 仅供模板展示' : 'Illustrative menu and prices · template demonstration'}</p><div className="latte-menu-groups">{menu.map((group, i) => <Reveal className={`latte-menu-group ${i % 2 ? 'is-reversed' : ''}`} key={group.title.en}><div className="latte-menu-card"><h3>{text(group.title, locale)}</h3><dl>{group.items.map(item => <div className="latte-menu-item" key={item.name.en}><dt><span>{text(item.name, locale)}</span><span>{item.price}</span></dt><dd>{text(item.description, locale)}</dd></div>)}</dl></div><figure className="latte-menu-photo"><img src={group.photo} alt={text(group.caption, locale)} loading="lazy"/><figcaption>{text(group.caption, locale)}</figcaption></figure></Reveal>)}</div></section>; }
