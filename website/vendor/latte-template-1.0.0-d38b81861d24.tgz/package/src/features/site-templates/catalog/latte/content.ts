import type { TemplateLocale } from '../../types';
export type Copy = Record<TemplateLocale, string>;
export const copy = (zh: string, en: string): Copy => ({ zh, en });
export const text = (value: Copy, locale: TemplateLocale) => value[locale];
export const ui = {
  menu: copy('咖啡与烘焙', 'Menu'), news: copy('咖啡手记', 'News'), contact: copy('来店坐坐', 'Visit us'),
  title: copy('把日常慢下来\n让咖啡香起来', 'Brewed to perfection'),
  intro: copy('一杯好咖啡 一口新鲜烘焙\n在这里 找到属于你的片刻', 'Your perfect spot for coffee, pastries, and more.'),
  explore: copy('探索菜单', 'Explore menu'), ourMenu: copy('今天 想喝点什么', 'Our Menu'),
  latest: copy('新鲜出炉的咖啡手记', 'Latest coffee news'), allNews: copy('所有咖啡手记', 'All news'),
  about: copy('我们 热爱咖啡', 'We love coffee'),
  aboutBody: copy('城市的步调很快 我们想留一个慢下来的角落。现磨咖啡、刚出炉的可颂和窗边的阳光，让普通的一天也值得期待。', 'A warm corner of the city, filled with freshly ground coffee, just-baked pastries and a little afternoon light. Make yourself at home.'),
  welcome: copy('随时来坐坐 把片刻留给自己', 'A little pause. A very good cup.'),
  footer: copy('让每一杯 都有温度', 'Good coffee. Warm company.'),
  hours: copy('营业时间', 'Opening hours'), location: copy('门店位置', 'Location'), phone: copy('电话', 'Phone'),
  hoursWeek: copy('周一至周四 11:00–21:00', 'Mon–Thu: 11:00 AM–9:00 PM'),
  hoursWeekend: copy('周五至周六 11:00–22:00', 'Fri–Sat: 11:00 AM–10:00 PM'),
  hoursSunday: copy('周日 12:00–20:00', 'Sun: 12:00 PM–8:00 PM'),
  demo: copy('演示表单：仅在当前页面校验，不发送、不保存，也不会创建预约。', 'Demo form: validates on this page only. Nothing is sent, saved or booked.'),
  previous: copy('上一张', 'Previous slide'), next: copy('下一张', 'Next slide'),
};
export const policies = {
  'privacy-policy': { title: copy('隐私政策', 'Privacy policy'), sections: [
    [copy('本地演示', 'Local demonstration'), copy('本模板没有账户、后台数据存储或第三方统计。联系表单内容仅用于当前页面校验，不上传、不保存；离开或刷新页面后清除。', 'This demo has no accounts, server storage or third-party analytics. Form entries are validated in the current page, never transmitted or stored, and disappear when you leave or reload.')],
    [copy('资源与外部服务', 'Assets and external services'), copy('图片与字体由当前站点本地提供，不嵌入外部地图。正式运营前应按实际数据处理方式更新本说明。', 'Images and fonts are served locally. No external map is embedded. Update this notice to match actual data processing before operating a live business.')],
  ] },
  cookies: { title: copy('Cookie 说明', 'Cookie notice'), sections: [
    [copy('当前使用情况', 'Current use'), copy('本模板不主动写入 Cookie 或本地存储。语言由网址路径决定，无需使用追踪标识。', 'This template does not set cookies or local storage. The language is selected by the URL path, without a tracking identifier.')],
    [copy('正式使用', 'Before launch'), copy('如后续接入统计、登录或第三方服务，请同步更新 Cookie 分类、有效期与同意管理。', 'If analytics, sign-in or third-party services are added, document cookie categories, retention and consent controls.')],
  ] },
  'terms-and-conditions': { title: copy('使用条款', 'Terms & conditions'), sections: [
    [copy('展示用途', 'Demonstration only'), copy('菜单、价格、评分、营业时间、电话与地址均为模板示例，不构成真实交易、预约或经营承诺。', 'Menus, prices, ratings, opening times, phone numbers and addresses are illustrative. They do not establish a transaction, reservation or business commitment.')],
    [copy('知识产权', 'Intellectual property'), copy('参考图像与字体的权利归各自权利人所有。公开可访问不代表可再分发，正式使用前须完成授权核验或替换。', 'Reference images and fonts remain the property of their rights holders. Public availability does not grant redistribution rights; confirm permissions or replace assets before launch.')],
  ] },
} satisfies Record<string, { title: Copy; sections: Copy[][] }>;
