'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import type { SiteTemplatePageProps } from '../../../types';
import { Shell } from '../components/Shell';
import { articleDate, NewsCard } from '../components/NewsCards';
import { articles } from '../data';
import { text, ui } from '../content';
export default function ArticlePage({ basePath, locale = 'zh' }: SiteTemplatePageProps) {
  const pathname = usePathname() ?? '', article = articles.find(item => pathname.replace(/\/$/, '').endsWith('/news/' + item.slug));
  if (!article) return <Shell basePath={basePath} locale={locale}><section className="latte-container latte-inner"><h1>{locale === 'zh' ? '文章未找到' : 'Article not found'}</h1><Link href={`${basePath}/news`}>{text(ui.allNews, locale)}</Link></section></Shell>;
  return <Shell basePath={basePath} locale={locale}><article className="latte-article"><header className="latte-article-head"><Link className="latte-back" href={`${basePath}/news`}>← {text(ui.allNews, locale)}</Link><time dateTime={article.date}>{articleDate(article.date, locale)}</time><h1>{text(article.title, locale)}</h1></header><img className="latte-article-cover" src={article.image} alt={text(article.title, locale)}/><div className="latte-article-body"><p className="latte-article-intro">{text(article.intro, locale)}</p>{article.sections.map(section => <section key={section.title.en}><h2>{text(section.title, locale)}</h2><p>{text(section.body, locale)}</p></section>)}</div></article><section className="latte-container latte-news-section"><h2>{locale === 'zh' ? '再读一篇' : 'Another cup, another story'}</h2><div className="latte-news-grid">{articles.filter(item => item.slug !== article.slug).slice(0, 3).map(item => <NewsCard key={item.slug} article={item} basePath={basePath} locale={locale}/>)}</div></section></Shell>;
}
