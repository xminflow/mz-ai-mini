'use client';
import { useState } from 'react';
import type { SiteTemplatePageProps } from '../../../types';
import { Shell } from '../components/Shell';
import { NewsCard } from '../components/NewsCards';
import { articles } from '../data';
import { text, ui } from '../content';
export default function NewsPage({ basePath, locale = 'zh' }: SiteTemplatePageProps) {
  const [index, setIndex] = useState(0), featured = articles.slice(0, 3);
  return <Shell basePath={basePath} locale={locale} visit={false}><section className="latte-container latte-news-feature" aria-label={locale === 'zh' ? '精选文章' : 'Featured stories'}><h1 className="latte-sr">{text(ui.news, locale)}</h1>{featured.length > 0 && <><NewsCard article={featured[index % featured.length]} basePath={basePath} locale={locale} featured/>{featured.length > 1 && <div className="latte-feature-controls"><button type="button" aria-label={text(ui.previous, locale)} onClick={() => setIndex((index + featured.length - 1) % featured.length)}>‹</button><span aria-live="polite">{index + 1} / {featured.length}</span><button type="button" aria-label={text(ui.next, locale)} onClick={() => setIndex((index + 1) % featured.length)}>›</button></div>}</>}</section><section className="latte-container latte-news-section"><h2>{text(ui.allNews, locale)}</h2><div className="latte-news-grid">{articles.map(article => <NewsCard key={article.slug} article={article} basePath={basePath} locale={locale}/>)}</div></section></Shell>;
}
