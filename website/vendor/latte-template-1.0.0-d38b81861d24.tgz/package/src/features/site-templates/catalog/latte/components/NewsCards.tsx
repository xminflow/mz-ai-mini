'use client';
import Link from 'next/link';
import { articles, type Article } from '../data';
import { text, ui } from '../content';
import type { SiteTemplatePageProps, TemplateLocale } from '../../../types';
export function articleDate(date: string, locale: TemplateLocale) { return new Intl.DateTimeFormat(locale === 'zh' ? 'zh-CN' : 'en-US', { year: 'numeric', month: 'short', day: 'numeric', timeZone: 'UTC' }).format(new Date(date + 'T12:00:00Z')); }
export function NewsCard({ article, basePath, locale = 'zh', featured = false }: SiteTemplatePageProps & { article: Article; featured?: boolean }) { return <Link className={`latte-news-card ${featured ? 'is-featured' : ''}`} href={`${basePath}/news/${article.slug}`}><div className="latte-news-image"><img src={article.image} alt={text(article.title, locale)} loading={featured ? 'eager' : 'lazy'}/></div><div className="latte-news-copy"><time dateTime={article.date}>{articleDate(article.date, locale)}</time><h3>{text(article.title, locale)}</h3><span className="latte-news-arrow" aria-hidden="true">↗</span></div></Link>; }
export function NewsSection({ basePath, locale = 'zh' }: SiteTemplatePageProps) { return <section className="latte-container latte-news-section" id="news"><div className="latte-section-row"><h2>{text(ui.latest, locale)}</h2><Link href={`${basePath}/news`}>{text(ui.allNews, locale)} ↗</Link></div><div className="latte-news-grid">{articles.slice(0, 3).map(article => <NewsCard key={article.slug} article={article} basePath={basePath} locale={locale}/>)}</div></section>; }
