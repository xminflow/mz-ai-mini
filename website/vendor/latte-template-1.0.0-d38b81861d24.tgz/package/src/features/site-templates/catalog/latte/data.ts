import { copy, type Copy } from './content';
export const image = (name: string) => '/templates/latte/images/' + name;
export const photos = {
  pastry: image('PRDfIQEwfBAD6WhfpVujpWW5c.png'), chocolate: image('rgN0P1vQKsq9ZG5BJOPaR9KY.png'),
  latte: image('ffAQuLErAZ9FhPrK3M7QLPo5g.png'), cafe: image('wGH7yhEM7Dvwg5tG7oiMVQd0M.png'),
  chai: image('i6aEvR24jRpFkZDao1hmf0YYo.png'),
};
export const gallery = [
  { src: photos.pastry, alt: copy('新鲜烘焙的酥脆可颂', 'Freshly baked croissants') },
  { src: photos.chocolate, alt: copy('棉花糖热巧克力', 'Hot chocolate with marshmallows') },
  { src: photos.latte, alt: copy('木桌上的拉花拿铁', 'Latte art on a wooden table') },
  { src: photos.cafe, alt: copy('阳光洒进咖啡馆', 'Sunlight in the café') },
  { src: image('HxZ5ZF3EmNZV8ft3wsqxeOgQE.png'), alt: copy('咖啡馆的温暖角落', 'A welcoming café corner') },
];
export interface MenuItem { name: Copy; price: string; description: Copy }
export interface MenuGroup { title: Copy; photo: string; caption: Copy; items: MenuItem[] }
const item = (zh: string, en: string, price: string, descriptionZh: string, descriptionEn: string): MenuItem => ({ name: copy(zh, en), price, description: copy(descriptionZh, descriptionEn) });
export const menu: MenuGroup[] = [
  { title: copy('经典咖啡', 'Coffee'), photo: photos.latte, caption: copy('拿铁', 'Latte'), items: [
    item('浓缩咖啡', 'Espresso', '$2.50', '小小一杯 浓郁醇香', 'A concentrated shot with a full, lasting finish.'),
    item('美式咖啡', 'Americano', '$3.00', '浓缩与热水交融 清爽而饱满', 'Espresso lengthened with water for an easy, balanced cup.'),
    item('拿铁', 'Latte', '$4.00', '浓缩、热牛奶与细腻奶泡 可选香草、焦糖、榛果与摩卡风味', 'Espresso under silky milk. Choose vanilla, caramel, hazelnut or mocha.'),
    item('卡布奇诺', 'Cappuccino', '$4.00', '咖啡、牛奶、奶泡的经典平衡', 'A classic balance of espresso, warm milk and airy foam.'),
    item('馥芮白', 'Flat White', '$4.00', '双份浓缩 覆上绵密微奶泡', 'A double espresso with a fine, velvety milk texture.'),
    item('玛奇朵', 'Macchiato', '$4.00', '一小朵奶泡 点亮浓缩风味', 'A small touch of milk foam over an espresso shot.'),
    item('摩卡', 'Mocha', '$4.00', '浓缩、巧克力与牛奶的甜蜜相遇', 'Chocolate and espresso brought together with warm milk.'),
    item('冷萃', 'Cold Brew', '$4.00', '低温慢萃 加冰更清爽', 'Slow-steeped coffee, chilled and served over ice.'),
  ] },
  { title: copy('风味拿铁', 'Specialty Lattes'), photo: photos.chai, caption: copy('香料奶茶拿铁', 'Chai Latte'), items: [
    item('抹茶拿铁', 'Matcha Latte', '$4.50', '细腻抹茶 搭配温热牛奶', 'Finely whisked matcha with warm, smooth milk.'),
    item('姜黄拿铁', 'Turmeric Latte', '$4.50', '姜黄、生姜与肉桂的温暖香气', 'A gently spiced blend of turmeric, ginger, cinnamon and milk.'),
    item('香料奶茶拿铁', 'Chai Latte', '$4.00', '茶香、香料与奶香层层交织', 'Fragrant chai spices folded into steamed milk.'),
    item('蜂蜜薰衣草拿铁', 'Honey Lavender Latte', '$5.00', '蜂蜜的柔甜 遇见淡淡薰衣草', 'An espresso latte with honey sweetness and a floral touch.'),
  ] },
  { title: copy('茶与其他饮品', 'Tea & Other Beverages'), photo: photos.chocolate, caption: copy('热巧克力', 'Hot Chocolate'), items: [
    item('精选茶饮', 'Tea', '$3.00', '红茶、绿茶与草本茶 可按喜好选择', 'A choice of black, green and herbal infusions.'),
    item('热巧克力', 'Hot Chocolate', '$4.50', '浓郁可可 配上轻盈奶油', 'A comforting cocoa drink finished with whipped cream.'),
    item('黄金牛奶', 'Golden Milk', '$4.00', '姜黄、生姜与蜂蜜融入温牛奶', 'Warm milk with turmeric, ginger and a touch of honey.'),
    item('冰茶', 'Iced Tea', '$5.00', '现泡冷却 加冰慢慢享用', 'Freshly brewed tea, cooled and poured over ice.'),
  ] },
  { title: copy('每日新鲜烘焙', 'Pastries & Baked Goods'), photo: photos.pastry, caption: copy('黄油可颂', 'Croissant'), items: [
    item('黄油可颂', 'Croissant', '$3.00', '层层酥脆 每天新鲜出炉', 'Golden layers baked fresh for a buttery bite.'),
    item('麦芬', 'Muffins', '$2.50', '蓝莓、巧克力豆与香蕉坚果风味', 'Choose blueberry, chocolate chip or banana nut.'),
    item('司康', 'Scones', '$4.00', '蔓越莓香橙或香草风味', 'Cranberry-orange and vanilla-bean varieties.'),
    item('曲奇', 'Cookies', '$2.00', '巧克力豆、燕麦葡萄干与双重巧克力', 'Chocolate chip, oatmeal raisin or double chocolate.'),
    item('布朗尼', 'Brownies', '$3.00', '薄脆表皮 包裹浓郁巧克力内心', 'A delicate top over a rich, soft chocolate centre.'),
  ] },
];
export interface Article { slug: string; date: string; title: Copy; image: string; intro: Copy; sections: { title: Copy; body: Copy }[] }
export const articles: Article[] = [
  { slug: 'exploring-the-world-of-coffee-origins', date: '2024-03-15', title: copy('循着咖啡香 探索风味的原点', 'A journey through coffee origins'), image: image('WdPcmK6WsWeWHrhqIJCvdYtA.jpg'), intro: copy('一杯咖啡的个性，从它生长的土地开始。跟随我们的咖啡地图，认识不同产区的风味线索。', 'A coffee’s character begins where it grows. Follow a few flavour clues through our café’s selection of origins.'), sections: [
    { title: copy('从花果香开始', 'A floral beginning'), body: copy('品尝埃塞俄比亚咖啡时，试着留意花香、果香和明亮的酸质。让咖啡稍稍降温，香气会呈现不同层次。', 'Try an Ethiopian selection slowly, noticing floral aromas, fruit and a bright finish. Compare a warm sip with a cooler one to discover how the cup changes.') },
    { title: copy('寻找平衡与甜感', 'Balance and sweetness'), body: copy('哥伦比亚与巴西是认识平衡感的好起点。把同一种豆子分别做成黑咖啡和奶咖，观察甜感、醇厚度与烘焙风格之间的关系。', 'Colombian and Brazilian selections offer a useful starting point for comparing sweetness and body. Taste a bean black and then with milk to see what each preparation reveals.') },
    { title: copy('给风味留下空间', 'Leave room for discovery'), body: copy('产地只是起点，处理方式、烘焙与冲煮同样塑造一杯咖啡。来店时可以问问当天使用的豆子，用自己的味觉写下答案。', 'Origin is one clue among many: processing, roasting and brewing all shape the result. Ask what is on the grinder today and build your own tasting notes.') },
  ] },
  { slug: '5-ways-to-elevate-your-coffee-experience-at-home', date: '2024-02-28', title: copy('在家也能喝好咖啡的五个小习惯', 'Five small habits for better coffee at home'), image: image('nuDSHnIFowt4cHh6TTY0cDBAVI.jpg'), intro: copy('不必把厨房变成咖啡实验室。从几个容易坚持的小习惯开始，让每天的第一杯更合心意。', 'You do not need a laboratory on your kitchen counter. Start with a few repeatable habits and make your morning cup your own.'), sections: [
    { title: copy('一 让器具保持干净', '1. Keep equipment clean'), body: copy('冲煮后及时清洗滤杯、壶具与磨豆机可清理的部件。干净的器具能减少旧咖啡残留对下一杯的影响。', 'Rinse brewers after use and clean accessible grinder parts as directed by the manufacturer. Start every brew without yesterday’s residue.') },
    { title: copy('二 现磨 三 称量', '2. Grind fresh. 3. Measure.'), body: copy('在冲煮前研磨，并用电子秤记录咖啡粉和水的重量。先找到一个喜欢的比例，再每次只调整一个变量。', 'Grind shortly before brewing and weigh both coffee and water. Find a starting ratio you enjoy, then change one variable at a time.') },
    { title: copy('四 关注水 五 留下记录', '4. Consider water. 5. Take notes.'), body: copy('使用适合饮用的清洁水，按照器具建议控制水温。简单记录豆子、研磨与风味，下一次就有了可以参考的起点。', 'Use clean drinking water and follow the brewer’s temperature guidance. A short note about the beans, grind and taste makes your next experiment easier.') },
  ] },
  { slug: 'eco-friendly-practices-at-latte-haven', date: '2024-02-06', title: copy('从这一杯开始 让日常更可持续', 'Small steps towards a more thoughtful café'), image: image('7MaKWyyvDSoo5ueFYsJkDl3I.jpg'), intro: copy('好咖啡之外，我们也关心每一杯背后的选择。减少浪费，可以从看得见的小事开始。', 'A thoughtful café looks beyond the cup. Here are practical ways a neighbourhood coffee shop can work towards less waste.'), sections: [
    { title: copy('多用一次 少丢一点', 'Reuse where possible'), body: copy('堂食优先使用可重复清洗的杯具。外带时自带杯子，并只取用需要的纸巾和配件。', 'Choose washable cups when staying in. Bring a reusable cup for takeaway and take only the napkins and accessories you need.') },
    { title: copy('了解包装的去向', 'Understand the packaging'), body: copy('可回收和可堆肥并不代表可以随处处理。按照当地回收设施的要求分类，减少不必要的包装比多一层包装更有效。', 'Recyclable and compostable materials need suitable local facilities. Follow local sorting guidance and avoid unnecessary packaging first.') },
    { title: copy('把改变变成习惯', 'Build a lasting habit'), body: copy('按需求备料、维护设备、珍惜用水，都是日常可以持续改善的事情。本页展示的是模板理念，并非真实门店的认证或经营声明。', 'Preparing to demand, maintaining equipment and using water carefully are ongoing practices. These are illustrative ideas, not certifications or claims about a real café.') },
  ] },
  { slug: 'the-art-of-the-perfect-latte', date: '2023-08-10', title: copy('一杯拿铁的细腻之处', 'The little details of a lovely latte'), image: photos.latte, intro: copy('咖啡与牛奶之间，藏着一杯拿铁的平衡。比起复杂图案，我们更在意入口的口感。', 'The pleasure of a latte lives in the balance between coffee and milk. Texture matters as much as the pattern on top.'), sections: [
    { title: copy('浓缩是风味的底色', 'Start with the espresso'), body: copy('先品尝浓缩，再调整咖啡与牛奶的比例。不同豆子会带来不同的甜感、香气与余味。', 'Taste the espresso first, then explore the balance with milk. Different beans bring their own sweetness, aroma and finish.') },
    { title: copy('奶泡要细腻 也要流动', 'Silky milk, gently poured'), body: copy('细腻奶泡与咖啡融合时，入口应该均匀顺滑。植物饮品也可以尝试，留意不同配方在加热后的表现。', 'Finely textured milk should blend smoothly with the coffee. Plant-based alternatives offer another variation; their behaviour differs by formulation.') },
    { title: copy('在最喜欢的时刻享用', 'Enjoy the moment'), body: copy('端起杯子闻一闻，再小口品尝。拉花是短暂的画，喝到喜欢的那一口才是最好的答案。', 'Pause over the aroma before your first sip. Latte art is a fleeting picture; the cup you enjoy is the one that matters.') },
  ] },
  { slug: 'seasonal-specials-at-latte-haven-summer-edition', date: '2022-01-12', title: copy('把夏天 装进咖啡杯', 'A little summer in your coffee cup'), image: image('a71UxklC56LWechfZymPKtbsckY.jpg'), intro: copy('天气变暖时，咖啡也可以换一种节奏。用清爽的温度和明亮的风味，打开夏日灵感。', 'As the days grow warmer, coffee can take a lighter rhythm. Explore cooler serves and brighter flavours for a summer pause.'), sections: [
    { title: copy('冰块之外的清爽', 'More than a handful of ice'), body: copy('提前冷却的咖啡和足量冰块，可以减少一入口就过度稀释的问题。先尝原味，再决定是否加入牛奶或糖。', 'Chill the coffee ahead and use enough ice to keep it cool. Taste it first before deciding whether to add milk or sweetness.') },
    { title: copy('给茶饮留一个位置', 'Make room for tea'), body: copy('清爽冰茶和抹茶拿铁同样适合夏天。搭配一份新鲜烘焙，把午后留给简单的快乐。', 'Iced tea and a matcha latte offer a change of pace. Add something freshly baked and keep the afternoon simple.') },
    { title: copy('当季灵感 以门店为准', 'Seasonal inspiration'), body: copy('本页为季节菜单展示示例，不代表实际在售。正式使用时，请同步更新产品、价格、过敏原和供应信息。', 'This seasonal menu is illustrative, not an availability promise. For a live café, keep products, prices, allergens and availability up to date.') },
  ] },
];
