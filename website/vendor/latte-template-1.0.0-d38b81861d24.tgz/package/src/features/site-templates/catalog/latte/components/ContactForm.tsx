'use client';
import { useState, type FormEvent } from 'react';
import type { TemplateLocale } from '../../../types';
import { text, ui } from '../content';
export function ContactForm({ locale }: { locale: TemplateLocale }) {
  const [complete, setComplete] = useState(false);
  function submit(event: FormEvent<HTMLFormElement>) { event.preventDefault(); if (!event.currentTarget.reportValidity()) return; setComplete(true); }
  return <form className="latte-form latte-glass" onSubmit={submit} onChange={() => setComplete(false)}><h2>{locale === 'zh' ? '留一句话 给下一次见面' : 'A note for your next visit'}</h2><p id="latte-form-notice">{text(ui.demo, locale)}</p><label htmlFor="latte-name">{locale === 'zh' ? '怎么称呼你' : 'Your name'}</label><input id="latte-name" name="name" required minLength={2} maxLength={80} autoComplete="name" aria-describedby="latte-form-notice"/><label htmlFor="latte-email">{locale === 'zh' ? '电子邮箱' : 'Email address'}</label><input id="latte-email" name="email" type="email" required maxLength={254} autoComplete="email"/><label htmlFor="latte-message">{locale === 'zh' ? '想说的话' : 'Your message'}</label><textarea id="latte-message" name="message" rows={5} required minLength={5} maxLength={2000}/><label className="latte-checkbox"><input type="checkbox" required/>{locale === 'zh' ? '我理解此表单仅做本地演示' : 'I understand this is a local demo only'}</label><button className="latte-button" type="submit">{locale === 'zh' ? '校验演示内容' : 'Validate demo message'}</button><p className="latte-form-status" role="status">{complete ? (locale === 'zh' ? '校验通过。内容未发送、未保存，也未创建预约。' : 'Validation passed. Nothing was sent, saved or booked.') : ''}</p></form>;
}
