'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { MotionConfig, motion } from 'framer-motion';
import { useEffect, useState, type ReactNode } from 'react';
import type { SiteTemplatePageProps } from '../../../types';
import { brand } from '../config/brand';
import { text, ui } from '../content';
import { useLatteHost } from '../host';
import { VisitSection } from './VisitSection';
import '../tokens.css';
import '../theme.css';
export function Shell({ basePath, locale = 'zh', children, visit = true }: SiteTemplatePageProps & { children: ReactNode; visit?: boolean }) {
  const host = useLatteHost(), pathname = usePathname() ?? basePath, router = useRouter();
  const [open, setOpen] = useState(false);
  const name = host.brandName?.[locale] ?? brand.name[locale], logo = host.logo ?? brand.logo;
  const root = locale === 'en' ? basePath.slice(0, -3) : basePath;
  const languagePath = `${locale === 'en' ? root : root + '/en'}${pathname.slice(basePath.length)}` || '/';
  useEffect(() => { if (!open) return; const escape = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); }; document.addEventListener('keydown', escape); return () => document.removeEventListener('keydown', escape); }, [open]);
  return <MotionConfig reducedMotion="user"><div className="latte-site" data-locale={locale}>
    <a className="latte-skip" href="#latte-main">{locale === 'zh' ? '跳到正文' : 'Skip to content'}</a>
    <header className="latte-header"><Link href={basePath || '/'} className={`latte-brand ${host.logo ? 'is-host' : ''}`} aria-label={name}><img src={logo} alt={host.logo ? '' : name}/>{host.logo && <span>{name}</span>}</Link>
      <nav id="latte-navigation" className={open ? 'latte-nav is-open' : 'latte-nav'} aria-label={locale === 'zh' ? '主导航' : 'Main navigation'}>
        <Link href={`${basePath}/#menu`} onClick={() => setOpen(false)}>{text(ui.menu, locale)}</Link><Link href={`${basePath}/news`} onClick={() => setOpen(false)}>{text(ui.news, locale)}</Link><Link href={`${basePath}/contact`} onClick={() => setOpen(false)}>{text(ui.contact, locale)}</Link>
      </nav>
      <div className="latte-actions"><Link className="latte-language" href={languagePath} aria-label={locale === 'zh' ? '切换为英文' : 'Switch to Chinese'} onClick={e => { if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return; e.preventDefault(); router.push(languagePath + location.search + location.hash); setOpen(false); }}>{locale === 'zh' ? 'EN' : '中文'}</Link><button type="button" className="latte-menu-toggle" aria-controls="latte-navigation" aria-expanded={open} aria-label={locale === 'zh' ? '切换导航菜单' : 'Toggle navigation menu'} onClick={() => setOpen(!open)}>{open ? '✕' : '☰'}</button></div>
    </header>
    <main id="latte-main">{children}</main>
    {visit && <VisitSection basePath={basePath} locale={locale}/>}
    <footer className="latte-footer"><div className="latte-container"><div className="latte-footer-top"><Link className="latte-brand" href={basePath || '/'}><img src={logo} alt=""/><span>{name}</span></Link><h2>{text(ui.footer, locale)}</h2></div><div className="latte-footer-grid"><div><h3>{text(ui.hours, locale)}</h3><p>{text(ui.hoursWeek, locale)}<br/>{text(ui.hoursWeekend, locale)}<br/>{text(ui.hoursSunday, locale)}</p></div><div><h3>{text(ui.phone, locale)}</h3><p>{brand.phone}</p><small>{locale === 'zh' ? '示例电话' : 'Sample phone'}</small></div><div><h3>{text(ui.location, locale)}</h3><p>{name}<br/>{brand.address[locale]}</p></div></div><div className="latte-footer-bottom"><span>© {brand.year} {name}</span><Link href={`${basePath}/privacy-policy`}>{locale === 'zh' ? '隐私政策' : 'Privacy policy'}</Link><Link href={`${basePath}/cookies`}>{locale === 'zh' ? 'Cookie 说明' : 'Cookies'}</Link><Link href={`${basePath}/terms-and-conditions`}>{locale === 'zh' ? '使用条款' : 'Terms & conditions'}</Link>{host.marketplaceHref && <Link href={host.marketplaceHref}>{host.marketplaceLabel?.[locale] ?? name}</Link>}{host.filing}</div></div></footer>
    {host.marketplaceHref && <Link className="latte-marketplace" href={host.marketplaceHref} aria-label={host.marketplaceAriaLabel?.[locale] ?? name}><img src={host.lightLogo ?? logo} alt=""/><span>{name}</span></Link>}
  </div></MotionConfig>;
}
export function Reveal({ children, className = '' }: { children: ReactNode; className?: string }) { return <motion.div className={className} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: .05 }} transition={{ duration: .5 }}>{children}</motion.div>; }
