# 权利边界

实现源码为本次任务编写，未另行授予公开分发许可。参考站 Furnexa 的图像、英文正文、人物肖像与商标仍归原权利人；本地读取不代表许可。其再分发授权未确认，模板维持 listed=false / redistributionAllowed=false。

Poppins 使用 OFL，许可见 public/templates/furnexa/fonts/Poppins-OFL.txt。MiSans 来源与条款见 fonts/misans/LICENSE-SOURCE.md。字体许可独立于参考图片。

运行素材来源逐项见 ASSET-SOURCES.json，包含 SHA256；摘要只证明一致性，不证明权利。公开使用前核实相关许可。
