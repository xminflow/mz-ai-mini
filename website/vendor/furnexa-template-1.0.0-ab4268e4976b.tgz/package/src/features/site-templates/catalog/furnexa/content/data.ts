import catalog from './catalog.json'
export type Locale = 'zh' | 'en'
export type Bilingual = Record<Locale, string>
export const { products, articles, categories, hero } = catalog
export type Product = typeof products[number]
export type Article = typeof articles[number]
export const categoryLabels: Record<string, Bilingual> = {
  Armchairs: { zh: '扶手椅', en: 'Armchairs' }, 'Bedroom Furniture Sets': { zh: '卧室套装', en: 'Bedroom Furniture Sets' },
  Tables: { zh: '桌几', en: 'Tables' }, Clipboards: { zh: '储物柜', en: 'Cupboards' }, 'Laptop Stands': { zh: '支架与置物架', en: 'Stands & shelves' },
  'Rocking Chairs': { zh: '摇椅', en: 'Rocking Chairs' }, Rugs: { zh: '地毯', en: 'Rugs' },
}
export const topicLabels: Record<string, Bilingual> = { 'Furniture Guides': {zh:'家具指南',en:'Furniture Guides'}, 'Office Design':{zh:'办公设计',en:'Office Design'},'Living Spaces':{zh:'生活空间',en:'Living Spaces'} }
export const colors = [ {id:'beige',hex:'#cfc4b3',name:{zh:'自然米色',en:'Neutral Beige'}}, {id:'sage',hex:'#9fa897',name:{zh:'鼠尾草绿',en:'Soft Sage Green'}}, {id:'pink',hex:'#d4b5af',name:{zh:'柔雾粉色',en:'Blush Pink'}} ]
export const benefits: Bilingual[] = [{zh:'恒久的现代设计',en:'Timeless modern design'},{zh:'舒适的每一天',en:'Exceptional everyday comfort'},{zh:'细致的手作工艺',en:'Premium handcrafted quality'},{zh:'用心的材质选择',en:'Thoughtful material choices'}]
export const reviews = [
 {name:'Emily K.',image:'gdIpPnoNeLlRcXnNClLNRPgaM.jpg',text:{zh:'工作区终于变得整洁又有灵感。桌椅稳固、优雅，长时间使用也很舒适。',en:'Our workspace finally feels organized and inspiring. The desk and chair set are sturdy, elegant, and incredibly comfortable for long hours.'}},
 {name:'Daniel R.',image:'0lSifXWECafBhhk5HGPHlNBmyn8.jpg',text:{zh:'家具的设计、触感和舒适度都很出色，客厅变得更精致，也更让人想要停留。',en:'Beautifully designed furniture that feels premium and comfortable. Our living room looks refined and welcoming now.'}},
 {name:'Sophia M.',image:'W1j20H0E8XacKvhqCcv267uj0.jpg',text:{zh:'从细节到整体都考虑得很周到，给居家办公带来了轻松而自然的变化。',en:'Thoughtful design, great comfort, and smooth delivery made the entire experience feel effortless.'}},
 {name:'Alex T.',image:'5WuceO7Q9d9H6u5bcUOpOx9Zk.jpg',text:{zh:'温暖、简洁又耐看。无需在品质和实用性之间妥协，就能打造理想的家。',en:'Stylish, comfortable, and timeless furniture helped us create a warm, modern home.'}},
]
export const faqGroups = [
 {name:{zh:'选购与演示',en:'Ordering & demo'},items:[
  {q:{zh:'如何挑选并加入购物车？',en:'How do I add furniture to my cart?'},a:{zh:'浏览商品，选择颜色和数量，然后点击加入购物车。购物车仅在当前浏览会话中演示，不创建真实订单。',en:'Browse a product, choose a color and quantity, then add it to your cart. The cart is a session-only demonstration and creates no order.'}},
  {q:{zh:'支持哪些付款方式？',en:'Which payment methods are accepted?'},a:{zh:'本模板不接入真实支付，不收集银行卡信息，也不会扣款。结算只做本地信息校验。',en:'This template has no payment integration, collects no card details, and charges nothing. Checkout only validates fields locally.'}},
  {q:{zh:'可以修改数量或移除商品吗？',en:'Can I change or remove items?'},a:{zh:'可以。在购物车中调整数量，或移除不需要的商品。演示库存为每款 10 件。',en:'Yes. Adjust quantities or remove items in the cart. Demo stock is ten units per product.'}},
  {q:{zh:'会员和订阅会保存信息吗？',en:'Does membership or subscribing save my details?'},a:{zh:'不会。联系和订阅表单只在当前页面进行校验，信息不会发送或保存。',en:'No. Contact and newsletter forms validate on this page only. No information is sent or saved.'}},
 ]},
 {name:{zh:'配送与交付',en:'Shipping & delivery'},items:[
  {q:{zh:'配送需要多长时间？',en:'How long does delivery take?'},a:{zh:'参考配送方案为标准配送 7–10 个工作日、加急配送 3–5 个工作日。本模板仅展示方案，不提供实际物流服务。',en:'Illustrative delivery is 7–10 business days for standard service or 3–5 for express. This demo provides no actual shipping.'}},
  {q:{zh:'如何准备家具配送？',en:'How should I prepare for delivery?'},a:{zh:'提前测量门洞、电梯与通道，清理摆放区域。实际配送范围、费用与安装服务需由经营方确认。',en:'Measure doors, lifts, and access routes, and clear the placement area. The operating store must confirm coverage, fees, and assembly.'}},
 ]},
 {name:{zh:'退换与售后',en:'Returns & exchanges'},items:[
  {q:{zh:'收到损坏商品怎么办？',en:'What if an item arrives damaged?'},a:{zh:'实际交易中应保留包装和损坏照片，及时联系经营方。本演示不会创建售后申请。',en:'For a real purchase, keep packaging and photographs and contact the store promptly. This demo opens no support claim.'}},
  {q:{zh:'定制商品可以退换吗？',en:'Can made-to-order furniture be returned?'},a:{zh:'定制商品应在购买前确认尺寸、颜色和经营方的退换规则；演示政策不是实际交易承诺。',en:'Confirm dimensions, color, and the store’s return terms before ordering custom pieces. Demonstration policies are not a commercial promise.'}},
 ]},
 {name:{zh:'产品护理',en:'Product care'},items:[
  {q:{zh:'如何清洁木质家具？',en:'How do I care for wooden furniture?'},a:{zh:'使用柔软的微湿布轻拭，再用干布擦干。避免阳光直晒、积水和强效清洁剂。',en:'Wipe with a soft, slightly damp cloth and dry afterwards. Avoid direct sunlight, standing water, and harsh cleaners.'}},
  {q:{zh:'如何保持布艺座椅的状态？',en:'How do I maintain upholstered seating?'},a:{zh:'定期轻柔吸尘，及时用干净软布吸去泼洒液体。使用清洁产品前先在隐蔽处试用。',en:'Vacuum gently, blot spills promptly, and test cleaning products on a hidden area first.'}},
 ]},
]
export const image = (name:string) => '/templates/furnexa/images/'+name
export const money = (amount:number, locale:Locale) => new Intl.NumberFormat(locale==='zh'?'zh-CN':'en-US',{style:'currency',currency:'USD',maximumFractionDigits:0}).format(amount)
