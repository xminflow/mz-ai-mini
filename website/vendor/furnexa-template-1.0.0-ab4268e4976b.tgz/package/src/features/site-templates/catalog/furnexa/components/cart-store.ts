'use client'
import {useSyncExternalStore} from 'react'
import {products} from '../content/data'
export interface CartLine {slug:string;color:string;quantity:number}
let lines: readonly CartLine[] = []
const empty: readonly CartLine[] = []
const listeners = new Set<()=>void>()
function publish(next:readonly CartLine[]){lines=next;for(const listener of listeners)listener()}
function subscribe(listener:()=>void){listeners.add(listener);return ()=>{listeners.delete(listener)}}
export function useCart(){return useSyncExternalStore(subscribe,()=>lines,()=>empty)}
/** 库存按同商品全部颜色合计校验；演示状态仅保存在内存，不产生订单。 */
export function addToCart(slug:string,color:string,quantity:number):boolean {
 const product=products.find(p=>p.slug===slug)
 if(!product||!Number.isInteger(quantity)||quantity<1||lines.filter(x=>x.slug===slug).reduce((n,x)=>n+x.quantity,0)+quantity>product.stock)return false
 const found=lines.find(x=>x.slug===slug&&x.color===color)
 publish(found?lines.map(x=>x===found?{...x,quantity:x.quantity+quantity}:x):[...lines,{slug,color,quantity}]);return true
}
export function updateCart(slug:string,color:string,quantity:number):boolean {
 const product=products.find(p=>p.slug===slug)
 if(!product||!Number.isInteger(quantity)||quantity<0||lines.filter(x=>x.slug===slug&&x.color!==color).reduce((n,x)=>n+x.quantity,0)+quantity>product.stock)return false
 publish(quantity===0?lines.filter(x=>!(x.slug===slug&&x.color===color)):lines.map(x=>x.slug===slug&&x.color===color?{...x,quantity}:x));return true
}
