import type {SiteTemplatePageProps} from '../../../types'
import {products} from '../content/data'
import {ProductView} from './ProductPage'
export default function Page(props:SiteTemplatePageProps){return <ProductView {...props} product={products[8]}/>}