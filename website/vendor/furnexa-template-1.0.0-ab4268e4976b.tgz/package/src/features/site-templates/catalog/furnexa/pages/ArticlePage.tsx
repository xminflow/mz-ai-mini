'use client'
import Link from 'next/link'
import {useFurnexaHost} from '../host'
import {brand} from '../config/brand'
import type {SiteTemplatePageProps} from '../../../types'
import {type Article,articles,topicLabels} from '../content/data'
import {Shell} from '../components/Shell'
import {Picture,ArticleCard} from '../components/ui'
export function ArticleView({locale='zh',basePath,article}:SiteTemplatePageProps&{article:Article}){const zh=locale==='zh',host=useFurnexaHost(),name=host.brandName?.[locale]??brand.name[locale];return <Shell locale={locale} basePath={basePath}><article><header className="fx-article-header"><Link className="fx-eyebrow" href={`${basePath}/blog`}>{topicLabels[article.category][locale]} / {zh?'2025 年 11 月':'NOVEMBER 2025'}</Link><h1>{article.name[locale]}</h1><p>{zh?'作者：':'Author: '}{name}{zh?' 编辑团队':' Editorial Team'}</p></header><Picture className="fx-article-cover" src={article.image} alt={article.name[locale]} eager/><div className="fx-prose"><p className="fx-lead">{article.intro[locale]}</p>{article.sections.slice(1,zh?7:undefined).filter(section=>section[locale]).map((section,i)=><section key={i}>{i%3===0&&<h2>{zh?['从真实生活出发','让材质彼此呼应','给日常留出余地'][Math.floor(i/3)%3]:['Design with intention','Balance form and function','Thoughtful details'][Math.floor(i/3)%3]}</h2>}<p>{section[locale]}</p></section>)}<Link className="fx-text-link" href={`${basePath}/blog`}>← {zh?'返回灵感期刊':'Back to articles'}</Link></div></article><section className="fx-section"><h2>{zh?'继续阅读':'More inspiration'}</h2><div className="fx-article-grid">{articles.filter(a=>a.slug!==article.slug).slice(0,3).map(a=><ArticleCard key={a.slug} article={a} locale={locale} basePath={basePath}/>)}</div></section></Shell>}
