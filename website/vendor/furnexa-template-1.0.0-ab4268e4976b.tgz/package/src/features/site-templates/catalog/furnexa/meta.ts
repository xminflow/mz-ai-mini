import type {SiteTemplate} from '../../types'
export const furnexaTemplate:SiteTemplate={...{
  "id": "furnexa",
  "name": "Furnexa · 现代家居",
  "localizedNames": {
    "en": "Furnexa · Modern furniture"
  },
  "sceneId": "online-store",
  "listed": false,
  "tags": [
    "家具商城",
    "暖灰极简",
    "中英文",
    "PC / iPad / H5"
  ],
  "summary": "现代家具整站模板：全屏轮播、五类空间集合、十四件商品、筛选搜索、演示购物车、八篇灵感期刊与本地联系表单。",
  "accentColor": "#555b45",
  "cover": "/templates/furnexa/screenshots/desktop-home.webp",
  "screenshots": [
    {
      "src": "/templates/furnexa/screenshots/desktop-home.webp",
      "alt": "Furnexa desktop home",
      "device": "desktop",
      "width": 1440,
      "height": 1000
    },
    {
      "src": "/templates/furnexa/screenshots/desktop-shop.webp",
      "alt": "Furnexa desktop shop",
      "device": "desktop",
      "width": 1440,
      "height": 1000
    },
    {
      "src": "/templates/furnexa/screenshots/desktop-blog.webp",
      "alt": "Furnexa desktop blog",
      "device": "desktop",
      "width": 1440,
      "height": 1000
    },
    {
      "src": "/templates/furnexa/screenshots/desktop-contact.webp",
      "alt": "Furnexa desktop contact",
      "device": "desktop",
      "width": 1440,
      "height": 1000
    },
    {
      "src": "/templates/furnexa/screenshots/tablet-home.webp",
      "alt": "Furnexa tablet home",
      "device": "tablet",
      "width": 834,
      "height": 1180
    },
    {
      "src": "/templates/furnexa/screenshots/tablet-shop.webp",
      "alt": "Furnexa tablet shop",
      "device": "tablet",
      "width": 834,
      "height": 1180
    },
    {
      "src": "/templates/furnexa/screenshots/tablet-blog.webp",
      "alt": "Furnexa tablet blog",
      "device": "tablet",
      "width": 834,
      "height": 1180
    },
    {
      "src": "/templates/furnexa/screenshots/tablet-contact.webp",
      "alt": "Furnexa tablet contact",
      "device": "tablet",
      "width": 834,
      "height": 1180
    },
    {
      "src": "/templates/furnexa/screenshots/mobile-home.webp",
      "alt": "Furnexa mobile home",
      "device": "mobile",
      "width": 390,
      "height": 844
    },
    {
      "src": "/templates/furnexa/screenshots/mobile-shop.webp",
      "alt": "Furnexa mobile shop",
      "device": "mobile",
      "width": 390,
      "height": 844
    },
    {
      "src": "/templates/furnexa/screenshots/mobile-blog.webp",
      "alt": "Furnexa mobile blog",
      "device": "mobile",
      "width": 390,
      "height": 844
    },
    {
      "src": "/templates/furnexa/screenshots/mobile-contact.webp",
      "alt": "Furnexa mobile contact",
      "device": "mobile",
      "width": 390,
      "height": 844
    }
  ]
},surfaces:[{id:'site',name:'家居商城',platform:'pc',locales:['zh','en'],pages:[
{slug:"",title:"首页",localizedTitles:{en:"Home"},load:()=>import('./pages/HomePage')},
{slug:"shop",title:"商店",localizedTitles:{en:"Shop"},load:()=>import('./pages/ShopPage')},
{slug:"about-us",title:"关于我们",localizedTitles:{en:"About"},load:()=>import('./pages/AboutPage')},
{slug:"blog",title:"灵感期刊",localizedTitles:{en:"Articles"},load:()=>import('./pages/BlogPage')},
{slug:"contact-us",title:"联系我们",localizedTitles:{en:"Contact"},load:()=>import('./pages/ContactPage')},
{slug:"faq",title:"常见问题",localizedTitles:{en:"FAQ"},load:()=>import('./pages/FaqPage')},
{slug:"shop/living",title:"客厅",localizedTitles:{en:"Living Room"},load:()=>import('./pages/CollectionLivingPage')},
{slug:"shop/dining",title:"餐厅",localizedTitles:{en:"Dining"},load:()=>import('./pages/CollectionDiningPage')},
{slug:"shop/office",title:"办公",localizedTitles:{en:"Office"},load:()=>import('./pages/CollectionOfficePage')},
{slug:"shop/bedroom",title:"卧室",localizedTitles:{en:"Bedroom"},load:()=>import('./pages/CollectionBedroomPage')},
{slug:"shop/lamps",title:"灯具",localizedTitles:{en:"Lamps"},load:()=>import('./pages/CollectionLampsPage')},
{slug:"shop/modern-armchair",title:"现代休闲椅",localizedTitles:{en:"Modern armchair"},load:()=>import('./pages/Product0Page')},
{slug:"shop/king-size-bed",title:"宽境双人床",localizedTitles:{en:"King size bed"},load:()=>import('./pages/Product1Page')},
{slug:"shop/cozy-table",title:"闲适茶几",localizedTitles:{en:"Cozy table"},load:()=>import('./pages/Product2Page')},
{slug:"shop/cupboard",title:"藤编边柜",localizedTitles:{en:"Cupboard"},load:()=>import('./pages/Product3Page')},
{slug:"shop/hanger",title:"简约衣架",localizedTitles:{en:"Hanger"},load:()=>import('./pages/Product4Page')},
{slug:"shop/luna-nightstand",title:"Luna 床头柜",localizedTitles:{en:"Luna Nightstand"},load:()=>import('./pages/Product5Page')},
{slug:"shop/rocking-chair",title:"弧线摇椅",localizedTitles:{en:"Rocking Chair"},load:()=>import('./pages/Product6Page')},
{slug:"shop/rugs",title:"肌理地毯",localizedTitles:{en:"Rugs"},load:()=>import('./pages/Product7Page')},
{slug:"shop/shelf",title:"木作置物架",localizedTitles:{en:"Shelf"},load:()=>import('./pages/Product8Page')},
{slug:"shop/luxe-sofa",title:"Luxe 柔软沙发",localizedTitles:{en:"Luxe Sofa"},load:()=>import('./pages/Product9Page')},
{slug:"shop/ivory-curve",title:"Ivory 曲线椅",localizedTitles:{en:"Ivory Curve"},load:()=>import('./pages/Product10Page')},
{slug:"shop/minimalist-armchair",title:"极简扶手椅",localizedTitles:{en:"Minimalist Armchair"},load:()=>import('./pages/Product11Page')},
{slug:"shop/terra-chair",title:"Terra 餐椅",localizedTitles:{en:"Terra Chair"},load:()=>import('./pages/Product12Page')},
{slug:"shop/dining-chair",title:"经典餐椅",localizedTitles:{en:"Dining Chair"},load:()=>import('./pages/Product13Page')},
{slug:"blog/design-styling-tips",title:"让空间更有层次的搭配技巧",localizedTitles:{en:"Design styling tips"},load:()=>import('./pages/Article0Page')},
{slug:"blog/office-setup-ideas",title:"居家办公空间布置灵感",localizedTitles:{en:"Office setup ideas"},load:()=>import('./pages/Article1Page')},
{slug:"blog/home-decor-inspiration",title:"把家的温度藏进细节",localizedTitles:{en:"Home décor inspiration"},load:()=>import('./pages/Article2Page')},
{slug:"blog/modern-living-essentials",title:"现代生活的家具清单",localizedTitles:{en:"Modern living essentials"},load:()=>import('./pages/Article3Page')},
{slug:"blog/workday-workspace-upgrade",title:"为工作日升级一方天地",localizedTitles:{en:"Workday workspace upgrade"},load:()=>import('./pages/Article4Page')},
{slug:"blog/dining-mood-table-design",title:"餐桌之上的相聚时光",localizedTitles:{en:"Dining mood table design"},load:()=>import('./pages/Article5Page')},
{slug:"blog/comfort-driven-design",title:"以舒适为起点的设计",localizedTitles:{en:"Comfort driven design"},load:()=>import('./pages/Article6Page')},
{slug:"blog/thoughtful-furniture-choices",title:"更有意识地选择家具",localizedTitles:{en:"Thoughtful furniture choices"},load:()=>import('./pages/Article7Page')},
{slug:"legal/shipping",title:"配送信息",localizedTitles:{en:"Shipping"},load:()=>import('./pages/LegalshippingPage')},
{slug:"legal/refund-policy",title:"退换政策",localizedTitles:{en:"Returns"},load:()=>import('./pages/LegalrefundpolicyPage')},
{slug:"legal/privacy-policy",title:"隐私政策",localizedTitles:{en:"Privacy"},load:()=>import('./pages/LegalprivacypolicyPage')},
{slug:"legal/terms",title:"使用条款",localizedTitles:{en:"Terms"},load:()=>import('./pages/LegaltermsPage')}
]}]}
