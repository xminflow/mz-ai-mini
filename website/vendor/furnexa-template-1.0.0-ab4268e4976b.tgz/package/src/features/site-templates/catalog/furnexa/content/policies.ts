import type {Bilingual} from './data'
interface Policy {title:Bilingual;sections:{title:Bilingual;body:Bilingual}[]}
export const policies:Record<string,Policy>={
 shipping:{title:{zh:'配送信息',en:'Shipping information'},sections:[
 {title:{zh:'1. 标准配送',en:'1. Standard delivery'},body:{zh:'参考方案为 7–10 个工作日。此模板不接入物流服务，也不会生成发货通知；实际时效与费用需由经营方在上线前确认。',en:'The illustrative standard delivery window is 7–10 business days. This template has no logistics integration and sends no dispatch notices. The operating store must confirm times and fees before launch.'}},
 {title:{zh:'2. 加急与国际配送',en:'2. Express and international shipping'},body:{zh:'加急方案参考 3–5 个工作日。国际配送涉及区域限制、关税与清关要求，具体方案不能由演示页面保证。',en:'Illustrative express delivery is 3–5 business days. International orders may involve regional restrictions, customs charges, and clearance requirements; this demo guarantees none of these services.'}},
 {title:{zh:'3. 物流追踪',en:'3. Track your order'},body:{zh:'真实商店应在发货后提供有效物流编号。当前演示不产生订单，因此也没有可追踪的物流状态。',en:'A real store should provide a valid tracking reference after dispatch. This demo creates no orders and therefore has no shipment to track.'}},
 {title:{zh:'4. 配送前准备',en:'4. Preparing for delivery'},body:{zh:'请测量门洞、电梯和楼梯，保持通道畅通，并提前与经营方确认搬运和安装需求。',en:'Measure doorways, lifts, and stairs, keep access routes clear, and agree on carrying and assembly requirements with the store beforehand.'}},
 {title:{zh:'5. 损坏与异常',en:'5. Damage and delivery issues'},body:{zh:'实际收货时请检查包装与产品。发现损坏应拍照并保留凭证，联系实际卖方处理。演示联系表单不会提交售后申请。',en:'Inspect packaging and furniture on receipt. Photograph damage, retain evidence, and contact the actual seller. The demonstration contact form submits no support claim.'}},
 ]},
 'refund-policy':{title:{zh:'退换与退款政策',en:'Return & refund policy'},sections:[
 {title:{zh:'1. 演示政策范围',en:'1. Scope of this demonstration'},body:{zh:'本页面展示退换政策应包含的信息，不构成实际销售承诺。模板不接受付款，因此也不能发起退款。',en:'This page illustrates the information a returns policy should contain. It is not a sales promise. The template takes no payments and cannot issue refunds.'}},
 {title:{zh:'2. 退换条件',en:'2. Return eligibility'},body:{zh:'真实业务应明确退换期限、包装与使用状态要求，以及定制产品的例外。消费者依法享有的权利不因演示文案而改变。',en:'A real store must define return windows, packaging and condition requirements, and exceptions for custom furniture. Demonstration text does not alter statutory consumer rights.'}},
 {title:{zh:'3. 申请与检查',en:'3. Requests and inspection'},body:{zh:'实际申请应提供订单、照片和问题说明。经营方确认收货方式并检查产品后，再决定退款或换货。不要向本演示提交真实订单或个人资料。',en:'A real request should include the order reference, photographs, and a description of the issue. The store should agree a return method and inspect the item before refunding or replacing it. Do not submit real order or personal information to this demo.'}},
 {title:{zh:'4. 退款与运费',en:'4. Refunds and transport costs'},body:{zh:'退款渠道、时间与退货运费应在真实交易前清晰披露。演示页面不显示或处理支付信息。',en:'Refund methods, processing times, and return transport costs must be disclosed before a real transaction. This demo neither displays nor processes payment details.'}},
 ]},
 'privacy-policy':{title:{zh:'隐私政策',en:'Privacy policy'},sections:[
 {title:{zh:'1. 本地演示行为',en:'1. Local demonstration behavior'},body:{zh:'联系、订阅与结算表单只使用浏览器原生校验和页面状态，不向业务 API 发送表单内容，也不保存这些内容。请使用虚构资料测试。',en:'Contact, newsletter, and checkout forms use browser validation and page state only. They send no form data to a business API and save none of it. Use fictional details for testing.'}},
 {title:{zh:'2. 购物车状态',en:'2. Cart state'},body:{zh:'购物车仅保存在当前浏览会话的内存中；刷新页面后清空。不使用 Cookie 或本地存储跟踪购物行为。',en:'The cart exists only in memory during this browsing session and clears on refresh. It uses no cookies or local storage to track shopping behavior.'}},
 {title:{zh:'3. 素材与服务器日志',en:'3. Assets and server logs'},body:{zh:'家具图片与字体由本站本地路径提供。部署平台可能记录基本访问日志，其实际规则由平台和经营方决定；本模板不内置广告或分析追踪。',en:'Furniture images and fonts are served from local site paths. Hosting infrastructure may record basic access logs under its own policies. This template includes no advertising or analytics tracker.'}},
 {title:{zh:'4. 实际上线前的责任',en:'4. Before commercial operation'},body:{zh:'接入后台、支付、邮件、分析服务或账户后，应重新制定数据收集、保存期限、访问权与删除流程，并提供实际运营方的联系方式。',en:'Before adding accounts, payments, email, analytics, or a backend, define data collection, retention, access, and deletion procedures and provide the actual operator’s contact details.'}},
 ]},
 terms:{title:{zh:'使用条款',en:'Terms & conditions'},sections:[
 {title:{zh:'1. 模板用途',en:'1. Template purpose'},body:{zh:'本网站为家具商城交互演示。商品、库存、优惠、团队和评价属于展示数据，不形成交易合同。',en:'This website is an interactive furniture store demonstration. Products, stock, offers, team profiles, and reviews are sample data and form no sales contract.'}},
 {title:{zh:'2. 价格与下单',en:'2. Prices and ordering'},body:{zh:'价格以美元展示。购物车与结算按钮仅演示流程，不扣款、不创建订单、不安排配送。',en:'Prices are displayed in USD. Cart and checkout controls demonstrate a flow only: they charge nothing, create no order, and arrange no delivery.'}},
 {title:{zh:'3. 内容与素材权利',en:'3. Content and asset rights'},body:{zh:'参考站图片、商标与英文内容的权利仍归原权利人。模板可用性不等于取得素材再分发许可，公开使用前需核实授权。',en:'Reference images, marks, and English content remain the property of their respective rights holders. Technical availability grants no redistribution license; verify permissions before public use.'}},
 {title:{zh:'4. 真实运营',en:'4. Commercial operation'},body:{zh:'真实运营需补充有效的商家身份、交易条款、售后政策与数据处理说明，并验证支付、库存、物流和异常处理。',en:'Commercial operation requires a valid merchant identity, transaction terms, support policies, and data handling notices, together with verified payment, inventory, logistics, and error handling.'}},
 ]},
}
