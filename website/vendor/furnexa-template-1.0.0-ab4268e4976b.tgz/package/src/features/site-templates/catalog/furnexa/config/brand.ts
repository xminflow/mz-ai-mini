export const brand = {
  name: { zh: 'Furnexa', en: 'Furnexa' },
  year: 2026,
  email: 'hello@furnexa.example',
  phone: '+1 (800) 452-8392',
  address: { zh: '加利福尼亚 · 设计街区展示空间（演示）', en: 'California · Design district showroom (demo)' },
  tagline: { zh: '让生活空间更有温度', en: 'Thoughtful furniture for everyday living' },
}
