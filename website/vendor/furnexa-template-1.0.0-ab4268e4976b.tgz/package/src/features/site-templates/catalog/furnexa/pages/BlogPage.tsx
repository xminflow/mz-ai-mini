'use client'
import {useState} from 'react'
import type {SiteTemplatePageProps} from '../../../types'
import {articles,topicLabels} from '../content/data'
import {Shell} from '../components/Shell'
import {PageTitle,ArticleCard} from '../components/ui'
export default function BlogPage({locale='zh',basePath}:SiteTemplatePageProps){const [topic,setTopic]=useState(''),zh=locale==='zh',items=articles.filter(a=>!topic||a.category===topic);return <Shell locale={locale} basePath={basePath}><PageTitle locale={locale} title={zh?'灵感期刊':'Articles'} subtitle={zh?'探索家具、空间与设计背后的故事':'Explore inspiring stories on furniture, interiors, and design'}/><section className="fx-section"><div className="fx-tabs" aria-label={zh?'文章分类':'Article topics'}><button aria-pressed={topic===''} onClick={()=>setTopic('')}>{zh?'全部':'All'}</button>{Object.entries(topicLabels).map(([id,label])=><button key={id} aria-pressed={topic===id} onClick={()=>setTopic(id)}>{label[locale]}</button>)}</div><p className="fx-note" role="status">{items.length} {zh?'篇文章':'articles'}</p><div className="fx-article-grid">{items.map(a=><ArticleCard key={a.slug} article={a} locale={locale} basePath={basePath}/>)}</div></section></Shell>}
