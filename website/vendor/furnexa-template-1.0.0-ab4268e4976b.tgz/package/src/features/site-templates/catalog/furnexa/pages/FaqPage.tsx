import Link from 'next/link'
import type {SiteTemplatePageProps} from '../../../types'
import {Shell} from '../components/Shell'
import {PageTitle} from '../components/ui'
import {Faq} from '../components/Sections'
export default function FaqPage({locale='zh',basePath}:SiteTemplatePageProps){const zh=locale==='zh';return <Shell locale={locale} basePath={basePath}><PageTitle locale={locale} title={zh?'常见问题':'Frequently Asked Questions'} subtitle={zh?'关于选购、配送、退换与护理的常见解答':'Find answers to common questions about furniture, orders, delivery, and care.'}/><section className="fx-section fx-faq"><Faq locale={locale}/><div className="fx-question-cta"><h2>{zh?'还有其他问题？':'Still have questions?'}</h2><p>{zh?'从你的生活习惯与空间需求开始聊起':'Our team is here to help with furniture choices and styling ideas.'}</p><Link className="fx-button" href={`${basePath}/contact-us`}>{zh?'联系我们':'Contact us'} ↗</Link></div></section></Shell>}
