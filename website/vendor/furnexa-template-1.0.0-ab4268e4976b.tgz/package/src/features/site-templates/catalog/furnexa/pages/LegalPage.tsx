import type {SiteTemplatePageProps} from '../../../types'
import {Shell} from '../components/Shell'
import {PageTitle} from '../components/ui'
import {policies} from '../content/policies'
export function LegalView({locale='zh',basePath,policyId}:SiteTemplatePageProps&{policyId:string}){const policy=policies[policyId];return <Shell locale={locale} basePath={basePath}><PageTitle locale={locale} title={policy.title[locale]} subtitle={locale==='zh'?'演示政策 · 更新于 2026 年 10 月 20 日':'Demonstration policy · Updated October 20, 2026'}/><article className="fx-prose">{policy.sections.map(section=><section key={section.title.en}><h2>{section.title[locale]}</h2><p>{section.body[locale]}</p></section>)}</article></Shell>}
