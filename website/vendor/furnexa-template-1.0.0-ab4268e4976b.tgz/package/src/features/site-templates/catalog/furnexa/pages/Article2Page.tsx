import type {SiteTemplatePageProps} from '../../../types'
import {articles} from '../content/data'
import {ArticleView} from './ArticlePage'
export default function Page(props:SiteTemplatePageProps){return <ArticleView {...props} article={articles[2]}/>}