import type {SiteTemplatePageProps} from '../../../types'
import {LegalView} from './LegalPage'
export default function Page(props:SiteTemplatePageProps){return <LegalView {...props} policyId="shipping"/>}