import type {SiteTemplatePageProps} from '../../../types'
import {ShopView} from './ShopPage'
export default function Page(props:SiteTemplatePageProps){return <ShopView {...props} collection="office"/>}
