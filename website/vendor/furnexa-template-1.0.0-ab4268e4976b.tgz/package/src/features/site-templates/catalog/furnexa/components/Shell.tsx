'use client'
import Link from 'next/link'
import {usePathname,useRouter} from 'next/navigation'
import {useRef,useState,useEffect,type ReactNode} from 'react'
import {brand} from '../config/brand'
import {useFurnexaHost} from '../host'
import {categories,products,colors,money,type Locale} from '../content/data'
import {useCart,updateCart} from './cart-store'
import {Picture,DemoForm,ProductGrid} from './ui'
import '../theme.css'
export function Shell({children,locale,basePath,home=false}:{children:ReactNode;locale:Locale;basePath:string;home?:boolean}){
 const zh=locale==='zh',host=useFurnexaHost(),name=host.brandName?.[locale]??brand.name[locale],path=usePathname(),router=useRouter()
 const [menu,setMenu]=useState(false),[query,setQuery]=useState(''),[checkout,setCheckout]=useState(false),[cartError,setCartError]=useState(false)
 const search=useRef<HTMLDialogElement>(null),cart=useRef<HTMLDialogElement>(null),lines=useCart()
 const count=lines.reduce((n,x)=>n+x.quantity,0),total=lines.reduce((n,x)=>n+(products.find(p=>p.slug===x.slug)?.price??0)*x.quantity,0)
 const nav=[['',zh?'首页':'Home'],['shop',zh?'商店':'Shop'],['about-us',zh?'关于':'About'],['blog',zh?'灵感期刊':'Blog'],['contact-us',zh?'联系':'Contact']]
 const root=locale==='en'?basePath.replace(/\/en$/,''):basePath
 const nextLocale=locale==='en'?'zh':'en',relative=path.slice(basePath.length),languageHref=`${root}${nextLocale==='en'?'/en':''}${relative}`||'/'
 useEffect(()=>{if(!menu)return;const key=(event:KeyboardEvent)=>{if(event.key==='Escape')setMenu(false)};document.addEventListener('keydown',key);return ()=>document.removeEventListener('keydown',key)},[menu])
 function openCart(){setCheckout(false);setCartError(false);cart.current?.showModal()}
 function change(slug:string,color:string,quantity:number){setCartError(!updateCart(slug,color,quantity))}
 return <div className={`furnexa ${home?'fx-is-home':''}`} lang={zh?'zh-CN':'en'}>
  <a href="#fx-main" className="fx-skip">{zh?'跳至内容':'Skip to content'}</a>
  <header className="fx-header"><Link className="fx-brand" href={basePath||'/'}>{host.logo?<Picture src={home?(host.lightLogo??host.logo):host.logo} alt=""/>:null}<span>{name}</span></Link><nav className="fx-desktop-nav" aria-label={zh?'主导航':'Main navigation'}>{nav.map(([slug,label])=><Link key={slug} aria-current={path===`${basePath}${slug?'/'+slug:''}`?'page':undefined} href={`${basePath}${slug?'/'+slug:''}`||'/'}>{label}</Link>)}</nav><div className="fx-header-actions">
   <Link href={languageHref} hrefLang={nextLocale==='zh'?'zh-CN':'en'} aria-label={zh?'切换为英文':'Switch to Chinese'} onClick={event=>{event.preventDefault();router.push(languageHref+window.location.search+window.location.hash)}}>{zh?'EN':'中文'}</Link>
   <button className="fx-icon" aria-label={zh?'搜索商品':'Search products'} onClick={()=>search.current?.showModal()}><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6"/><path d="m15 15 5 5"/></svg></button>
   <button className="fx-icon" aria-label={`${zh?'购物车':'Cart'} (${count})`} onClick={openCart}><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h16l-2 12H6L4 8ZM8 8l4-6 4 6M9 12v4m6-4v4"/></svg><sup>{count}</sup></button>
   <button className="fx-icon fx-menu-toggle" aria-expanded={menu} aria-controls="fx-menu" aria-label={menu?(zh?'关闭菜单':'Close menu'):(zh?'打开菜单':'Open menu')} onClick={()=>setMenu(!menu)}>{menu?'×':'☰'}</button>
  </div></header>
  {menu&&<nav id="fx-menu" className="fx-mobile-nav" aria-label={zh?'移动导航':'Mobile navigation'}>{nav.map(([slug,label])=><Link key={slug} href={`${basePath}${slug?'/'+slug:''}`||'/'} onClick={()=>setMenu(false)}>{label}<span>↗</span></Link>)}</nav>}
  <main id="fx-main">{children}</main>
  <footer className="fx-footer"><div className="fx-footer-top"><div><Link className="fx-footer-brand" href={basePath||'/'}>{name}</Link><p>{brand.tagline[locale]}</p><p>{zh?'为现代生活与灵感工作空间而设计的家具':'Premium furniture designed for modern living and inspired workspaces.'}</p><p>{brand.email}<br/>{brand.phone}<br/>{brand.address[locale]}</p></div><div><h2>{zh?'订阅灵感':'Newsletter'}</h2><DemoForm locale={locale} kind="newsletter"/></div></div>
   <div className="fx-footer-links"><div><h3>{zh?'探索':'Explore'}</h3>{nav.map(([slug,label])=><Link key={slug} href={`${basePath}${slug?'/'+slug:''}`||'/'}>{label}</Link>)}<Link href={`${basePath}/faq`}>FAQ</Link></div><div><h3>{zh?'家具集合':'Collections'}</h3>{categories.map(c=><Link key={c.slug} href={`${basePath}/shop/${c.slug}`}>{c.name[locale]}</Link>)}</div><div><h3>{zh?'支持':'Support'}</h3>{[['shipping',zh?'配送信息':'Shipping information'],['refund-policy',zh?'退换政策':'Returns & refunds'],['privacy-policy',zh?'隐私政策':'Privacy policy'],['terms',zh?'使用条款':'Terms & conditions']].map(([slug,label])=><Link key={slug} href={`${basePath}/legal/${slug}`}>{label}</Link>)}{host.marketplaceHref&&<Link href={host.marketplaceHref}>{host.marketplaceLabel?.[locale]}</Link>}</div></div>
   <div className="fx-footer-bottom"><span>© {brand.year} {name}. {zh?'保留所有权利 · 演示模板':'All rights reserved · Demonstration template'}</span>{host.filing}</div>
  </footer>
  {host.marketplaceHref&&<Link className="fx-marketplace" href={host.marketplaceHref} aria-label={host.marketplaceAriaLabel?.[locale]}>{host.lightLogo&&<Picture src={host.lightLogo} alt=""/>}<span>{name}</span></Link>}
  <dialog className="fx-dialog fx-search-dialog" ref={search}><div className="fx-dialog-top"><h2>{zh?'搜索商品':'Search products'}</h2><button className="fx-icon" aria-label={zh?'关闭搜索':'Close search'} onClick={()=>search.current?.close()}>×</button></div><label>{zh?'名称或关键词':'Name or keyword'}<input autoFocus value={query} onChange={event=>setQuery(event.target.value)} placeholder={zh?'试试「椅」':'Try “chair”'}/></label><p role="status">{products.filter(p=>(p.name[locale]+' '+p.description[locale]).toLowerCase().includes(query.toLowerCase())).length} {zh?'件商品':'products'}</p><div onClick={event=>{if((event.target as HTMLElement).closest('a'))search.current?.close()}}><ProductGrid items={products.filter(p=>(p.name[locale]+' '+p.description[locale]).toLowerCase().includes(query.toLowerCase()))} locale={locale} basePath={basePath}/></div></dialog>
  <dialog className="fx-dialog fx-cart-dialog" ref={cart}><div className="fx-dialog-top"><h2>{zh?'购物车':'Your cart'} ({count})</h2><button className="fx-icon" aria-label={zh?'关闭购物车':'Close cart'} onClick={()=>cart.current?.close()}>×</button></div><p className="fx-note">{zh?'演示购物车：不保存、不创建订单、不收款。':'Demo cart: nothing is saved, ordered, or charged.'}</p>
   {lines.length===0?<p>{zh?'购物车还是空的，去发现喜欢的家具吧。':'Your cart is empty. Discover something you love.'}</p>:<>{lines.map(line=>{const p=products.find(p=>p.slug===line.slug)!;return <div className="fx-cart-line" key={line.slug+line.color}><Picture src={p.images[0]} alt={p.name[locale]}/><div><h3>{p.name[locale]}</h3><p>{colors.find(c=>c.id===line.color)?.name[locale]} · {money(p.price,locale)}</p><div className="fx-quantity"><button aria-label={zh?'减少数量':'Decrease quantity'} onClick={()=>change(line.slug,line.color,line.quantity-1)}>−</button><output>{line.quantity}</output><button aria-label={zh?'增加数量':'Increase quantity'} onClick={()=>change(line.slug,line.color,line.quantity+1)}>+</button></div><button className="fx-text-button" onClick={()=>change(line.slug,line.color,0)}>{zh?'移除':'Remove'}</button></div></div>})}<p className="fx-total">{zh?'合计':'Subtotal'}<strong>{money(total,locale)}</strong></p>{cartError&&<p role="alert">{zh?'该商品演示库存不足（最多 10 件）。':'Demo stock limit reached (10 units per product).'}</p>}{checkout?<DemoForm kind="checkout" locale={locale}/>:<button className="fx-button" onClick={()=>setCheckout(true)}>{zh?'演示结算':'Demo checkout'} ↗</button>}</>}
  </dialog>
 </div>
}
