'use client'

import Link from 'next/link'
import {useFurnexaHost} from '../host'
import {brand} from '../config/brand'
import {motion,useReducedMotion} from 'framer-motion'
import {useState,type ReactNode,type FormEvent} from 'react'
import {products,topicLabels,money,type Product,type Article,type Locale} from '../content/data'
export function Reveal({children,className=''}:{children:ReactNode;className?:string}){const reduced=useReducedMotion();return <motion.div className={className} initial={reduced?false:{opacity:0,y:20}} whileInView={{opacity:1,y:0}} viewport={{once:true,amount:0.08}} transition={{duration:0.5}}>{children}</motion.div>}
export function Picture({src,alt,className='',eager=false}:{src:string;alt:string;className?:string;eager?:boolean}){return <img className={className} src={src} alt={alt} loading={eager?'eager':'lazy'} decoding="async"/>}
export function ProductCard({product,locale,basePath}:{product:Product;locale:Locale;basePath:string}){return <Link className="fx-product-card" href={`${basePath}/shop/${product.slug}`}><div className="fx-product-photo"><Picture src={product.images[0]} alt={product.name[locale]}/><span className="fx-card-arrow" aria-hidden="true">↗</span></div><div className="fx-card-meta"><h3>{product.name[locale]}</h3><span>{money(product.price,locale)}</span></div><div className="fx-swatches" aria-hidden="true"><i/><i/><i/></div></Link>}
export function ProductGrid({items=products,locale,basePath}:{items?:Product[];locale:Locale;basePath:string}){return <div className="fx-product-grid">{items.map(p=><ProductCard key={p.slug} product={p} locale={locale} basePath={basePath}/>)}</div>}
export function ArticleCard({article,locale,basePath}:{article:Article;locale:Locale;basePath:string}){return <Link href={`${basePath}/blog/${article.slug}`} className="fx-article-card"><Picture src={article.image} alt={article.name[locale]}/><span className="fx-eyebrow">{topicLabels[article.category][locale]}</span><h3>{article.name[locale]} <span aria-hidden="true">↗</span></h3></Link>}
export function PageTitle({title,subtitle,locale='zh'}:{title:string;subtitle?:string;locale?:Locale}){const host=useFurnexaHost();return <header className="fx-page-title"><span className="fx-eyebrow">{(host.brandName?.[locale]??brand.name[locale]).toUpperCase()} / COLLECTION</span><h1>{title}</h1>{subtitle&&<p>{subtitle}</p>}</header>}
export function Accordion({items}:{items:{title:string;body:ReactNode}[]}){return <div className="fx-accordion">{items.map((item,i)=><details key={item.title} open={i===0}><summary>{item.title}<span aria-hidden="true">+</span></summary><div>{item.body}</div></details>)}</div>}
export function DemoForm({locale,kind='contact'}:{locale:Locale;kind?:'contact'|'newsletter'|'checkout'}){
 const [done,setDone]=useState(false),zh=locale==='zh'
 function submit(event:FormEvent<HTMLFormElement>){event.preventDefault();setDone(true);console.debug('[furnexa:form]',{kind,status:'validated-locally',sent:false,saved:false})}
 return <form className={`fx-form fx-form-${kind}`} onSubmit={submit} onChange={()=>setDone(false)}>
  <p className="fx-note">{zh?'演示表单：仅本地校验，不发送或保存信息。':'Demo form: local validation only. Nothing is sent or saved.'}</p>
  {kind!=='newsletter'&&<label>{zh?'姓名':'Name'}<input name="name" autoComplete="name" required maxLength={80}/></label>}
  <label>{zh?'邮箱':'Email'}<input name="email" type="email" autoComplete="email" required maxLength={160}/></label>
  {kind==='contact'&&<><label>{zh?'咨询主题':'Subject'}<select name="subject"><option>{zh?'一般咨询':'General inquiry'}</option><option>{zh?'家具与搭配':'Furniture & styling'}</option><option>{zh?'会员演示':'Membership demo'}</option></select></label><label>{zh?'留言':'Message'}<textarea name="message" required minLength={10} maxLength={3000} rows={5}/></label></>}
  {kind==='checkout'&&<label>{zh?'配送地址（演示）':'Delivery address (demo)'}<textarea name="address" required minLength={10} rows={3}/></label>}
  <button className="fx-button" type="submit">{kind==='newsletter'?(zh?'校验订阅信息':'Validate subscription'):kind==='checkout'?(zh?'校验结算信息':'Validate checkout'):(zh?'校验留言':'Validate message')} <span aria-hidden="true">↗</span></button>
  {done&&<p role="status" className="fx-success">{zh?'校验通过。信息尚未发送或保存，未创建订单或订阅。':'Validation passed. Nothing was sent or saved. No order or subscription was created.'}</p>}
 </form>
}
