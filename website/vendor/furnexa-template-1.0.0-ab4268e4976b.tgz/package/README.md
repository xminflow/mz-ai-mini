# Furnexa 现代家居模板

先读 [.tpl/README.md](.tpl/README.md)。37 个页面、中英文、家具搜索筛选、详情图库、内存购物车与本地表单。

这是独立 Next.js / React 工程。素材授权未确认，未公开发布。

源码仓库：https://github.com/weelume/furnexa-template。
