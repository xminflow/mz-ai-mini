# 权利说明

参考：https://jiro.build/templates/local-services/pet-grooming-landing-page-pawlio 。Jiro 页面设计与插画/图片、SVG 卡通狗和 Logo 的商业再分发授权未完整核实，本模板不声明 MIT 或可商用，不上架。Unsplash 图片保留原始URL，适用 Unsplash License，作者归属与各项使用权应在商业使用前复核。字体许可见 public/templates/pawlio/fonts/README.md 与对应许可文件。演示性提交或公开下载不构成素材商业许可。
