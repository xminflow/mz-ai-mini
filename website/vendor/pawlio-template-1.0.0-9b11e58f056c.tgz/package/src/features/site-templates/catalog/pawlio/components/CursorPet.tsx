'use client'
import {useEffect,useRef,useState} from 'react'
import {motion,useReducedMotion} from 'framer-motion'

function Dog({running}:{running:boolean}){
 return <svg width="80" height="72" viewBox="0 0 80 72" fill="none" aria-hidden="true">{running?<>
  <motion.path d="M18 36C10 32 6 22 11 15" stroke="#e69558" strokeWidth="6" strokeLinecap="round" animate={{rotate:[-20,25,-20]}} transition={{repeat:Infinity,duration:.24}} style={{transformOrigin:'18px 36px'}}/>
  {[{d:['M26 42C23 48 18 56 12 60','M26 42C28 48 34 54 36 58'],color:'#c97b42'},{d:['M48 42C44 48 40 55 35 59','M48 42C52 48 58 54 62 58'],color:'#c97b42'}].map((p,i)=><motion.path key={i} d={p.d[0]} stroke={p.color} strokeWidth="6" strokeLinecap="round" animate={{d:[...p.d,p.d[0]]}} transition={{repeat:Infinity,duration:.36}}/>)}
  <path d="M20 38C20 28 28 24 40 24C52 24 58 30 58 40C58 46 50 48 38 48C26 48 20 46 20 38Z" fill="#e69558"/><circle cx="25" cy="37" r="13" fill="#e69558"/><circle cx="46" cy="36" r="14" fill="#e69558"/>
  {['M30 42C33 48 38 55 42 59','M52 42C56 48 62 54 66 58'].map((d,i)=><motion.path key={d} d={d} stroke="#e69558" strokeWidth="6" strokeLinecap="round" animate={{d:[d,i?'M52 42C46 48 42 55 38 60':'M30 42C25 48 20 56 15 60',d]}} transition={{repeat:Infinity,duration:.36}}/>)}
  <circle cx="56" cy="24" r="13.5" fill="#e69558"/><motion.path d="M48 16C46 22 47 30 52 32C55 33 56 29 55 24C54 18 51 15 48 16Z" fill="#c97b42" animate={{rotate:[-10,16,-10]}} transition={{repeat:Infinity,duration:.28}} style={{transformOrigin:'48px 16px'}}/>
  <ellipse cx="64" cy="27" rx="7" ry="5.5" fill="#fad1a8"/><ellipse cx="68.5" cy="24.5" rx="2.5" ry="2" fill="#2d2825"/><circle cx="57" cy="21" r="2.2" fill="#2d2825"/><circle cx="57.8" cy="20.2" r=".8" fill="white"/><path d="M64 30C64 33 67 33 67 30M47 33C52 35 58 35 62 31" stroke="#cb015c" strokeWidth="3"/><circle cx="55" cy="34.5" r="2" fill="gold"/>
 </>:<>
  <motion.path d="M62 48C70 44 74 34 70 24" stroke="#e69558" strokeWidth="6" strokeLinecap="round" animate={{rotate:[-12,16,-12]}} transition={{repeat:Infinity,duration:.65}} style={{transformOrigin:'62px 48px'}}/>
  <ellipse cx="23" cy="50" rx="10" ry="8" fill="#c97b42"/><ellipse cx="57" cy="50" rx="10" ry="8" fill="#c97b42"/><ellipse cx="21" cy="56" rx="7.5" ry="4.5" fill="#e69558"/><ellipse cx="59" cy="56" rx="7.5" ry="4.5" fill="#e69558"/>
  <path d="M26 58C26 40 31 32 40 32C49 32 54 40 54 58Z" fill="#e69558"/><path d="M32 58C32 42 35 37 40 37C45 37 48 42 48 58Z" fill="#fad1a8"/>
  {[30,43].map(x=><g key={x}><rect x={x} y="44" width="7" height="15" rx="3.5" fill="#e69558"/><ellipse cx={x+3.5} cy="58.5" rx="4.8" ry="3" fill="#e69558"/></g>)}
  {[false,true].map(right=><motion.path key={String(right)} d={right?'M53 16C57 18 60 25 59 33C58 36 54 36 52 32C50 26 51 19 53 16Z':'M27 16C23 18 20 25 21 33C22 36 26 36 28 32C30 26 29 19 27 16Z'} fill="#c97b42" animate={{rotate:right?[3,-4,3]:[-3,4,-3]}} transition={{repeat:Infinity,duration:1.8}} style={{transformOrigin:right?'53px 16px':'27px 16px'}}/>)}
  <circle cx="40" cy="24" r="16" fill="#e69558"/><path d="M28 35C33 38 47 38 52 35" stroke="#cb015c" strokeWidth="4"/><circle cx="40" cy="38" r="2.8" fill="gold"/><ellipse cx="40" cy="27" rx="8.5" ry="6" fill="#fad1a8"/><ellipse cx="40" cy="23.5" rx="3.5" ry="2.5" fill="#2d2825"/>
  {[32,48].map(x=><motion.g key={x} animate={{scaleY:[1,1,.08,1,.08,1,1,.08,1]}} transition={{repeat:Infinity,duration:3.6,times:[0,.25,.28,.32,.36,.4,.82,.85,.9]}} style={{transformOrigin:`${x}px 19px`}}><circle cx={x} cy="19" r="3.8" fill="white"/><circle cx={x} cy="19" r="2.4" fill="#2d2825"/><circle cx={x-1} cy="18" r=".9" fill="white"/></motion.g>)}
  <motion.path d="M36.5 28C36.5 35 43.5 35 43.5 28" fill="#ff4081" stroke="#cb015c" animate={{scaleY:[.2,1,1,.2],scaleX:[.7,1,1,.7]}} transition={{repeat:Infinity,duration:3.6,times:[0,.2,.75,.95]}} style={{transformOrigin:'40px 28px'}}/>
  {[.3,.8,1.3].map(delay=><motion.path key={delay} d="M40 35C38.8 35 38 36 38 37.2C38 38.4 38.9 39.2 40 39.2C41.1 39.2 42 38.4 42 37.2C42 36 41.2 35 40 35Z" fill="#38bdf8" animate={{y:[0,8,18],opacity:[0,1,0],scale:[.6,1,.4]}} transition={{repeat:Infinity,duration:1.8,delay,ease:'easeIn'}}/>)}</>}
 </svg>
}

export function CursorPet(){
 const reduced=useReducedMotion(),target=useRef({x:-100,y:-100,interactive:false}),position=useRef({x:-100,y:-100}),dog=useRef<HTMLDivElement>(null)
 const [pointer,setPointer]=useState({x:-100,y:-100,visible:false,interactive:false}),[state,setState]=useState({running:false,right:true,caught:false})
 useEffect(()=>{
  if(reduced)return;const query=window.matchMedia('(min-width:1024px) and (pointer:fine)');let frame=0,last=0;const current={running:false,right:true,caught:false}
  const move=(e:MouseEvent)=>{if(!query.matches)return;const control=(e.target as Element).closest('button,a,input,select,textarea,[role="button"]');const rect=control?.getBoundingClientRect();target.current={x:rect?rect.left+rect.width/2:e.clientX,y:rect?rect.bottom+14:e.clientY,interactive:!!control};setPointer({x:e.clientX,y:e.clientY,visible:true,interactive:!!control})}
  const leave=()=>setPointer(p=>({...p,visible:false}))
  // 原站以每秒180px追逐，靠近交互控件加速至220px；进入6px阈值后坐下。
  const tick=(time:number)=>{const dt=Math.min((time-last)/1000,.1);last=time;const a=position.current,b=target.current;if(b.x!==-100){if(a.x===-100){a.x=b.x;a.y=b.y}const dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy),running=d>6;if(running){const step=Math.min(d,(b.interactive?220:180)*dt);a.x+=dx/d*step;a.y+=dy/d*step}const right=Math.abs(dx)>1?dx>0:current.right;if(current.running!==running||current.right!==right||current.caught===running){Object.assign(current,{running,right,caught:!running});setState({...current})}if(dog.current)dog.current.style.transform=`translate3d(${a.x-40}px,${a.y-40}px,0)`}frame=requestAnimationFrame(tick)}
  window.addEventListener('mousemove',move);document.addEventListener('mouseleave',leave);frame=requestAnimationFrame(tick);return()=>{cancelAnimationFrame(frame);window.removeEventListener('mousemove',move);document.removeEventListener('mouseleave',leave)}
 },[reduced])
 if(reduced)return null
 return <div className="pw-cursor" aria-hidden="true" style={{visibility:pointer.visible?'visible':'hidden'}}><motion.div className="pw-bone" animate={{x:pointer.x-16,y:pointer.y-16,opacity:pointer.interactive||state.caught?0:.95,scale:pointer.interactive||state.caught?.3:1,rotate:state.running?(state.right?12:-12):0}} transition={{type:'spring',stiffness:600,damping:35,mass:.2}}><svg viewBox="0 0 32 32"><path d="M7 25C1 27 0 20 5 18C7 17 8 19 10 18L18 10C19 8 17 7 18 5C20 0 27 1 25 7C31 5 32 12 27 14C25 15 24 13 22 14L14 22C13 24 15 25 14 27C12 32 5 31 7 25Z" fill="#cb015c"/></svg></motion.div><div className="pw-dog" ref={dog}><motion.div animate={{scaleX:state.running&&!state.right?-1:1,y:state.running?[0,-7,1,0]:0,rotate:state.running?(state.right?[0,4,-3,0]:[0,-4,3,0]):0,scaleY:state.running?[1,.94,1.04,1]:1}} transition={{y:{repeat:Infinity,duration:.36},rotate:{repeat:Infinity,duration:.36},scaleY:{repeat:Infinity,duration:.36},scaleX:{duration:.16}}}><Dog running={state.running}/></motion.div></div></div>
}
