export const serviceTiming = {
  desktop: { imageDuration: 4, textDuration: 0.5, textLead: 0.25, scrubDuration: 1 },
  mobile: { imageDuration: 3.5, textDuration: 0.45, textLead: 0.2, scrubDuration: 0.8 },
} as const

export function scrubEase(progress: number): number {
  return progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress)
}

/** 图片与文字共享原站时间轴；图片先到终点，最后一条文字仍需完成半段切换。 */
export function servicePosition(
  progress: number,
  count: number,
  textHeight: number,
  mobile: boolean,
): { imageProgress: number; textOffset: number } {
  if (count < 2) return { imageProgress: 0, textOffset: 0 }
  const timing = mobile ? serviceTiming.mobile : serviceTiming.desktop
  const time = Math.max(0, Math.min(1, progress)) *
    (timing.imageDuration + timing.textDuration - timing.textLead)
  let textOffset = 0
  for (let index = 1; index < count; index++) {
    const start = timing.imageDuration * index / (count - 1) - timing.textLead
    const local = Math.max(0, Math.min(1, (time - start) / timing.textDuration))
    // GSAP power2.inOut 对应三次幂；文字过渡跟随滚动而非另外启动动画。
    const eased = local < 0.5 ? 4 * local ** 3 : 1 - (-2 * local + 2) ** 3 / 2
    textOffset -= textHeight * eased
  }
  return { imageProgress: Math.min(1, time / timing.imageDuration), textOffset }
}
