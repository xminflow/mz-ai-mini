import type {Bilingual} from '../config/brand'
const bi=(zh:string,en:string):Bilingual=>({zh,en})
export const copy={
 nav:[bi('首页','Home'),bi('关于我们','About'),bi('护理服务','Services'),bi('套餐价格','Pricing')],
 navTargets:['home','about','services2','pricing'],
 contact:bi('联系我们','Contact us'),reserve:bi('预约一次宠爱','Make A Reservation'),
 hero:bi('用真心打理毛发\n像家人一样宠爱','Groomed with true love,\ncared for like family'),
 intro:bi('让每一次专业护理都伴着开心的摇尾巴。预约一场温柔的美容之旅，让毛孩子带着最好的模样与心情回家。','Professional grooming that keeps tails wagging. Book a session and let your furry friend leave looking (and feeling) their absolute best.'),
 about:bi('温柔的护理\n藏在耐心与善意里','Gentle grooming made with patience, and kindness'),
 aboutSub:bi('值得信赖的照护，专业的护理，以及安心放松的体验。','Trusted care, modern medicine, and a fear-free experience.'),
 aboutText:bi('把专业知识与细致关怀融为一体。我们认真对待每一次护理，陪伴宠物拥有更健康、更快乐的生活。','Cutting-edge technology combined with extensive knowledge. We are dedicated to offering top-notch diagnostics for pets, helping them live longer, healthier lives.'),
 stats:[{value:24,suffix:'/7',label:bi('贴心关怀','Always here for you')},{value:15,suffix:'+',label:bi('年专业经验','Years of experience')},{value:2.89,suffix:'k+',label:bi('快乐毛孩子','Happy pets')}],
 servicesTitle:bi('为毛孩子量身定制\n专业美容与护理','Professional pet grooming solutions'),
 tailored:bi('专属护理\n让快乐从毛尖开始','Tailored Grooming, Happy Pets'),tailoredSub:bi('好看、舒服、健康。每一份宠爱，都为毛孩子量身定制。','Everything your pet needs to look great, feel amazing, and live a healthier life!'),
 beforeLabel:bi('护理前后','Before & After'),beforeTitle:bi('看见每一份\n闪闪发光的改变','See the Beautiful Transformation'),beforeSub:bi('每只宠物都值得美好与舒适。这里记录着我们的关怀、耐心与专业。','Every pet deserves to look and feel their best. Here’s just a sneak peek of the love, care, and expertise we provide.'),
 before:bi('护理前','Before'),after:bi('护理后','After'),
 reviewTitle:bi('听听毛孩子家长怎么说','What Pet Parents Say'),
 pricingTitle:bi('每一种宠爱\n都有合适的套餐','The {brand} Grooming\nPackages & Pricing'),pricingSub:bi('从日常焕新到全套宠爱，为你的毛孩子找到合适的护理方案。','From quick refreshes to full pampering sessions, we have the perfect grooming package for your furry friend.'),
 faqTitle:bi('关于护理\n你可能还想了解','Frequently Asked Questions'),
 footerTitle:bi('让我们\n保持联系','Stay Connected\nWith Us'),community:bi('加入爱宠小社区','Join Our Pet-Loving Community'),communitySub:bi('获取实用护理知识、新鲜动态与更多宠物灵感。','Get helpful pet care tips, exclusive offers, and updates straight to your inbox.'),
 demo:bi('演示表单：仅在本地校验，不发送、不保存任何资料。','Demo form: local validation only. Nothing is sent or saved.'),done:bi('本地校验通过。资料未发送，也未保存。','Local validation passed. Nothing was sent or saved.'),
 name:bi('你的称呼','Your Name'),email:bi('电子邮箱','Your Email'),petName:bi('宠物名字','Pet’s Name'),submit:bi('订阅动态','Subscribe'),close:bi('关闭','Close'),menu:bi('打开菜单','Open menu'),
 quick:bi('快速导航','Quick Links'),care:bi('宠物护理','Pet Care'),company:bi('关于品牌','Company'),privacy:bi('隐私说明','Privacy Policy'),terms:bi('使用条款','Terms & Conditions'),
 privacyText:bi('本演示页面不发送或保存表单资料。图片与评价用于展示设计，不代表真实客户记录。正式业务需另行配置预约、隐私及数据保护流程。','This demo does not send or store form data. Images and testimonials illustrate the design and do not represent real customer records. A live business needs its own booking, privacy, and data protection processes.'),
 termsText:bi('此页面为宠物护理展示模板，套餐、价格、指标与评价均为演示内容，不构成服务承诺或医疗建议。预约表单不会创建真实预约。','This pet-care template contains demonstration packages, prices, statistics and testimonials. It makes no service promises or medical recommendations. The booking form does not create an appointment.'),
 rights:bi('保留所有权利','All rights reserved'),tagline:bi('让每一次宠爱，都温柔发生。','A little care. A lot of happy tails.'),
}
export const services=[
 {title:bi('毛发修剪与造型','Haircut and styling'),body:bi('根据品种与毛发特点，打造舒适又有个性的造型。','Expert breed-specific cuts with trendy grooming styles.')},
 {title:bi('牙齿清洁','Teeth brushing'),body:bi('温和清洁口腔，让呼吸与笑容都更清新。','Improves your pet’s fresh breath and oral health.')},
 {title:bi('口腔护理','Tartar removal'),body:bi('关注口腔健康；需要治疗时请咨询兽医。','Reduces tartar buildup and promotes dental wellness.')},
 {title:bi('指甲修整','Nail trimming'),body:bi('细致修整指甲，让每一步都舒适安心。','Precise nail trimming for comfort and safe movement.')},
 {title:bi('洗护与吹干','Bathing and drying'),body:bi('柔和洗浴与耐心吹干，留下干净蓬松的毛发。','Soft bathing and gentle drying for a clean, shiny coat.')},
 {title:bi('眼周清洁','Eye care'),body:bi('细心清洁眼周，照顾敏感的小细节。','Delicate eye cleaning to avoid any irritation.')},
]
export const careCards=[
 {title:bi('美容与水疗','Grooming & Spa Services'),color:'#4a72ec',icon:'clipboard' as const,rotate:-8,x:-120,y:10,items:[bi('沐浴与毛发养护','Bath & Coat Care'),bi('修剪与造型','Haircuts & Styling'),bi('指甲修整','Nail Trimming'),bi('耳部清洁','Ear Cleaning'),bi('换毛期护理','De-Shedding Treatments'),bi('香氛与精致收尾','Pet Perfume & Finishing')]},
 {title:bi('健康与日常照护','Health & Wellness Care'),color:'#ffae38',icon:'bandaid' as const,rotate:2,x:0,y:30,items:[bi('日常健康观察','Full Body Health Check'),bi('皮肤与毛发护理','Skin & Coat Treatments'),bi('跳蚤与蜱虫防护','Flea & Tick Protection'),bi('口腔清洁','Dental Care'),bi('体重管理知识','Weight Management'),bi('幼宠与老年宠护理','Puppy & Senior Care')]},
 {title:bi('特别护理','Special Care Treatments'),color:'#f05748',icon:'tooth' as const,rotate:8,x:120,y:0,items:[bi('专用洗护','Medicated Baths'),bi('温润按摩','Hot Oil Massage'),bi('牙齿清洁','Teeth Cleaning'),bi('肛门腺护理','Anal Gland Expression'),bi('卫生区域修剪','Sanitary Trim'),bi('清新除味水疗','Deodorizing Spa')]},
]
export const transformations=[
 {name:bi('泰迪熊造型','Teddy Bear Cut'),before:'photo-1583511655857-d19b40a7a54e.jpg',after:'photo-1591768575198-88dac53fbd0a.jpg'},
 {name:bi('蓬松水疗修剪','Fluffy Spa Trim'),before:'photo-1537151608828-ea2b11777ee8.jpg',after:'photo-1587300003388-59208cc962cb.jpg'},
 {name:bi('全套洗护造型','Full Bath & Style'),before:'photo-1543466835-00a7907e9de1.jpg',after:'photo-1517849845537-4d257902454a.jpg'},
 {name:bi('精细修剪','Precision Haircut'),before:'photo-1552053831-71594a27632d.jpg',after:'photo-1530281700549-e82e7bf110d6.jpg'},
]
export const reviews=[
 {name:bi('莎拉','Sarah Johnson'),role:bi('金毛贵宾的家长','Golden Doodle Mom'),quote:bi('他们像家人一样对待我们的狗狗！每次回家都开心、干净、香香的。细致又用心的护理，让人特别放心。','They treat our dog like family! Every visit leaves him happy, clean, and smelling amazing. The care and attention to detail are unmatched.'),image:'photo-1534528741775-53994a69daeb.jpg',color:'#fef08a'},
 {name:bi('大卫','David Chen'),role:bi('贵宾犬的家长','Poodle Dad'),quote:bi('终于找到真正了解毛发护理的美容师。每次接 Max 回家，他都像刚刚走下领奖台一样神气。','Finding a groomer who truly understands coat care was a game changer. Max always comes back looking like a champion!'),image:'photo-1507003211169-0a1dd7228f2d.jpg',color:'#e2e8f0'},
 {name:bi('艾米莉','Emily Watson'),role:bi('比熊犬的家长','Bichon Mom'),quote:bi('温柔、有耐心，手艺也很棒。Luna 以前很怕美容，现在一到门口就开始摇尾巴了！','Gentle, patient, and incredibly skilled. Luna used to be anxious about grooming, but now she wags her tail when we arrive!'),image:'photo-1517841905240-472988babdf9.jpg',color:'#dcfce7'},
 {name:bi('马库斯','Marcus Vance'),role:bi('雪纳瑞的家长','Schnauzer Dad'),quote:bi('Winston 每次的泰迪熊造型都很漂亮。让人安心的专业服务，每一分细节都值得。','The teddy bear cut on Winston is flawless every single time. Premium service that’s worth every penny!'),image:'photo-1500648767791-00dcc994a43e.jpg',color:'#e0e7ff'},
]
export const plans=[{name:bi('日常焕新','Mini Groom'),price:60,body:bi('日常的清爽，从细致基础护理开始。','Essential care for your pet’s everyday freshness.')},{name:bi('全套宠爱','Complete Groom'),price:100,body:bi('从头到爪的完整护理，干净、健康又快乐。','Complete grooming for a clean, healthy & happy pet.')},{name:bi('精致手工造型','Hand Scissor Groom'),price:140,body:bi('细致手剪，为毛孩子留下恰到好处的造型。','Premium hand scissor grooming for the perfect finish.')}]
export const planFeatures=[bi('温和低敏沐浴','Bath (Hypo-Allergenic)'),bi('日常健康观察','Fitness Check Up'),bi('毛发与指甲修整','Hair and Nail Cut'),bi('滋养护毛','Conditioning Treatment'),bi('耳部清洁','Ears Flushed & Cleaned')]
export const faqs=[
 {q:bi('首次护理需要带些什么？','What should I bring to my pet’s first appointment?'),a:bi('请携带最新的疫苗记录，并使用安全的牵引绳或航空箱。如果兽医建议使用专用洗护用品，也请一并带上。','Please bring your pet’s up-to-date vaccination records (especially Rabies), a secure leash or carrier, and any specific medicated shampoos or favorite treats if recommended by your vet.'),color:'#ef6c60'},
 {q:bi('多久进行一次美容比较合适？','How often should my pet be groomed?'),a:bi('大多数狗狗可每 4–6 周进行护理，以维护毛发、避免打结并修整指甲。短毛品种可结合居家梳理，将间隔调整为 8–12 周。','For most dogs, we recommend grooming every 4 to 6 weeks to maintain a healthy coat, prevent matting, and keep nails trim. Short-haired breeds may go 8 to 12 weeks with regular home brushing.'),color:'#ffb03a'},
 {q:bi('一次护理大约需要多长时间？','How long does a grooming session take?'),a:bi('全套护理通常需要 1.5–3 小时，视体型、毛发状况与宠物状态而定。我们更重视舒适与耐心，不催促毛孩子。','A full grooming session usually takes between 1.5 to 3 hours depending on your pet’s size, coat condition, and behavior. We never rush to ensure a calm, gentle experience.'),color:'#5c86ed'},
 {q:bi('全套护理包含哪些服务？','What services are included in an appointment?'),a:bi('包含洗浴、吹干、梳毛、修剪造型、剪指甲、耳部清洁和卫生区域整理。具体项目需根据毛孩子状况确认。','Our full grooming package includes a bath with premium shampoo, blow dry, coat brush out, haircut or breed trim, nail clipping, ear cleaning, and a gentle hygiene refresh.'),color:'#85ce93'},
 {q:bi('如何照顾容易紧张的宠物？','How do you keep nervous pets comfortable?'),a:bi('采用温和引导、低噪音吹风、防滑台面和正向鼓励；安排适当休息，按照毛孩子的节奏进行。','We use fear-free handling techniques, low-noise dryers, non-slip surfaces, and positive reinforcement. We take regular rest breaks and adapt our pace to keep nervous pets completely relaxed.'),color:'#bfa3e6'},
 {q:bi('幼宠和老年宠也可以预约吗？','Can I book an appointment for puppies or senior pets?'),a:bi('可以。幼宠以熟悉环境与温和引导为主；老年宠则根据行动能力安排更细致的支持与休息。','Absolutely! We offer specialized gentle puppy orientation sessions to get young pets comfortable with grooming, as well as extra-support care for senior pets with mobility needs.'),color:'#fcd65a'},
]
