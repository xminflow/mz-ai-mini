'use client'
import { createContext, useContext, type ReactNode } from 'react'
import { brand, type Bilingual } from './config/brand'
export interface PawlioHostConfig {
  brandName: Bilingual
  logo?: string
  lightLogo?: string
  marketplaceHref?: string
  marketplaceLabel?: Bilingual
  marketplaceAriaLabel?: Bilingual
  filing?: ReactNode
}
const Context = createContext<PawlioHostConfig>({ brandName: brand.name })
export function PawlioHostProvider({ children, ...config }: PawlioHostConfig & { children: ReactNode }) {
  return <Context.Provider value={config}>{children}</Context.Provider>
}
export const usePawlioHost = () => useContext(Context)
