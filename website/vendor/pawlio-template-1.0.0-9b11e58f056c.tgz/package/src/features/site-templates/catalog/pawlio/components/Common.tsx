'use client'
import {motion,useReducedMotion} from 'framer-motion'
import {createContext,useContext,type ReactNode,type ButtonHTMLAttributes} from 'react'
import type {TemplateLocale} from '../../../types'
import type {Bilingual} from '../config/brand'
export const PageContext=createContext<{locale:TemplateLocale;open:(kind:'booking'|'privacy'|'terms')=>void}>({locale:'zh',open:()=>{throw new Error('Missing Pawlio page context')}})
export function usePage(){const c=useContext(PageContext);return {...c,t:(v:Bilingual)=>v[c.locale]}}
export const ease=[.16,1,.3,1] as const
export function Heading({title,body}:{title:Bilingual;body?:Bilingual}){const {t}=usePage();const reduced=useReducedMotion();return <motion.header className="pw-heading" initial={reduced?false:{opacity:0,y:30}} whileInView={{opacity:1,y:0}} viewport={{once:true,amount:.3}} transition={{duration:.8,ease}}><h2>{t(title)}</h2>{body&&<p>{t(body)}</p>}</motion.header>}
export function Button({children,className='',...props}:ButtonHTMLAttributes<HTMLButtonElement>){return <button className={'pw-button '+className} {...props}><span>{children}</span></button>}
export function Photo({file,alt,className='',...props}:{file:string;alt:string;className?:string;loading?:'eager'|'lazy'}){return <img src={'/templates/pawlio/media/'+file} alt={alt} className={className} loading="lazy" {...props}/>}
export function Section({id,children,className=''}:{id:string;children:ReactNode;className?:string}){return <section id={id} className={'pw-section '+className}><div className="pw-container">{children}</div></section>}
