# Pawlio 宠物美容护理模板

双语响应式单页，默认中文，英文 /en。九区块：首屏、关于、专业服务滚动、三类护理卡片、前后对比、评价、价格、FAQ、页脚。含桌面小狗追逐光标、24秒装饰旋转、计数、卡片错峰、服务固定滚动与移动横向展示。按单页范围交付，未创建博客、团队或招聘内页。

## 运行

Node 24.16.0，pnpm 9.15.4。pnpm install --frozen-lockfile；pnpm dev；默认 http://127.0.0.1:43680。生产 pnpm build 后 pnpm start；Ctrl+C 停止本次启动进程。PORT/HOSTNAME 为服务端环境变量，无数据库与第三方服务配置。依赖沿用既有模板工具链，没有新增第三方库。

## 检查与修改

pnpm typecheck、pnpm lint、pnpm test、pnpm build。品牌配置在 src/features/site-templates/catalog/pawlio/config/brand.ts；双语内容 content/data.ts；素材清单 .tpl/docs/ASSETS.json；主题 theme.css；交互 components/；页面组合 pages/HomePage.tsx；注册 meta.ts。host.tsx 提供可选品牌、Logo、市场入口、备案插槽，独立工程默认自身品牌。共享运行包使用 pnpm bundle 生成，完整源码另由 Git 管理。

## 限制

所有预约与订阅仅本地校验，不发送、不保存个人资料。指标、评价、价格为设计演示。商业素材权利待核实，listed=false；实际 Git 远端创建被审批阻止，gitUrl 保持 null，协议就绪检查不会冒充通过。动效完整一致性以 .tpl/docs/MOTION.md 及实际验收记录为准。
