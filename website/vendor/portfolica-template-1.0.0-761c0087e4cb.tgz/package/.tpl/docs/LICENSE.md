# 许可与权利边界
代码为独立实现，参考 https://portfolica.framer.website/。原站设计、人物、项目、标识与客户图片尚未取得商业再分发授权，仅供设计研究；listed=false，redistributionAllowed=false。真实 Git 地址与内容摘要不证明素材商业许可。Poppins 按随附 OFL；MiSans 按官方字体许可；工具按其自身许可。公开源码不构成素材商业授权。
