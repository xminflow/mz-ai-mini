'use client'
import Link from 'next/link'
import {usePathname,useRouter} from 'next/navigation'
import {useState,type ReactNode,type FormEvent} from 'react'
import {AnimatePresence,motion,useReducedMotion} from 'framer-motion'
import type {SiteTemplatePageProps} from '../../../types'
import {usePortfolicaHost} from '../host'
import {brand} from '../config/brand'
import {labels,profile,copy} from '../content/data'
import {motionLog} from './Motion'
import '../theme.css'

const MotionLink=motion.create(Link)
export function Button({href,children,primary=false}:{href:string;children:ReactNode;primary?:boolean}){const reduced=useReducedMotion();return <MotionLink className={'pf-button '+(primary?'pf-primary':'')} href={href} initial="rest" whileHover="hover" whileFocus="hover"><span className="pf-roll pf-spring-roll">{[false,true].map(hidden=><motion.span key={String(hidden)} aria-hidden={hidden||undefined} variants={{rest:{y:0},hover:{y:'-100%'}}} transition={reduced?{duration:0}:{type:'spring',stiffness:300,damping:40,mass:.1}}>{children}</motion.span>)}</span></MotionLink>}
export function Shell({children,basePath,locale='zh'}:SiteTemplatePageProps & {children:ReactNode}) {
 const host=usePortfolicaHost(),pathname=usePathname(),router=useRouter(),reduced=useReducedMotion(),[open,setOpen]=useState(false),[newsletter,setNewsletter]=useState(false)
 const root=basePath.replace(/\/en$/,''); const home=basePath||'/'
 const href=(slug:string)=>`${basePath}/${slug}`
 const nav=[['about',labels.about[locale]],['all-projects',labels.projects[locale]],['contact',labels.contact[locale]],['404','404']]
 const name=host.brandName?.[locale]??brand.name[locale]
 function switchLanguage(){const suffix=pathname.slice(basePath.length);const target=(locale==='zh'?root+'/en':root)+suffix+window.location.search+window.location.hash;motionLog('language-switch',{locale});return target||'/'}
 const languageHref=(locale==='zh'?root+'/en':root)+(pathname.slice(basePath.length)||'')
 function subscribe(e:FormEvent<HTMLFormElement>){e.preventDefault();setNewsletter(true);motionLog('newsletter-local-validation')}
 return <div className="pf" lang={locale==='zh'?'zh-CN':'en'}>
  <motion.header className="pf-header" initial={{y:reduced?0:-77,opacity:reduced?1:0}} animate={{y:0,opacity:1}} transition={{type:'spring',duration:1.5,bounce:.2,delay:.1}}>
   <nav aria-label={copy('主导航','Main navigation')[locale]} className="pf-nav">
    <Link href={home} className="pf-brand" aria-label={name}><img src={host.logo??profile} alt={name}/></Link>
    <div className="pf-desktop-links">{nav.map(([slug,label])=><Link key={slug} href={href(slug)}><span className="pf-roll"><span>{label}</span><span aria-hidden="true">{label}</span></span></Link>)}</div>
    <button className={'pf-menu '+(open?'is-open':'')} aria-label={copy('切换菜单','Toggle menu')[locale]} aria-expanded={open} aria-controls="pf-mobile-menu" onClick={()=>{setOpen(!open);motionLog('menu-toggle',{open:!open})}}><span/><span/></button>
    <AnimatePresence>{open&&<motion.div id="pf-mobile-menu" className="pf-mobile-links" initial={{height:0,opacity:0}} animate={{height:'auto',opacity:1}} exit={{height:0,opacity:0}} transition={{duration:reduced?0:.4,ease:[.44,0,.56,1]}}>{nav.map(([slug,label],i)=><motion.div key={slug} initial={{y:reduced?0:16,opacity:0}} animate={{y:0,opacity:1}} transition={{delay:reduced?0:i*.05}}><Link onClick={()=>setOpen(false)} href={href(slug)}>{label}</Link></motion.div>)}</motion.div>}</AnimatePresence>
   </nav>
   <div className="pf-header-actions"><Button href={href('contact')}>{labels.call[locale]}</Button><Link className="pf-language" href={languageHref||'/'} onClick={e=>{e.preventDefault();router.push(switchLanguage());setOpen(false)}}>{locale==='zh'?'EN':'中文'}</Link></div>
  </motion.header>
  <motion.main key={pathname} initial={{opacity:reduced?1:0}} animate={{opacity:1}} transition={{duration:reduced?0:.2,ease:[.27,0,.51,1]}}>{children}</motion.main>
  <footer className="pf-footer"><div className="pf-footer-grid pf-container">
   <div><p>{copy('社交平台','Socials')[locale]}</p><div className="pf-socials"><img src={host.logo??profile} alt={name}/><div>{['Dribbble','Behance','Figma','X'].map(v=><a key={v} href={'https://'+(v==='Behance'?'behance.net':(v==='X'?'x':v.toLowerCase())+'.com')} target="_blank" rel="noreferrer">{v}</a>)}</div></div></div>
   <div><p>{copy('站内链接','Links')[locale]}</p><div className="pf-footer-links">{nav.map(([slug,label])=><Link key={slug} href={href(slug)}>{label}</Link>)}</div></div>
   <div><p>{copy('订阅通讯','Newsletter')[locale]}</p><p className="pf-muted">{copy('订阅设计灵感、优惠信息与项目动态。','Subscribe to get early access to special offers, design discounts, and exclusive project updates.')[locale]}</p><form onSubmit={subscribe}><label className="pf-sr" htmlFor="pf-newsletter">{copy('订阅邮箱','Newsletter email')[locale]}</label><div className="pf-newsletter"><input id="pf-newsletter" type="email" required placeholder={copy('你的邮箱','jane@brand.com')[locale]}/><button type="submit">{copy('订阅','Subscribe')[locale]}</button></div><small role="status">{newsletter?labels.success[locale]:labels.demo[locale]}</small></form></div>
  </div><div className="pf-footer-bottom pf-container"><div><Link href={href('legal/privacy-policy')}>{copy('隐私政策','Privacy Policy')[locale]}</Link><Link href={href('legal/terms-conditions')}>{copy('服务条款','Terms of Service')[locale]}</Link></div><span>{name} © {brand.copyrightYear} · {copy('让创意成为真实影响力','Turn creativity into real impact')[locale]}</span>{host.filing}</div></footer>
  {host.marketplaceHref&&<Link href={host.marketplaceHref} className="pf-market" aria-label={host.marketplaceAriaLabel?.[locale]}>{host.lightLogo&&<img src={host.lightLogo} alt=""/>}<span>{host.brandName?.[locale]}</span></Link>}
 </div>
}
