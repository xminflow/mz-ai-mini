import type {SiteTemplatePageProps} from '../../../types'
import {Shell,Button} from '../components/Shell'
import {Title} from '../components/Motion'
import {copy} from '../content/data'
export default function NotFoundPage(props:SiteTemplatePageProps){const l=props.locale??'zh';return <Shell {...props}><section className="pf-not-found pf-container"><strong>404</strong><Title text={copy('这个页面暂时迷路了','This page got lost')[l]}/><p>{copy('试试回到首页，继续发现好作品。','Head back home and discover more good work.')[l]}</p><Button href={props.basePath||'/'} primary>{copy('回到首页','Back to home')[l]}</Button></section></Shell>}
