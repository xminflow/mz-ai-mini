import type { TemplateLocale } from '../../../types'
export type Copy = Record<TemplateLocale, string>
export const copy = (zh: string, en: string): Copy => ({ zh, en })
export const assets = '/templates/portfolica/'
export const image = (name: string) => assets + 'images/' + name + '.png'
export const profile = image('GLrXdyCPhNqdGXFCIVsn5gnaXvE')
export const labels = {
 about: copy('关于我', 'About'), projects: copy('全部作品', 'All Projects'), contact: copy('联系', 'Contact'),
 call: copy('预约 30 分钟沟通', 'Book a 30 min call'), start: copy('开始一个项目', 'Start a Project'), see: copy('浏览作品', 'See Projects'),
 view: copy('查看全部作品', 'View All Projects'), rating: copy('已帮助 120 多家企业持续成长', 'Helped 120+ businesses & counting'),
 intro: copy('用数字体验，为你的业务带来真实增长。让我们一起创造兼具美感与成效的作品。', "I build digital experiences that drive real growth for your business. Let's partner to create work that gets results."),
 selected: copy('精选项目，呈现我对设计、开发与落地的理解。', 'Selected projects that reflect my approach to design, development, and execution.'),
 open: copy('期待新的项目与合作。欢迎分享你正在构思的事，即使它还只是一个想法。', 'I’m open to projects & alliances. Feel free to reach out & share what you’re building, even if it’s an early idea.'),
 demo: copy('仅本地校验演示，不会发送或保存任何信息。', 'Local validation demo only. Nothing is sent or saved.'),
 success: copy('校验通过，信息尚未发送或保存。', 'Validation passed. Your information has not been sent or saved.'),
}
export const projects = [
 {id:'connecto',name:'Connecto',year:'2023',industry:copy('通信','Telecom'),cover:'ZM6pJ8R7DfnbSUPqJJjn7Hc8',gallery:['UZhcB6sr9gmWTA63B0h3NfQsVE','ASlXQc0spF9uH7SCuXjxpWIIX0','QoO4vsKOp6DkE603EUrjGQ3Obzg'],description:copy('为日常移动管理设计的通信应用，整合充值、用量追踪与客户支持。','Connecto is a telecom app for recharges, tracking, support, & seamless everyday mobile management.')},
 {id:'paynest',name:'PayNest',year:'2024',industry:copy('金融科技','Fintech'),cover:'hmgNaJ2lIT0EgDscxDxJhXR05ic',gallery:["QsdA548N7Gu3jhrCEHLFgsrs04","XNBUHZ3Fth8RwCKmsWSAsRL8CU","ubWnscZGEwgvwVyAvmkY9kr5k"],description:copy('集即时转账、账单支付、支出追踪与安全交易于一体的数字钱包。','PayNest is a digital wallet app for instant transfers, bill payments, expense tracking, and secure daily transactions.')},
 {id:'shopora',name:'Shopora',year:'2014',industry:copy('电子商务','E-commerce'),cover:'XN77XLOZkyZJ9fBtXN2ylMD6xTA',gallery:["9olZPaKbiaJNw47dZqXIrpoeK2k","BMIIfm3F6KOhs4e0XbupycuU","gVrTztIpPNz1DSntx0wNoors"],description:copy('以流畅购物体验连接商品探索、结算与订单管理的电商平台。','Shopora is an e-commerce platform for product discovery, seamless checkout, and order tracking.')},
 {id:'edunova',name:'EduNova',year:'2026',industry:copy('教育','Education'),cover:'QR06j1eRvSWQMXnQdxQxjcPJnqE',gallery:['JaSR9dqndU3W5DukWxErBX9myic','6226OWEOo2jiofOMMWbqK4BykK0','wWM4O3FUUedeVCL1ZsQrZMNPZ0'],description:copy('面向现代学习者的在线教育平台，整合课程、进度追踪、直播和学习管理。','EduNova is an online learning platform for courses, progress tracking, live sessions, and smart learning management built for modern students.')},
 {id:'medilink',name:'MediLink',year:'2026',industry:copy('医疗健康','Healthcare'),cover:'IiZsArK56TE4aFJCBh2ttC2Zc',gallery:['qcJxvQqLcGey4cNnN1WNBFshCg','S51Ut7i2FDNu5GiPJT9dxrARbk','QE9DuP9oZgIYva4vwh4LQ6hcg'],description:copy('连接预约、报告、在线咨询与患者管理，让医疗服务更清晰、更便捷。','MediLink is a healthcare app for doctor appointments, medical reports, consultations, and patient management built for modern users.')},
 {id:'travelio',name:'Travelio',year:'2026',industry:copy('旅行','Travel'),cover:'IsN1vEtHRZr4t37DgLjXTSW0o',gallery:["r13uC0loylC7UCy1flJYmpOxraY","dSOEoYvaIiU6VtEXiXYZjilZ6MY","4ogfJrQenTSc6VnYawhMS1ONo"],description:copy('让目的地探索、行程规划与预订在同一体验中自然衔接的旅行应用。','Travelio brings destination discovery, travel planning, and booking together in one seamless experience.')},
]
export type Project = typeof projects[number]
export const about = [
 [copy('我的工作','What I do'),copy('用有思想、有力量的设计，帮助品牌找到清晰的表达。','I help brands find clarity and express it through strong, thoughtful design.')],
 [copy('我的背景','Background'),copy('来自墨西哥城，拥有 7 年以上品牌设计经验，与初创团队、餐厅、酒店及创意创业者合作。','Originally from CDMX, I’ve been designing identities for 7+ years, working with startups, restaurants, hoteliers, & creative founders across Mexico.')],
 [copy('我的方法','My Approach'),copy('好的设计始于共情。认真提问，耐心倾听，创造诚实、美好且经得起时间考验的品牌。','I believe good design starts with empathy. I ask questions, listen closely, and build brands that feel as good as they look, honest, beautiful, and built to last.')],
]
export const careers = [
 [copy('设计总监','Design Director'),'Solvix','2025 – Now'], [copy('高级产品设计师','Sr. Product Designer'),'Coreva','2024 – 2025'],
 [copy('产品设计师','Product Designer'),'Belvo','2015 – 2024'], [copy('UI/UX 设计师','UI/UX Designer'),'Arvion','2012 – 2015'],
]
export const services = [
 [copy('体验与创意设计','UX-UI & Creative'),copy('设计清晰友好的界面，表达你的品牌，创造流畅的使用体验。','Crafting clean, user-friendly sites that reflect your brand & deliver a seamless experience.')],
 [copy('网站开发','Web Development'),copy('构建快速、易管理的网站，为各种设备优化体验。','Building fast, no-code websites that are easy to manage and optimized for every device.')],
 [copy('品牌识别','Brand Identity'),copy('从标志到色彩，用完整的视觉系统，让品牌一眼被认出。','Cohesive visual systems — from logos to colors — make your brand instantly recognizable.')],
 [copy('设计咨询','Design Consultation'),copy('用策略建议，帮助你规划、打磨并落实设计构想。','Offering strategic guidance to help you plan, refine, and execute your design ideas effectively.')],
]
export const process = [
 copy('每一个好设计都始于共情。深入理解问题，发现决定方向的关键洞察。','Every great design starts with empathy. I dive deep into the problem to uncover insights that shape the foundation.'),
 copy('融合策略、可用性与视觉叙事，让体验直觉自然，也独具个性。','I blend strategy, usability, and visual storytelling to design experiences that feel intuitive and look distinct.'),
 copy('通过反馈、测试和迭代，确保设计在真实世界中同样有效。','Through feedback, testing, and iteration, I ensure the design works in the real world — not just on Figma.'),
 copy('从概念一路陪伴到上线，构建可扩展的设计系统，保持跨产品的品牌一致性。','I guide projects from concept to launch, helping teams build scalable design systems and maintain consistent, well-crafted brand experiences across products.'),
]
export const faq = [
 [copy('我们如何开始合作？','How do we get started?'),copy('先介绍你的项目、目标与时间安排，再共同确认合作范围。此演示表单只做本地校验，不会发送或保存信息。','Start by sharing your project, goals, and timeline, then we can define the scope together. This demo form validates locally and does not send or save information.')],
 [copy('可以重新设计现有网站或应用吗？','Can you redesign my existing website or app?'),copy('可以。从分析现有体验入手，保留有效的部分，改进关键用户流程与视觉表达。','Yes. I review the existing experience, preserve what works, and refine the core user flows and visual design.')],
 [copy('你也负责开发吗？','Do you also handle development or just design?'),copy('提供设计与网站开发服务，具体交付内容在项目开始前共同确认。','I offer design and website development. We agree on the deliverables before starting the project.')],
 [copy('你使用哪些设计工具？','What tools do you use for design?'),copy('使用 Figma 进行界面、原型与设计系统工作，并根据项目需要选择开发工具。','I use Figma for interfaces, prototypes, and design systems, with development tools selected for the project.')],
 [copy('可以追加修改吗？','Can I request additional revisions?'),copy('可以。先对照已确认的范围讨论反馈，额外工作会明确安排与费用后再进行。','Yes. We review feedback against the agreed scope and discuss timing and costs for any additional work before proceeding.')],
]
export const testimonials = [
 ['C5JEZM3Q2De1KeV9iBE8mB7wlRY','4.9',copy('他真正理解了我的愿景，并将其变成有影响力的设计，成果远超预期。','Alex truly understood my vision & turned it into impactful designs, results went beyond my expectations!')],
 ['0KUb3KY8ttwerFLCzKGXlij29ao','5.0',copy('从构想到落地，每一步都清晰高效，最终成果令人惊喜。','Alex truly understood my vision and turned it into impactful designs, the results went beyond my expectations!')],
 ['gUS7IiAItPt19RwnJ61B9uRKg','4.6',copy('作为小企业经营者，我很珍惜这样轻松、顺畅的合作体验。','As a small business owner, I appreciated how stress-free Alex Morgan made the process.')],
 ['QQLXFwiAzPVBXNZXEeEoUZafLc','5.0',copy('清晰的引导与出色的设计，让整个过程毫不费力。','As a small business owner, the entire process felt effortless thanks to Alex’s clear guidance & excellence.')],
 ['etfhEWMWsFUDsPklgewErMtFPk','4.8',copy('经营小企业充满挑战，但这次设计合作一直顺畅、安心。','Running a small business is challenging, but Alex Morgan made this experience smooth and completely hassle-free.')],
] as const
