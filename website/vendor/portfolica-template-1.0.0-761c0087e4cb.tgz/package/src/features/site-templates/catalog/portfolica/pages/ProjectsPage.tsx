import type {SiteTemplatePageProps} from '../../../types'
import {Shell} from '../components/Shell'
import {Heading,ProjectGrid,Hero,Services,FAQ,Contact} from '../components/Sections'
import {copy} from '../content/data'
export default function ProjectsPage(props:SiteTemplatePageProps){const l=props.locale??'zh';return <Shell {...props}><section className="pf-page-heading pf-container"><Heading eyebrow={copy('作品','Projects')[l]} title={copy('作品与案例研究','Projects & case studies')[l]}/><p>{copy('完整呈现不同项目与设计领域中的实践。','Complete view of my work across different projects & disciplines.')[l]}</p></section><ProjectGrid {...props} all/><Hero {...props} compact/><Services locale={l}/><FAQ locale={l}/><Contact locale={l}/></Shell>}
