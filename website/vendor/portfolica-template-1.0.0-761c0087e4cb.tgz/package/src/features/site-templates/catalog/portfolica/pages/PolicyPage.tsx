'use client'
import {usePathname} from 'next/navigation'
import type {SiteTemplatePageProps} from '../../../types'
import {Shell} from '../components/Shell'
import {Title} from '../components/Motion'
import {copy} from '../content/data'
const sections=[
 [copy('隐私与信息保护','Privacy and information protection'),copy('你的隐私很重要。本模板是作品集演示，联系与订阅表单仅在浏览器中校验，不会发送或保存个人信息。若将来接入真实服务，需先明确数据用途、保存期限和处理方。','Your privacy matters. This portfolio is a demonstration. Contact and newsletter forms validate in the browser and do not send or save personal information. Any future connected service must disclose its purpose, retention period, and processors.')],
 [copy('数据权利','Your Data Rights'),copy('在正式服务中，你可以请求查看、更正或删除已提供的个人信息。此演示不创建账号，也不接入分析、付款或持久化数据服务。','For an operational service, you may request a copy, correction, or deletion of the personal information you have shared. This demo does not create accounts or connect to analytics, payment, or persistent data services.')],
 [copy('退款政策','Refund Policy'),copy('此演示没有购买、付款或交付流程。如需开展真实数字产品销售，应另行明确商品说明、支持渠道、退款条件与争议处理方式。','This demo has no purchase, payment, or fulfillment flow. Any future digital product sales must define product descriptions, support channels, refund eligibility, and dispute handling.')],
 [copy('会员取消','Membership Cancellation'),copy('此模板不提供真实会员服务。如果后续接入订阅，应提供明确的取消入口、处理时限与确认通知。','This template does not provide an operational membership service. Any future subscription must include a clear cancellation process, processing time, and confirmation.')],
]
export default function PolicyPage(props:SiteTemplatePageProps){const l=props.locale??'zh',terms=usePathname().endsWith('terms-conditions');return <Shell {...props}><article className="pf-policy pf-narrow pf-container"><small>{copy('更新于 2026 年 10 月 24 日','Updated October 24, 2026')[l]}</small><Title hero text={(terms?copy('服务条款','Terms & Conditions'):copy('隐私政策','Privacy Policy'))[l]}/>{sections.map(([title,body])=><section key={title.en}><h2>{title[l]}</h2><p>{body[l]}</p></section>)}</article></Shell>}
