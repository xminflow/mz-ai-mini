import type {SiteTemplate} from '../../types'
export const portfolicaTemplate:SiteTemplate={...{
  "id": "portfolica",
  "name": "Portfolica · 数字设计师作品集",
  "localizedNames": {
    "en": "Portfolica · Digital designer portfolio"
  },
  "sceneId": "brand-portfolio",
  "listed": false,
  "tags": [
    "设计师作品集",
    "橙灰极简",
    "逐字模糊动效",
    "双语",
    "PC / iPad / H5"
  ],
  "summary": "数字设计师作品集，包含关于、6 个项目案例、服务、评价、流程、常见问题、联系与政策页面。",
  "accentColor": "#ff4b18",
  "cover": "/templates/portfolica/screenshots/desktop-home.webp",
  "screenshots": [
    {
      "src": "/templates/portfolica/screenshots/desktop-home.webp",
      "alt": "Portfolica desktop home",
      "device": "desktop",
      "width": 1440,
      "height": 1000
    },
    {
      "src": "/templates/portfolica/screenshots/desktop-projects.webp",
      "alt": "Portfolica desktop projects",
      "device": "desktop",
      "width": 1440,
      "height": 1000
    },
    {
      "src": "/templates/portfolica/screenshots/desktop-case.webp",
      "alt": "Portfolica desktop case",
      "device": "desktop",
      "width": 1440,
      "height": 1000
    },
    {
      "src": "/templates/portfolica/screenshots/desktop-contact.webp",
      "alt": "Portfolica desktop contact",
      "device": "desktop",
      "width": 1440,
      "height": 1000
    },
    {
      "src": "/templates/portfolica/screenshots/tablet-home.webp",
      "alt": "Portfolica tablet home",
      "device": "tablet",
      "width": 834,
      "height": 1180
    },
    {
      "src": "/templates/portfolica/screenshots/tablet-projects.webp",
      "alt": "Portfolica tablet projects",
      "device": "tablet",
      "width": 834,
      "height": 1180
    },
    {
      "src": "/templates/portfolica/screenshots/tablet-case.webp",
      "alt": "Portfolica tablet case",
      "device": "tablet",
      "width": 834,
      "height": 1180
    },
    {
      "src": "/templates/portfolica/screenshots/tablet-contact.webp",
      "alt": "Portfolica tablet contact",
      "device": "tablet",
      "width": 834,
      "height": 1180
    },
    {
      "src": "/templates/portfolica/screenshots/mobile-home.webp",
      "alt": "Portfolica mobile home",
      "device": "mobile",
      "width": 390,
      "height": 844
    },
    {
      "src": "/templates/portfolica/screenshots/mobile-projects.webp",
      "alt": "Portfolica mobile projects",
      "device": "mobile",
      "width": 390,
      "height": 844
    },
    {
      "src": "/templates/portfolica/screenshots/mobile-case.webp",
      "alt": "Portfolica mobile case",
      "device": "mobile",
      "width": 390,
      "height": 844
    },
    {
      "src": "/templates/portfolica/screenshots/mobile-contact.webp",
      "alt": "Portfolica mobile contact",
      "device": "mobile",
      "width": 390,
      "height": 844
    }
  ]
},surfaces:[{id:'site',name:'作品集官网',platform:'pc',locales:['zh','en'],pages:[{slug:"",title:"首页",localizedTitles:{en:"Home"},load:()=>import('./pages/HomePage')},
{slug:"about",title:"关于",localizedTitles:{en:"About"},load:()=>import('./pages/AboutPage')},
{slug:"all-projects",title:"全部作品",localizedTitles:{en:"All projects"},load:()=>import('./pages/ProjectsPage')},
{slug:"project-details/connecto",title:"connecto",localizedTitles:{en:"connecto"},load:()=>import('./pages/ProjectPage')},
{slug:"project-details/paynest",title:"paynest",localizedTitles:{en:"paynest"},load:()=>import('./pages/ProjectPage')},
{slug:"project-details/shopora",title:"shopora",localizedTitles:{en:"shopora"},load:()=>import('./pages/ProjectPage')},
{slug:"project-details/edunova",title:"edunova",localizedTitles:{en:"edunova"},load:()=>import('./pages/ProjectPage')},
{slug:"project-details/medilink",title:"medilink",localizedTitles:{en:"medilink"},load:()=>import('./pages/ProjectPage')},
{slug:"project-details/travelio",title:"travelio",localizedTitles:{en:"travelio"},load:()=>import('./pages/ProjectPage')},
{slug:"contact",title:"联系",localizedTitles:{en:"Contact"},load:()=>import('./pages/ContactPage')},
{slug:"404",title:"页面未找到",localizedTitles:{en:"Page not found"},load:()=>import('./pages/NotFoundPage')},
{slug:"legal/privacy-policy",title:"隐私政策",localizedTitles:{en:"Privacy policy"},load:()=>import('./pages/PolicyPage')},
{slug:"legal/terms-conditions",title:"服务条款",localizedTitles:{en:"Terms & conditions"},load:()=>import('./pages/PolicyPage')}]}]}
