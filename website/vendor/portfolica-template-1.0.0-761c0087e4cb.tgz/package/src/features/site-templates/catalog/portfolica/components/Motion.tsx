'use client'
import { Children, useRef, useEffect, type ReactNode } from 'react'
import { motion, useReducedMotion, useAnimationFrame, useMotionValue } from 'framer-motion'

export const motionLog=(event:string,context:Record<string,string|number|boolean>={})=>{if(process.env.NODE_ENV==='development')console.debug('[portfolica]',event,context)}

/** 原站按字符触发模糊消散，不能以整个标题的淡入替代。空格保留断行语义。 */
export function Title({text,hero=false}:{text:string;hero?:boolean}) {
 const reduced=useReducedMotion()
 const words=text.split(' ');let index=0
 const Tag=hero?motion.h1:motion.h2
 return <Tag className={hero?'pf-display':'pf-title'} aria-label={text} initial="hidden" whileInView="shown" viewport={{once:true,amount:1}} onViewportEnter={()=>motionLog('title-enter',{characters:text.length})}>
  {words.map((word,w)=><span className="pf-word" aria-hidden="true" key={w}>{Array.from(word).map(char=>{const i=index++;return <motion.span key={i} style={{display:'inline-block'}} variants={{hidden:{opacity:reduced?1:0,filter:reduced?'blur(0px)':'blur(10px)',y:reduced?0:10},shown:{opacity:1,filter:'blur(0px)',y:0,transition:{type:'spring',duration:1,bounce:0,delay:reduced?0:i*.02}}}}>{char}</motion.span>})}{w<words.length-1?'\u00a0':''}</span>)}
 </Tag>
}
export function Reveal({children,delay=0,distance=20,className='',physics=false}:{children:ReactNode;delay?:number;distance?:number;className?:string;physics?:boolean}) {
 const reduced=useReducedMotion()
 return <motion.div className={className} initial={{opacity:reduced?1:0,y:reduced?0:distance}} whileInView={{opacity:1,y:0}} viewport={{once:true,amount:.15}} transition={physics?{type:'spring',stiffness:80,damping:30,mass:1,delay:reduced?0:delay}:{type:'spring',duration:1.5,bounce:0,delay:reduced?0:delay}}>{children}</motion.div>
}
/** 速度按像素/秒计算，响应式改变卡宽不会改变循环节奏。离屏与后台暂停。 */
export function Ticker({children,speed=40,className='',label}:{children:ReactNode;speed?:number;className?:string;label:string}) {
 const reduced=useReducedMotion(),x=useMotionValue(0),group=useRef<HTMLDivElement>(null),visible=useRef(true),paused=useRef(false),width=useRef(0)
 const items=Children.toArray(children)
 useEffect(()=>{
  const element=group.current;if(!element)return
  const measure=()=>{width.current=element.getBoundingClientRect().width};measure()
  const resize=new ResizeObserver(measure);resize.observe(element)
  const observer=new IntersectionObserver(([entry])=>{visible.current=entry.isIntersecting});observer.observe(element)
  return()=>{resize.disconnect();observer.disconnect()}
 },[])
 useAnimationFrame((_,delta)=>{if(reduced||!visible.current||paused.current||document.hidden||!width.current)return;const next=x.get()-speed*Math.min(delta,64)/1000;x.set(next<=-width.current?next+width.current:next)})
 const pause=(value:boolean)=>{paused.current=value;motionLog('ticker-pause',{label,paused:value})}
 return <div className={'pf-ticker '+className} aria-label={label} onMouseEnter={()=>pause(true)} onMouseLeave={()=>pause(false)} onFocusCapture={()=>pause(true)} onBlurCapture={e=>{if(!e.currentTarget.contains(e.relatedTarget))pause(false)}}>
  <motion.div className="pf-drag" drag={reduced?false:'x'} dragConstraints={{left:0,right:0}} dragElastic={.15} dragSnapToOrigin onDragStart={()=>pause(true)} onDragEnd={()=>{pause(false);motionLog('ticker-release',{label})}} transition={{type:'spring',stiffness:180,damping:30}}>
   <motion.div className="pf-track" style={{x:reduced?0:x}}><div className="pf-group" ref={group}>{items}</div>{!reduced&&<div className="pf-group" aria-hidden="true" inert>{items}</div>}</motion.div>
  </motion.div>
 </div>
}
