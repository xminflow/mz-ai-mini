import type {SiteTemplatePageProps} from '../../../types'
import {Shell} from '../components/Shell'
import {Contact,FAQ} from '../components/Sections'
export default function ContactPage(props:SiteTemplatePageProps){return <Shell {...props}><Contact locale={props.locale} page/><FAQ locale={props.locale}/></Shell>}
