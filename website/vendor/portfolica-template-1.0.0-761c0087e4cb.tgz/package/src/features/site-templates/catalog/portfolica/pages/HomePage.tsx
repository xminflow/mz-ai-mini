import type {SiteTemplatePageProps} from '../../../types'
import {Shell} from '../components/Shell'
import {Hero,ProjectTicker,AboutSection,Clients,ProjectGrid,Stats,Testimonials,Process,Services,FAQ,Contact} from '../components/Sections'
export default function HomePage(props:SiteTemplatePageProps){return <Shell {...props}><Hero {...props}/><ProjectTicker {...props}/><AboutSection locale={props.locale}/><Clients locale={props.locale}/><ProjectGrid {...props}/><Stats locale={props.locale}/><Testimonials locale={props.locale}/><Process locale={props.locale}/><Services locale={props.locale}/><FAQ locale={props.locale}/><Contact locale={props.locale}/></Shell>}
