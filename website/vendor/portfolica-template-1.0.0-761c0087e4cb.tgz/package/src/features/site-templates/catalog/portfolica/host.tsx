'use client'
import { createContext, useContext, type ReactNode } from 'react'
import type { TemplateLocale } from '../../types'
export interface PortfolicaHostOptions {
 brandName?: Record<TemplateLocale,string>; logo?: string; lightLogo?: string;
 marketplaceHref?: string; marketplaceLabel?: Record<TemplateLocale,string>; marketplaceAriaLabel?: Record<TemplateLocale,string>; filing?: ReactNode;
}
const Context=createContext<PortfolicaHostOptions>({})
/** 品牌与市场入口由消费方注入，业务源码不依赖消费方目录。 */
export function PortfolicaHostProvider({children,...options}:PortfolicaHostOptions & {children:ReactNode}) {return <Context.Provider value={options}>{children}</Context.Provider>}
export const usePortfolicaHost=()=>useContext(Context)
