export const brand = { name: { zh:'艾历克斯 · 摩根', en:'Alex Morgan' }, first: {zh:'艾历克斯',en:'Alex'}, last:{zh:'摩根',en:'Morgan'}, copyrightYear:2026 }
