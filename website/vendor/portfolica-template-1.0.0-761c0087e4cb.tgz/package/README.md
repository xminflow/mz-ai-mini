# Portfolica 数字设计师作品集

独立 Next.js / React / TypeScript 模板。包含首页、关于、全部作品、六个案例、联系、404 与两份政策，共 13 页、26 条中英文路径。默认中文，英文以 /en 为前缀。品牌、内容、主题、组件、页面与路由分别维护。

## 环境与运行

Node 版本见 .nvmrc，pnpm 9.15.4。无需秘密配置。复制 .env.example 按需设置 PORT、HOSTNAME；默认 http://127.0.0.1:43346。

执行 pnpm install --frozen-lockfile，pnpm dev；Ctrl+C 停止本次服务。检查：pnpm typecheck、pnpm lint、pnpm test、pnpm build；生产服务 pnpm start。pnpm bundle 生成通用运行包，不自动上传或部署。

## 能力与限制

已实现逐字模糊入场、错峰弹簧、滚动触发、作品与评价循环、悬浮卡片、手机菜单、FAQ 高度动画、双语客户端导航和本地表单校验。遵守减少动态效果。实际验收及差异见 .tpl/docs/VERIFICATION.md 和 MOTION.md。

联系与订阅表单仅本地校验，不发送、不保存、不付款、不预约。没有后台、账号或数据库。素材商业再分发权未确认，listed=false。截图与构建通过不等于完整动效复刻通过。

## 修改与交付

固定首读 .tpl/README.md、template.json、project.json。品牌入口 src/features/site-templates/catalog/portfolica/config/brand.ts；双语数据 content/data.ts；主题 theme.css；组件 components/；页面 pages/。维护双语内容与主题令牌，保留真实状态反馈和无障碍属性。exports 提供 ./template、./host；消费方通过 HostProvider 注入品牌，无须复制页面。

提交前检查 Git 差异，不提交依赖、缓存、日志、私密配置或构建产物。许可与素材记录见 .tpl/docs/LICENSE.md 和 ASSETS.md。

