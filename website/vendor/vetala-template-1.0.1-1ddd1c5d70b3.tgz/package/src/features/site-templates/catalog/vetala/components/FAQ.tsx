'use client'
import {AnimatePresence,motion} from 'framer-motion'
import {useState} from 'react'
import {faqs,text,type Locale} from '../content/site'
export function FAQ({locale}:{locale:Locale}){
 const [open,setOpen]=useState<number|null>(2)
 return <section className="vt-section vt-container vt-faq" id="faq"><div><span className="vt-pill">FAQ</span><h2>{locale==='zh'?'你关心的问题\n在这里找到答案':'Get All Your Important\nQuestions Fully Answered Here'}</h2><p>{locale==='zh'?'关于 AI 员工、工作方式与演示边界的清晰说明。':'Clear answers about AI employees, workflows and demonstration boundaries.'}</p></div><div>{faqs.map((item,i)=><div className={`vt-faq-item ${open===i?'is-open':''}`} key={i}><h3><button onClick={()=>{setOpen(open===i?null:i);console.debug('[vetala:faq] toggled',{index:i,expanded:open!==i})}} aria-expanded={open===i} aria-controls={`vt-faq-${i}`}>{text(item.q,locale)}<motion.span animate={{rotate:open===i?45:0}} transition={{duration:.3}} aria-hidden="true">+</motion.span></button></h3><AnimatePresence initial={false}>{open===i&&<motion.div id={`vt-faq-${i}`} initial={{height:0,opacity:0}} animate={{height:'auto',opacity:1}} exit={{height:0,opacity:0}} transition={{duration:.3,ease:'easeInOut'}}><p>{text(item.a,locale)}</p></motion.div>}</AnimatePresence></div>)}</div></section>
}
