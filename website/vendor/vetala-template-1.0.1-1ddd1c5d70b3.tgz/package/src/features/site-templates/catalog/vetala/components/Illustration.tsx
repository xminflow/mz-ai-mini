import type {Locale} from '../content/site'
export function CampaignCaption(){return <div className="vt-campaign-caption" aria-hidden="true"><div><b>✦</b><span>创建营销活动计划</span><b>✓</b></div><div><span>AI 营销员工正在工作</span><i/><small>78% 已完成</small></div></div>}
export function Illustration({index,locale}:{index:number;locale:Locale}){
 if(locale==='en')return <img src={`/templates/vetala/media/card-${index+1}.png`} alt={index===2?'Content performance illustration':'Growth opportunity illustration'}/>
 if(index===3)return <div className="vt-flow"><div className="vt-flow-row"><span>提升广告获客表现？</span><b>+1.2K 线索</b></div><div className="vt-flow-row"><span>改善邮件打开率？</span><b>+18% 打开率</b></div><div className="vt-flow-result"><b>✓</b><div>高影响力增长机会<small>建议优先采取行动</small></div></div></div>
 return <div className="vt-chart"><div className="vt-chart-label"><span>内容表现</span><b>28% 更多互动</b></div><div className="vt-bars">{[95,68,40,23].map((height,j)=><i key={j} style={{height:`${height}%`,background:['linear-gradient(#7143da,#5433af)','linear-gradient(#2867d4,#1541a8)','linear-gradient(#389a50,#247737)','linear-gradient(#bbb,#999)'][j]}}/>)}</div><div className="vt-chart-label">{['博客','落地页','广告文案','邮件'].map(label=><span key={label}>{label}</span>)}</div></div>
}
