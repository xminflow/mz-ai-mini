export type Locale = 'zh' | 'en'
export type Copy = { zh: string; en: string }
export const text = (value: Copy, locale: Locale) => value[locale]
export const copy = {
  hero: {zh:'你的 AI 员工\n专注营销增长',en:'Your AI employee\nin Marketing'},
  intro: {zh:'让 AI 员工负责营销活动的执行与优化，让团队专注于更有价值的增长。',en:'Let AI employees handle campaign execution and optimization while your team focuses on growth.'},
  hire: {zh:'聘请 AI 员工',en:'Hire your AI agent'}, explore:{zh:'探索产品功能',en:'Explore features'},
  featureTitle:{zh:'更聪明的营销\n更确定的增长',en:'Smarter Marketing.\nBigger Growth.'},
  featureIntro:{zh:'规划、创作、优化与自动化，让 AI 员工成为团队的增长伙伴。',en:'AI employees that plan, create, optimize, and automate marketing—so your team can focus on growth.'},
  about:{zh:'你的 AI 员工能够规划、执行并优化每一次营销活动。创作内容、自动化工作流、分析营销表现，与自主协作的 AI 智能体一起加速增长。',en:'Your AI employee that plans, executes, and optimizes every marketing campaign. Create content, automate workflows, analyze performance, and accelerate growth with autonomous AI agents.'},
  demo:{zh:'查看工作方式',en:'See how it works'},
}
export const nav = [
  {title:{zh:'产品',en:'Product'},slug:'features'}, {title:{zh:'解决方案',en:'Solutions'},slug:'#comparison'},
  {title:{zh:'AI 员工',en:'AI Agent'},slug:'#metrics'}, {title:{zh:'定价',en:'Pricing'},slug:'#pricing'},
  {title:{zh:'资源',en:'Resources'},slug:'blog'},
]
export const features = [
  {title:{zh:'自主运行的 AI 营销活动',en:'Autonomous AI Campaigns'},body:{zh:'让 AI 员工构建、排期并执行高效的全渠道营销活动，将策略顺畅地变为行动。',en:'Let AI employees build, schedule, and execute high-performing omni-channel marketing initiatives seamlessly.'}},
  {title:{zh:'实时营销洞察',en:'Real-Time Marketing Insights'},body:{zh:'捕捉实时客户意图与营销信号，在关键时刻作出有依据的决策。',en:'Capture live customer intent and campaign signals—so you can act on what matters most.'}},
  {title:{zh:'内容表现信号',en:'Content Performance Signals'},body:{zh:'结合真实数据和 AI 洞察，改进内容、落地页、广告与邮件。',en:'Use real data and AI insights to improve content, landing pages, ads, and emails.'}},
  {title:{zh:'发现增长机会',en:'Campaign & Growth Opps'},body:{zh:'找到有潜力的机会，优先投入真正带来影响的营销行动。',en:'Identify winning opportunities and prioritize what drives the most impact.'}},
]
export const faqs = [
  {q:{zh:'可以与现有软件集成吗？',en:'Can it integrate with your existing software?'},a:{zh:'模板展示了工具集成的使用方式。实际连接工作区、客户平台和自定义工具，需要配置相应服务及权限；此演示不会访问任何真实账户。',en:'This template demonstrates integrations with workspaces, client platforms and custom tools. Live connections require service configuration and permissions; this demo never accesses real accounts.'}},
  {q:{zh:'多久可以开始使用？',en:'How fast can I get started?'},a:{zh:'你可以先浏览功能与方案，再通过联系表单整理需求。当前站点为演示，不会创建真实 AI 员工或开通付费服务。',en:'Explore the features and plans, then use the contact form to outline your needs. This demonstration does not provision live AI employees or paid services.'}},
  {q:{zh:'我的数据安全吗？',en:'Is my data fully secure?'},a:{zh:'演示表单只在浏览器中校验，不上传、不持久化。正式产品需单独落实加密、访问控制、审计与数据保留策略。',en:'Demo forms validate locally in your browser without uploading or persisting data. A production product requires its own encryption, access controls, audit and retention policies.'}},
  {q:{zh:'AI 会接管团队的所有任务吗？',en:'Does this AI take over team tasks?'},a:{zh:'AI 的定位是协作伙伴，负责重复性、高频次工作。团队仍应掌握重要决策与发布审核。',en:'AI is a collaborative partner for repetitive, high-volume work. Your team retains control over important decisions and publishing reviews.'}},
  {q:{zh:'哪些团队适合使用？',en:'Which industries benefit most from this platform?'},a:{zh:'营销团队、创意代理机构、SaaS 公司，以及需要建立可重复增长流程的企业，都可以从这一工作方式中获得启发。',en:'Marketing teams, creative agencies, SaaS companies and enterprises building repeatable growth workflows can benefit from this approach.'}},
  {q:{zh:'如何安排 AI 员工与人的协作？',en:'How do AI employees collaborate with people?'},a:{zh:'先定义目标、品牌规则与审批节点，再让 AI 执行具体任务，并定期复核效果。所有对外发送和账户操作都应具有明确授权。',en:'Define goals, brand rules and approval checkpoints, then assign specific tasks and review results. External communications and account operations should have explicit authorization.'}},
]
export const advantages: Copy[] = [
  {zh:'围绕品牌定制的解决方案',en:'Tailored, brand-specific solutions'}, {zh:'价格透明，没有隐藏费用',en:'Clear pricing, no hidden fees'},
  {zh:'敏捷高效，减少等待',en:'Agile, efficient, no delays'}, {zh:'灵活合作，无长期绑定',en:'Flexible terms, no long contracts'}, {zh:'直接获得专业支持',en:'Direct access to experts'},
]
export const alternatives: Copy[] = [
  {zh:'千篇一律的通用方案',en:'Generic, one-size-fits-all'}, {zh:'模糊报告与意外成本',en:'Vague reports, surprise costs'},
  {zh:'繁琐流程，错过时机',en:'Slow processes, missed deadlines'}, {zh:'冗长合约，缺少弹性',en:'Locked into lengthy agreements'}, {zh:'标准化的客户对接',en:'Generic account managers'},
]
export const plans = [
  {name:{zh:'起步版',en:'Starter'},monthly:49,yearly:39,items:[{zh:'1 位 AI 营销员工',en:'1 AI Marketing Employee'},{zh:'最多 5 个营销活动',en:'Up to 5 Campaigns'},{zh:'内容生成',en:'Content Generation'},{zh:'基础分析',en:'Basic Analytics'},{zh:'邮件支持',en:'Email Support'}],annual:[{zh:'1 位专属 AI 专家',en:'1 Dedicated AI Specialist'},{zh:'最多 8 个活动',en:'Up to 8 active Campaigns (Bonus)'},{zh:'优先内容生成',en:'Priority Content Generation'},{zh:'每日效果报告',en:'Daily performance reports'},{zh:'优先邮件支持',en:'Priority Email Support'}]},
  {name:{zh:'增长版',en:'Growth'},monthly:149,yearly:119,items:[{zh:'5 位 AI 营销员工',en:'5 AI Marketing Employees'},{zh:'不限营销活动数量',en:'Unlimited Campaigns'},{zh:'多渠道执行',en:'Multi-Channel Execution'},{zh:'进阶数据分析',en:'Advanced Analytics'},{zh:'优先支持',en:'Priority Support'}],annual:[{zh:'6 位 AI 员工，含赠送席位',en:'6 AI Employees (1 Free Seat)'},{zh:'不限高级营销活动',en:'Unlimited Premium Campaigns'},{zh:'多渠道与自动化',en:'Multi-Channel + Automation'},{zh:'实时进阶洞察',en:'Real-time Advanced Insights'},{zh:'全天候专属优先支持',en:'24/7 Dedicated Priority Support'}]},
  {name:{zh:'企业版',en:'Enterprise'},monthly:299,yearly:239,items:[{zh:'不限 AI 员工数量',en:'Unlimited AI Employees'},{zh:'自定义集成',en:'Custom Integrations'},{zh:'高级安全功能',en:'Advanced Security'},{zh:'专属客户经理',en:'Dedicated Account Manager'},{zh:'自定义报告',en:'Custom Reporting'}],annual:[{zh:'不限员工与专属机器人',en:'Unlimited Employees + Dedicated Bot'},{zh:'不限自定义集成',en:'Unlimited Custom Integrations'},{zh:'企业安全工作流',en:'Enterprise security workflows'},{zh:'一对一专属客户经理',en:'1-on-1 Dedicated Account Manager'},{zh:'定时定制分析报告',en:'Custom scheduled analytics reporting'}]},
]
export const reviews = [
  {name:'James Carter',role:{zh:'营销经理',en:'Marketing Manager'},quote:{zh:'AI 营销员工改变了我们组织活动的方式。团队节省了时间，也能更清楚地看到结果。',en:'Vetala’s AI marketing employees have transformed how we run campaigns. We save time and see better results.'}},
  {name:'Sophia Lin',role:{zh:'内容策略师',en:'Content Strategist'},quote:{zh:'内容更贴近品牌语气，团队可以将精力集中在创意与策略，而不是重复执行。',en:'The content created by our AI employee is incredibly on-brand. Our social engagement has increased by 40%.'}},
  {name:'Noah Davis',role:{zh:'SEO 专家',en:'SEO Specialist'},quote:{zh:'将关键词优化和链接分析融入自动化工作流，让我们的日常协作更加从容。',en:'Automating keyword optimization and backlink analysis saved us hundreds of hours. Highly recommended!'}},
  {name:'Ethan Wong',role:{zh:'广告投放专家',en:'Paid Ads Specialist'},quote:{zh:'持续比较素材与预算，为我们提供了更有价值的优化线索。',en:'The AI constantly split tests creatives and budgets. Our cost-per-acquisition dropped significantly.'}},
  {name:'Olivia Bennett',role:{zh:'品牌策略师',en:'Brand Strategist'},quote:{zh:'统一的品牌语气与风格，让每个渠道都能讲述同一个清晰的故事。',en:'A game-changer for brand consistency. The voice and tone are perfectly aligned with our values.'}},
  {name:'Lucas Vance',role:{zh:'增长负责人',en:'Growth Lead'},quote:{zh:'将活动执行交给可复用的流程，团队终于有时间思考下一步增长。',en:'Scale has never been this easy. We launched ten campaigns in a single day, entirely managed by AI.'}},
  {name:'Emma Watson',role:{zh:'数字公关经理',en:'Digital PR Manager'},quote:{zh:'更细致的个性化沟通，使我们的外联工作更有条理。',en:'Outreach campaigns are fully customized and personalized, boosting our response rate by 2.5x.'}},
]
export const articles = [
 {slug:'ai-marketing-team',title:{zh:'从工具到伙伴：构建 AI 营销团队',en:'From tools to teammates: building an AI marketing team'},category:{zh:'团队协作',en:'Teamwork'},intro:{zh:'从明确的目标与边界开始，让 AI 与人各展所长。',en:'Start with clear goals and boundaries so AI and people can do their best work.'},sections:[{zh:'先明确需要完成的工作，再选择自动化方式。将研究、创作、执行和复盘拆成清晰的任务，避免把一个模糊目标直接交给智能体。',en:'Define the work before selecting automation. Separate research, creation, execution and review into clear tasks rather than giving an agent an ambiguous goal.'},{zh:'建立品牌规则、素材来源和人工审批节点。对外发布与账户操作保持明确授权，让自动化始终可观察、可停止。',en:'Establish brand rules, asset sources and human approval checkpoints. Keep publishing and account operations explicitly authorized, observable and stoppable.'}]},
 {slug:'campaign-measurement',title:{zh:'让每一次营销优化都有据可依',en:'Make every campaign optimization measurable'},category:{zh:'增长洞察',en:'Growth insights'},intro:{zh:'从有意义的指标出发，建立持续学习的营销循环。',en:'Build a learning loop around metrics that matter.'},sections:[{zh:'点击量只是故事的一部分。将获客质量、转化效率与客户留存放在一起观察，才能判断活动是否带来真实价值。',en:'Clicks tell only part of the story. Observe lead quality, conversion efficiency and retention together to understand the value of a campaign.'},{zh:'每次实验只改变一个关键变量，记录样本、时间窗口与结果。不把演示数据当作真实业绩，也不把相关性误认为因果关系。',en:'Change one key variable per experiment and record samples, time windows and results. Do not treat demo data as real performance or correlation as causation.'}]},
 {slug:'connected-workflows',title:{zh:'用协作工作流连接你的营销工具',en:'Connect your marketing tools with collaborative workflows'},category:{zh:'产品实践',en:'Product practice'},intro:{zh:'减少工具之间的割裂，让信息带着上下文流动。',en:'Reduce fragmentation and let information travel with its context.'},sections:[{zh:'在连接工具之前，先约定数据的来源、用途、权限与保留时间。共享必要信息，同时避免将敏感信息写入日志。',en:'Before connecting tools, agree on data sources, purposes, permissions and retention. Share necessary context without writing sensitive information to logs.'},{zh:'为失败设计明确的状态与人工介入路径。可重复执行的任务仍需考虑幂等与去重，确保协作不会产生重复发送。',en:'Design explicit failure states and human intervention paths. Repeatable tasks still need idempotency and deduplication to prevent duplicate sends.'}]},
]
