import type {SiteTemplatePageProps} from '../../../types'
import {Shell} from '../components/Shell'
import {Hero} from '../components/Hero'
import {About} from '../components/AboutSection'
import {Comparison} from '../components/ComparisonSection'
import {Features} from '../components/FeatureSection'
import {Metrics} from '../components/Metrics'
import {Testimonials} from '../components/ReviewSection'
import {Integrations} from '../components/Integrations'
import {Pricing} from '../components/Pricing'
import {FAQ} from '../components/FAQ'
import {CTA} from '../components/CTA'
export default function HomePage({locale='zh',basePath}:SiteTemplatePageProps){return <Shell locale={locale} basePath={basePath} hero><Hero locale={locale} basePath={basePath}/><About locale={locale} basePath={basePath}/><Comparison locale={locale}/><Features locale={locale} basePath={basePath}/><Metrics locale={locale} basePath={basePath}/><Testimonials locale={locale}/><Integrations locale={locale}/><Pricing locale={locale} basePath={basePath}/><FAQ locale={locale}/><CTA locale={locale} basePath={basePath}/></Shell>}

