'use client'
import {useState} from 'react'
import {advantages,alternatives,text,type Locale} from '../content/site'
import {useVetalaHost} from '../host'
import {Reveal} from './Motion'
function MagnifyRow({label,positive}:{label:string;positive:boolean}){
 const [point,setPoint]=useState<{x:number;y:number}|null>(null)
 return <div className="vt-compare-row" onPointerMove={event=>{if(event.pointerType!=='mouse'||innerWidth<640)return;const rect=event.currentTarget.getBoundingClientRect();setPoint({x:event.clientX-rect.left,y:event.clientY-rect.top})}} onPointerLeave={()=>setPoint(null)}><div className={point?'is-magnified':''}><span aria-hidden="true">{positive?'✓':'×'}</span>{label}</div>{point&&<div className="vt-magnifier" style={{left:point.x-32,top:point.y-32}} aria-hidden="true"><div style={{left:32-1.5*point.x,top:32-1.5*point.y}}><span>{positive?'✓':'×'}</span>{label}</div></div>}</div>
}
export function Comparison({locale}:{locale:Locale}){const host=useVetalaHost();return <section className="vt-section vt-tint" id="comparison"><div className="vt-container"><div className="vt-section-heading"><h2>{locale==='zh'?'为何选择\n不一样的增长方式':'What sets us\napart from others'}</h2><p>{locale==='zh'?'从执行到优化，由 AI 员工驱动。':'From execution to optimization, powered by AI employees.'}</p></div><Reveal className="vt-compare"><div className="vt-compare-positive"><div className="vt-brand"><img src={host.lightLogo||host.logo} alt=""/>{host.brandName[locale]}</div>{advantages.map((label,i)=><MagnifyRow key={i} label={text(label,locale)} positive/>)}</div><div><h3>{locale==='zh'?'传统代理机构':'Other Agencies'}</h3>{alternatives.map((label,i)=><MagnifyRow key={i} label={text(label,locale)} positive={false}/>)}</div></Reveal></div></section>}
