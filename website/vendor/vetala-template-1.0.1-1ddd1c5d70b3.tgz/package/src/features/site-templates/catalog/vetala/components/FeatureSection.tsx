'use client'
import {useState} from 'react'
import Link from 'next/link'
import {copy,features,text,type Locale} from '../content/site'
import {href} from './Shell'
import {ScrollFocus} from './Motion'
import {CampaignCaption,Illustration} from './Illustration'
export function Features({locale,basePath}:{locale:Locale;basePath:string}){
 const [active,setActive]=useState(0)
 return <section className="vt-section vt-container" id="features"><ScrollFocus><div className="vt-section-heading"><h2>{text(copy.featureTitle,locale)}</h2><p>{text(copy.featureIntro,locale)}</p></div><div className="vt-feature-grid">{features.map((item,i)=><article key={i} className={`vt-feature-card ${i<2?'vt-feature-switch':''} ${active===i?'is-active':''}`} onMouseEnter={()=>{if(i<2)setActive(i)}}><div className="vt-feature-content"><span className="vt-eyebrow">0{i+1}</span><h3>{text(item.title,locale)}</h3><p>{text(item.body,locale)}</p>{i<2&&<Link href={href(basePath,'contact')} className="vt-button vt-button-outline">{text(copy.demo,locale)}</Link>}</div>{i<2?<button className="vt-feature-art" onClick={()=>setActive(active===i?-1:i)} aria-pressed={active===i} aria-label={locale==='zh'?`切换${text(item.title,locale)}展示`:`Toggle ${text(item.title,locale)} preview`}><img src={`/templates/vetala/media/card-${i+1}.png`} alt=""/>{locale==='zh'&&i===0&&<CampaignCaption/>}<span>{locale==='zh'?'点击查看功能说明':'Tap for feature details'}</span></button>:<div className="vt-feature-illustration" aria-label={locale==='zh'?'数据面板演示':'Illustrative data panel'}><Illustration index={i} locale={locale}/></div>}</article>)}</div></ScrollFocus></section>
}
