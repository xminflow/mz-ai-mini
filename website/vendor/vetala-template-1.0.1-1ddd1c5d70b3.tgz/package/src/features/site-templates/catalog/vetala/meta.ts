import type {SiteTemplate,TemplateScreenshot} from '../../types'
const shots:TemplateScreenshot[]=(['desktop','tablet','mobile'] as const).flatMap(device=>['home','features','blog','contact'].map(page=>({src:`/templates/vetala/screenshots/${device}-${page}.webp`,alt:`Vetala ${device} ${page}`,device,width:{desktop:1440,tablet:834,mobile:390}[device],height:{desktop:1000,tablet:1180,mobile:844}[device]})))
export const vetalaTemplate:SiteTemplate={id:'vetala',gitUrl:'https://github.com/weelume/vetala-template',name:'Vetala · AI 营销员工',localizedNames:{en:'Vetala · AI marketing employees'},sceneId:'corporate-site',listed:false,tags:['AI','营销','动态视频','智能体','中英文'],summary:'AI 营销员工整站模板，包含指针控制视频、滚动视频展开、弹性评价轮播、工具轨道、可拖拽徽章与双语内容。',accentColor:'#21c59f',cover:'/templates/vetala/screenshots/desktop-home.webp',screenshots:shots as [TemplateScreenshot,...TemplateScreenshot[]],surfaces:[{id:'site',name:'AI 营销官网',platform:'pc',locales:['zh','en'],pages:[
 {slug:'',title:'首页',localizedTitles:{en:'Home'},load:()=>import('./pages/HomePage')},
 {slug:'features',title:'产品功能',localizedTitles:{en:'Features'},load:()=>import('./pages/FeaturesPage')},
 {slug:'blog',title:'增长日志',localizedTitles:{en:'Journal'},load:()=>import('./pages/BlogPage')},
 {slug:'blog/ai-marketing-team',title:'构建 AI 营销团队',localizedTitles:{en:'Building an AI marketing team'},load:()=>import('./pages/TeamArticlePage')},
 {slug:'blog/campaign-measurement',title:'衡量营销优化',localizedTitles:{en:'Measuring campaign optimization'},load:()=>import('./pages/MeasurementArticlePage')},
 {slug:'blog/connected-workflows',title:'协作工作流',localizedTitles:{en:'Connected workflows'},load:()=>import('./pages/WorkflowArticlePage')},
 {slug:'contact',title:'联系',localizedTitles:{en:'Contact'},load:()=>import('./pages/ContactPage')},
 {slug:'privacy',title:'隐私说明',localizedTitles:{en:'Privacy notice'},load:()=>import('./pages/PrivacyPage')},
 {slug:'terms',title:'使用说明',localizedTitles:{en:'Terms'},load:()=>import('./pages/TermsPage')},
]}]}
