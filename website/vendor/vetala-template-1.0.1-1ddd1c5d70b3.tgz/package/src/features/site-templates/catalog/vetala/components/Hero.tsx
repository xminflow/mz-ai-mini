'use client'
import {motion,useReducedMotion} from 'framer-motion'
import {useEffect,useRef,useState} from 'react'
import Link from 'next/link'
import {copy,text,type Locale} from '../content/site'
import {href,Nav} from './Shell'
import {ease} from './Motion'

export function Hero({locale,basePath}:{locale:Locale;basePath:string}){
 const left=useRef<HTMLVideoElement>(null),right=useRef<HTMLVideoElement>(null),cursor=useRef<HTMLDivElement>(null)
 const pointer=useRef(.5),side=useRef<'left'|'right'>('right'),reduced=useReducedMotion()
 const [mobile,setMobile]=useState(false),[active,setActive]=useState<'left'|'right'>('right'),[error,setError]=useState(false)
 useEffect(()=>{const media=matchMedia('(max-width:1023px)');const update=()=>setMobile(media.matches);update();media.addEventListener('change',update);return()=>media.removeEventListener('change',update)},[])
 useEffect(()=>{
  const a=left.current,b=right.current
  if(!a||!b)return
  if(reduced){a.pause();b.pause();return}
  if(mobile){const video=active==='left'?a:b;const other=active==='left'?b:a;let current=true;other.pause();video.currentTime=0;video.play().then(()=>{if(current)setError(false)}).catch(reason=>{const name=reason instanceof Error?reason.name:'unknown';if(!current){console.debug('[vetala:hero] obsolete playback cancelled',{name});return}console.error('[vetala:hero] playback failed',{name});setError(true)});return()=>{current=false;video.pause()}}
  a.pause();b.pause()
  let frame=0
  /** 桌面采用左右两条视频按指针归一化位置 seek；中线保留 5% 死区防止抖动。 */
  const tick=()=>{
   const x=pointer.current
   if(x<.45)side.current='left';else if(x>.55)side.current='right'
   a.style.opacity=side.current==='left'?'1':'0';b.style.opacity=side.current==='right'?'1':'0'
   const video=side.current==='left'?a:b
   const progress=side.current==='left'?Math.max(0,(.45-x)/.45):Math.max(0,(x-.55)/.45)
   if(Number.isFinite(video.duration)&&!video.seeking&&Math.abs(video.currentTime-progress*video.duration)>.035)video.currentTime=Math.min(Math.max(0,video.duration-.04),progress*video.duration)
   frame=requestAnimationFrame(tick)
  };frame=requestAnimationFrame(tick);return()=>cancelAnimationFrame(frame)
 },[active,mobile,reduced])
 const variants={hidden:{opacity:0,x:-30,y:-30},visible:{opacity:1,x:0,y:0,transition:{type:'spring' as const,damping:14,stiffness:150}}}
 const title=text(copy.hero,locale)
 return <section className="vt-hero" onPointerMove={event=>{const rect=event.currentTarget.getBoundingClientRect();pointer.current=(event.clientX-rect.left)/rect.width;if(cursor.current&&!mobile){cursor.current.style.transform=`translate(${event.clientX-rect.left-12}px,${event.clientY-rect.top-12}px)`;cursor.current.style.opacity='1'}}} onPointerLeave={()=>{pointer.current=.5;if(cursor.current)cursor.current.style.opacity='0'}}>
  <div className="vt-hero-media" aria-hidden="true">{(['right','left'] as const).map(name=><video key={name} ref={name==='left'?left:right} src={`/templates/vetala/media/hero-${name}.mp4`} muted playsInline preload="auto" style={{opacity:mobile?Number(active===name):Number(name==='right')}} onEnded={()=>setActive(name==='right'?'left':'right')} onError={()=>{console.error('[vetala:hero] media failed',{side:name});setError(true)}}/>)}</div>
  <div className="vt-hero-shade"/><Nav locale={locale} basePath={basePath} hero/>
  <div className="vt-hero-body vt-container"><div className="vt-hero-copy"><motion.h1 initial={reduced?false:'hidden'} whileInView="visible" viewport={{once:false,amount:.1}} variants={{hidden:{opacity:0,x:-100},visible:{opacity:1,x:0,transition:{duration:.9,ease,staggerChildren:.02,delayChildren:.1}}}}>{title.split('\n').map((line,i)=><span className="vt-title-line" key={i}>{Array.from(line).map((char,j)=><motion.span key={j} variants={variants}>{char===' '?'\u00a0':char}</motion.span>)}</span>)}</motion.h1><motion.p initial={reduced?false:{opacity:0,x:-100}} whileInView={{opacity:1,x:0}} transition={{duration:.9,delay:.1,ease}}>{text(copy.intro,locale)}</motion.p><motion.div className="vt-actions" initial={reduced?false:{opacity:0,y:25}} whileInView={{opacity:1,y:0}} transition={{duration:.9,delay:.2,ease}}><Link className="vt-button vt-roll" href={href(basePath,'contact')}><span><span>{text(copy.hire,locale)}</span><span aria-hidden="true">{text(copy.hire,locale)}</span></span></Link><Link className="vt-button vt-button-glass vt-roll" href={href(basePath,'features')}><span><span>{text(copy.explore,locale)}</span><span aria-hidden="true">{text(copy.explore,locale)}</span></span></Link></motion.div></div>
   <div className="vt-hero-aside"><div><p>{locale==='zh'?'适合这样的团队':'IDEAL FOR:'}</p>{[{zh:'营销团队',en:'Marketing Teams'},{zh:'代理机构与 SaaS 公司',en:'Agencies & SaaS Companies'},{zh:'企业与初创团队',en:'Enterprises & Startups'},{zh:'B2B 公司与大型组织',en:'B2B Companies & Enterprises'}].map((item,i)=><motion.div key={i} initial={reduced?false:{opacity:0,x:80}} whileInView={{opacity:1,x:0}} transition={{duration:.8,delay:.1*i,ease}}>{item[locale]}<span aria-hidden="true">✦</span></motion.div>)}</div><div className="vt-partners"><p>{locale==='zh'?'合作伙伴 · 演示':'OUR PARTNERS · DEMO'}</p><div className="vt-marquee"><div>{Array.from({length:4},(_,i)=>['Logoluxe','Graphicraft','Logolaze','Primeark'].map((name,j)=><span key={`${i}-${j}`}><b aria-hidden="true">{['◇','✣','◉','▦'][j]}</b>{name}</span>))}</div></div></div></div>
  </div><div className="vt-cursor" ref={cursor} aria-hidden="true">⦿</div>{error&&<p className="vt-media-error" role="status">{locale==='zh'?'视频加载或播放失败，请检查浏览器媒体权限后重试。':'Video could not load or play. Check browser media permissions and retry.'}</p>}
 </section>
}
