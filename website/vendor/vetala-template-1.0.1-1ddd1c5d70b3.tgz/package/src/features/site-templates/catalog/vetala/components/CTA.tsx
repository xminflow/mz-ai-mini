'use client'
import Link from 'next/link'
import {copy,text,type Locale} from '../content/site'
import {href} from './Shell'
import {Reveal,ScrollFocus} from './Motion'
export function CTA({locale,basePath}:{locale:Locale;basePath:string}){
 return <section className="vt-section vt-container vt-cta"><ScrollFocus><Reveal><span className="vt-pill">✦ {locale==='zh'?'准备好改变你的营销方式了吗？':'Ready to transform your marketing?'}</span></Reveal><Reveal delay={.1}><h2>{locale==='zh'?'聘请 AI 员工\n让好想法变成好结果':'Hire AI employees.\nGet real results.'}</h2></Reveal><Reveal delay={.2}><p>{locale==='zh'?'与更聪明的工作方式同行，让团队有时间创造真正的价值。500+ 团队为参考站演示文案，不代表本产品实际客户。':'Join 500+ marketing teams already scaling smarter with AI employees. Reference demo copy; not a verified customer count.'}</p></Reveal><Reveal delay={.3} className="vt-actions"><Link href={href(basePath,'contact')} className="vt-button">{text(copy.hire,locale)}</Link><Link href={href(basePath,'features')} className="vt-button vt-button-outline">{text(copy.explore,locale)}</Link></Reveal><div className="vt-cta-trust"><div>{[9,10,15].map(i=><img src={`/templates/vetala/media/avatar-${i}.jpg`} alt="" key={i}/>)}</div><span>{locale==='zh'?'与面向未来的营销团队一起成长':'Trusted by marketing teams worldwide'}</span></div></ScrollFocus></section>
}
