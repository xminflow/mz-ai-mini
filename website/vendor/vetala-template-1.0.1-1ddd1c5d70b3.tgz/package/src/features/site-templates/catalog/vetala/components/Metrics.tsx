'use client'
import Link from 'next/link'
import {useEffect,useRef,useState,type PointerEvent} from 'react'
import {motion,useInView,useReducedMotion} from 'framer-motion'
import {copy,text,type Locale} from '../content/site'
import {href} from './Shell'
import {Reveal} from './Motion'

function Count({end,prefix='',suffix='%'}:{end:number;prefix?:string;suffix?:string}){
 const ref=useRef<HTMLSpanElement>(null),visible=useInView(ref,{once:true,amount:.1}),reduced=useReducedMotion(),[value,setValue]=useState(0)
 useEffect(()=>{if(!visible||reduced)return;let frame=0,start=0;const tick=(time:number)=>{if(!start)start=time;const p=Math.min(1,(time-start)/1500);setValue(Math.floor(p*(2-p)*end));if(p<1)frame=requestAnimationFrame(tick)};frame=requestAnimationFrame(tick);return()=>cancelAnimationFrame(frame)},[end,reduced,visible])
 return <span ref={ref}>{prefix}{reduced?end:value}{suffix}</span>
}
interface Particle {x:number;y:number;vx:number;vy:number;targetX:number;rotation:number;angle:number;dragging:boolean;lastX:number;lastY:number}
interface WaveNode {x:number;y:number;vy:number;target:number}
const badgeCopy=[{zh:'多智能体 AI',en:'Multi-Agent AI'},{zh:'增长团队之选',en:'Trusted by Growth Teams'},{zh:'团队协作',en:'Clutch'},{zh:'全天候 AI 员工',en:'24/7 AI Employees'},{zh:'100+ 集成',en:'100+ Integrations'},{zh:'企业级安全',en:'Enterprise Security'}]
export function WaveBadges({locale}:{locale:Locale}){
 const ref=useRef<HTMLDivElement>(null),path=useRef<SVGPathElement>(null),elements=useRef<(HTMLButtonElement|null)[]>([]),reduced=useReducedMotion(),visible=useInView(ref,{amount:.05})
 const particles=useRef<Particle[]>([]),nodes=useRef<WaveNode[]>([]),dragIndex=useRef<number|null>(null),previous=useRef({x:0,y:0})
 useEffect(()=>{
  const base=(x:number)=>100+75*Math.pow(x/1440,1.5)
  nodes.current=Array.from({length:15},(_,i)=>({x:i/14*1440,y:base(i/14*1440),target:base(i/14*1440),vy:0}))
  particles.current=[340,600,880,450,720,1000].map((x,i)=>({x,y:reduced?base(x)-5:-150-i*60,vx:0,vy:5+i*.35,targetX:x,rotation:[-10,-6,10,4,-4,8][i],angle:0,dragging:false,lastX:x,lastY:0}))
 },[reduced])
 useEffect(()=>{
  if(!visible)return
  let frame=0,last=0
  /** 15 节点波面与徽章共用坐标系；碰撞、重力、弹簧回弹和指针扰动独立计算。 */
  const tick=(time:number)=>{
   const step=last?Math.min(2,(time-last)/16.667):1;last=time
   const wave=nodes.current,items=particles.current
   if(!reduced){
    for(const n of wave){n.vy+=-.02*(n.y-n.target)*step;n.vy*=Math.pow(.96,step);n.y+=n.vy*step}
    for(let i=0;i<wave.length;i++){if(i>0){const force=.035*(wave[i].y-wave[i-1].y)*step;wave[i-1].vy+=force;wave[i].vy-=force}if(i<wave.length-1){const force=.035*(wave[i].y-wave[i+1].y)*step;wave[i+1].vy+=force;wave[i].vy-=force}}
    for(let i=0;i<items.length;i++)for(let j=i+1;j<items.length;j++){
     const a=items[i],b=items[j],dx=a.x-b.x,dy=a.y-b.y,ox=180-Math.abs(dx),oy=46-Math.abs(dy)
     if(ox>0&&oy>0){const horizontal=ox<oy,force=(horizontal?ox:oy)*.5,sign=(horizontal?dx:dy)>=0?1:-1;if(!a.dragging){if(horizontal){a.x+=sign*force;a.vx+=sign*force*.05}else{a.y+=sign*force;a.vy+=sign*force*.05}}if(!b.dragging){if(horizontal){b.x-=sign*force;b.vx-=sign*force*.05}else{b.y-=sign*force;b.vy-=sign*force*.05}}}
    }
    items.forEach((item,i)=>{
     if(item.dragging){item.vx=Math.max(-15,Math.min(15,item.x-item.lastX));item.vy=Math.max(-15,Math.min(15,item.y-item.lastY));item.lastX=item.x;item.lastY=item.y;item.angle+=(0-item.angle)*.15;return}
     item.vy+=.35*step
     const position=Math.max(0,Math.min(14,item.x/1440*14)),index=Math.floor(position),next=Math.min(14,index+1),fraction=position-index
     const surface=wave[index].y*(1-fraction)+wave[next].y*fraction
     if(item.y>surface-5){item.vy-=.065*(item.y-surface+5)*step;item.vy*=Math.pow(.82,step);item.vx*=Math.pow(.82,step);item.angle+=(item.rotation+3*Math.sin(time*.003+i)-item.angle)*.1;wave[Math.round(position)].vy+=.08*item.vy}else{item.vy*=Math.pow(.99,step);item.angle+=(item.rotation-item.angle)*.05}
     item.vx+=(item.targetX-item.x)*.003*step;item.vx*=Math.pow(.96,step);item.x+=item.vx*step;item.y+=item.vy*step
     if(item.x<100||item.x>1340){item.x=Math.max(100,Math.min(1340,item.x));item.vx*=-.5}if(item.y>195){item.y=195;item.vy*=-.3}
    })
   }
   items.forEach((item,i)=>{const el=elements.current[i];if(el){el.style.left=`${item.x/1440*100}%`;el.style.top=`${item.y}px`;el.style.transform=`translate(-50%,-100%) rotate(${item.angle}deg)`}})
   if(path.current&&wave.length){let d=`M1440 200 L0 200 L0 ${wave[0].y}`;for(let i=1;i<wave.length;i++)d+=` Q${wave[i-1].x} ${wave[i-1].y} ${(wave[i-1].x+wave[i].x)/2} ${(wave[i-1].y+wave[i].y)/2}`;path.current.setAttribute('d',d+` L1440 ${wave[14].y} Z`)}
   if(!reduced)frame=requestAnimationFrame(tick)
  };frame=requestAnimationFrame(tick);return()=>cancelAnimationFrame(frame)
 },[reduced,visible])
 const disturb=(x:number,force:number)=>{const wave=nodes.current;const index=Math.round(x/1440*14);for(let i=-2;i<=2;i++)if(wave[index+i])wave[index+i].vy+=force*(1-Math.abs(i)*.35)}
 const move=(event:PointerEvent<HTMLButtonElement>)=>{const index=dragIndex.current;if(index===null||!ref.current)return;const rect=ref.current.getBoundingClientRect(),item=particles.current[index];item.x=Math.max(80,Math.min(1360,(event.clientX-rect.left)/rect.width*1440));item.y=Math.max(-200,Math.min(190,event.clientY-rect.top))}
 const release=(event:PointerEvent<HTMLButtonElement>)=>{const index=dragIndex.current;if(index===null)return;particles.current[index].dragging=false;disturb(particles.current[index].x,28);dragIndex.current=null;if(event.currentTarget.hasPointerCapture(event.pointerId))event.currentTarget.releasePointerCapture(event.pointerId);console.debug('[vetala:wave] drag released',{badge:index})}
 return <div className="vt-wave" ref={ref} onPointerMove={event=>{if(reduced)return;const rect=event.currentTarget.getBoundingClientRect(),speed=event.clientY-previous.current.y;disturb((event.clientX-rect.left)/rect.width*1440,Math.max(-8,Math.min(8,speed*.12)));previous.current={x:event.clientX,y:event.clientY}}}><svg viewBox="0 0 1440 200" preserveAspectRatio="none" aria-hidden="true"><path ref={path} fill="white"/></svg>{badgeCopy.map((item,i)=><button key={i} ref={el=>{elements.current[i]=el}} className="vt-wave-badge" aria-label={`${item[locale]} · ${locale==='zh'?'拖动或按方向键':'Drag or use arrow keys'}`} onPointerDown={event=>{if(reduced)return;event.preventDefault();event.currentTarget.setPointerCapture(event.pointerId);dragIndex.current=i;const particle=particles.current[i];particle.dragging=true;particle.lastX=particle.x;particle.lastY=particle.y}} onPointerMove={move} onPointerUp={release} onPointerCancel={release} onMouseEnter={()=>{if(!reduced&&particles.current[i])disturb(particles.current[i].x,-16)}} onKeyDown={event=>{const particle=particles.current[i];if(!particle||reduced)return;if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key)){event.preventDefault();particle.vx+=event.key==='ArrowLeft'?-8:event.key==='ArrowRight'?8:0;particle.vy+=event.key==='ArrowUp'?-10:event.key==='ArrowDown'?10:0;disturb(particle.x,12)}}}><span aria-hidden="true">✦</span>{item[locale]}</button>)}</div>
}
export function Metrics({locale,basePath}:{locale:Locale;basePath:string}){
 const [hover,setHover]=useState<number|null>(null)
 return <section className="vt-metrics" id="metrics"><div className="vt-container"><Reveal className="vt-metrics-top"><span>{locale==='zh'?'策略与执行':'STRATEGY & EXECUTION'}</span><span>{locale==='zh'?'全天候 AI，持续优化':'24/7 AI. ALWAYS OPTIMIZING.'}</span></Reveal><div className="vt-metrics-grid"><Reveal><h2>{locale==='zh'?'营销 AI 员工\n让效果看得见':'Marketing\nAI Employees\nPerformance'}</h2><p>{locale==='zh'?'让 AI 员工自动化营销、优化活动，推动业务增长。以下为参考站演示指标。':'AI employees that automate marketing, optimize campaigns, and drive business growth. Illustrative reference metrics.'}</p><Link href={href(basePath,'contact')} className="vt-button vt-button-outline">{text(copy.hire,locale)}</Link></Reveal><div className="vt-metric-cards">{[{value:79,zh:'线索获取',en:'Lead Generation'},{value:39,zh:'营销表现',en:'Campaign Performance'},{value:147,zh:'营销生产力',en:'Marketing Productivity'}].map((item,i)=><motion.div key={i} onMouseEnter={()=>setHover(i)} onMouseLeave={()=>setHover(null)} animate={{scale:hover===i?1.04:hover===null?1:.96,opacity:hover===null||hover===i?1:.6}} transition={{type:'spring',stiffness:300,damping:25}} className="vt-metric-card"><span>{item[locale]}</span><strong><Count end={item.value} prefix={i===1?'+':''}/></strong></motion.div>)}</div></div><Reveal className="vt-ratings">{[{zh:'团队信赖',en:'Trusted teams'},{zh:'持续优化',en:'Always optimizing'},{zh:'协作增长',en:'Growing together'},{zh:'安全工作流',en:'Secure workflows'}].map((item,i)=><div key={i}><span aria-hidden="true">★★★★★</span><b>{item[locale]}</b><small>{locale==='zh'?'演示评价':'Demo rating'}</small></div>)}</Reveal></div><WaveBadges locale={locale}/></section>
}
