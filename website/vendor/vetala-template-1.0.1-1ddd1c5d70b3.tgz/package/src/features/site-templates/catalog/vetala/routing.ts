/** 根路径由宿主注入；独立部署和模板预览共用同一组相对路由。 */
export function href(basePath:string,slug=''){return (basePath.replace(/\/$/,'')+'/'+slug).replace(/\/$/,'')||'/'}
/** 点击时传入当前位置，防止客户端切页中残留上一个页面的锚点。 */
export function languageHref(pathname:string,basePath:string,locale:'zh'|'en',search='',hash=''){
 const base=basePath.replace(/\/en$/,'').replace(/\/$/,'')
 const suffix=pathname.startsWith(basePath)?pathname.slice(basePath.length):''
 return (`${base}${locale==='zh'?'/en':''}${suffix}`||'/')+search+hash
}
