import type {SiteTemplatePageProps} from '../../../types'
import {Shell} from '../components/Shell'
import {Features} from '../components/FeatureSection'
import {Integrations} from '../components/Integrations'
import {CTA} from '../components/CTA'
export default function FeaturesPage({locale='zh',basePath}:SiteTemplatePageProps){return <Shell locale={locale} basePath={basePath}><header className="vt-page-heading vt-container"><span className="vt-eyebrow">{locale==='zh'?'产品功能':'PRODUCT'}</span><h1>{locale==='zh'?'从想法到行动\n让 AI 与团队一起创造':'From ideas to action\nAI that works with your team'}</h1><p>{locale==='zh'?'将内容、洞察与执行连接成一个清晰的工作流。':'Connect content, insights and execution in one clear workflow.'}</p></header><Features locale={locale} basePath={basePath}/><Integrations locale={locale}/><CTA locale={locale} basePath={basePath}/></Shell>}

