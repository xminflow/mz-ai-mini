export const brand={name:{zh:'Vetala',en:'Vetala'},logo:'/templates/vetala/media/icon-dark.svg',lightLogo:'/templates/vetala/media/icon-light.svg',email:'hello@vetala.example',year:2026};
