'use client';
import {createContext,useContext,type ReactNode} from 'react';
import {brand} from './config/brand';
export interface VetalaHost {brandName:{zh:string;en:string};logo:string;lightLogo?:string;marketplaceHref?:string;marketplaceLabel?:{zh:string;en:string};marketplaceAriaLabel?:{zh:string;en:string};filing?:ReactNode}
const Context=createContext<VetalaHost>({brandName:brand.name,logo:brand.logo,lightLogo:brand.lightLogo});
export function VetalaHostProvider({children,...host}:VetalaHost&{children:ReactNode}){return <Context.Provider value={host}>{children}</Context.Provider>}
export const useVetalaHost=()=>useContext(Context);
