import Link from 'next/link'
import type {SiteTemplatePageProps} from '../../../types'
import {articles,text} from '../content/site'
import {Shell} from '../components/Shell'
import {href} from '../routing'
import {Reveal} from '../components/Motion'
export default function BlogPage({locale='zh',basePath}:SiteTemplatePageProps){return <Shell locale={locale} basePath={basePath}><header className="vt-page-heading vt-container"><span className="vt-eyebrow">{locale==='zh'?'增长日志':'JOURNAL'}</span><h1>{locale==='zh'?'关于 AI 协作\n与持续增长的思考':'Ideas for AI collaboration\nand sustainable growth'}</h1><p>{locale==='zh'?'产品实践、团队协作与营销洞察。文章为模板原创演示内容。':'Product practice, teamwork and marketing insights. Original demonstration articles.'}</p></header><div className="vt-container vt-blog-grid">{articles.map((article,i)=><Reveal delay={i*.12} key={article.slug}><Link href={href(basePath,'blog/'+article.slug)} className="vt-blog-card"><div className={`vt-blog-art vt-blog-art-${i}`}><span aria-hidden="true">{['✦','◉','▦'][i]}</span><small>{text(article.category,locale)}</small></div><div><span className="vt-eyebrow">{text(article.category,locale)} · 2026.10.25</span><h2>{text(article.title,locale)}</h2><p>{text(article.intro,locale)}</p><span className="vt-text-link">{locale==='zh'?'阅读文章':'Read article'}</span></div></Link></Reveal>)}</div></Shell>}
