'use client'
import {motion,useMotionValue,useReducedMotion} from 'framer-motion'
import {useEffect,useRef,useState} from 'react'
import Link from 'next/link'
import {copy,text,type Locale} from '../content/site'
import {href} from './Shell'
import {ReadWord} from './Motion'
export function About({locale,basePath}:{locale:Locale;basePath:string}){
 const ref=useRef<HTMLElement>(null),start=useRef<HTMLDivElement>(null),end=useRef<HTMLDivElement>(null),statement=useRef<HTMLParagraphElement>(null),reduced=useReducedMotion(),scrollYProgress=useMotionValue(0)
 const [box,setBox]=useState<{top:number;left:number;width:number;height:number}|null>(null)
 /** 根据真实起止矩形逐像素插值，避免 var()/百分比混合单位导致动画跳变。 */
 useEffect(()=>{let frame=0;const measure=()=>{if(!ref.current||!start.current||!end.current||!statement.current)return;const root=ref.current.getBoundingClientRect(),a=start.current.getBoundingClientRect(),b=end.current.getBoundingClientRect(),words=statement.current.getBoundingClientRect(),p=reduced?1:Math.max(0,Math.min(1,(innerHeight*.85-words.top)/(innerHeight*.7)));scrollYProgress.set(p);setBox({top:a.top-root.top+(b.top-a.top)*p,left:a.left-root.left+(b.left-a.left)*p,width:a.width+(b.width-a.width)*p,height:a.height+(b.height-a.height)*p})};const update=()=>{cancelAnimationFrame(frame);frame=requestAnimationFrame(measure)};update();const observer=new ResizeObserver(update);if(ref.current)observer.observe(ref.current);window.addEventListener('scroll',update,{passive:true});window.addEventListener('resize',update);return()=>{cancelAnimationFrame(frame);observer.disconnect();window.removeEventListener('scroll',update);window.removeEventListener('resize',update)}},[reduced,locale,scrollYProgress])
 const words=locale==='en'?text(copy.about,locale).split(' '):Array.from(text(copy.about,locale))
 return <section className="vt-about vt-container" ref={ref} id="about"><div className="vt-about-top"><div className="vt-about-slot" ref={start}/><span>{locale==='zh'?'自主智能 AI':'AGENTIC AI'}</span></div><p className="vt-about-statement" ref={statement}>{words.map((word,index)=><ReadWord key={index} word={word+(locale==='en'?' ':'')} index={index} count={words.length} progress={scrollYProgress}/>)}</p><div className="vt-about-bottom"><Link className="vt-button vt-button-outline" href={href(basePath,'features')}>{text(copy.demo,locale)}</Link><video src="/templates/vetala/media/about-small.mp4" autoPlay={!reduced} muted loop playsInline controls={!!reduced} aria-label={locale==='zh'?'AI 工作流演示视频':'AI workflow video'}/></div><div className="vt-about-large-slot" ref={end}/><motion.div className="vt-about-morph" style={box??undefined}><video src="/templates/vetala/media/about-main.mp4" autoPlay={!reduced} muted loop playsInline controls={!!reduced} aria-label={locale==='zh'?'AI 营销过程视频':'AI marketing process video'}/></motion.div></section>
}
