'use client'
import {motion,useReducedMotion,useScroll,useTransform,type MotionValue} from 'framer-motion'
import {useRef,type ReactNode} from 'react'
export const ease = [.16,1,.3,1] as const
export function Reveal({children,className='',delay=0,x=0}:{children:ReactNode;className?:string;delay?:number;x?:number}){
 const reduced=useReducedMotion()
 return <motion.div className={className} initial={reduced?false:{opacity:0,y:x?0:30,x}} whileInView={{opacity:1,y:0,x:0}} viewport={{once:true,amount:.12}} transition={{duration:.8,delay,ease}}>{children}</motion.div>
}
/** 原站按区块进入/离开视口连续计算模糊度，不以统一淡入替代。 */
export function ScrollFocus({children,className=''}:{children:ReactNode;className?:string}){
 const ref=useRef<HTMLDivElement>(null),reduced=useReducedMotion()
 const {scrollYProgress}=useScroll({target:ref,offset:['start 95%','end 15%']})
 const opacity=useTransform(scrollYProgress,[0,.2,.85,1],[.4,1,1,.4])
 const filter=useTransform(scrollYProgress,[0,.2,.85,1],['blur(12px)','blur(0px)','blur(0px)','blur(12px)'])
 const scale=useTransform(scrollYProgress,[0,.2,.85,1],[.95,1,1,.95])
 return <motion.div ref={ref} className={className} style={reduced?undefined:{opacity,filter,scale}}>{children}</motion.div>
}
export function ReadWord({word,index,count,progress}:{word:string;index:number;count:number;progress:MotionValue<number>}){
 const reduced=useReducedMotion(),start=.05+index/count*.8
 const color=useTransform(progress,[start,start+.08],['#a3acba','#101626'])
 return <motion.span style={reduced?{color:'#101626'}:{color}}>{word}</motion.span>
}
