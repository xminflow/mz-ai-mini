'use client'
import Link from 'next/link'
import {usePathname,useRouter} from 'next/navigation'
import {AnimatePresence,motion,MotionConfig} from 'framer-motion'
import {useState,type ReactNode} from 'react'
import {useVetalaHost} from '../host'
import {nav,text,type Locale} from '../content/site'
import '../theme.css'
import {href,languageHref} from '../routing'
export {href} from '../routing'
export function Language({locale,basePath}:{locale:Locale;basePath:string}){
 const pathname=usePathname(),router=useRouter()
 return <Link href={languageHref(pathname,basePath,locale)} onClick={event=>{if(event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;event.preventDefault();router.push(languageHref(window.location.pathname,basePath,locale,window.location.search,window.location.hash))}} aria-label={locale==='zh'?'Switch to English':'切换到中文'} className="vt-language">{locale==='zh'?'EN':'中文'}</Link>
}
export function Nav({locale,basePath,hero=false}:{locale:Locale;basePath:string;hero?:boolean}){
 const host=useVetalaHost(),[open,setOpen]=useState(false)
 const link=(slug:string)=>slug.startsWith('#')?href(basePath)+slug:href(basePath,slug)
 return <nav className={`vt-nav ${hero?'vt-nav-hero':''}`} aria-label={locale==='zh'?'主导航':'Main navigation'}>
  <Link className="vt-brand" href={href(basePath)}><img src={hero?host.lightLogo||host.logo:host.logo} alt=""/>{host.brandName[locale]}</Link>
  <div className="vt-nav-links">{nav.map(n=><Link key={n.slug} href={link(n.slug)}>{text(n.title,locale)}</Link>)}</div>
  <div className="vt-nav-actions"><Language locale={locale} basePath={basePath}/><Link className="vt-button vt-button-small" href={href(basePath,'contact')}>{locale==='zh'?'免费开始':'Start Free'}</Link><button className="vt-menu" aria-expanded={open} aria-controls="vt-mobile-nav" aria-label={locale==='zh'?'打开或关闭菜单':'Toggle menu'} onClick={()=>setOpen(!open)}>{open?'×':'☰'}</button></div>
  <AnimatePresence>{open&&<motion.div id="vt-mobile-nav" className="vt-mobile-nav" initial={{opacity:0,y:-20}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-20}} transition={{duration:.25,ease:'easeOut'}}>{nav.map(n=><Link key={n.slug} href={link(n.slug)} onClick={()=>setOpen(false)}>{text(n.title,locale)}</Link>)}<Link href={href(basePath,'contact')} onClick={()=>setOpen(false)}>{locale==='zh'?'联系我们':'Contact us'}</Link></motion.div>}</AnimatePresence>
 </nav>
}
export function Footer({locale,basePath}:{locale:Locale;basePath:string}){
 const host=useVetalaHost()
 return <motion.footer className="vt-footer" initial={{opacity:0,y:40}} whileInView={{opacity:1,y:0}} viewport={{once:true,margin:"-100px"}} transition={{duration:.8,ease:"easeOut"}}><div className="vt-container"><div className="vt-footer-top"><div><Link className="vt-brand" href={href(basePath)}><img src={host.lightLogo||host.logo} alt=""/>{host.brandName[locale]}</Link><h2>{locale==='zh'?'让 AI 负责执行\n让增长持续发生':'Hire AI employees.\nGet real results.'}</h2></div><div><p>{locale==='zh'?'保持联系':'Let’s Connect'}</p><p>{locale==='zh'?'一起构建更聪明的营销团队。':'Build, scale and grow smarter with AI.'}</p><Link href={href(basePath,'contact')}>{locale==='zh'?'联系我们':'Contact'}</Link></div></div><div className="vt-footer-links">{[{slug:'features',zh:'产品功能',en:'Features'},{slug:'blog',zh:'增长日志',en:'Blog'},{slug:'contact',zh:'联系',en:'Contact'},{slug:'privacy',zh:'隐私政策',en:'Privacy Policy'},{slug:'terms',zh:'使用条款',en:'Terms'}].map(n=><Link key={n.slug} href={href(basePath,n.slug)}>{n[locale]}</Link>)}<button onClick={()=>window.scrollTo({top:0,behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'})}>{locale==='zh'?'返回顶部':'Back to top'}</button></div><div className="vt-footer-bottom"><span>© 2026 {host.brandName[locale]}</span><span>{locale==='zh'?'演示内容与指标，仅供展示':'Demo content and metrics for illustration'}</span>{host.marketplaceHref&&<Link href={host.marketplaceHref}>{host.marketplaceLabel?.[locale]}</Link>}{host.filing}</div><div className="vt-footer-word" aria-hidden="true">{host.brandName[locale]}</div></div></motion.footer>
}
export function Shell({locale='zh',basePath,children,hero=false}:{locale?:Locale;basePath:string;children:ReactNode;hero?:boolean}){
 const host=useVetalaHost()
 return <MotionConfig reducedMotion="user"><div className="vt-root" lang={locale==='zh'?'zh-CN':'en'}><a className="vt-skip" href="#vt-main">{locale==='zh'?'跳至正文':'Skip to content'}</a>{!hero&&<Nav locale={locale} basePath={basePath}/>}<main id="vt-main">{children}</main><Footer locale={locale} basePath={basePath}/>{host.marketplaceHref&&<Link className="vt-marketplace" href={host.marketplaceHref} aria-label={host.marketplaceAriaLabel?.[locale]}><img src={host.lightLogo||host.logo} alt=""/><span>{host.brandName[locale]}</span></Link>}</div></MotionConfig>
}

