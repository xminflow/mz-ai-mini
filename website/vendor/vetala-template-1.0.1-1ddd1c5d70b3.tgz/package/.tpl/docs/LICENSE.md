# 权利边界

本项目为 Jiro Vetala 设计的参考复刻演示。应用实现、原始设计、照片、Logo、视频、图片、字体和协议工具分别适用其权利条件。不能因工具为 MIT 推断整套模板可自由再分发。Jiro 原始设计与 CDN 素材商业再分发许可未核实；Unsplash 照片遵循原站许可并需单独核实肖像和商业权利。Poppins 使用随包 OFL；MiSans 使用随包许可。保持 listed=false、redistributionAllowed=false。Git 或源码 ZIP 的可访问性不证明商业授权。
