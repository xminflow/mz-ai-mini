# Vetala AI 营销员工模板

9 个页面、18 条中英文路由，默认中文，英文位于 /en。首页按参考单页保留全部区块，另提供功能、博客、三篇原创演示文章、联系、隐私和使用说明页。

## 运行与验证

Node 24.16.0、pnpm 9.15.4。执行 `pnpm install --frozen-lockfile`，`pnpm dev` 启动开发；`pnpm build` 后 `pnpm start` 运行生产预览，默认 http://127.0.0.1:43570。使用启动终端 Ctrl+C 停止。PORT/HOSTNAME 可以覆盖监听配置，无数据库或秘密配置。安装、编译与打包在本地 Linux 文件系统进行。

`pnpm typecheck`、`pnpm lint`、`pnpm test`、`pnpm build` 为应用检查；`.tpl/tools/check.mjs` 为协议检查，不代替浏览器验收。`pnpm bundle` 生成供宿主消费的共享运行包，完整源码按 Git 工程交付。所有依赖沿用既有版本，没有新增第三方库。

## 交互与边界

首屏左右视频按指针位置寻帧，移动端交替播放；标题逐字弹簧入场；介绍视频随滚动扩大并逐词变色；对比放大镜、功能图文切换、计数、物理徽章与波面、3.5 秒评价轮播、24 秒工具半椭圆轨道、月年方案切换、FAQ 和按钮滚动字。系统减少动态效果受到尊重。

表单仅在浏览器本地校验，不发送、不保存。工具集成没有连接账户。人物评价、结果、价格和客户数量均为演示。原始视频内部可能包含英文界面；视频不替换为静态图片。完整原站逐帧一致性尚未通过，实际差异与验证范围见 `.tpl/docs/MOTION.md`。

## 修改入口

品牌位于 `src/features/site-templates/catalog/vetala/config/brand.ts`；双语内容、报价、FAQ 和文章位于 `content/site.ts`；`theme.css`/`fonts.css` 管理视觉与字体；`components/` 管理可复用区块；`pages/` 只组合页面；`meta.ts` 注册页面；`routing.ts` 统一链接与语言切换。`host.tsx` 支持可选品牌、入口与备案插槽，默认使用模板自身品牌。素材位于 `public/templates/vetala`，市场截图位于 `.tpl/assets`。

## 权利

参考设计与素材商用权利尚未核实，保持未上架且不声明可自由再分发。逐项来源见 `.tpl/docs/ASSETS.json`，字体许可在字体目录，工具许可在 `.tpl/tools/LICENSE`。
