export const brand = { name: { zh: 'Unseen', en: 'Unseen' }, logo: '/templates/unseen/brand.svg', lightLogo: '/templates/unseen/brand-light.svg' }
