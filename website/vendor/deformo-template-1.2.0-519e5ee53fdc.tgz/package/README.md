# Deformo 独立创意机构模板

从 Weelume 本地工作树新迁移的独立 Git / Next.js 工程。完整运行、修改、验收与许可规则见 [.tpl/README.md](.tpl/README.md)。

Node 22.13.1、pnpm 12.10.1。

```text
pnpm install --frozen-lockfile
pnpm run build
pnpm start
```

中文 http://127.0.0.1:43121/templates/deformo/site ，英文追加 /en。开发使用 pnpm dev；前台 Ctrl+C 停止。联系和订阅仅本地交互演示。

共享包接入、宿主适配、本地源码引用、部署快照与素材生成规则见 docs/INTEGRATION.md（在 .tpl/docs 内为同目录 INTEGRATION.md）。
