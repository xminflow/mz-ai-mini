import type { SiteTemplatePageProps } from '../../../types'
import { ContactView } from '../components/ContentViews'
import '../theme.css'

export default function ContactPage(props: SiteTemplatePageProps) {
  return <ContactView {...props} />
}

