# Deformo 页面模块

本目录由 Weelume 迁入；当前运行、修改和验收请读根目录 .tpl/README.md。原始源站说明保留在 docs/provenance/SOURCE-README.md，仅历史参考，不是本工程启动合同或验收记录。
