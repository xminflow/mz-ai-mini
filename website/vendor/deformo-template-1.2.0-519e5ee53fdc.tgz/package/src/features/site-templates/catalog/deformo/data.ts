import type { TemplateLocale } from '../../types'

export type Copy = readonly [zh: string, en: string]
export const text = (copy: Copy, locale: TemplateLocale): string => copy[locale === 'en' ? 1 : 0]
export const photo = (file: string): string => `/templates/deformo/photos/${file}`

export const navigation: { slug: string; title: Copy }[] = [
  { slug: '', title: ['首页', 'Home'] },
  { slug: 'projects', title: ['作品', 'Projects'] },
  { slug: 'about-us', title: ['关于', 'About'] },
  { slug: 'blog', title: ['洞察', 'Blog'] },
  { slug: 'contact', title: ['联系我们', 'Contact us'] },
]

export const services: { title: Copy; description: Copy; symbol: string }[] = [
  { title: ['网站设计', 'Website Design'], description: ['从品牌的独特气质出发，让布局、内容与每一次交互都有明确目的。无论是单页展示还是完整官网，我们都让美感与转化相互成就。', 'A website should feel unmistakably yours. We shape clear journeys, thoughtful interactions, and responsive layouts that connect your brand to the people who matter.'], symbol: '↗' },
  { title: ['产品设计', 'Product Design'], description: ['从真实用户需求出发，梳理复杂信息，验证关键流程。通过可交互原型和一致的设计系统，把想法转化为易于理解、乐于使用的产品。', 'We turn complicated workflows into considered product experiences. Research, prototypes, and a shared design system give your team a clear direction from the first sketch.'], symbol: '◈' },
  { title: ['开发实现', 'Development'], description: ['设计与工程从项目开始就共同工作。我们关注响应速度、无障碍与多设备表现，让每一个经过推敲的细节在真实环境中准确落地。', 'Design and engineering work side by side. We build for performance, accessibility, and long-term maintainability, giving every carefully considered detail a reliable foundation.'], symbol: '⌘' },
  { title: ['品牌塑造', 'Branding'], description: ['找到品牌值得被记住的理由，再用字体、色彩、图形和表达方式形成完整的视觉语言。让每一个触点都讲述同一个清晰的故事。', 'We find the idea that makes your brand worth remembering, then express it through typography, color, and a distinctive visual language across every touchpoint.'], symbol: '✳' },
]

export const process: { title: Copy; description: Copy }[] = [
  { title: ['策略与研究', 'Strategy & Research'], description: ['了解业务、用户和市场，找到真正值得解决的问题。清晰的方向，是优秀设计的起点。', 'We map your goals, audience, and market before deciding what to build. A shared understanding gives the project a useful starting point.'] },
  { title: ['设计与原型', 'Design & Prototype'], description: ['从探索草图到交互原型，让想法尽早可见、可体验，在协作中找到最合适的表达。', 'We make ideas tangible through sketches and interactive prototypes, exploring possibilities together before committing to a direction.'] },
  { title: ['构建与验证', 'Build, Test & Optimize'], description: ['在真实设备和使用场景中验证设计，依据测试与反馈持续打磨，让体验经得起实际使用。', 'We build carefully, test across devices, and refine the experience with practical feedback from the people who will use it.'] },
  { title: ['上线与陪伴', 'Launch & Support'], description: ['上线之后继续关注表现，提供清晰的交付与持续支持，让数字产品随业务一起成长。', 'A considered handover and continued support help your team move forward confidently after launch.'] },
]

export const faqs: { question: Copy; answer: Copy }[] = [
  { question: ['微域生光与其他设计团队有什么不同', 'What makes Weelume different?'], answer: ['我们让策略、设计和开发从第一天共同参与。你会直接与实际负责项目的人沟通，重要决策都围绕用户需求和业务目标展开。', 'Strategists, designers, and developers collaborate from day one. You work directly with the people making the work, with decisions grounded in your audience and business goals.'] },
  { question: ['一个项目通常需要多长时间', 'How long does a project usually take?'], answer: ['网站项目通常需要 4–8 周，完整品牌项目约 6–12 周。具体时间取决于范围、内容准备和反馈节奏，会在启动前共同确认。', 'Websites typically take 4–8 weeks and a full brand engagement around 6–12 weeks. We agree on a schedule based on scope, content readiness, and review milestones.'] },
  { question: ['你们也与初创团队合作吗', 'Do you work with early-stage teams?'], answer: ['是的。无论是验证新想法的初创团队，还是准备进入新阶段的成熟企业，我们都会围绕当下最重要的目标来规划工作。', 'Yes. We work with early-stage teams and established organizations, shaping the engagement around the next meaningful step for the business.'] },
  { question: ['设计流程包含哪些内容', 'What is included in the design process?'], answer: ['通常包含需求探索、策略研究、创意设计、原型验证、开发实现与上线支持。每个阶段都有明确产物和反馈节点。', 'Discovery, strategy, creative exploration, prototyping, development, and launch support. Each stage has a clear deliverable and a chance to review together.'] },
  { question: ['可以重新设计已有网站吗', 'Can you redesign an existing website?'], answer: ['可以。我们会先评估现有内容、用户路径与技术约束，保留有效资产，再针对品牌表达和关键体验进行系统升级。', 'Absolutely. We begin by reviewing existing content, user journeys, and technical constraints, then build on what works while improving the areas that matter most.'] },
]

export interface Project {
  slug: string
  name: string
  image: string
  gallery: string[]
  tags: Copy[]
  description: Copy
  title: Copy
  industry: Copy
  period: string
  duration: Copy
  introduction: Copy
  challenge: Copy
  solution: Copy
  metrics: { value: string; label: Copy }[]
  quote: Copy
  founder: string
}

export const projects: Project[] = [
  {
    slug: 'colorado', name: 'Colorado', image: 'VbZoFfyXdBYgx7vAiRcoPYyq59U.jpg',
    gallery: ['isTgxTYoGb3cpDjWNKUxWJ4NKU.jpg', 'xIJ52gcMmpxYcbcfOPapi7GnlZI.jpg', 'hmnaJYfn5COytCi4s8Yr9isxjc.jpg'],
    tags: [['品牌设计', 'Branding'], ['网站设计', 'Website Design']],
    description: ['为精品文具品牌重塑品牌与官网，让数字体验拥有与产品一致的细腻质感。', 'A considered new identity and digital home for a premium stationery maker.'],
    title: ['让纸张的温度\n成为品牌的力量', 'A tactile identity\nwith a lasting impression'],
    industry: ['文具与纸品', 'Stationery & Paper'], period: 'Q2 2023', duration: ['8 周', '8 weeks'],
    introduction: ['Colorado 的纸品因精致工艺受到喜爱，但线上形象未能传递产品的真实品质。这个概念案例围绕品牌识别和购物体验展开，让细腻触感成为可感知的数字语言。', 'Colorado had earned a loyal following for its carefully made paper goods. This concept case explores how a more coherent identity and an inviting digital experience can communicate that same attention to detail.'],
    challenge: ['原有视觉表达缺少一致性，网站中的产品信息分散，移动端浏览也缺乏节奏。我们需要在保留品牌亲切感的同时，建立更鲜明的识别，并让用户轻松找到适合自己的产品。', 'The existing experience lacked a consistent visual voice. Product discovery needed a clearer path, particularly on smaller screens. The challenge was to express quality without losing the warmth that made the brand approachable.'],
    solution: ['从品牌策略梳理开始，我们以温和的中性色、克制的排版和近距离产品影像构建视觉系统。网站围绕产品故事组织内容，让浏览、理解与选择自然衔接，并统一各设备上的购物体验。', 'A restrained palette, confident typography, and close-up imagery create a tactile visual system. The site connects the story behind each product to a clear browsing journey, with the same care applied to every screen size.'],
    metrics: [{ value: '3.4×', label: ['上线后营收增长 · 演示数据', 'Revenue growth · illustrative'] }, { value: '68%', label: ['自然访问增长 · 演示数据', 'Traffic growth · illustrative'] }],
    quote: ['新的视觉语言让我们能够清晰地讲述产品的价值，也让每一个品牌触点更有整体感。', 'The new direction gives us a clearer way to share the care behind our products.'], founder: 'Sarah Okonkwo',
  },
  {
    slug: 'kinetic', name: 'Kinetic', image: 'thkGtPGOsQTJcfA7oo0IuhDdddE.jpg', gallery: [],
    tags: [['品牌设计', 'Branding'], ['设计系统', 'Design System']],
    description: ['为运动科技公司建立鲜明的品牌语言，让技术实力从第一眼就被看见。', 'Precision and momentum, expressed through a new identity for a motion technology company.'],
    title: ['让品牌的势能\n追上技术的雄心', 'An ambitious brand\nfor technology in motion'],
    industry: ['运动控制技术', 'Motion Systems'], period: 'Q2 2025', duration: ['10 周', '10 weeks'],
    introduction: ['Kinetic 的技术已经进入新的发展阶段，品牌表达也需要同步成长。这个概念案例以精准和动势为线索，探索科技企业如何通过清晰的定位与设计建立信任。', 'Kinetic had reached a new stage of technical ambition. This concept case explores an identity that expresses precision and momentum while making a specialized product easier to understand.'],
    challenge: ['早期标识与页面缺少统一规则，复杂技术也没有被解释得足够直观。新的品牌既要延续已有认知，也要帮助更广泛的用户快速理解产品与应用价值。', 'Early brand materials had grown without a shared system. Technical information needed a more approachable structure, while the identity had to stay recognizable to existing customers.'],
    solution: ['我们用清晰的几何关系、高对比配色和模块化布局构建品牌系统。官网优先说明产品价值，再通过应用案例建立信心，最后以简洁的演示申请路径连接潜在客户。', 'Geometric forms, a high-contrast palette, and a modular layout give the brand a consistent foundation. The website explains the product first, supports it with practical examples, and offers a straightforward route to a conversation.'],
    metrics: [{ value: '2.8×', label: ['有效咨询增长 · 演示数据', 'Inbound lead growth · illustrative'] }, { value: '4.1×', label: ['平均访问时长 · 演示数据', 'Session duration · illustrative'] }],
    quote: ['品牌终于有了与我们正在构建的技术相匹配的清晰度和力量。', 'Our identity now has the clarity and confidence we want people to see in our technology.'], founder: 'Daniel Marsh',
  },
  {
    slug: 'growthview', name: 'GrowthView', image: '6ZBtBjULSTuKxctDAeVwFn1mjU.jpg', gallery: [],
    tags: [['品牌设计', 'Branding'], ['产品设计', 'Product Design']],
    description: ['为数据分析平台重构品牌与产品体验，把复杂数据转化为清晰的下一步。', 'A clearer brand and product experience for an analytics platform with a lot to say.'],
    title: ['让复杂的数据\n变成清晰的洞察', 'Complex information\nwith a clear direction'],
    industry: ['营销数据分析', 'Marketing Analytics'], period: 'Q3 2024', duration: ['9 周', '9 weeks'],
    introduction: ['GrowthView 拥有强大的分析能力，但首次使用的用户常常难以找到需要的信息。这个概念案例从信息架构出发，让产品价值更快地被理解。', 'GrowthView offered powerful analytics but needed to make the first experience more focused. This concept case starts with information architecture and explores a shorter path from data to useful insight.'],
    challenge: ['界面同时呈现过多信息，新用户缺少明确的起点。品牌也需要在专业感与易用性之间找到平衡，帮助不同规模的团队建立使用信心。', 'Too much information competed for attention at once. New users needed a more obvious starting point, and the brand needed to feel reliable without becoming distant or overly technical.'],
    solution: ['我们重排仪表盘的信息优先级，以一致的视觉层级突出关键数据、操作与下一步。同步升级品牌识别与引导流程，让用户能够从小目标开始，逐步探索更完整的能力。', 'The redesigned dashboard gives key insights, actions, and next steps distinct roles. A refreshed identity and guided onboarding help people start with one useful outcome before exploring the wider product.'],
    metrics: [{ value: '41%', label: ['流失率降低 · 演示数据', 'Churn reduction · illustrative'] }, { value: '3.2×', label: ['试用转化提升 · 演示数据', 'Trial conversion · illustrative'] }],
    quote: ['用户现在更快找到所需的洞察，我们也有了更一致的产品表达。', 'People can find the insight they need sooner, and our product now tells a more coherent story.'], founder: 'Priya Nair',
  },
]

export interface ArticleSection { title: Copy; body: Copy }
export interface Article { slug: string; title: Copy; category: Copy; summary: Copy; image: string; date: string; sections: ArticleSection[] }

// 文章沿用参考站主题与目录位置；正文为双语重新编写的模板内容。
export const articles: Article[] = [
  {
    slug: 'why-visual-hierarchy-determines-digital-success', title: ['视觉层级如何决定数字体验的成效', 'Designing a visual hierarchy that helps people act'], category: ['设计趋势', 'Trends'],
    summary: ['让信息有轻重，让用户清楚知道下一步。视觉层级，是体验中安静却重要的引导。', 'Give information a clear order and help people understand what to do next.'], image: '7uToyPQFPyAiTT7Gtl9o1r0rZF0.jpg', date: '2025-05-15',
    sections: [
      { title: ['看不见的信息骨架', 'The structure behind the screen'], body: ['在页面开始设计之前，先明确用户来到这里要完成什么。把内容按任务排序，决定什么需要首先被看见，什么可以留到下一步。一个明确的主操作，比同时突出的多个入口更容易理解。', 'Start by defining the task a person came to complete. Put information in the order that supports that task, and decide what can wait. One clear primary action gives the page a more useful center of gravity.'] },
      { title: ['用关系组织注意力', 'Organize attention through relationships'], body: ['字号只是层级的一部分。间距决定内容是否属于同一组，色彩表达状态，位置建立阅读顺序。先用黑白线框检查结构，再加入视觉风格，能更早发现信息组织中的问题。', 'Spacing groups related information, position establishes sequence, and color communicates state. Review the structure in a simple wireframe before adding a visual style. A strong hierarchy should remain understandable without decorative details.'] },
      { title: ['从用户行为验证设计', 'Observe the path people take'], body: ['让没有参与设计的人尝试完成关键任务，观察他们先看哪里、在哪一步停顿。结合任务完成率、误操作与访谈，判断视觉重点是否真正帮助了理解。', 'Ask someone outside the project to complete a key task. Observe their first choice and where they hesitate. Task completion, mistakes, and a short conversation reveal more than assumptions about what appears visually prominent.'] },
      { title: ['让层级持续进化', 'Keep the hierarchy useful'], body: ['内容增长和业务变化会改变信息的重要程度。将层级规则纳入设计系统，定期检查移动端和长文案，让新增内容依然服务清晰的体验。', 'As a product grows, information priorities change. Document the rules in your design system and review smaller screens and longer content regularly so new features remain part of a coherent experience.'] },
    ],
  },
  {
    slug: 'why-accessibility-should-be-your-competitive-advantage', title: ['让无障碍设计成为产品的长期优势', 'Make accessibility part of your product advantage'], category: ['无障碍', 'Accessibility'],
    summary: ['把更多人的使用方式纳入设计，产品会变得更清晰，也更可靠。', 'A wider understanding of how people use your product makes the experience clearer for everyone.'], image: 'tdCvL1bMUTdc0IDRzqxVt90RX6I.jpg', date: '2025-05-12',
    sections: [
      { title: ['从真实使用情境出发', 'Begin with real situations'], body: ['在强光中阅读、暂时受伤、单手操作，都会改变人与界面的互动方式。把不同能力和情境纳入研究，有助于发现原本被忽略的设计障碍。', 'Bright light, a temporary injury, or using one hand can change how someone interacts with an interface. Include different abilities and contexts in research to uncover barriers that a typical design review might miss.'] },
      { title: ['将基础能力做扎实', 'Make the fundamentals dependable'], body: ['清晰的标签、足够的文字对比度、完整的键盘路径和可感知的焦点，是日常体验的一部分。表单错误需要说明原因，并明确指出如何修正。', 'Clear labels, readable contrast, keyboard access, and visible focus belong in everyday product work. Form errors should explain what happened and provide a practical way to continue.'] },
      { title: ['在流程中持续检查', 'Build review into the process'], body: ['设计评审时检查阅读顺序，开发时使用语义化元素，验收时结合自动检查与人工操作。越早发现问题，修正成本越低，也更容易形成团队共识。', 'Review reading order during design, use semantic elements in development, and combine automated checks with hands-on testing. Early feedback makes improvements easier to incorporate into the shared system.'] },
      { title: ['把反馈变成产品能力', 'Learn from a wider audience'], body: ['让有不同使用需求的人参与测试，认真记录他们遇到的摩擦。将修正沉淀为组件规则，让一次改进能够帮助整个产品。', 'Invite people with different access needs to test important journeys. Capture the friction they encounter and turn improvements into component rules that benefit the wider product.'] },
    ],
  },
  {
    slug: 'why-user-research-should-drive-your-digital-strategy', title: ['让用户研究为数字策略指明方向', 'A digital strategy grounded in user research'], category: ['工作方法', 'Process'], summary: ['把假设放到真实场景里检验，让设计决策有据可依。', 'Test assumptions in real situations and give design decisions a firmer foundation.'], image: 'ljrughQNVnot3g4MdAkHARx3cU.jpg', date: '2025-05-08',
    sections: [
      { title: ['先写下未知的问题', 'Name what you need to learn'], body: ['将团队的判断区分为事实与假设。优先研究那些会影响产品方向、又缺少证据的问题，避免一次研究试图回答所有事情。', 'Separate established facts from team assumptions. Focus research on unanswered questions that could change the product direction. A narrow, useful question is easier to investigate well.'] },
      { title: ['选择合适的研究方式', 'Choose an appropriate method'], body: ['访谈帮助理解动机，观察揭示真实行为，可用性测试暴露具体流程中的障碍。根据问题选择方法，再决定需要邀请哪些人参与。', 'Interviews reveal motivation, observation shows behavior, and usability sessions expose friction in a specific journey. Choose the method around the question, then recruit people whose experience is relevant.'] },
      { title: ['将发现连接到决策', 'Connect findings to decisions'], body: ['研究结论需要说明证据、影响和建议。与产品、设计和工程共同讨论取舍，明确哪些内容现在实施，哪些还需要继续验证。', 'Show the evidence, its implications, and a proposed next step. Discuss tradeoffs with product, design, and engineering so findings lead to specific decisions and clearly identified follow-up questions.'] },
      { title: ['让学习成为持续过程', 'Keep learning after release'], body: ['上线之后观察实际使用，将新问题带回下一轮研究。持续的小规模验证，比项目结束才做一次完整检查更有价值。', 'Observe use after release and bring new questions into the next research cycle. Regular small studies keep the team connected to changing needs and help avoid decisions based on outdated assumptions.'] },
    ],
  },
  {
    slug: 'measuring-digital-success-beyond-vanity-metrics', title: ['衡量数字成效，从热闹的数据走向真实价值', 'Measure outcomes beyond the headline numbers'], category: ['数据分析', 'Analytics'], summary: ['从用户目标和业务结果出发，找到值得持续观察的指标。', 'Choose measures that connect user goals to meaningful business outcomes.'], image: 'z42TNMMPzNRP8dVMKkV2UgPkgdg.jpg', date: '2025-05-05',
    sections: [
      { title: ['先定义成功的行为', 'Define the useful outcome'], body: ['访问量反映规模，却未必说明体验有效。先明确用户完成了什么，以及这个行为如何创造价值，再选择对应的指标。', 'Traffic shows scale, but does not tell the full story of an experience. Define the useful thing a person completes and explain how that outcome creates value before selecting a metric.'] },
      { title: ['把过程与结果放在一起', 'Pair journey measures with results'], body: ['同时观察任务完成率、耗时与错误，以及咨询、留存或复购。过程指标帮助定位原因，结果指标帮助判断改动是否值得持续。', 'Observe completion, time, and errors alongside inquiries, retention, or repeat use. Journey measures help locate friction while outcome measures show whether a change deserves further investment.'] },
      { title: ['建立可比较的基线', 'Create a comparable baseline'], body: ['记录改动前的数据口径，区分不同设备和访问来源。给观察留出足够时间，避免把短期波动当作长期变化。', 'Document the measurement definition before a release and examine differences by device and acquisition source. Allow enough observation time to distinguish a short-lived fluctuation from a useful pattern.'] },
      { title: ['让数字带来下一步', 'Turn evidence into action'], body: ['定期讨论数据变化与用户反馈，提出能够验证的改进假设。好的报表应帮助团队决定下一步，而不只是记录过去。', 'Review patterns alongside user feedback and propose a testable improvement. A useful report helps the team decide what to investigate or change next.'] },
    ],
  },
  {
    slug: 'brand-identity-through-bold-typography-choices', title: ['用有主张的字体选择塑造品牌', 'Give your brand a recognizable typographic voice'], category: ['工作方法', 'Process'], summary: ['在文字被读懂之前，字体已经开始传达品牌的性格。', 'Typography gives an impression of your brand before a sentence is fully read.'], image: 'jXir2BtfXSqa7BmBefTGpK2s.png', date: '2025-05-01',
    sections: [
      { title: ['从品牌气质寻找方向', 'Start with the brand character'], body: ['先讨论品牌需要传递的性格，再选择字体。温暖、理性或富有力量的表达，都需要与目标受众和实际内容相匹配。', 'Discuss the character the brand should express before choosing a typeface. Warmth, precision, or confidence should be tested against the audience and the content people will actually read.'] },
      { title: ['用真实内容进行测试', 'Test with real content'], body: ['用产品名称、中文长标题、数字和表单标签检查字体表现。拉丁字母与中文需要独立调整比例，避免只看英文样张就做决定。', 'Try product names, long headings, numbers, and form labels. Test each language independently and adjust proportions so the system works beyond a polished sample headline.'] },
      { title: ['建立克制的排版系统', 'Build a restrained system'], body: ['控制字体和字重数量，以明确的字号、行高与间距形成层级。将规则转化为令牌，让设计与开发使用同一套标准。', 'Use a focused set of families and weights. Establish hierarchy through size, line height, and spacing, then translate those choices into tokens shared by design and engineering.'] },
      { title: ['关注加载与授权', 'Plan for delivery and licensing'], body: ['在项目早期确认字体授权范围与加载成本，优先保留真实字重，设置合适的字形子集和回退顺序。品牌表达也需要可靠的技术基础。', 'Confirm licensing and loading costs early. Use real weights, appropriate subsets, and a considered fallback stack so the visual identity remains dependable in real browsing conditions.'] },
    ],
  },
  {
    slug: 'e-commerce-trends-that-will-shape-2025', title: ['电商体验的新方向：更有用，也更有温度', 'A more useful and considered commerce experience'], category: ['设计趋势', 'Trends'], summary: ['从商品理解到售后支持，重新审视每一步购物体验。', 'Rethink the journey from understanding a product to getting support after purchase.'], image: 'Nr83RY61jRCcbIBNpycA77VZj4.jpg', date: '2025-04-28',
    sections: [
      { title: ['帮助用户做出选择', 'Help people make a choice'], body: ['清晰说明产品适合谁、解决什么问题，比堆叠推荐更有效。高质量影像、尺寸与材料信息，让用户在购买之前建立合理预期。', 'Explain who a product is for and what it helps them do. Useful imagery, dimensions, and material details create a more informed expectation before someone decides to buy.'] },
      { title: ['减少交易中的摩擦', 'Remove friction from checkout'], body: ['尽早展示运费和交付时间，保留购物状态，让地址填写和支付过程更直接。每一个额外步骤都需要说明存在的理由。', 'Show delivery costs and timing early, preserve the basket, and keep address and payment steps focused. Every additional step should have a clear purpose in the journey.'] },
      { title: ['个性化需要透明', 'Keep personalization understandable'], body: ['让用户知道推荐基于什么，并保留调整偏好的入口。将有用的建议与清晰的数据选择结合，才能形成可持续的信任。', 'Explain the basis for recommendations and give people a way to adjust preferences. Useful suggestions work better when the surrounding data choices remain visible and understandable.'] },
      { title: ['把售后看作体验的一部分', 'Include what happens after purchase'], body: ['订单追踪、使用指导和退换说明都影响品牌印象。将这些内容设计得易于查找，会让用户更愿意再次回来。', 'Order tracking, product guidance, and return information all shape the impression of a brand. Make them easy to find so the experience stays helpful after the transaction.'] },
    ],
  },
  {
    slug: 'mobile-first-design-strategies-that-convert-better', title: ['从移动端出发，设计更顺畅的转化路径', 'Design a clearer journey from the smallest screen'], category: ['体验创新', 'Innovation'], summary: ['有限的屏幕空间，让真正重要的内容更加清晰。', 'A smaller canvas helps reveal which content and actions matter most.'], image: 'YYIgVR6qAuLg4dTqt8iqAfwf4.jpg', date: '2025-04-24',
    sections: [
      { title: ['围绕一个关键任务组织首屏', 'Give the first screen a clear purpose'], body: ['移动端首屏需要让用户理解价值，并看见主要操作。先安排标题、说明与行动按钮，再考虑装饰影像和辅助信息。', 'Help people understand the value and find the primary action quickly. Establish the heading, supporting copy, and next step before allocating space to decoration or secondary information.'] },
      { title: ['为触控设计真实空间', 'Design for touch in practice'], body: ['操作区域需要足够大且彼此有间距。菜单、下拉选择和表单应在真实手机上测试，同时关注单手操作与系统键盘出现后的布局。', 'Give controls adequate room and separation. Test menus, selects, and forms on a real phone, including one-handed use and the layout changes caused by the software keyboard.'] },
      { title: ['把速度纳入设计', 'Treat speed as part of design'], body: ['按设备提供合适的图片尺寸，控制首屏资源数量，避免动效阻碍操作。让用户先看到可阅读、可操作的内容。', 'Serve appropriately sized imagery and keep the initial resource load focused. Motion should support the journey while readable, usable content becomes available promptly.'] },
      { title: ['从小屏扩展到大屏', 'Expand the idea across screens'], body: ['在更宽的屏幕上增加并行信息与留白，但保持同样的任务顺序。响应式设计需要重新组织布局，而不只是放大手机画面。', 'Use wider screens to introduce useful parallel information and space while preserving the task sequence. Responsive design reorganizes relationships instead of simply enlarging the mobile layout.'] },
    ],
  },
  {
    slug: 'why-data-should-drive-your-design-decisions', title: ['让数据为设计判断提供支点', 'Use evidence to sharpen design decisions'], category: ['设计趋势', 'Trends'], summary: ['把观察、数据与设计经验结合，让每一次改进更有方向。', 'Combine observation, data, and craft to give each iteration a clearer purpose.'], image: 'up2xNsLfNm1TiEvBiec5TuAxfqM.jpg', date: '2025-04-21',
    sections: [
      { title: ['明确需要回答的问题', 'Begin with a decision'], body: ['先说明团队要做什么决定，再选择数据。问题越具体，越容易找到有意义的观察，也越能避免为了图表而收集信息。', 'Describe the decision the team needs to make before collecting numbers. A specific question makes it easier to identify useful observations and avoid gathering information without a practical purpose.'] },
      { title: ['把行为与动机放在一起', 'Combine behavior and motivation'], body: ['行为数据可以告诉我们哪里出现了中断，访谈帮助理解为什么。把两种证据结合，能减少对单一数字的过度解读。', 'Behavioral data can locate a break in the journey, while a conversation helps explain it. Combining the two reduces the risk of treating a single metric as the whole explanation.'] },
      { title: ['以小步实验降低不确定性', 'Learn through focused experiments'], body: ['为改动写下假设、目标指标与观察周期。尽量减少同时改变的因素，保留对体验质量的人工检查。', 'Write down the hypothesis, outcome measure, and observation period. Keep changes focused enough to interpret, and retain hands-on review of the experience itself.'] },
      { title: ['记录结论与适用边界', 'Document what the evidence means'], body: ['记录结果的同时说明样本与场景。将结论用于下一次设计讨论，而不是把一次实验当成适用于所有页面的规则。', 'Record the audience and context alongside the result. Bring the finding into the next design discussion without assuming a single experiment defines a universal rule.'] },
    ],
  },
  {
    slug: 'breaking-design-conventions-that-actually-work', title: ['有目的地打破惯例，让体验值得记住', 'Challenge a convention with a clear purpose'], category: ['体验创新', 'Innovation'], summary: ['在熟悉的操作基础上，为品牌创造值得记住的时刻。', 'Create memorable brand moments on top of an understandable interaction model.'], image: 'ksEg4SekMNWrHDaIucGbnnaoU.jpg', date: '2025-04-17',
    sections: [
      { title: ['先理解惯例解决了什么', 'Understand the convention first'], body: ['熟悉的模式通常承载着用户预期。决定改变之前，先判断它帮助用户解决什么，再明确新的方式能带来哪些具体价值。', 'Familiar patterns carry expectations. Before changing one, understand the problem it solves and describe the specific value a new approach would add.'] },
      { title: ['在适合的位置表达个性', 'Choose where to be distinctive'], body: ['品牌故事、过渡动效和作品展示可以承载探索。付款、提交和错误提示等关键环节，则需要优先保证清晰与可预测。', 'Brand storytelling, transitions, and project presentations offer room for experimentation. Critical actions such as payment, submission, and error handling benefit from clarity and predictability.'] },
      { title: ['让原型接受真实检验', 'Test the idea in a prototype'], body: ['用可操作的原型检查用户是否理解新的模式。观察他们的行为与情绪，及时调整那些需要额外解释的细节。', 'Use an interactive prototype to see whether people understand the new pattern. Observe both behavior and reactions, and refine the moments that need extra explanation.'] },
      { title: ['为不同偏好保留空间', 'Respect different preferences'], body: ['动效需要尊重减少动态效果设置，复杂交互需要兼顾触控和键盘。优秀的创意应当让更多人感到轻松，而不是增加使用负担。', 'Respect reduced-motion preferences and support touch and keyboard use. An expressive idea should remain comfortable and usable for people with different needs.'] },
    ],
  },
  {
    slug: 'accessible-design-creating-digital-spaces-for-everyone', title: ['为每个人创造更友好的数字空间', 'Create digital spaces that welcome more people'], category: ['无障碍', 'Accessibility'], summary: ['包容性的设计，始于认真对待不同的使用需求。', 'Inclusive design starts with paying attention to different ways of using a product.'], image: 'thm0Z2soUJxKStbIIYagahxi7fE.jpg', date: '2025-04-14',
    sections: [
      { title: ['从语言和内容开始', 'Begin with understandable content'], body: ['清楚的标题、直接的语言和可预测的导航，让更多人能够独立完成任务。优先说明必要信息，把复杂解释拆成可以逐步理解的内容。', 'Clear headings, direct language, and predictable navigation help people complete tasks independently. Prioritize essential information and introduce complexity in manageable steps.'] },
      { title: ['让结构可以被感知', 'Make the structure perceivable'], body: ['使用有序标题、真实按钮与关联标签，为图片提供有意义的说明。页面在没有视觉样式时，也应保留合理的阅读顺序。', 'Use ordered headings, real buttons, associated labels, and meaningful image descriptions. The page should retain a sensible reading order when its visual styling is removed.'] },
      { title: ['覆盖完整的操作路径', 'Support the entire journey'], body: ['从打开菜单到提交表单，都需要检查键盘操作、焦点和状态反馈。成功与错误不应只依赖颜色表达。', 'Review keyboard access, focus, and feedback from the menu through to form submission. Communicate success and errors through text and structure as well as color.'] },
      { title: ['让包容成为团队习惯', 'Make inclusion a shared habit'], body: ['在设计系统中记录组件的交互约定，把无障碍检查纳入日常验收。定期邀请不同用户参与，持续发现新的改进空间。', 'Document interaction expectations in the design system and include accessibility in everyday acceptance checks. Regular participation from a wider audience keeps revealing opportunities to improve.'] },
    ],
  },
]

export const team: { name: string; role: Copy; image: string }[] = [
  { name: 'Maya Yoshido', role: ['创始人 · 创意总监', 'Founder & Creative Director'], image: 'KBYdvhrkL0UezexGBsjnKRpuNYg.jpg' },
  { name: 'Nia Bennett', role: ['策略负责人', 'Head of Strategy'], image: '51S3zjoOrsvbWEgjs8dVcWmWxWA.jpg' },
  { name: 'Leon Kowalski', role: ['技术总监', 'Technical Director'], image: 'fYT9n8MmNxAqmnggbq0d9l4.png' },
  { name: 'Zora Kim', role: ['品牌设计师', 'Brand Designer'], image: '0fskyZgL5pN7wrSJuk8LNVXs.jpg' },
  { name: 'Rafael Ortiz', role: ['资深产品设计师', 'Senior Product Designer'], image: 'sNQtmDVqEDwnilCm1yDju6hcgFw.jpg' },
  { name: 'Cleo Marsh', role: ['动态与交互设计师', 'Motion & Interaction Designer'], image: 'Lbh5JNKTq928IDVkQUSI3At6ZNA.jpg' },
  { name: 'James Okafor', role: ['前端开发工程师', 'Frontend Developer'], image: 'AhP99TxWMUwLglcDkOIYCnFg4I.jpg' },
]
