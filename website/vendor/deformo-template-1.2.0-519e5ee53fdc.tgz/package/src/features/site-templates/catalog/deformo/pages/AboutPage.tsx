import type { SiteTemplatePageProps } from '../../../types'
import { AboutView } from '../components/ContentViews'
import '../theme.css'

export default function AboutPage(props: SiteTemplatePageProps) {
  return <AboutView {...props} />
}

