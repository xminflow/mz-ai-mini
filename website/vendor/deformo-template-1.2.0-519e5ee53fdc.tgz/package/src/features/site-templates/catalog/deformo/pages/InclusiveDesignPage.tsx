import type { SiteTemplatePageProps } from '../../../types'
import { ArticleView } from '../components/ContentViews'
import '../theme.css'
import { articles } from '../data'

const article = articles[9]

export default function InclusiveDesignPage(props: SiteTemplatePageProps) {
  return <ArticleView {...props} article={article} />
}

