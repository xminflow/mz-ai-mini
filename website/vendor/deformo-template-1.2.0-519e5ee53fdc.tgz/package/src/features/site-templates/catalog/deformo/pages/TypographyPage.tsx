import type { SiteTemplatePageProps } from '../../../types'
import { ArticleView } from '../components/ContentViews'
import '../theme.css'
import { articles } from '../data'

const article = articles[4]

export default function TypographyPage(props: SiteTemplatePageProps) {
  return <ArticleView {...props} article={article} />
}

