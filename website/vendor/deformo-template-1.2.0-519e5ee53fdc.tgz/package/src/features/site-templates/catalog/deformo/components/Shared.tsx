'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { AnimatePresence, MotionConfig, motion } from 'framer-motion'
import { createContext, useContext, useEffect, useState, useSyncExternalStore, type ReactNode } from 'react'
import { Reveal } from '../../../shared/Reveal'
import type { SiteTemplatePageProps, TemplateLocale } from '../../../types'
import { articles, navigation, photo, text, type Copy } from '../data'
import { useDeformoHost } from '../host'

const LocaleContext = createContext<TemplateLocale>('zh')
export function useCopy() {
  const locale = useContext(LocaleContext)
  return { locale, t: (zh: string, en: string) => locale === 'en' ? en : zh, copy: (value: Copy) => text(value, locale) }
}

export function Button({ href, children, secondary = false, type = 'button' }: { href?: string; children: ReactNode; secondary?: boolean; type?: 'button' | 'submit' }) {
  const className = `dm-button${secondary ? ' dm-button-secondary' : ''}`
  const content = <>{children}<span aria-hidden="true">↗</span></>
  return href ? <Link className={className} href={href}>{content}</Link> : <button className={className} type={type}>{content}</button>
}

export function Label({ children, number }: { children: ReactNode; number?: string }) {
  return <div className="dm-label">{number ? <span className="dm-number">{number}</span> : <span className="dm-dot" aria-hidden="true" />}<span>{children}</span></div>
}

export function SectionTitle({ number, label, title, description }: { number?: string; label: Copy; title: Copy; description?: Copy }) {
  const { copy } = useCopy()
  return <Reveal className="dm-section-heading"><Label number={number}>{copy(label)}</Label><div className="dm-heading-row"><h2>{copy(title)}</h2>{description && <p>{copy(description)}</p>}</div></Reveal>
}

export function PageHeader({ label, title, description, centered = false }: { label: Copy; title: Copy; description?: Copy; centered?: boolean }) {
  const { copy } = useCopy()
  return <header className={`dm-page-header dm-container${centered ? ' dm-centered' : ''}`}><Reveal><Label>{copy(label)}</Label><div className="dm-heading-row"><h1>{copy(title)}</h1>{description && <p>{copy(description)}</p>}</div></Reveal></header>
}

const subscribeScroll = (listener: () => void) => {
  window.addEventListener('scroll', listener, { passive: true })
  return () => window.removeEventListener('scroll', listener)
}
const scrollSnapshot = () => window.scrollY > 64
const serverScrollSnapshot = () => false

function Navigation({ basePath, home }: { basePath: string; home: boolean }) {
  const { t, locale, copy } = useCopy()
  const pathname = usePathname() ?? basePath
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const scrolled = useSyncExternalStore(subscribeScroll, scrollSnapshot, serverScrollSnapshot)
  const light = home && !scrolled && !open
  const root = locale === 'en' ? basePath.replace(/\/en$/, '') : basePath
  const tail = pathname.startsWith(basePath) ? pathname.slice(basePath.length) : ''
  const languagePath = `${root}${locale === 'en' ? '' : '/en'}${tail}`
  useEffect(() => {
    const close = (event: KeyboardEvent) => { if (event.key === 'Escape') setOpen(false) }
    window.addEventListener('keydown', close)
    return () => window.removeEventListener('keydown', close)
  }, [])

  return <nav className={`dm-nav${light ? ' dm-nav-light' : ''}`} aria-label={t('主导航', 'Main navigation')}>
    <div className="dm-nav-bar">
      <Link href={basePath} className="dm-brand" onClick={() => setOpen(false)} aria-label={t('微域生光首页', 'Weelume home')}><img src={light ? '/templates/deformo/logo/weiyu-logo-web-light.svg' : '/templates/deformo/logo/weiyu-logo-web-dark.svg'} width={24} height={24} alt="" /><span>{t('微域生光', 'Weelume')}</span></Link>
      <span className="dm-nav-caption"><span aria-hidden="true">•</span>{t('独立创意团队', 'Creative Collective')}</span>
      <div className="dm-nav-links">{navigation.slice(1, 4).map(item => <Link key={item.slug} href={`${basePath}/${item.slug}`} aria-current={pathname === `${basePath}/${item.slug}` ? 'page' : undefined}>{copy(item.title)}</Link>)}<Link className="dm-nav-contact" href={`${basePath}/contact`}>{t('联系我们', 'Contact us')}<span aria-hidden="true">→</span></Link></div>
      <Link className="dm-language" href={languagePath} aria-label={t('切换到英文', 'Switch to Chinese')} onClick={event => {
        if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return
        // 在客户端拼接当前查询与锚点，避免服务端读取浏览器状态造成水合差异。
        event.preventDefault()
        setOpen(false)
        router.push(`${languagePath}${window.location.search}${window.location.hash}`, { scroll: false })
      }}>{locale === 'en' ? '中文' : 'EN'}</Link>
      <button type="button" className="dm-menu-toggle" aria-expanded={open} aria-controls="deformo-menu" aria-label={open ? t('关闭菜单', 'Close menu') : t('打开菜单', 'Open menu')} onClick={() => setOpen(!open)}>{open ? '−' : '+'}<span>{t('菜单', 'Menu')}</span></button>
    </div>
    <AnimatePresence>{open && <motion.div id="deformo-menu" className="dm-mobile-menu" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}>{navigation.map((item, index) => <Link key={item.slug} href={`${basePath}${item.slug ? `/${item.slug}` : ''}`} onClick={() => setOpen(false)}><span>0{index + 1}</span>{copy(item.title)}<span aria-hidden="true">↗</span></Link>)}</motion.div>}</AnimatePresence>
  </nav>
}

function Footer({ basePath }: { basePath: string }) {
  const { t, copy } = useCopy()
  const host = useDeformoHost()
  const [submitted, setSubmitted] = useState(false)
  return <footer className="dm-footer">
    <div className="dm-container">
      <div className="dm-footer-top"><div><Link href={basePath} className="dm-brand"><img src="/templates/deformo/logo/weiyu-logo-web-light.svg" width={24} height={24} alt="" /><span>{t('微域生光', 'Weelume')}</span></Link><h2>{t('让每一个好想法\n拥有独特的表达', 'A new perspective\nfor your next chapter')}</h2></div><nav aria-label={t('页脚导航', 'Footer navigation')}>{navigation.map(item => <Link key={item.slug} href={`${basePath}${item.slug ? `/${item.slug}` : ''}`}>{copy(item.title)}</Link>)}</nav><form className="dm-newsletter" onSubmit={event => { event.preventDefault(); setSubmitted(true); console.debug('[deformo] newsletter validation passed; demo only, no request sent') }}><label htmlFor="dm-newsletter-email">{t('订阅设计来信，获得新的灵感与思考', 'A considered note on design, ideas, and what comes next.')}</label><div className="dm-newsletter-input"><input id="dm-newsletter-email" name="newsletter-email" type="email" autoComplete="email" required placeholder={t('你的邮箱地址', 'Your email address')} /><button type="submit">{t('订阅', 'Subscribe')}<span aria-hidden="true">↗</span></button></div><label className="dm-consent"><input type="checkbox" required name="newsletter-consent" /><span>{t('我已阅读并同意', 'I have read and agree to the ')}<Link href={`${basePath}/legal/terms-of-service`}>{t('服务条款', 'Terms of Service')}</Link>{t('与', ' and ')}<Link href={`${basePath}/legal/privacy-policy`}>{t('隐私政策', 'Privacy Policy')}</Link></span></label><p className="dm-demo-note">{t('演示订阅仅在本地校验，不发送或保存数据', 'Demo only: local validation; no data is sent or stored.')}</p>{submitted && <p role="status">{t('校验通过。这是演示订阅，尚未发送或保存。', 'Validated locally. This demo has not sent or stored your subscription.')}</p>}</form></div>
      <div className="dm-footer-wordmark" aria-hidden="true">WEELUME<span>®</span></div>
      <div className="dm-footer-bottom"><span>© 2026 {t('微域生光 · 保留所有权利', 'Weelume · All rights reserved')}</span><Link href={host.marketplaceHref ?? basePath}>{host.marketplaceHref ? t('微域生光：模板市场', 'Weelume: Template marketplace') : t('微域生光首页', 'Weelume home')}</Link>{host.filing}<Link href={`${basePath}/legal/terms-of-service`}>{t('服务条款', 'Terms')}</Link><Link href={`${basePath}/legal/privacy-policy`}>{t('隐私政策', 'Privacy')}</Link></div>
    </div>
  </footer>
}

export function ContactCTA({ basePath }: { basePath: string }) {
  const { t } = useCopy()
  return <section className="dm-contact-cta dm-gradient"><div className="dm-container"><Reveal><Label number="↗">{t('开启对话', 'Get in touch')}</Label><h2>{t('一起创造\n值得骄傲的作品', 'Let’s make something\nworth putting out there')}</h2><p>{t('从一个想法开始，让策略、设计与技术共同推动它发生。我们期待听见你的下一步。', 'Bring a brief, a question, or the beginning of an idea. We would love to hear what you are thinking about.')}</p><div className="dm-actions"><Button href={`${basePath}/contact`}>{t('开始一个项目', 'Start a project')}</Button><Button secondary href={`${basePath}/projects`}>{t('看看我们的作品', 'Explore our work')}</Button></div></Reveal><span className="dm-cta-star" aria-hidden="true">✳</span></div></section>
}

export function ArticleGrid({ basePath, items = articles, showLink = false }: { basePath: string; items?: typeof articles; showLink?: boolean }) {
  const { t, copy } = useCopy()
  return <div className="dm-blog-layout"><aside><p>{t('最新文章\n新的思考', 'Latest articles.\nFresh perspectives.')}</p>{showLink && <Link href={`${basePath}/blog`}>{t('查看全部', 'View all posts')} ↗</Link>}</aside><div className="dm-blog-grid">{items.map(item => <Reveal key={item.slug}><Link className="dm-blog-card" href={`${basePath}/blog/${item.slug}`}><Label>{copy(item.category)}</Label><h3>{copy(item.title)}</h3><div className="dm-blog-image"><img src={photo(item.image)} alt={copy(item.title)} loading="lazy" width={800} height={560} /><span aria-hidden="true">↗</span></div><p>{copy(item.summary)}</p></Link></Reveal>)}</div></div>
}

export function Shell({ basePath, locale = 'zh', children, home = false }: SiteTemplatePageProps & { children: ReactNode; home?: boolean }) {
  const host = useDeformoHost()
  const t = (zh: string, en: string) => locale === 'en' ? en : zh
  const [scrolling, setScrolling] = useState(false)

  useEffect(() => {
    let hideTimer: number | undefined
    const showScrollbar = () => {
      setScrolling(true)
      if (hideTimer !== undefined) window.clearTimeout(hideTimer)
      hideTimer = window.setTimeout(() => setScrolling(false), 650)
    }

    window.addEventListener('scroll', showScrollbar, { passive: true })
    return () => {
      window.removeEventListener('scroll', showScrollbar)
      if (hideTimer !== undefined) window.clearTimeout(hideTimer)
    }
  }, [])

  return <LocaleContext.Provider value={locale}><MotionConfig reducedMotion="user"><div className="dm-site" data-scroll-state={scrolling ? 'scrolling' : 'idle'}><Navigation basePath={basePath} home={home} /><main id="dm-main">{children}<ContactCTA basePath={basePath} /></main><Footer basePath={basePath} /><Link className="dm-market-badge" href={host.marketplaceHref ?? basePath} title={host.marketplaceHref ? t('微域生光：模板市场', 'Weelume: Template marketplace') : t('微域生光首页', 'Weelume home')} aria-label={t('微域生光：模板首页', 'Weelume: Template home')}><img src="/templates/deformo/logo/weiyu-logo-web-light.svg" alt="" width={24} height={24} /><span>{t('微域生光', 'Weelume')}</span></Link></div></MotionConfig></LocaleContext.Provider>
}

