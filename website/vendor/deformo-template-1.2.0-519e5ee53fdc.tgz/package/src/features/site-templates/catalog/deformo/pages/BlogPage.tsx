import type { SiteTemplatePageProps } from '../../../types'
import { BlogView } from '../components/ContentViews'
import '../theme.css'

export default function BlogPage(props: SiteTemplatePageProps) {
  return <BlogView {...props} />
}

