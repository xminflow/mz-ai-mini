import type { SiteTemplatePageProps } from '../../../types'
import { ProjectView } from '../components/ContentViews'
import '../theme.css'
import { projects } from '../data'

const project = projects.find(item => item.slug === 'kinetic')
if (!project) throw new Error('[deformo] Missing project: kinetic')

export default function KineticPage(props: SiteTemplatePageProps) {
  return <ProjectView {...props} project={project!} />
}

