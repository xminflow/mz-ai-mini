import type { SiteTemplatePageProps } from '../../../types'
import { ArticleView } from '../components/ContentViews'
import '../theme.css'
import { articles } from '../data'

const article = articles[6]

export default function MobileFirstPage(props: SiteTemplatePageProps) {
  return <ArticleView {...props} article={article} />
}

