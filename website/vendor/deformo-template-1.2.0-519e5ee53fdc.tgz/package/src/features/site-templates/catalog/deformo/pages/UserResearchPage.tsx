import type { SiteTemplatePageProps } from '../../../types'
import { ArticleView } from '../components/ContentViews'
import '../theme.css'
import { articles } from '../data'

const article = articles[2]

export default function UserResearchPage(props: SiteTemplatePageProps) {
  return <ArticleView {...props} article={article} />
}

