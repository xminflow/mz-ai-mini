import type { SiteTemplatePageProps } from '../../../types'
import { PolicyView } from '../components/ContentViews'
import '../theme.css'

export default function PrivacyPage(props: SiteTemplatePageProps) {
  return <PolicyView {...props} kind="privacy" />
}

