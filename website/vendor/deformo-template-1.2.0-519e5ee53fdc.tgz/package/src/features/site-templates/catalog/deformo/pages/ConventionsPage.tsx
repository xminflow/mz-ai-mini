import type { SiteTemplatePageProps } from '../../../types'
import { ArticleView } from '../components/ContentViews'
import '../theme.css'
import { articles } from '../data'

const article = articles[8]

export default function ConventionsPage(props: SiteTemplatePageProps) {
  return <ArticleView {...props} article={article} />
}

