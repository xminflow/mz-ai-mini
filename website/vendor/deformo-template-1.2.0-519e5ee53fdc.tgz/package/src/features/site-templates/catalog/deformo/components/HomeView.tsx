'use client'

import Link from 'next/link'
import { AnimatePresence, motion } from 'framer-motion'
import { useState } from 'react'
import type { SiteTemplatePageProps } from '../../../types'
import { Reveal } from '../../../shared/Reveal'
import { articles, faqs, photo, process, projects, services, type Project } from '../data'
import { ArticleGrid, Button, Label, SectionTitle, Shell, useCopy } from './Shared'

export function ProjectCards({ basePath, items = projects }: { basePath: string; items?: Project[] }) {
  const { copy, t } = useCopy()
  return <div className="dm-projects">{items.map((project, index) => <Reveal key={project.slug}><Link className="dm-project-card" href={`${basePath}/projects/${project.slug}`}><img src={photo(project.image)} alt={t(`${project.name} 品牌设计作品`, `${project.name} brand design project`)} width={1600} height={1000} loading="lazy" /><div className="dm-project-shade" /><p className="dm-project-description">{copy(project.description)}</p><div className="dm-project-meta"><div><span className="dm-project-index">0{index + 1} / {String(items.length).padStart(2, '0')}</span><h3>{project.name}</h3><div className="dm-tags">{project.tags.map(tag => <span key={tag[1]}>{copy(tag)}</span>)}</div></div><span className="dm-project-link">{t('查看项目', 'View case study')}<span aria-hidden="true">↗</span></span></div></Link></Reveal>)}</div>
}

function Services() {
  const { copy, t } = useCopy()
  const [active, setActive] = useState<number | null>(0)
  return <section className="dm-section dm-container" id="services"><SectionTitle number="01" label={['我们的服务', 'Services']} title={['让复杂的数字挑战\n拥有清晰的答案', 'Complex challenges\nConsidered solutions']} /><div className="dm-services-grid"><Reveal className="dm-service-art dm-glass"><span className="dm-art-orbit" aria-hidden="true">✳</span><p>{t('策略 × 设计 × 技术', 'Strategy × Design × Technology')}</p><span className="dm-art-caption">WEELUME — CREATIVE COLLECTIVE</span></Reveal><div className="dm-accordion">{services.map((service, index) => <div className={`dm-accordion-item${active === index ? ' dm-active' : ''}`} key={service.title[1]}><h3><button type="button" aria-expanded={active === index} aria-controls={`dm-service-${index}`} onClick={() => setActive(active === index ? null : index)}><span className="dm-service-symbol" aria-hidden="true">{service.symbol}</span>{copy(service.title)}<span className="dm-accordion-plus" aria-hidden="true">{active === index ? '−' : '+'}</span></button></h3><AnimatePresence initial={false}>{active === index && <motion.div id={`dm-service-${index}`} className="dm-accordion-panel" initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}><p>{copy(service.description)}</p></motion.div>}</AnimatePresence></div>)}</div></div></section>
}

export function FAQ() {
  const { copy, t } = useCopy()
  const [active, setActive] = useState<number | null>(0)
  return <div className="dm-accordion dm-faq">{faqs.map((item, index) => <div className="dm-accordion-item" key={item.question[1]}><h3><button type="button" onClick={() => setActive(active === index ? null : index)} aria-expanded={active === index} aria-controls={`dm-faq-${index}`}><span>{copy(item.question)}</span><span className="dm-accordion-plus" aria-hidden="true">{active === index ? '−' : '+'}</span></button></h3><AnimatePresence initial={false}>{active === index && <motion.div id={`dm-faq-${index}`} className="dm-accordion-panel" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}><p>{copy(item.answer)}</p></motion.div>}</AnimatePresence></div>)}<p className="dm-demo-note">{t('具体项目范围与排期会在沟通后共同确认', 'Scope and timelines are agreed together for each engagement.')}</p></div>
}

export function ProcessGrid() {
  const { copy } = useCopy()
  return <div className="dm-process-grid">{process.map((step, index) => <Reveal key={step.title[1]} delay={index * .06}><article className="dm-process-card dm-glass"><span className="dm-process-number">0{index + 1}<span aria-hidden="true">↘</span></span><h3>{copy(step.title)}</h3><p>{copy(step.description)}</p></article></Reveal>)}</div>
}

function Testimonials() {
  const { copy, t } = useCopy()
  const [active, setActive] = useState(0)
  const item = projects[active]
  return <section className="dm-section dm-testimonials"><div className="dm-container"><SectionTitle number="06" label={['伙伴的声音', 'Client stories']} title={['好的合作\n让想法走得更远', 'Good people\nGreat collaborations']} /><div className="dm-testimonial-grid"><div className="dm-testimonial-brands">{projects.map((project, index) => <button key={project.slug} type="button" aria-pressed={active === index} onClick={() => setActive(index)}>{project.name}<span aria-hidden="true">↗</span></button>)}</div><div className="dm-quote-wrap"><AnimatePresence mode="wait" initial={false}><motion.figure className="dm-quote" key={active} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }}><span className="dm-quote-mark" aria-hidden="true">“</span><blockquote>{copy(item.quote)}</blockquote><figcaption><span>— {item.founder}</span><span>{item.name} · {t('概念案例评价', 'Illustrative testimonial')}</span></figcaption></motion.figure></AnimatePresence><div className="dm-carousel-controls"><button type="button" aria-label={t('上一条评价', 'Previous testimonial')} onClick={() => setActive((active + projects.length - 1) % projects.length)}>←</button><span>0{active + 1} / 03</span><button type="button" aria-label={t('下一条评价', 'Next testimonial')} onClick={() => setActive((active + 1) % projects.length)}>→</button></div></div></div></div></section>
}

function HomeContent({ basePath }: { basePath: string }) {
  const { t } = useCopy()
  return <>
    <section className="dm-hero dm-gradient"><div className="dm-hero-center"><Reveal><p className="dm-hero-eyebrow">WEELUME® — {t('独立创意团队', 'INDEPENDENT CREATIVE COLLECTIVE')}</p><h1>{t('用不一样的想法\n创造不一样的可能', 'A different perspective\nA distinctive presence')}</h1></Reveal></div><div className="dm-hero-bottom dm-container"><p>{t('连接设计、技术与策略\n让好想法成为真正有影响力的作品', 'Thoughtful strategy, distinctive design, and\ntechnology that brings your ideas to life.')}</p><Button href={`${basePath}/contact`}>{t('与我们合作', 'Work with us')}</Button><span className="dm-hero-scroll" aria-hidden="true">{t('向下探索', 'SCROLL TO EXPLORE')} ↓</span></div></section>
    <section className="dm-intro dm-container"><Reveal><Label>{t('保持好奇，认真创造', 'Curiosity, intention, and craft')}</Label><h2>{t('我们以好奇心看待每个问题\n用策略找到方向\n再以设计与技术，让想法发生', 'Curious minds. Considered ideas.\nCarefully crafted digital work\nthat makes a lasting impression.')}</h2><p>{t('每个品牌都有自己的故事。我们帮助它找到独特而清晰的表达。', 'Every brand has a story. We help it find a clear and distinctive expression.')}</p></Reveal></section>
    <Services />
    <section className="dm-section dm-about-band"><div className="dm-container"><SectionTitle number="02" label={['关于微域生光', 'About Weelume']} title={['有主张的团队\n有温度的创造', 'Independent thinkers\nOne shared ambition']} description={['我们汇聚设计、技术与商业的不同视角，把复杂的问题变成值得使用、值得记住的数字体验。', 'Different backgrounds in design, technology, and business. A shared commitment to making digital experiences that are useful and memorable.']} /><Reveal className="dm-stats"><div><strong>85<span>+</span></strong><h3>{t('项目交付', 'Projects delivered')}</h3></div><div><strong>25<span>+</span></strong><h3>{t('跨领域伙伴', 'Creative specialists')}</h3></div><div><strong>1.47<span>×</span></strong><h3>{t('业务成长', 'Client growth')}</h3></div><div className="dm-stat-vision"><strong aria-hidden="true">✳</strong><h3>{t('让愿景成为现实', 'Your vision, realized')}</h3></div></Reveal><p className="dm-demo-note">{t('以上为模板演示数据，不代表微域生光实际经营业绩', 'Illustrative template data; not a statement of Weelume business results.')}</p></div></section>
    <section className="dm-section dm-container"><SectionTitle number="03" label={['精选作品', 'Selected projects']} title={['好的想法\n在这里发生', 'Ideas made tangible\nOur selected work']} /><ProjectCards basePath={basePath} /></section>
    <section className="dm-philosophy dm-gradient"><div className="dm-container"><Reveal><Label number="04">{t('我们的理念', 'Our philosophy')}</Label><h2>{t('大胆想象\n灵活思考\n独特表达', 'Think boldly.\nStay adaptable.\nMake it distinct.')}</h2><p>{t('让每一个设计决定都服务真实的目标，在清晰的策略与自由的探索之间，找到品牌独有的答案。', 'Make room for unexpected ideas, ground them in a clear strategy, and shape an experience that feels unmistakably yours.')}</p><Button href={`${basePath}/about-us`}>{t('进一步了解我们', 'Get to know us')}</Button></Reveal><span className="dm-philosophy-star" aria-hidden="true">✳</span></div></section>
    <section className="dm-section dm-container" id="process"><SectionTitle number="05" label={['合作流程', 'Our process']} title={['从初次对话\n到共同创造', 'From the first conversation\nTo the next chapter']} /><ProcessGrid /></section>
    <Testimonials />
    <section className="dm-section dm-container" id="pricing"><SectionTitle number="07" label={['合作方式', 'Ways to work together']} title={['清晰的合作\n透明的投入', 'Clear expectations\nA considered investment']} description={['一次聚焦的项目，或一段长期的设计伙伴关系。选择适合你当前阶段的方式。', 'A focused project or a continuing design partnership. Choose the arrangement that fits your next step.']} /><div className="dm-pricing-grid"><Reveal><article className="dm-price-card dm-glass"><Label>{t('按项目合作', 'Project engagement')}</Label><div className="dm-price">$2,999<span>+</span></div><p>{t('每个项目 · 演示报价', 'Per project · illustrative pricing')}</p><span className="dm-price-status"><i />{t('48 小时内响应需求', 'A considered response within 48 hours')}</span><h3>{t('明确范围，专注交付', 'Focused scope. Thoughtful delivery.')}</h3><p>{t('围绕一个清晰的目标，制定完整方案和交付计划。适合品牌升级、网站重构或新产品设计。', 'A defined scope and a shared timeline for a brand refresh, a new website, or a focused product challenge.')}</p><Button href={`${basePath}/contact?plan=project`}>{t('聊聊你的项目', 'Discuss a project')}</Button></article></Reveal><Reveal delay={.08}><article className="dm-price-card dm-price-featured dm-glass"><span className="dm-popular">{t('长期伙伴', 'Design partnership')} ↗</span><Label>{t('按月合作', 'Monthly retainer')}</Label><div className="dm-price">$3,999</div><p>{t('每月 · 演示报价', 'Per month · illustrative pricing')}</p><span className="dm-price-status"><i />{t('灵活协作，持续推进', 'A flexible, continuing collaboration')}</span><h3>{t('和你的团队，一起向前', 'A creative team by your side.')}</h3><p>{t('持续获得策略、设计与开发支持。每月约 80 小时协作，范围与退出安排在实际合作前确认。', 'Ongoing strategy, design, and development support, with an illustrative allocation of 80 hours per month. Terms are agreed before work begins.')}</p><Button href={`${basePath}/contact?plan=retainer`}>{t('成为设计伙伴', 'Explore a partnership')}</Button></article></Reveal></div></section>
    <section className="dm-section dm-container"><SectionTitle number="08" label={['设计洞察', 'From the journal']} title={['把思考分享出来', 'Ideas worth sharing']} /><ArticleGrid basePath={basePath} items={articles.slice(0, 2)} showLink /></section>
    <section className="dm-section dm-faq-section"><div className="dm-container"><SectionTitle number="09" label={['常见问题', 'Frequently asked questions']} title={['在开始之前\n你可能想了解', 'A few things\nYou might be wondering']} /><div className="dm-faq-grid"><div><p>{t('关于合作方式、项目节奏与我们的工作方法，在这里找到答案。还有其他问题，欢迎随时联系。', 'A little more about how we work, what to expect, and how to get started. We are happy to discuss anything else.')}</p><Button href={`${basePath}/contact`}>{t('联系我们', 'Get in touch')}</Button></div><FAQ /></div></div></section>
  </>
}

export function HomeView(props: SiteTemplatePageProps) {
  return <Shell {...props} home><HomeContent basePath={props.basePath} /></Shell>
}
