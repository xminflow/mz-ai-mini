import type { SiteTemplatePageProps } from '../../../types'
import { ArticleView } from '../components/ContentViews'
import '../theme.css'
import { articles } from '../data'

const article = articles[3]

export default function DigitalMetricsPage(props: SiteTemplatePageProps) {
  return <ArticleView {...props} article={article} />
}

