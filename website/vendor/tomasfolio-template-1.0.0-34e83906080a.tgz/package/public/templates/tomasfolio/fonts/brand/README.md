# 本地字体

本模板自带 MiSans 与 Poppins，运行不依赖外部字体服务或其他工程。字体声明使用 Tomasfolio 独立字体族；许可文件随目录保留。
