/** 英文独立路径返回中文时保持单个前导斜线，兼容宿主挂载路径。 */
export function languagePath(basePath:string,pathname:string,locale:'zh'|'en'):string{const root=locale==='en'?basePath.replace(/\/en$/,''):basePath;const tail=basePath?pathname.slice(basePath.length):pathname==='/'?'':pathname;return (locale==='en'?root+tail:root+'/en'+tail)||'/'}
