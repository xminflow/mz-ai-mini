export const brand={name:{zh:'托马斯',en:'tomas'},logo:'/templates/tomasfolio/logo.svg',lightLogo:'/templates/tomasfolio/logo-light.svg',email:'hello@tomasfolio.design',year:2026}

