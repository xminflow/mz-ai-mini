'use client'
import { Shell,Intro,t } from '../components/Shell'
import { Articles } from '../components/Collections'
import type { SiteTemplatePageProps } from '../../../types'
export default function ArticlesPage({basePath,locale='zh'}:SiteTemplatePageProps){return <Shell basePath={basePath} locale={locale}><Intro eyebrow={t(locale,'设计 / 思考 / 新知','Design / Thinking / Insight')} title={t(locale,'文章与新想法','Articles & News')}/><section className="tm-section tm-section-first"><Articles basePath={basePath} locale={locale}/></section></Shell>}
