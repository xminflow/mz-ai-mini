export const asset=(path:string)=>'/templates/tomasfolio/'+path
export const projects=[
  {
    "slug": "auralis",
    "name": "Auralis",
    "summary": {
      "zh": "以半透明材质与人类感知探索人工智能的品牌识别",
      "en": "A brand identity exploring artificial intelligence through translucency and human perception."
    },
    "cover": "assets/4dck2m67Jky5nDwEYq1Gb9duA.png",
    "images": [
      "assets/bzManDoE7oWx6Ush2HZSkoa6WTQ.png",
      "assets/IT8WCjMRbeYaESCAOW7FiTxhFZ0.png",
      "assets/aHQtN3pnPfotpJMeZnrLIiueQs.png",
      "assets/AtWlvvQGssUVox1CDDiaaU4.png"
    ],
    "category": {
      "zh": "研究与技术",
      "en": "Research & Technology"
    },
    "deliverable": {
      "zh": "品牌识别",
      "en": "Brand Identity"
    },
    "timeline": "2 months · 2024",
    "description": {
      "zh": "Auralis 关注以人为本的智能研究。品牌将有机形态、光感材质与生成纹理融为一体，让先进技术呈现直观、平静且富有情感的气质。",
      "en": "Auralis is an AI research and development brand focused on human-centric intelligence. The identity blends organic forms, light-reactive materials, and generative textures to express advanced cognition that feels intuitive, calm, and emotionally aware rather than purely technical."
    }
  },
  {
    "slug": "synta",
    "name": "Synta",
    "summary": {
      "zh": "用结构与有机张力表达智能的触感视觉系统",
      "en": "A tactile visual system expressing intelligence through structure and organic tension."
    },
    "cover": "assets/fmXj9WshOciYhrHXHDg7ECRk7SY.png",
    "images": [
      "assets/ESvdwGH8YG1KYTcNyoOMxE2A0.png",
      "assets/XCI97n6gOJxjrxoIeRT9xRkKKec.png",
      "assets/yLWub8mPI0KNcA5O4q2RaTxsHMo.png",
      "assets/PHfK3dThGCAMTsypRsEjuMEuoE.png"
    ],
    "category": {
      "zh": "应用研究",
      "en": "Applied Research"
    },
    "deliverable": {
      "zh": "生成式视觉",
      "en": "Generative Visuals"
    },
    "timeline": "2 months · 2024",
    "description": {
      "zh": "Synta 探索受自然几何启发的合成系统。通过抽象有机形态和清晰的结构逻辑，塑造兼具实验精神、前瞻性与可信度的品牌。",
      "en": "Synta is an AI research platform exploring synthetic systems inspired by natural geometry. The branding merges abstract organic forms with sharp structural logic, positioning the company as experimental, forward-looking, and grounded."
    }
  },
  {
    "slug": "korop-co",
    "name": "Korop.Co",
    "summary": {
      "zh": "以平衡和控制为核心的 AI 平台极简品牌",
      "en": "Minimal branding for an AI systems platform built on balance and control."
    },
    "cover": "assets/XEPfDOs0VtLyIu4xBDMlM6iztig.png",
    "images": [
      "assets/gz7dC7LVHzqmoK1vNyG0yuM30.png",
      "assets/NbzEYITaG4CNdXbWuZLDLenmB4.png",
      "assets/xBX09akpHRctAu5x7aUo3UJ3pI.png",
      "assets/TOlgUKnqmaaLR2CkP7Q2Cnzkssw.png"
    ],
    "category": {
      "zh": "企业软件",
      "en": "Enterprise Software"
    },
    "deliverable": {
      "zh": "iOS 应用",
      "en": "iOS App"
    },
    "timeline": "1 month · 2023",
    "description": {
      "zh": "KOROP 专注 AI 基础设施的编排与系统协同。减法设计、开阔留白与克制色彩共同传达精确、可靠与自信。",
      "en": "KOROP is an AI infrastructure company focused on orchestration and system harmony. The branding uses reduction, wide spatial tension, and restrained color to communicate precision, reliability, and confidence without relying on typical futuristic or sci-fi aesthetics."
    }
  },
  {
    "slug": "nexaformat",
    "name": "NexaFormat",
    "summary": {
      "zh": "为生成智能与工业自动化打造材质驱动的品牌",
      "en": "Material-driven identity for generative intelligence and industrial automation."
    },
    "cover": "assets/Hgf1K9JpIXktLSrq4TBQcfuzc4.png",
    "images": [
      "assets/e8zXU0raKEI192fsbrthKFLNrM.png",
      "assets/Vb6fbcRC77TgreJiJa4DzUbo.png",
      "assets/5Ucr3vNfh7ZoInE72vj0wkUm5LM.png",
      "assets/qfThZaV9XqfTFBsmRPYEEHGT4ZM.png",
      "assets/R0YIvf3HsRoz90sxG0GuXoYjs.png"
    ],
    "category": {
      "zh": "工业与制造",
      "en": "Industrial & Manufacturing"
    },
    "deliverable": {
      "zh": "视觉识别",
      "en": "Visual Identity"
    },
    "timeline": "Ongoing · 2025",
    "description": {
      "zh": "NEXFORM 连接机器智能与制造业。视觉语言把算法转化为具有工程感的实体形态，通过反射材质与受控结构呈现精确性、可扩展性和技术深度。",
      "en": "NEXFORM is an AI company operating at the intersection of machine intelligence and manufacturing. The visual language translates algorithmic processes into physical, engineered forms, using reflective materials and controlled structure to emphasize precision, scalability, and technical depth."
    }
  },
  {
    "slug": "gradia",
    "name": "Gradia",
    "summary": {
      "zh": "围绕渐变、数据流与转变建立的克制识别系统",
      "en": "A restrained identity system centered on gradients, data flow, and transition."
    },
    "cover": "assets/QdZ39kurLDL67P3WqYtE1w2Lc.png",
    "images": [
      "assets/EqCFZgf5MVYTrjYeKkYMZTQdx0c.png",
      "assets/UZ10dM5GMmlKnNEWDQ3W0I6UpjY.png",
      "assets/ueugCtBH77ESmhG5tIFBFoXONIM.png",
      "assets/wboAdooId8jBSjCy8Qb7Tv2n8Xw.png"
    ],
    "category": {
      "zh": "设计工具与 SaaS",
      "en": "Design Tools & SaaS"
    },
    "deliverable": {
      "zh": "品牌识别",
      "en": "Brand Identity"
    },
    "timeline": "1 month · 2024",
    "description": {
      "zh": "GRADIA 将原始数据转化为实用洞察。细腻渐变、肌理变化与色调过渡表现持续学习、演化和逐渐清晰的计算过程。",
      "en": "GRADIA is an AI design tool focused on transforming raw data into usable insight. The identity relies on subtle gradients, texture shifts, and tonal transitions to represent continuous learning, evolution, and clarity emerging through computation."
    }
  }
]
export const articles=[
  {
    "slug": "generate-design-ideas",
    "title": {
      "zh": "借助 AI 构建更聪明、更高效的设计工作流",
      "en": "Harnessing the Power of AI to Build Smarter and More Efficient Design Workflows."
    },
    "category": {
      "zh": "人工智能",
      "en": "Artificial Intelligence"
    },
    "date": "2024-12-13",
    "image": "assets/f4FuSNy2wJ3AzgJ2wNXvKVjHK9I.png",
    "body": {
      "en": [
        {
          "tag": "h2",
          "text": "Streamline repetitive tasks"
        },
        {
          "tag": "p",
          "text": "AI can take over the repetitive, time-consuming tasks that often slow down the design process. Tools like AI-powered design assistants can help with resizing images, generating color palettes, or suggesting layouts. This gives you more time to focus on the creative and strategic aspects of your work."
        },
        {
          "tag": "h3",
          "text": "Generate design variations"
        },
        {
          "tag": "p",
          "text": "When you're stuck in the design process, AI can help you break free from creative blocks. Tools like DALL·E or MidJourney can generate design variations, layouts, or illustrations based on simple prompts, offering fresh perspectives. This allows you to explore a wider range of options quickly and move forward without getting bogged down in iterations."
        },
        {
          "tag": "h3",
          "text": "Personalize user experiences"
        },
        {
          "tag": "p",
          "text": "AI can analyze user behavior to help you design more personalized experiences. By using AI to track how users interact with your product, you can identify patterns, preferences, and pain points. This data can be used to create designs that are more intuitive, responsive, and tailored to individual needs, improving the overall user experience."
        },
        {
          "tag": "h3",
          "text": "Optimize your UI with data-driven insights"
        },
        {
          "tag": "p",
          "text": "AI tools like heatmaps and user session recordings can give you valuable insights into how users are interacting with your design. This allows you to refine your UI, improve usability, and make more data-informed decisions about layout, content placement, and navigation."
        },
        {
          "tag": "h3",
          "text": "Automate user testing"
        },
        {
          "tag": "p",
          "text": "AI-driven tools can simulate user behavior, allowing you to test design variations quickly without waiting for human participants. This can help you validate your ideas faster and with fewer resources. Some tools can even predict how changes will affect user interactions based on historical data, speeding up the iteration cycle."
        },
        {
          "tag": "h3",
          "text": "Boost collaboration with AI-powered tools"
        },
        {
          "tag": "p",
          "text": "AI can also enhance teamwork and communication. With collaborative platforms powered by AI, design teams can automatically sync updates, track design changes, and even get feedback on their work. This helps ensure everyone is aligned and minimizes the time spent on back-and-forth communication."
        },
        {
          "tag": "h3",
          "text": "Improve accessibility and inclusivity"
        },
        {
          "tag": "p",
          "text": "AI can assist in making your designs more inclusive. Tools like color contrast analyzers and accessibility checkers can automatically scan your design for accessibility issues, helping you ensure that your product is usable for people with diverse abilities. AI can also provide suggestions for improving content accessibility, like simplifying language or optimizing for screen readers."
        },
        {
          "tag": "h3",
          "text": "Final thoughts"
        },
        {
          "tag": "p",
          "text": "AI is a powerful ally in your product design toolkit. By automating routine tasks, personalizing experiences, and providing deeper insights into user behavior, AI can help you work more efficiently, make smarter decisions, and ultimately create better products. Embrace these tools to not replace your creativity but to amplify it, allowing you to focus on what really matters: solving user problems and designing meaningful experiences."
        }
      ],
      "zh": [
        {
          "tag": "h3",
          "text": "精简重复任务"
        },
        {
          "tag": "p",
          "text": "让 AI 协助调整图像尺寸、生成配色和探索布局，把时间留给创意和策略判断。"
        },
        {
          "tag": "h3",
          "text": "生成设计变体"
        },
        {
          "tag": "p",
          "text": "遇到创意瓶颈时，用清晰的提示探索视觉方向，再根据项目目标筛选与完善。"
        },
        {
          "tag": "h3",
          "text": "个性化用户体验"
        },
        {
          "tag": "p",
          "text": "通过行为模式了解偏好与痛点，同时尊重隐私，让界面更直观、更符合实际需求。"
        },
        {
          "tag": "h3",
          "text": "用数据优化界面"
        },
        {
          "tag": "p",
          "text": "结合热力图和会话观察，判断内容布局与导航是否有效，而不是只凭直觉做决定。"
        },
        {
          "tag": "h3",
          "text": "辅助用户测试"
        },
        {
          "tag": "p",
          "text": "模拟可以帮助发现早期问题，但重要决策仍需真实用户参与，避免将预测当作事实。"
        },
        {
          "tag": "h3",
          "text": "促进团队协作"
        },
        {
          "tag": "p",
          "text": "用自动同步和变更追踪减少沟通成本，确保设计、产品与工程围绕同一目标工作。"
        },
        {
          "tag": "h3",
          "text": "提升可访问性"
        },
        {
          "tag": "p",
          "text": "检查对比度、阅读顺序和屏幕阅读器体验，让不同能力的用户都能使用产品。"
        },
        {
          "tag": "h3",
          "text": "结语"
        },
        {
          "tag": "p",
          "text": "AI 可以放大设计能力。让它承担重复劳动，把人的判断留给问题定义和有意义的体验。"
        }
      ]
    }
  },
  {
    "slug": "is-figma-all-you-need",
    "title": {
      "zh": "选择合适的平台，让作品集真正呈现你的思考",
      "en": "Choosing the Right Platform and Building a Portfolio That Properly Showcases Your Work."
    },
    "category": {
      "zh": "设计系统",
      "en": "Design Systems"
    },
    "date": "2025-02-01",
    "image": "assets/Oaa6Roge4dFd1t5ZjWu3VddswR0.png",
    "body": {
      "en": [
        {
          "tag": "h2",
          "text": "For designers, a portfolio isn’t just a collection of projects—it’s how you tell your story and guide someone through your thinking. With tools like Figma making it easy to create interactive case studies, some designers wonder if a dedicated website is even necessary. But is Figma really the best way to present your work, or does a website offer something more?"
        },
        {
          "tag": "h3",
          "text": "The problem with Figma portfolios"
        },
        {
          "tag": "p",
          "text": "Figma is great for design work, but not necessarily for showcasing it. Unlike a structured website, a Figma file can feel disorienting, requiring viewers to zoom in and pan around to find what they need. There's no clear navigation, and unless someone is familiar with the tool, they might struggle to follow your case studies. Plus, sharing a raw Figma file doesn’t create a polished first impression—it feels more like handing over a work-in-progress."
        },
        {
          "tag": "h3",
          "text": "Why a website still matters"
        },
        {
          "tag": "p",
          "text": "A website gives you full control over how your work is presented. It allows you to guide visitors through your process in a structured, engaging way, without distractions. A well-designed portfolio site also signals professionalism, making you more memorable to recruiters, clients, and anyone who comes across your work. Unlike a Figma link, a website is easy to access, works on any device, and gives you a permanent space to build your personal brand."
        },
        {
          "tag": "h3",
          "text": "When Figma might be enough"
        },
        {
          "tag": "p",
          "text": "If you’re sharing your work with a hiring manager or team that already uses Figma daily, a Figma-based portfolio might work as a temporary solution. It’s quick to set up and easy to update. But even then, it’s worth considering a more structured approach—like using Framer, Notion, or a simple one-page site—to avoid the friction that comes with navigating a raw Figma file."
        },
        {
          "tag": "h3",
          "text": "Final thoughts"
        },
        {
          "tag": "p",
          "text": "Figma is an incredible design tool, but it’s not the best way to present a portfolio. A dedicated website gives your work the structure, clarity, and polish it deserves. If you want to make a strong impression and ensure your work is easy to navigate, investing in a website is the way to go."
        }
      ],
      "zh": [
        {
          "tag": "h3",
          "text": "作品集也是你的叙事"
        },
        {
          "tag": "p",
          "text": "作品集不仅是项目的集合，更要引导读者理解你的思考。设计文件很适合协作，但展示还需要清晰的阅读路径。"
        },
        {
          "tag": "h3",
          "text": "Figma 作品集的局限"
        },
        {
          "tag": "p",
          "text": "缩放和平移会打断阅读，没有明确导航时，访客很难按预期理解案例，原始文件也容易显得尚未完成。"
        },
        {
          "tag": "h3",
          "text": "为什么仍然需要网站"
        },
        {
          "tag": "p",
          "text": "网站提供清晰结构、跨设备访问和稳定的个人品牌入口，让读者专注于问题、过程与结果。"
        },
        {
          "tag": "h3",
          "text": "什么时候可以使用 Figma"
        },
        {
          "tag": "p",
          "text": "熟悉工具的招聘团队可以快速查看文件，但面向更多读者时，仍应提供易于访问的展示方式。"
        },
        {
          "tag": "h3",
          "text": "结语"
        },
        {
          "tag": "p",
          "text": "选择工具时，优先考虑读者如何理解内容。好的作品集应该让作品的价值自然显现。"
        }
      ]
    }
  },
  {
    "slug": "finding-your-first-gig",
    "title": {
      "zh": "没有经验，如何进入设计行业并找到第一份机会",
      "en": "Breaking Into the Design Industry and Finding Opportunities Without Prior Experience."
    },
    "category": {
      "zh": "设计",
      "en": "Design"
    },
    "date": "2025-01-04",
    "image": "assets/gKnOksbAO56Pg2v4fTAz0jtI7E4.png",
    "body": {
      "en": [
        {
          "tag": "h2",
          "text": "Document your learning process on platforms like LinkedIn, Twitter, or a personal blog. Share what you’re working on, what you’ve learned, and how you approach problems. This not only helps you build credibility but also attracts opportunities. Many hiring managers value passion and problem-solving skills just as much as experience."
        },
        {
          "tag": "h3",
          "text": "Network strategically"
        },
        {
          "tag": "p",
          "text": "Networking isn’t just about sending cold messages on LinkedIn—it’s about building genuine relationships. Join tech communities, attend meetups, and engage in conversations where recruiters and hiring managers are active. If you admire someone’s work, reach out with a thoughtful message. Sometimes, a personal connection can open doors that job applications can’t."
        },
        {
          "tag": "h3",
          "text": "Tailor your applications"
        },
        {
          "tag": "p",
          "text": "Instead of sending the same resume to dozens of companies, customize your application for each role. Highlight relevant skills, tweak your portfolio to match the job, and write a compelling cover letter that explains why you’re a great fit. Recruiters can spot a generic application instantly—showing effort increases your chances of getting noticed."
        },
        {
          "tag": "h3",
          "text": "Apply before you feel ready"
        },
        {
          "tag": "p",
          "text": "Imposter syndrome is real, but don’t let it hold you back. Many job postings list “requirements” that aren’t actually dealbreakers. If you meet 60–70% of the qualifications, apply anyway. Hiring managers know that junior candidates won’t have years of experience—they’re looking for problem-solvers with a willingness to learn."
        },
        {
          "tag": "p",
          "text": "Final thoughts"
        },
        {
          "tag": "p",
          "text": "Your first tech job won’t come from waiting for the perfect opportunity—it comes from taking action. Build projects, put yourself out there, and don’t be afraid to apply before you feel ready. The sooner you start, the sooner you’ll land that first role."
        }
      ],
      "zh": [
        {
          "tag": "h3",
          "text": "公开你的学习过程"
        },
        {
          "tag": "p",
          "text": "分享正在做的项目、学到的知识和解决问题的方法。持续记录可以建立可信度，也能吸引合适的机会。"
        },
        {
          "tag": "h3",
          "text": "有目的地建立联系"
        },
        {
          "tag": "p",
          "text": "参加社区和交流活动，认真讨论你欣赏的作品。真诚的关系往往比批量发送冷消息更有效。"
        },
        {
          "tag": "h3",
          "text": "为岗位调整申请"
        },
        {
          "tag": "p",
          "text": "针对职位选择案例，突出相关能力，并解释你为什么适合团队，避免机械地投递同一份简历。"
        },
        {
          "tag": "h3",
          "text": "准备好之前也可以申请"
        },
        {
          "tag": "p",
          "text": "不要被职位描述中的每一项要求吓退。初级岗位更看重解决问题的能力和学习意愿。"
        },
        {
          "tag": "h3",
          "text": "结语"
        },
        {
          "tag": "p",
          "text": "主动做项目、分享过程并尝试申请。第一份机会往往来自行动，而不是等待万事俱备。"
        }
      ]
    }
  },
  {
    "slug": "design-systems-in-the-age-of-ai",
    "title": {
      "zh": "AI 正在怎样改变设计系统的构建与扩展",
      "en": "How AI is transforming the way we build and scale design systems."
    },
    "category": {
      "zh": "人工智能",
      "en": "Artificial Intelligence"
    },
    "date": "2025-02-08",
    "image": "assets/M1GMryexbMWxZttYUczNsfy6JlM.png",
    "body": {
      "en": [
        {
          "tag": "h2",
          "text": "How AI is transforming the way we build and scale design systems"
        },
        {
          "tag": "p",
          "text": "Design systems have long been the foundation of scalable, consistent, and efficient product design. They provide structure, align teams, and ensure that interfaces feel cohesive across platforms. But as AI rapidly changes how we design and develop digital products, the role of design systems is evolving. The question is—how do we adapt?"
        },
        {
          "tag": "h3",
          "text": "AI as a co-designer"
        },
        {
          "tag": "p",
          "text": "AI isn’t just automating design tasks; it’s becoming an active participant in the creative process. From generating layout variations to suggesting component usage based on patterns, AI-powered tools are streamlining workflows. This shift means that design systems can no longer be rigid—they need to support dynamic, evolving guidelines that accommodate AI-driven decisions."
        },
        {
          "tag": "h3",
          "text": "Beyond static libraries"
        },
        {
          "tag": "p",
          "text": "Traditional design systems are built around predefined components and fixed guidelines. But AI challenges this static nature. Imagine a system that learns from real-world usage, automatically refining components, adjusting design tokens, or even personalizing UI elements based on user behavior. The future of design systems isn’t just about consistency—it’s about intelligent adaptability."
        },
        {
          "tag": "h3",
          "text": "The rise of AI-generated components"
        },
        {
          "tag": "p",
          "text": "With AI generating layouts, typography pairings, and even full design patterns, the need for manually crafted components is shifting. Instead of focusing on pixel-perfect execution, designers will play a more strategic role—defining core principles, ensuring accessibility, and curating AI-generated outputs to align with a brand’s identity and user needs."
        },
        {
          "tag": "h3",
          "text": "Design systems as data hubs"
        },
        {
          "tag": "p",
          "text": "AI thrives on structured data, and design systems are rich with it. From component usage patterns to accessibility compliance and performance insights, these systems will increasingly serve as datasets that feed AI. This will lead to better automation, smarter design recommendations, and more intuitive developer handoffs."
        },
        {
          "tag": "h3",
          "text": "What designers need to adapt"
        },
        {
          "tag": "p",
          "text": "The shift toward AI-driven design systems isn’t about replacing human creativity—it’s about enhancing it. Designers will need to rethink how they build and maintain systems, moving away from static rules and embracing adaptive frameworks. The key will be balancing automation with intentional, human-centered design."
        },
        {
          "tag": "h3",
          "text": "Final thoughts"
        },
        {
          "tag": "p",
          "text": "In the age of AI, design systems are evolving from static repositories to intelligent, learning-driven ecosystems. The challenge now is ensuring they remain flexible, scalable, and—most importantly—human-centered. Designers who embrace this shift will be at the forefront of a new era in digital product design."
        }
      ],
      "zh": [
        {
          "tag": "h3",
          "text": "设计系统的新角色"
        },
        {
          "tag": "p",
          "text": "设计系统为产品提供一致性与结构。随着 AI 参与设计和开发，我们需要让规范适应新的工作方式。"
        },
        {
          "tag": "h3",
          "text": "AI 成为协作设计者"
        },
        {
          "tag": "p",
          "text": "从布局变体到组件建议，AI 正在参与创作。系统需要支持演进，同时保持明确的设计原则。"
        },
        {
          "tag": "h3",
          "text": "超越静态组件库"
        },
        {
          "tag": "p",
          "text": "未来的系统可以根据真实使用情况发现改进机会，但令牌与组件的变化仍需经过审阅和验证。"
        },
        {
          "tag": "h3",
          "text": "生成式组件的兴起"
        },
        {
          "tag": "p",
          "text": "设计师的重心会更多转向定义原则、保障可访问性和筛选输出，让生成结果符合品牌与用户需求。"
        },
        {
          "tag": "h3",
          "text": "设计系统成为数据中心"
        },
        {
          "tag": "p",
          "text": "组件使用情况、性能与可访问性检查可以为自动化提供依据，帮助设计与开发更顺畅地协作。"
        },
        {
          "tag": "h3",
          "text": "设计师如何适应"
        },
        {
          "tag": "p",
          "text": "在自动化和以人为本的设计之间保持平衡。用灵活的框架支持变化，而不是放弃有意图的判断。"
        },
        {
          "tag": "h3",
          "text": "结语"
        },
        {
          "tag": "p",
          "text": "设计系统正从静态仓库走向可演进的生态。保持灵活、可扩展和以人为本，是持续维护的关键。"
        }
      ]
    }
  }
]
export const services=[{symbol:'✳',title:{zh:'策略',en:'Strategy'},description:{zh:'帮助团队定义方向、做出明智决策，并围绕共同观点形成共识。',en:'I help teams define direction, make informed decisions, and align around a shared point of view.'},tags:{zh:['定位','方向','共识'],en:['Positioning','Direction','Alignment']}},{symbol:'◎',title:{zh:'识别',en:'Identity'},description:{zh:'从字体、视觉语言到品牌语气与一致性，让一切作为同一系统协同工作。',en:'From typography and visual language to tone and consistency, everything works as one system.'},tags:{zh:['字体','视觉','语气','一致性'],en:['Typography','Visuality','Voice','Consistency']}},{symbol:'⌘',title:{zh:'数字体验',en:'Digital'},description:{zh:'设计与构建网站、平台和界面，关注清晰表达、易用性与可扩展性。',en:'Designs and builds websites, platforms, and interfaces. Focused on clarity, usability, and scalability.'},tags:{zh:['架构','交互','系统','性能'],en:['Architecture','Interaction','Systems','Performance']}}]
export const experience=[['Google','2024 — Present','设计负责人','Design Lead','负责多产品设计方向、指导团队并建立质量标准。','Owns design direction across product areas, mentors designers, and sets quality standards.'],['Apple','2023 — 2024','产品设计师','Product designer','设计端到端的产品体验，与工程团队共同完成交付。','Designed end-to-end experiences and partnered with engineering through implementation and QA.'],['Meta','2021 — 2023','高级平面设计师','Sr Graphic Designer','为品牌活动建立视觉系统，与跨职能团队协作。','Led visual execution for campaigns and cross-team initiatives.'],['Adobe','2019 — 2021','平面设计师','Graphic Designer','为数字渠道、活动和产品传播设计一致的品牌素材。','Designed marketing and brand assets across digital channels.']] as const
