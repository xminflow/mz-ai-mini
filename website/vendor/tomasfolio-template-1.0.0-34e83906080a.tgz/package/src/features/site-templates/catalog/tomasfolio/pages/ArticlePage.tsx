'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Shell,Intro,t,url } from '../components/Shell'
import { articles } from '../data'
import type { SiteTemplatePageProps } from '../../../types'
export default function ArticlePage({basePath,locale='zh'}:SiteTemplatePageProps){const path=usePathname()??'',article=articles.find(item=>path.endsWith('/articles/'+item.slug));if(!article)return <Shell basePath={basePath} locale={locale}><Intro title={t(locale,'未找到文章','Article not found')}/></Shell>;return <Shell basePath={basePath} locale={locale}><Intro eyebrow={article.category[locale]} title={article.title[locale]}><p className="tm-label">Tomas Seul · {article.date}</p></Intro><article className="tm-reading"><Link href={url(basePath,'articles')}>↖ {t(locale,'返回文章列表','Back to lobby')}</Link>{article.body[locale].map((block,index)=>block.tag==='p'?<p key={index}>{block.text}</p>:<h2 key={index}>{block.text}</h2>)}<Link href={url(basePath,'articles')}>↖ {t(locale,'返回文章列表','Back to lobby')}</Link></article></Shell>}
