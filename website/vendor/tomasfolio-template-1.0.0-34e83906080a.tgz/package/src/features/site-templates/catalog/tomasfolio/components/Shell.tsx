'use client'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { languagePath } from '../routing'
import { MotionConfig, motion } from 'framer-motion'
import { useState, type ReactNode } from 'react'
import type { SiteTemplatePageProps, TemplateLocale } from '../../../types'
import { HostMarketplaceLabel, HostBrandName, HostLogo, HostMarketplaceLink, HostFiling } from '../host'
import { brand } from '../config/brand'
import '../theme.css'
export function t(locale:TemplateLocale,zh:string,en:string){return locale==='zh'?zh:en}
export function url(base:string,slug=''){return slug?`${base}/${slug}`:base||'/'}
export function Reveal({children,className=''}:{children:ReactNode;className?:string}){return <motion.div className={className} initial={{opacity:0,y:20}} whileInView={{opacity:1,y:0}} viewport={{once:true,amount:.08}} transition={{duration:.6}}>{children}</motion.div>}
export function Shell({basePath,locale='zh',children}:{children:ReactNode}&SiteTemplatePageProps){
 const [open,setOpen]=useState(false)
 const pathname=usePathname()??url(basePath),router=useRouter()
 const target=languagePath(basePath,pathname,locale)
 const nav=[['','首页','Home'],['projects','作品','Projects'],['#resume','履历','Resume'],['#testimonial','评价','Testimonials'],['articles','文章','Articles'],['contact','联系','Contact']] as const
 return <MotionConfig reducedMotion="user"><div className="tm-site" data-locale={locale}><a href="#tm-main" className="tm-skip">{t(locale,'跳到主要内容','Skip to content')}</a><header className="tm-header"><Link className="tm-brand" href={url(basePath)}><HostLogo alt=""/><span>© <HostBrandName locale={locale}/></span></Link><div className="tm-header-actions"><Link href={target} onClick={event=>{event.preventDefault();router.push(target+window.location.search+window.location.hash)}} aria-label={t(locale,'切换为英文','Switch to Chinese')}>{locale==='zh'?'EN':'中'}</Link><Link href={url(basePath,'contact')} className="tm-reach">{t(locale,'聊聊项目','Reach out')}</Link><button className="tm-menu-toggle" aria-label={t(locale,'切换导航菜单','Toggle navigation menu')} aria-expanded={open} aria-controls="tm-menu" onClick={()=>setOpen(!open)}>{open?'−':'+'}</button></div></header>
 {open&&<nav id="tm-menu" className="tm-menu" aria-label={t(locale,'主导航','Main navigation')}>{nav.map(([slug,zh,en])=><Link key={slug} href={slug.startsWith('#')?url(basePath)+slug:url(basePath,slug)} onClick={()=>setOpen(false)}>{t(locale,zh,en)}<span>↗</span></Link>)}</nav>}
 <aside className="tm-rail"><Link href={url(basePath,'contact')}>{t(locale,'聊聊项目','Reach out')}</Link></aside><main id="tm-main">{children}</main><footer className="tm-footer"><div className="tm-footer-heading"><span>© <HostBrandName locale={locale}/></span><Link href={url(basePath,'contact')}>{t(locale,'一起创造下一步','Reach out')} ↗</Link></div><Link className="tm-footer-email" href={url(basePath,'contact')}>{brand.email}</Link><div className="tm-footer-grid"><p>{t(locale,'让品牌表达更有力量','Creative direction for bold founders.')}<br/>{t(locale,'品牌设计师 · 独立顾问','Brand Designer | Freelance Consultant')}</p><div>{nav.map(([slug,zh,en])=><Link key={slug} href={slug.startsWith('#')?url(basePath)+slug:url(basePath,slug)}>{t(locale,zh,en)}</Link>)}</div><div><a href="https://linkedin.com">LinkedIn ↗</a><a href="https://behance.com">Behance ↗</a><Link href={url(basePath,'privacy-policy')}>{t(locale,'隐私政策','Privacy policy')}</Link><Link href={url(basePath,'terms-of-service')}>{t(locale,'服务条款','Terms of service')}</Link><HostMarketplaceLink href="/templates"><HostMarketplaceLabel/></HostMarketplaceLink></div></div><div className="tm-footer-bottom"><span>© {brand.year} <HostBrandName locale={locale}/> · {t(locale,'作品与履历均为模板演示','Projects and experience are template demonstrations')}</span><HostFiling/></div></footer>
 <HostMarketplaceLink href="/templates" className="tm-market" aria-label={t(locale,'打开模板市场','Open template marketplace')}><HostLogo light alt=""/><HostBrandName locale={locale}/></HostMarketplaceLink></div></MotionConfig>
}
export function Intro({eyebrow,title,children}:{eyebrow?:string;title:string;children?:ReactNode}){return <section className="tm-intro"><p className="tm-label">{eyebrow}</p><h1>{title}</h1>{children}</section>}

