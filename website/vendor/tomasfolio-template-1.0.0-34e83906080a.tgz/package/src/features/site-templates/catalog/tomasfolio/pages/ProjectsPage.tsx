'use client'
import { Shell,Intro,t } from '../components/Shell'
import { Projects } from '../components/Collections'
import type { SiteTemplatePageProps } from '../../../types'
export default function ProjectsPage({basePath,locale='zh'}:SiteTemplatePageProps){return <Shell basePath={basePath} locale={locale}><Intro eyebrow="2023 — 2025" title={t(locale,'作品','Projects')}/><section className="tm-section tm-section-first"><Projects basePath={basePath} locale={locale}/></section></Shell>}
