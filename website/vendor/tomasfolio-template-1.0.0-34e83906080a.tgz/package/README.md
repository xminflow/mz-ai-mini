# Tomasfolio 独立模板

暖白与橙红的品牌设计师作品集，15 个页面、30 条中英文路径。包含首页、五个案例、作品与文章列表、四篇文章、联系与政策页，以及 404。默认中文 /，英文 /en。

Git：https://github.com/weelume/tomasfolio-template

## 运行与检查

Node 24.16.0，pnpm 12.10.1。执行 pnpm install --frozen-lockfile；pnpm dev 默认端口 43318；Ctrl+C 停止。pnpm build 后 pnpm start。无需数据库和密钥。PORT 可自定义端口，HOSTNAME 可设置监听地址；不提交真实 .env。

检查：pnpm typecheck、pnpm lint、pnpm test、pnpm build、pnpm tpl:check。pnpm bundle 生成固定共享运行包。构建应在本地 Linux 文件系统进行。

## 修改入口

src/features/site-templates/catalog/tomasfolio 下：config/brand.ts 为品牌，data.ts 为双语内容，theme.css 为主题与断点，components 为公共组件，pages 为页面组合，meta.ts 为页面及展示注册。host.tsx 提供可选品牌、Logo、市场链接和备案插槽。运行素材在 public/templates/tomasfolio；真实展示图在 .tpl/assets。新增页面同步 .tpl/template.json。

## 能力边界

演示表单只在浏览器校验，不发送、不保存；邮件链接主动调用用户邮件客户端。履历和评价为演示；视频区域是明确标注的图像动效，不冒充原站视频。图片内的视觉设计英文属于原素材，页面 UI 和正文均双语。未确认原素材商业及再分发权，listed=false；正式商用前替换或取得许可。详见 .tpl/docs/LICENSE.md。
