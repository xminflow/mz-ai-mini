# 权利边界

参考：https://jiro.build/templates/e-commerce/cat-food-single-ecommerce-spycat 。原站为 Premium 公开预览，公开可见不代表源码、设计、品牌或素材拥有商业再分发许可。本实现独立编写，保留演示用途；listed=false，redistributionAllowed=false。图像与插画权利归原权利人，逐项记录见 ASSETS.json，商业使用与再分发授权尚未核实。

MiSans 与 Poppins 字体许可保留在 public/templates/spycat/fonts；Poppins 为 OFL，MiSans 按其附带声明执行。协议工具 LICENSE 仅覆盖工具，不能推导出模板或图像许可。
