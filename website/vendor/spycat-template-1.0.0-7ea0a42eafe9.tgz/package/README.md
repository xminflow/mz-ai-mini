# Spycat 猫粮品牌模板

独立的 Next.js / React / TypeScript 响应式品牌演示网站，默认中文，英文位于 /en。奶油底色、粉紫猫咪插画、旋转口味环、食材与猫龄环、悬停产品卡、评价轮播和 FAQ 构成九个首页区块。

## 使用

先读 .tpl/README.md、.tpl/template.json、.tpl/project.json。使用 .nvmrc 固定的 Node 24.16.0 与 package.json 固定的 pnpm 9.15.4。执行 pnpm install --frozen-lockfile、pnpm dev，访问 http://127.0.0.1:43470；停止使用 Ctrl+C。生产预览先 pnpm build，再 pnpm start。PORT 和 HOSTNAME 为可选配置，见 .env.example；无需密钥或外部服务。

## 页面与限制

首页、feeding-guide、contact、privacy、terms 各有中英文，共十条路径。原参考仅有一张落地页；指南、联系和政策用于补全演示入口，未伪造原站博客或交易页。没有支付、订单、真实订阅或邮件发送。联系表单只校验当前输入，不发送、不保存。

食材插画、健康与评价内容只用于设计演示。实际猫粮配方须由专业人员制定；不依据示例配置喂养量。示例评价不代表真实用户背书。参考中的葡萄与未经核实的医疗功效文案未用于喂养建议。

## 验证与修改

pnpm typecheck、pnpm lint、pnpm test、pnpm build；协议检查 node .tpl/tools/check.mjs .。具体入口见 .tpl/customization.json、.tpl/docs/ARCHITECTURE.md 与 CUSTOMIZATION.md。品牌在 config/brand.ts，双语在 content/data.ts，主题在 theme.css，页面位于 pages/，交互位于 components/。

## 交付

源码、依赖锁、.tpl、public 素材随独立 Git 工程交付。不要提交 node_modules、缓存、日志或真实环境配置。pnpm bundle 生成运行包与 SHA256；这不自动发布。./template 和 ./host 导出供通用消费方注入品牌，生产无需本机绝对路径。

## 许可

参考设计与插画来自 Jiro 的公开 Premium 预览；公开访问不代表获得商业再分发许可。模板 listed=false，redistributionAllowed=false，未核实授权前不得公开上架或商业分发。逐项来源见 .tpl/docs/ASSETS.json；工具许可仅覆盖工具，字体许可单独保留。
