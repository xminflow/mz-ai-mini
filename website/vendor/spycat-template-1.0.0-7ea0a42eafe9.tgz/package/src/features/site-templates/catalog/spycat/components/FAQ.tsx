'use client'
import { useState } from 'react'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import { copy, faqs } from '../content/data'
import type { Locale } from '../config/brand'
import { Reveal } from './Reveal'
export function FAQ({ locale }: { locale: Locale }) {
  const [open, setOpen] = useState<number | null>(0)
  const reduce = useReducedMotion()
  return <section id="faq" className="sc-container sc-faq"><Reveal><h2>{copy.faq[locale]}</h2></Reveal><div>{faqs.map((item, index) => <Reveal key={index} delay={index * .04}><div className={`sc-faq-item sc-glass ${open === index ? 'is-open' : ''}`}>
    <h3><button type="button" aria-expanded={open === index} aria-controls={`sc-faq-answer-${index}`} onClick={() => setOpen(open === index ? null : index)}>{item.question[locale]}<span aria-hidden="true">{open === index ? '−' : '+'}</span></button></h3>
    <AnimatePresence initial={false}>{open === index && <motion.div id={`sc-faq-answer-${index}`} initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: reduce ? 0 : .25 }} className="sc-faq-answer"><p>{item.answer[locale]}</p></motion.div>}</AnimatePresence>
  </div></Reveal>)}</div></section>
}
