'use client'
import { motion, useReducedMotion } from 'framer-motion'
import type { ReactNode } from 'react'
export function Reveal({ children, className, delay = 0, direction = 'up', initialY = 70, initialScale = .97, mass = 1 }: { children: ReactNode; className?: string; delay?: number; direction?: 'up' | 'left' | 'right'; initialY?: number; initialScale?: number; mass?: number }) {
  const reduce = useReducedMotion()
  return <motion.div className={className}
    initial={reduce ? false : { opacity: 0, x: direction === 'left' ? -30 : direction === 'right' ? 30 : 0, y: direction === 'up' ? initialY : 0, scale: initialScale }}
    whileInView={{ opacity: 1, x: 0, y: 0, scale: 1 }} viewport={{ once: true, amount: .1 }}
    transition={{ type: 'spring', stiffness: 70, damping: 14, mass, delay: reduce ? 0 : delay }}>{children}</motion.div>
}
