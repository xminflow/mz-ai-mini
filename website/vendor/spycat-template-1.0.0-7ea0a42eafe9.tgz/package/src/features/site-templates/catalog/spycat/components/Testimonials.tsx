'use client'
import { useEffect, useRef, useState } from 'react'
import { animate, motion, useReducedMotion } from 'framer-motion'
import { copy, testimonials } from '../content/data'
import { media, type Locale } from '../config/brand'
import { Reveal } from './Reveal'
export function Testimonials({ locale }: { locale: Locale }) {
  const track = useRef<HTMLDivElement>(null)
  const [active, setActive] = useState(0)
  const [visibleCount, setVisibleCount] = useState(3)
  const animation = useRef<{ stop: () => void } | null>(null)
  const reduce = useReducedMotion()
  const last = Math.max(0, testimonials.length - visibleCount)
  useEffect(() => {
    const element = track.current
    if (!element) return
    const observer = new ResizeObserver(() => {
      const card = element.children[0] as HTMLElement | undefined
      if (!card) return
      const visible = Math.max(1, Math.round((element.clientWidth + 20) / (card.offsetWidth + 20)))
      setVisibleCount(visible)
      setActive(index => Math.min(index, Math.max(0, testimonials.length - visible)))
    })
    observer.observe(element)
    return () => { observer.disconnect(); animation.current?.stop() }
  }, [])
  function stop() { animation.current?.stop(); if (track.current) track.current.style.scrollSnapType = 'x mandatory' }
  function go(index: number) {
    const next = Math.max(0, Math.min(last, index))
    const element = track.current?.children[next] as HTMLElement | undefined
    const container = track.current
    if (element && container) {
      animation.current?.stop()
      const left = element.offsetLeft - container.offsetLeft
      // 分页按原站弹簧曲线移动；触控仍保留原生滚动，避免动画与 scroll snap 争抢位置。
      container.style.scrollSnapType = 'none'
      if (reduce) { container.scrollLeft = left; container.style.scrollSnapType = 'x mandatory' }
      else animation.current = animate(container.scrollLeft, left, { type: 'spring', stiffness: 180, damping: 22, onUpdate: value => { container.scrollLeft = value }, onComplete: () => { container.style.scrollSnapType = 'x mandatory' } })
    }
    setActive(next)
  }
  return <section id="reviews" className="sc-container sc-testimonials"><Reveal><h2>{copy.testimonials[locale]}</h2></Reveal>
    <div ref={track} className="sc-testimonial-track" tabIndex={0} role="region" aria-label={locale === 'zh' ? '猫咪家长评价，可横向滑动' : 'Cat parent reviews; swipe horizontally'} onPointerDown={stop} onWheel={stop} onKeyDown={event => { if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') { event.preventDefault(); go(active + (event.key === 'ArrowRight' ? 1 : -1)) } }} onScroll={() => { if (!track.current) return; const step = (track.current.children[0] as HTMLElement)?.offsetWidth + 20; if (step) setActive(Math.max(0, Math.min(last, Math.round(track.current.scrollLeft / step)))) }}>
      {testimonials.map((item, index) => <motion.article key={index} className={`sc-review sc-glass sc-review-${index % 3}`} initial={reduce ? false : { opacity: 0, y: 80 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ type: 'spring', stiffness: 60, damping: 13, delay: reduce ? 0 : (index + 1) % 3 * .12 }} whileHover={reduce ? undefined : { y: -8, scale: 1.01 }}><p>“{item.text[locale]}”</p><img src={media(item.image)} alt={locale === 'zh' ? `示例评价插画 ${index + 1}` : `Illustrative cat parent ${index + 1}`} width="420" height="500" loading="lazy" /><span>{locale === 'zh' ? '示例评价' : 'Illustrative review'}</span></motion.article>)}
    </div>
    <div className="sc-carousel-controls"><button type="button" className="sc-round" disabled={active === 0} aria-label={locale === 'zh' ? '上一条评价' : 'Previous testimonial'} onClick={() => go(active - 1)}>‹</button><div className="sc-pagination">{Array.from({ length: last + 1 }, (_, index) => <button type="button" key={index} aria-label={locale === 'zh' ? `查看第 ${index + 1} 条评价` : `View review ${index + 1}`} aria-current={active === index ? 'true' : undefined} onClick={() => go(index)} />)}</div><button type="button" className="sc-round" disabled={active >= last} aria-label={locale === 'zh' ? '下一条评价' : 'Next testimonial'} onClick={() => go(active + 1)}>›</button></div>
  </section>
}
