'use client'
import { useEffect, useRef, useState, type CSSProperties } from 'react'
import { AnimatePresence, motion, useInView, useReducedMotion } from 'framer-motion'
import { copy, type OrbitItem } from '../content/data'
import { media, type Locale } from '../config/brand'
import { Reveal } from './Reveal'

export function Orbit({ items, locale, title, id, reverse = false }: { items: OrbitItem[]; locale: Locale; title: string; id: string; reverse?: boolean }) {
  const ref = useRef<HTMLElement>(null)
  const visible = useInView(ref, { amount: .15 })
  const reduce = useReducedMotion()
  const [active, setActive] = useState(0)
  const [hover, setHover] = useState(false)
  const [paused, setPaused] = useState(false)
  const stopped = paused || hover || !visible || !!reduce
  useEffect(() => {
    if (stopped || items.length < 2) return
    const timer = window.setInterval(() => setActive(index => (index + 1) % items.length), 4500)
    return () => window.clearInterval(timer)
  }, [stopped, items.length])
  if (!items.length) return null
  const item = items[active % items.length]
  // 同一数据环展示两次形成完整圆周；选中范围按真实数据长度计算。
  const ringItems = items.length === 1 ? items : [...items, ...items]
  return <section ref={ref} id={id} className={`sc-orbit-section ${reverse ? 'sc-orbit-reverse' : ''}`}>
    <div className="sc-container sc-orbit-layout">
      <div className="sc-orbit-copy"><Reveal direction={reverse ? 'right' : 'left'}><h2>{title}</h2></Reveal>
        <div className="sc-orbit-description" aria-live="off"><AnimatePresence mode="wait" initial={false}><motion.div key={active} initial={reduce ? false : { opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: .3 }}>
          <h3 style={{ color: item.color }}><span className="sc-dot" style={{ background: item.color }} />{item.name[locale]}</h3><p>{item.description[locale]}</p>
          <div className="sc-benefit sc-glass" style={{ borderColor: item.color }}><strong style={{ color: item.color }}>{copy.benefit[locale]}</strong><p>{item.benefit[locale]}</p></div>
        </motion.div></AnimatePresence></div>
        <div className="sc-orbit-options" aria-label={locale === 'zh' ? '选择展示内容' : 'Choose an item'}>{items.map((option, index) => <button type="button" key={option.image} aria-pressed={active === index} onClick={() => setActive(index)}>{option.name[locale]}</button>)}</div>
        <button className="sc-text-button" type="button" onClick={() => setPaused(!paused)} aria-pressed={paused}>{paused ? copy.resume[locale] : copy.pause[locale]}</button>
      </div>
      <div className={`sc-orbit-wheel ${reverse ? 'sc-age-wheel' : ''} ${stopped ? 'sc-paused' : ''}`} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} onFocusCapture={() => setHover(true)} onBlurCapture={event => { if (!event.currentTarget.contains(event.relatedTarget)) setHover(false) }}>
        <div className="sc-wheel-core"><img src={media(reverse ? 'cat stroke.png' : 'Food 01.png')} width="400" height="500" alt={locale === 'zh' ? reverse ? '猫咪线条插画' : '鲜食包装' : reverse ? 'Cat illustration' : 'Fresh food pack'} loading="lazy" /></div>
        <div className="sc-wheel-rotate">{ringItems.map((option, index) => <div key={`${option.image}-${index}`} className="sc-orbit-position" style={{ '--angle': `${index * 360 / ringItems.length}deg` } as CSSProperties}>
          <div className="sc-wheel-counter"><button type="button" tabIndex={index >= items.length ? -1 : 0} aria-hidden={index >= items.length} aria-label={option.name[locale]} onMouseEnter={() => setActive(index % items.length)} onFocus={() => setActive(index % items.length)} onClick={() => setActive(index % items.length)} className={active === index % items.length ? 'is-active' : ''}><img src={media(option.image)} alt="" width="150" height="150" loading="lazy" /></button></div>
        </div>)}</div>
      </div>
    </div>
  </section>
}
