'use client'
import { useRef, useState, type CSSProperties } from 'react'
import { useInView, useReducedMotion } from 'framer-motion'
import { copy, flavours } from '../content/data'
import { media, type Locale } from '../config/brand'
import { Reveal } from './Reveal'
export function Flavours({ locale }: { locale: Locale }) {
  const ref = useRef<HTMLElement>(null)
  const visible = useInView(ref, { amount: .1 })
  const reduce = useReducedMotion()
  const [paused, setPaused] = useState(false)
  const [hover, setHover] = useState(false)
  const [focus, setFocus] = useState(false)
  const [active, setActive] = useState<number | null>(null)
  return <section ref={ref} id="flavours" className={`sc-flavours ${paused || hover || focus || !visible || reduce ? 'sc-paused' : ''}`}>
    <div className="sc-flavour-ring">
      <div className="sc-flavour-title"><Reveal><h2>{copy.flavours[locale]}</h2></Reveal><p aria-live="polite">{active === null ? '2 kg' : flavours[active].name[locale]}</p><button type="button" className="sc-text-button" onClick={() => setPaused(!paused)} aria-pressed={paused}>{paused ? copy.resume[locale] : copy.pause[locale]}</button></div>
      <div className="sc-flavour-rotate">{flavours.map((flavour, index) => <div key={index} className="sc-flavour-position" style={{ '--angle': `${index * 360 / flavours.length}deg` } as CSSProperties}><div className="sc-flavour-counter"><button type="button" aria-label={flavour.name[locale]} aria-pressed={active === index} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)} onFocus={() => setFocus(true)} onBlur={() => setFocus(false)} onClick={() => setActive(index)}><img src={media('Food 01.png')} style={{ filter: flavour.filter }} alt="" width="180" height="230" loading="lazy" /></button></div></div>)}</div>
    </div>
  </section>
}
