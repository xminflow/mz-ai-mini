export type Locale = 'zh' | 'en'
export type Bilingual = Record<Locale, string>
export const brand = {
  name: { zh: 'Spycat', en: 'Spycat' },
  year: 2026,
  tagline: { zh: '让每一餐 都成为爱的日常', en: 'A little more love in every bowl.' },
}
export const media = (name: string) => `/templates/spycat/media/${encodeURIComponent(name)}`
export const hrefFor = (basePath: string, slug = '') => `${basePath}/${slug}`.replace(/\/$/, '') || '/'
export function languageHref(basePath: string, slug: string, locale: Locale): string {
  const root = basePath.replace(/\/en$/, '')
  return hrefFor(locale === 'en' ? `${root}/en` : root, slug)
}
