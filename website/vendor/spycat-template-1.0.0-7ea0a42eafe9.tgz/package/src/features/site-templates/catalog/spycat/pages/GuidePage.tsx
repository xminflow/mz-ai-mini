import type { SiteTemplatePageProps } from '../../../types'
import { Shell } from '../components/Shell'
import { Orbit } from '../components/Orbit'
import { ages, copy } from '../content/data'
export default function GuidePage({ locale = 'zh', basePath }: SiteTemplatePageProps) {
  return <Shell locale={locale} basePath={basePath} slug="feeding-guide"><div className="sc-container sc-page-heading"><p className="sc-eyebrow">{locale === 'zh' ? '喂养指南' : 'FEEDING GUIDE'}</p><h1>{locale === 'zh' ? '每个年龄\n都有专属的关爱' : 'A little care\nfor every life stage.'}</h1><p>{locale === 'zh' ? '以下为生活阶段概览。实际喂养量应依据产品标签、体重、活动量与兽医建议确定。' : 'A life-stage overview. Actual portions depend on the product label, weight, activity level and veterinary advice.'}</p></div><Orbit items={ages} id="cat-age" locale={locale} title={copy.age[locale]} reverse /></Shell>
}
