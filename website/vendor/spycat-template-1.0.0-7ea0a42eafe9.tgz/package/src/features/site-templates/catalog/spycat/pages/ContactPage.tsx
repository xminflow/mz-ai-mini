import type { SiteTemplatePageProps } from '../../../types'
import { Shell } from '../components/Shell'
import { DemoForm } from '../components/DemoForm'
import { Reveal } from '../components/Reveal'
import { media } from '../config/brand'
export default function ContactPage({ locale = 'zh', basePath }: SiteTemplatePageProps) {
  return <Shell locale={locale} basePath={basePath} slug="contact"><section className="sc-container sc-inner-page sc-contact"><Reveal><p className="sc-eyebrow">{locale === 'zh' ? '保持联系' : 'LET’S TALK'}</p><h1>{locale === 'zh' ? '关于猫咪\n关于每一餐' : 'For your cat.\nFor every bowl.'}</h1><p>{locale === 'zh' ? '从配方理念到每一个日常问题，我们愿意认真倾听。' : 'From recipe ideas to everyday questions, we’re all ears.'}</p><img src={media('Cat.svg')} alt="" width="400" height="400" /></Reveal><div className="sc-glass sc-form-card"><h2>{locale === 'zh' ? '留一句话' : 'Leave a little note'}</h2><DemoForm locale={locale} /></div></section></Shell>
}
