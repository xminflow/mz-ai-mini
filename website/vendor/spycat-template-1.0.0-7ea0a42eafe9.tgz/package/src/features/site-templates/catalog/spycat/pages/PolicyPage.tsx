import type { SiteTemplatePageProps } from '../../../types'
import { Shell } from '../components/Shell'
import { policies } from '../content/data'
export function PolicyPage({ locale = 'zh', basePath, kind }: SiteTemplatePageProps & { kind: 'privacy' | 'terms' }) {
  const policy = policies[kind]
  return <Shell locale={locale} basePath={basePath} slug={kind}><article className="sc-container sc-policy"><p className="sc-eyebrow">{locale === 'zh' ? '演示政策' : 'DEMO POLICY'}</p><h1>{policy.title[locale]}</h1>{policy.sections.map(section => <section key={section.title.en} className="sc-glass"><h2>{section.title[locale]}</h2><p>{section.text[locale]}</p></section>)}</article></Shell>
}
