import type { Bilingual } from '../config/brand'
const pair = (zh: string, en: string): Bilingual => ({ zh, en })
export const nav = [
  { id: 'why-homemade', label: pair('自制的用心', 'Why Homemade') },
  { id: 'ingredients', label: pair('真实食材', 'Ingredients') },
  { id: 'preparation', label: pair('用心制作', 'How We Prepare It') },
  { id: 'flavours', label: pair('探索口味', 'Flavours') },
  { id: 'faq', label: pair('常见问题', 'FAQ') },
]
export const copy = {
  hero: pair('猫咪的健康\n美食小铺', "Cat’s Healthy\nFood Store"),
  badge: pair('五星好评的美味', '5 STAR RATING FOOD'),
  heroCopy: pair('新鲜食材\n均衡营养', 'Fresh ingredients,\nbalanced nutrition'),
  heroBenefits: [pair('呵护柔软毛发', 'Cats with dry skin.'), pair('陪伴幼猫成长', 'Growing kittens.'), pair('活力室内生活', 'Active indoor cats.'), pair('关注敏感肠胃', 'Sensitive digestion.')],
  guide: pair('查看喂养指南', 'Get Feeding Guide'),
  flavours: pair('每种口味 都有惊喜', 'Meet The Flavours'),
  homemade: pair('像在家里一样用心', 'Why Homemade?'),
  ingredients: pair('真实食材\n真实的营养', 'Real Ingredients\nwith Real Nutrition'),
  age: pair('适合你的\n猫咪吗', 'Is This Right\nFor Your Cat?'),
  benefit: pair('营养看点', 'PRIMARY BENEFIT'),
  testimonials: pair('铲屎官的信任\n猫咪的偏爱', 'Trusted By Cat Parents,\nLoved By Cats.'),
  faq: pair('关于每一餐\n你想了解的事', 'Everything You Need To\nKnow About Spycat!'),
  pause: pair('暂停动画', 'Pause animation'),
  resume: pair('播放动画', 'Play animation'),
  demo: pair('本页面为品牌与交互演示，文案不构成营养或医疗建议。', 'This is a brand and interaction demo. Content is not nutritional or medical advice.'),
}
export const flavours = [
  { name: pair('海洋鲜鱼口味', 'Ocean Fish Flavor'), filter: 'hue-rotate(105deg) saturate(1.3)' },
  { name: pair('鸭肉与甘薯口味', 'Duck & Sweet Potato Flavor'), filter: 'hue-rotate(220deg) saturate(1.2)' },
  { name: pair('鸭肉与甘薯口味', 'Duck & Sweet Potato Flavor'), filter: 'hue-rotate(220deg) saturate(1.2)' },
  { name: pair('鸭肉与甘薯口味', 'Duck & Sweet Potato Flavor'), filter: 'hue-rotate(220deg) saturate(1.2)' },
  { name: pair('海洋鲜鱼口味', 'Ocean Fish Flavor'), filter: 'hue-rotate(105deg) saturate(1.3)' },
  { name: pair('鲜嫩鸡肉口味', 'Chicken'), filter: 'none' },
  { name: pair('鲜嫩鸡肉口味', 'Chicken'), filter: 'none' },
  { name: pair('海洋鲜鱼口味', 'Ocean Fish Flavor'), filter: 'hue-rotate(105deg) saturate(1.3)' },
]
export const reasons = [
  { text: pair('像为家人做饭一样\n认真准备每一餐', 'Prepared with the same care you would give at home.'), color: 'rose', filter: 'none' },
  { text: pair('优质蛋白\n搭配丰富的营养食材', 'High-quality proteins and nourishing ingredients.'), color: 'purple', filter: 'hue-rotate(220deg)' },
  { text: pair('不加人工色素\n不加多余填充物', 'No artificial colours or unnecessary fillers.'), color: 'blue', filter: 'hue-rotate(105deg)' },
]
export interface OrbitItem {
  name: Bilingual
  description: Bilingual
  benefit: Bilingual
  image: string
  color: string
}
export const ingredients: OrbitItem[] = [
  { name: pair('缤纷鲜果', 'Nourishing Fresh Fruits'), description: pair('用缤纷食材呈现新鲜与多样的品牌理念。', 'A colourful illustration of fresh, varied ingredients.'), benefit: pair('食材组合仅作设计展示，实际配方需由专业人员制定。', 'Illustrative ingredients; actual recipes require professional formulation.'), image: 'Ellipse 11.png', color: '#cc4848' },
  { name: pair('有机全蛋', 'Organic Whole Eggs'), description: pair('一枚小小的鸡蛋，蕴含丰富的蛋白质。', 'A little egg with a rich variety of proteins.'), benefit: pair('展现维生素与蛋白质的营养搭配。', 'A balanced combination of vitamins and proteins.'), image: 'Ellipse 10.png', color: '#b67523' },
  { name: pair('必需牛磺酸', 'Essential Taurine'), description: pair('关注猫咪独特的日常营养需求。', 'Thoughtfully considers cats’ specific nutritional needs.'), benefit: pair('牛磺酸是猫咪饮食中的必需营养素。', 'Taurine is an essential nutrient in a cat’s diet.'), image: 'Ellipse 9.png', color: '#8b49bc' },
  { name: pair('鲜美鱼肉', 'Wild-Caught Fish'), description: pair('鲜美风味，搭配多样脂肪酸。', 'Delicious flavour with a variety of fatty acids.'), benefit: pair('富含 Omega-3 与 Omega-6 脂肪酸。', 'A source of omega-3 and omega-6 fatty acids.'), image: 'Ellipse 5.png', color: '#2979b7' },
  { name: pair('真实鸡肉', 'Real Chicken Flakes'), description: pair('看得见的鸡肉，为日常增添美味。', 'Real, lean chicken for everyday deliciousness.'), benefit: pair('提供优质蛋白质。', 'A source of quality protein.'), image: 'Ellipse 4.png', color: '#b45c30' },
  { name: pair('新鲜南瓜', 'Fresh Pumpkin'), description: pair('温暖的色彩，来自自然的食材。', 'A naturally colourful ingredient with a mellow flavour.'), benefit: pair('含膳食纤维和 β-胡萝卜素。', 'Contains dietary fibre and beta-carotene.'), image: 'Ellipse 3.png', color: '#b65f1d' },
]
export const ages: OrbitItem[] = [
  { name: pair('幼猫期 · 0–6 个月', 'Kitten · 0–6 Months'), description: pair('快速成长，开始好奇地探索这个世界。', 'A time of rapid growth, curiosity and high energy.'), benefit: pair('关注生长所需的蛋白质与营养平衡。', 'Consider the balance of protein and nutrients needed for growth.'), image: 'Cat 01.png', color: '#a25447' },
  { name: pair('少年期 · 7–12 个月', 'Junior · 7–12 Months'), description: pair('身体逐渐长大，玩耍与探索更加自如。', 'Growing into their body, coordination and playful instincts.'), benefit: pair('根据体型、活动量及兽医建议调整饮食。', 'Adapt meals to size, activity level and veterinary advice.'), image: 'Cat 02.png', color: '#9b6429' },
  { name: pair('青年期 · 1–3 岁', 'Prime Adult · 1–3 Years'), description: pair('精力充沛，用充足的玩耍点亮每一天。', 'Full of energy, playfulness and everyday adventures.'), benefit: pair('保持完整均衡的日常营养。', 'Maintain complete, balanced everyday nutrition.'), image: 'Cat 03.png', color: '#8c4b98' },
  { name: pair('成年期 · 4–6 岁', 'Mature Adult · 4–6 Years'), description: pair('生活节奏更稳定，细心关注体重与习惯。', 'Settling into a routine with attention to weight and habits.'), benefit: pair('结合日常活动，关注合理食量。', 'Consider suitable portions alongside daily activity.'), image: 'Cat 04.png', color: '#36809b' },
  { name: pair('熟龄期 · 7–10 岁', 'Senior Life · 7–10 Years'), description: pair('慢下来享受生活，也需要更多日常关爱。', 'A calmer pace of life with a little extra everyday care.'), benefit: pair('定期检查，按个体需要调整饮食。', 'Review individual dietary needs during regular checkups.'), image: 'Cat 05.png', color: '#778026' },
  { name: pair('金龄期 · 11 岁以上', 'Golden Senior · 11+ Years'), description: pair('温柔陪伴，让每一天都舒适而安心。', 'Gentle companionship and comfort through the golden years.'), benefit: pair('由兽医评估老年猫的具体营养需求。', 'Ask a veterinarian to assess specific senior nutritional needs.'), image: 'Cat 06.png', color: '#98505d' },
]
export const testimonials = [
  { text: pair('换成新鲜餐之后，Oliver 每天都会开心地跑向自己的小碗。', 'Since switching to fresh meals, Oliver runs to his bowl every single day.'), image: 'R 1.png' },
  { text: pair('能清楚了解猫咪吃进了什么，这种透明与用心让我很安心。', 'I love knowing exactly what goes into my cat’s food. The transparency makes all the difference.'), image: 'R 2.png' },
  { text: pair('Luna 很喜欢新鲜的小批次餐食，每次都把碗舔得干干净净。', 'Luna loves the fresh small-batch recipes and licks the bowl completely clean.'), image: 'R 3.png' },
  { text: pair('从准备食材到分装，每个细节都能感受到对猫咪的关爱。', 'From ingredients to portions, every detail feels thoughtfully made for cats.'), image: 'R 2.png' },
  { text: pair('Milo 的每一餐都变成了我们期待的小小日常。', 'Every meal with Milo has become a little moment we look forward to.'), image: 'R 1.png' },
  { text: pair('提前分装的小包装，让忙碌日子里的喂养也变得轻松。', 'We love the convenient pre-portioned packs. Everyday feeding feels hassle-free.'), image: 'R 3.png' },
]
export const faqs = [
  { question: pair('适合所有猫咪吗？', 'Is this suitable for all cats?'), answer: pair('不同年龄、体型和健康状况的猫咪有不同需要。更换食物前，请咨询兽医，尤其是有疾病或特殊饮食要求的猫咪。', 'Cats have different needs depending on age, size and health. Consult your veterinarian before a dietary change, especially for medical conditions or special diets.') },
  { question: pair('餐食使用哪些食材？', 'What ingredients are used in the meals?'), answer: pair('本模板展示鸡肉、鱼肉、全蛋、南瓜和牛磺酸等食材概念。它不是实际商品配方或完整营养声明。', 'This template illustrates ingredients including chicken, fish, eggs, pumpkin and taurine. It is not an actual product formulation or complete nutritional declaration.') },
  { question: pair('为什么选择小批次制作？', 'Why choose small-batch meals?'), answer: pair('少量制作的理念强调新鲜、透明和细致的准备过程。实际商品仍需满足相应的营养与食品安全标准。', 'Small batches highlight freshness, transparency and careful preparation. Actual products must still meet applicable nutritional and food safety standards.') },
  { question: pair('含有人工色素或填充物吗？', 'Does the food contain artificial colours or fillers?'), answer: pair('页面以简洁、透明的配方理念展示品牌。实际产品的成分与添加剂，应以生产商标签和检测信息为准。', 'The design presents a simple, transparent recipe philosophy. Refer to manufacturer labels and testing information for actual ingredients and additives.') },
  { question: pair('应该如何保存餐食？', 'How should I store the food?'), answer: pair('实际产品请遵循包装上的冷藏、冷冻和食用期限说明。页面中的包装与喂养指南均为演示内容。', 'Follow the actual product label for refrigeration, freezing and use-by instructions. Packaging and feeding information on this site are demonstrations.') },
]
export const preparation = [pair('新鲜食材', 'FRESH INGREDIENTS'), pair('小批次制作', 'SMALL BATCHES'), pair('每一份都用心', 'PACK WITH CARE')]
export const values = [pair('真实食材', 'Real ingredients'), pair('关注营养', 'Thoughtful nutrition'), pair('透明配方', 'Transparent recipes'), pair('小批次手作', 'Hand-crafted batches')]
export const policies = {
  privacy: {
    title: pair('隐私政策', 'Privacy policy'),
    sections: [
      { title: pair('演示数据', 'Demo data'), text: pair('本模板无需注册，不连接业务数据库。联系表单仅在当前页面进行输入校验，不会发送或保存你的信息。', 'No registration or business database is connected. The contact form validates input on the current page and does not send or save information.') },
      { title: pair('浏览器与网络', 'Browser and network'), text: pair('页面素材由本站托管。模板不使用分析、广告或追踪 Cookie；网站宿主可能保留常规访问日志。', 'Assets are hosted locally. This template uses no analytics, advertising or tracking cookies; the hosting service may maintain normal access logs.') },
      { title: pair('正式使用前', 'Before production use'), text: pair('如接入支付、统计、邮件或订单服务，需据实际数据处理流程更新隐私政策，并说明保存期限和用户权利。', 'Update this policy for actual data processing, retention and user rights before integrating payments, analytics, email or order services.') },
    ],
  },
  terms: {
    title: pair('使用条款', 'Terms of service'),
    sections: [
      { title: pair('模板演示', 'Template demonstration'), text: pair('本网站用于展示品牌设计和交互，不销售商品，不处理订单、支付或真实订阅。价格、包装与评价不构成商业承诺。', 'This website demonstrates design and interactions. It does not sell goods or process orders, payments or real subscriptions. Packaging and testimonials are illustrative.') },
      { title: pair('营养信息', 'Nutrition information'), text: pair('所有营养相关信息仅为演示，不应替代专业兽医建议。请勿按页面插画或示例自行配制猫粮。', 'Nutritional content is illustrative and does not replace veterinary advice. Do not formulate cat food from the illustrations or examples.') },
      { title: pair('内容与许可', 'Content and licensing'), text: pair('图片与插画的权利归各自权利人所有。实际商业使用或再分发前，须独立确认相应授权。', 'Images and illustrations belong to their respective rights holders. Confirm appropriate rights before commercial use or redistribution.') },
    ],
  },
}
