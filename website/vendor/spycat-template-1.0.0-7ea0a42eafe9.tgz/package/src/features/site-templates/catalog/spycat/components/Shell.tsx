'use client'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { MotionConfig } from 'framer-motion'
import { useRef, useState, type ReactNode } from 'react'
import type { SiteTemplatePageProps } from '../../../types'
import { brand, hrefFor, languageHref } from '../config/brand'
import { copy, nav, values } from '../content/data'
import { useSpycatHost } from '../host'
import '../theme.css'

export function Shell({ children, basePath, locale = 'zh', slug = '' }: SiteTemplatePageProps & { children: ReactNode; slug?: string }) {
  const host = useSpycatHost()
  const router = useRouter()
  const [menu, setMenu] = useState(false)
  const menuButton = useRef<HTMLButtonElement>(null)
  const closeMenu = () => { setMenu(false); menuButton.current?.focus() }
  return <MotionConfig reducedMotion="user"><div className="spycat" lang={locale === 'zh' ? 'zh-CN' : 'en'}>
    <a className="sc-skip" href="#main">{locale === 'zh' ? '跳到主要内容' : 'Skip to main content'}</a>
    <header className="sc-header sc-container">
      <Link className="sc-brand" href={hrefFor(basePath)} aria-label={host.brandName[locale]}>
        {host.logo && <img src={host.logo} width="24" height="24" alt="" />}<span>{host.brandName[locale]}</span>
      </Link>
      <nav className="sc-desktop-nav" aria-label={locale === 'zh' ? '主导航' : 'Main navigation'}>{nav.map(item => <Link key={item.id} href={`${hrefFor(basePath)}#${item.id}`} className="sc-roll"><span>{item.label[locale]}</span><span aria-hidden="true">{item.label[locale]}</span></Link>)}</nav>
      <div className="sc-nav-actions">
        <Link className="sc-language" href={languageHref(basePath, slug, locale === 'zh' ? 'en' : 'zh')}
          aria-label={locale === 'zh' ? 'Switch to English' : '切换为中文'} onClick={event => {
            event.preventDefault()
            setMenu(false)
            // 宿主基础路径包含语言段；切换时原样保留当前查询参数和锚点。
            router.push(languageHref(basePath, slug, locale === 'zh' ? 'en' : 'zh') + window.location.search + window.location.hash)
          }}>{locale === 'zh' ? 'EN' : '中文'}</Link>
        <Link className="sc-button sc-guide-link" href={hrefFor(basePath, 'feeding-guide')}>{copy.guide[locale]}</Link>
        <button ref={menuButton} type="button" className="sc-menu-button" aria-expanded={menu} aria-controls="sc-mobile-menu" aria-label={locale === 'zh' ? '导航菜单' : 'Navigation menu'} onClick={() => setMenu(!menu)}>{menu ? '×' : '☰'}</button>
      </div>
    </header>
    {menu && <nav id="sc-mobile-menu" className="sc-mobile-menu sc-container" aria-label={locale === 'zh' ? '移动导航' : 'Mobile navigation'} onKeyDown={event => { if (event.key === 'Escape') closeMenu() }}>
      {nav.map(item => <Link key={item.id} onClick={() => setMenu(false)} href={`${hrefFor(basePath)}#${item.id}`}>{item.label[locale]}</Link>)}
      <Link href={hrefFor(basePath, 'feeding-guide')} onClick={() => setMenu(false)}>{copy.guide[locale]}</Link>
      <Link href={hrefFor(basePath, 'contact')} onClick={() => setMenu(false)}>{locale === 'zh' ? '联系我们' : 'Contact us'}</Link>
    </nav>}
    <main id="main">{children}</main>
    <footer className="sc-footer sc-container">
      <div className="sc-footer-top"><nav aria-label={locale === 'zh' ? '页脚导航' : 'Footer navigation'}>
        {[...nav.slice(0, 4), { id: 'cat-age', label: { zh: '猫龄指南', en: 'Cat Age Guide' } }].map(item => <Link className="sc-roll" key={item.id} href={`${hrefFor(basePath)}#${item.id}`}><span>{item.label[locale]}</span><span aria-hidden="true">{item.label[locale]}</span></Link>)}
        <Link href={hrefFor(basePath, 'contact')}>{locale === 'zh' ? '联系我们' : 'Contact us'}</Link>
      </nav><p>{brand.tagline[locale]}</p></div>
      <div className="sc-wordmark" aria-hidden="true">{host.brandName[locale]}</div>
      <div className="sc-values">{values.map((item, index) => <div key={item.en}><span aria-hidden="true">{['✿', '✧', '♡', '☀'][index]}</span><p>{item[locale]}</p></div>)}</div>
      <p className="sc-demo">{copy.demo[locale]}</p>
      <div className="sc-footer-bottom"><div><Link href={hrefFor(basePath, 'terms')}>{locale === 'zh' ? '使用条款' : 'Terms of service'}</Link><Link href={hrefFor(basePath, 'privacy')}>{locale === 'zh' ? '隐私政策' : 'Privacy policy'}</Link></div><span>© {brand.year} {host.brandName[locale]}</span>{host.filing}</div>
    </footer>
    {host.marketplaceHref && <Link className="sc-marketplace" href={host.marketplaceHref} aria-label={host.marketplaceAriaLabel?.[locale]}>{host.lightLogo && <img src={host.lightLogo} width="24" height="24" alt="" />}<span>{host.marketplaceLabel?.[locale] ?? host.brandName[locale]}</span></Link>}
  </div></MotionConfig>
}
