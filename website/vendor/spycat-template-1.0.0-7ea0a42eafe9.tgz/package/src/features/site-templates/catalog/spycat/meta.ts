import type { SiteTemplate } from '../../types'
const screenshots = (['desktop', 'tablet', 'mobile'] as const).flatMap(device => ['home', 'ingredients', 'feeding-guide', 'contact'].map(page => ({ src: `/templates/spycat/screenshots/${device}-${page}.webp`, alt: `Spycat ${device} ${page}`, device, width: device === 'desktop' ? 1425 : device === 'tablet' ? 819 : 375, height: device === 'desktop' ? 990 : device === 'tablet' ? 1159 : 812 })))
export const spycatTemplate: SiteTemplate = {
  id: 'spycat',
  gitUrl: 'https://github.com/weelume/spycat-template',
  name: 'Spycat · 新鲜猫粮品牌',
  localizedNames: { en: 'Spycat · Fresh cat food brand' },
  sceneId: 'online-store', listed: false,
  tags: ['宠物食品', '环形动效', '双语', 'PC / iPad / H5'],
  summary: '奶油底色、粉紫插画和环形食材展示构成的猫粮品牌模板，含口味、制作理念、猫龄指南、评价轮播、FAQ 与本地联系表单。',
  accentColor: '#daa5d3', cover: '/templates/spycat/screenshots/desktop-home.webp',
  screenshots: [screenshots[0], ...screenshots.slice(1)],
  surfaces: [{ id: 'site', name: '猫粮品牌官网', platform: 'pc', locales: ['zh', 'en'], pages: [
    { slug: '', title: '首页', localizedTitles: { en: 'Home' }, load: () => import('./pages/HomePage') },
    { slug: 'feeding-guide', title: '喂养指南', localizedTitles: { en: 'Feeding Guide' }, load: () => import('./pages/GuidePage') },
    { slug: 'contact', title: '联系', localizedTitles: { en: 'Contact' }, load: () => import('./pages/ContactPage') },
    { slug: 'privacy', title: '隐私政策', localizedTitles: { en: 'Privacy Policy' }, load: () => import('./pages/PrivacyPage') },
    { slug: 'terms', title: '使用条款', localizedTitles: { en: 'Terms of Service' }, load: () => import('./pages/TermsPage') },
  ] }],
}
