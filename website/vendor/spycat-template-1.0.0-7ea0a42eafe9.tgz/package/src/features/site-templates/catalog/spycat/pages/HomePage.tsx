'use client'
import Link from 'next/link'
import { motion, useReducedMotion } from 'framer-motion'
import type { SiteTemplatePageProps } from '../../../types'
import { media, hrefFor } from '../config/brand'
import { ages, copy, ingredients, preparation, reasons } from '../content/data'
import { Shell } from '../components/Shell'
import { Reveal } from '../components/Reveal'
import { Flavours } from '../components/Flavours'
import { Orbit } from '../components/Orbit'
import { Testimonials } from '../components/Testimonials'
import { FAQ } from '../components/FAQ'
export default function HomePage({ locale = 'zh', basePath }: SiteTemplatePageProps) {
  const reduce = useReducedMotion()
  return <Shell locale={locale} basePath={basePath}>
    <section className="sc-container"><motion.div className="sc-hero" initial={reduce ? false : { opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1.1, ease: [.16, 1, .3, 1] }}>
      <motion.h1 initial={reduce ? false : { opacity: 0, scale: .96 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: .2, duration: 1.2 }}>{copy.hero[locale]}</motion.h1>
      <div className="sc-hero-cat-wrap"><motion.img className="sc-hero-cat" src={media('Cat.svg')} alt={locale === 'zh' ? '正在伸懒腰的快乐猫咪插画' : 'Playful cat stretching illustration'} width="620" height="620" initial={reduce ? false : { opacity: 0, y: 60 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .3, duration: 1.3, ease: [.16, 1, .3, 1] }} fetchPriority="high" /></div>
      <div className="sc-hero-bottom"><Reveal direction="left" delay={.5}><span className="sc-oval">{copy.badge[locale]}</span><p className="sc-hero-copy">{copy.heroCopy[locale]}</p><Link className="sc-button" href={hrefFor(basePath, 'feeding-guide')}>{copy.guide[locale]}</Link></Reveal>
        <Reveal direction="right" delay={.65}><ul className="sc-hero-benefits">{copy.heroBenefits.map(item => <li key={item.en}>{item[locale]}</li>)}</ul></Reveal></div>
    </motion.div></section>
    <Flavours locale={locale} />
    <section id="why-homemade" className="sc-container"><div className="sc-homemade"><Reveal><h2>{copy.homemade[locale]}</h2></Reveal><div className="sc-reason-grid">{reasons.map((reason, index) => <Reveal key={reason.color} delay={.15 * index} initialY={100} initialScale={.95} mass={1.1}><motion.article className={`sc-reason sc-glass sc-${reason.color}`} whileHover={reduce ? undefined : { y: -6 }}>
      <span className="sc-card-line" /><h3>{reason.text[locale]}</h3><img className="sc-peep" src={media('Cat Illustration.svg')} alt="" width="340" height="260" loading="lazy" /><img className="sc-hover-pack" style={{ filter: reason.filter }} src={media('Food 01.png')} alt="" width="200" height="260" loading="lazy" />
    </motion.article></Reveal>)}</div></div></section>
    <Orbit id="ingredients" items={ingredients} locale={locale} title={copy.ingredients[locale]} />
    <section id="preparation" className="sc-container"><div className="sc-preparation"><div className="sc-dome" /><Reveal><div className="sc-preparation-title">{preparation.map((item, index) => <h2 key={item.en} className={index !== 1 ? 'sc-outline' : ''}>{item[locale]}</h2>)}</div></Reveal><Reveal className="sc-pack-reveal"><img src={media('Food 01.png')} alt={locale === 'zh' ? '新鲜猫粮包装' : 'Fresh cat food package'} width="500" height="650" loading="lazy" /></Reveal><span className="sc-pack-label sc-pack-left">{locale === 'zh' ? '简单配方' : 'Simple recipes'}</span><span className="sc-pack-label sc-pack-right">{locale === 'zh' ? '天然色彩' : 'Natural colours'}</span></div></section>
    <Orbit id="cat-age" items={ages} locale={locale} title={copy.age[locale]} reverse />
    <Testimonials locale={locale} />
    <FAQ locale={locale} />
  </Shell>
}
