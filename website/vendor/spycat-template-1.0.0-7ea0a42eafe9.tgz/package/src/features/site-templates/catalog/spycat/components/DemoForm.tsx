'use client'
import { useState, type FormEvent } from 'react'
import type { Locale } from '../config/brand'
export function DemoForm({ locale }: { locale: Locale }) {
  const [result, setResult] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const form = event.currentTarget
    const fields = new FormData(form)
    const next: Record<string, string> = {}
    if (!String(fields.get('name') ?? '').trim()) next.name = locale === 'zh' ? '请填写称呼' : 'Please enter your name'
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(fields.get('email') ?? '').trim())) next.email = locale === 'zh' ? '请填写有效邮箱' : 'Please enter a valid email'
    if (String(fields.get('message') ?? '').trim().length < 5) next.message = locale === 'zh' ? '请至少填写 5 个字' : 'Please enter at least 5 characters'
    setErrors(next)
    if (Object.keys(next).length) { setResult(''); (form.elements.namedItem(Object.keys(next)[0]) as HTMLElement | null)?.focus(); return }
    // 仅本地验证：不调用网络、不写入存储，也不把用户输入记录到日志。
    console.debug('[spycat] contact validation', { valid: true, sent: false, saved: false })
    setResult(locale === 'zh' ? '本地校验通过。这是演示表单，信息尚未发送或保存。' : 'Local validation passed. This is a demo; information has not been sent or saved.')
  }
  return <form className="sc-form" noValidate onSubmit={submit}>
    <p>{locale === 'zh' ? '仅在本地校验，不发送、不保存。' : 'Local validation only. Nothing is sent or saved.'}</p>
    <label htmlFor="sc-name">{locale === 'zh' ? '你的称呼' : 'Your name'}</label><input id="sc-name" name="name" required autoComplete="name" maxLength={80} aria-invalid={!!errors.name} aria-describedby={errors.name ? 'sc-name-error' : undefined} />{errors.name && <p className="sc-error" id="sc-name-error">{errors.name}</p>}
    <label htmlFor="sc-email">{locale === 'zh' ? '邮箱地址' : 'Email address'}</label><input id="sc-email" name="email" type="email" required autoComplete="email" maxLength={254} aria-invalid={!!errors.email} aria-describedby={errors.email ? 'sc-email-error' : undefined} />{errors.email && <p className="sc-error" id="sc-email-error">{errors.email}</p>}
    <label htmlFor="sc-message">{locale === 'zh' ? '想说的话' : 'Your message'}</label><textarea id="sc-message" name="message" rows={5} minLength={5} maxLength={2000} required aria-invalid={!!errors.message} aria-describedby={errors.message ? 'sc-message-error' : undefined} />{errors.message && <p className="sc-error" id="sc-message-error">{errors.message}</p>}
    <button className="sc-button sc-button-solid" type="submit">{locale === 'zh' ? '校验演示留言' : 'Validate demo message'}</button><p className="sc-result" role="status">{result}</p>
  </form>
}
