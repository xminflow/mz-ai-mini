'use client'
import { createContext, useContext, type ReactNode } from 'react'
import { brand, type Bilingual } from './config/brand'
export interface SpycatHostConfig {
  brandName: Bilingual
  logo?: string
  lightLogo?: string
  marketplaceHref?: string
  marketplaceLabel?: Bilingual
  marketplaceAriaLabel?: Bilingual
  filing?: ReactNode
}
const Context = createContext<SpycatHostConfig>({ brandName: brand.name })
export function SpycatHostProvider({ children, ...config }: SpycatHostConfig & { children: ReactNode }) {
  return <Context.Provider value={config}>{children}</Context.Provider>
}
export const useSpycatHost = () => useContext(Context)
