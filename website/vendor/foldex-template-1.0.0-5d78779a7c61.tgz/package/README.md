# Foldex · 拼贴创意工作室

完整使用规则见 [.tpl/README.md](.tpl/README.md)。独立 Next.js 工程，13 页、中英双语、46 项作品，包含作品灯箱、报价、评价及本地联系表单。

Git 远端尚未配置；template.json 的 gitUrl 保持 null，当前不满足可导入协议，不能声明格式验收通过。
