import type { SiteTemplatePageProps } from '../../../types'
import { Article } from '../components/Article'
export default function LeakArticle(props:SiteTemplatePageProps){return <Article {...props} index={0}/>}
