# 微域生光 独立创意机构模板

独立 Git / Next.js 模板，提供中英双语、响应式页面和本地演示表单。完整运行、修改、验收与许可规则见 [.tpl/README.md](.tpl/README.md)。

Node 22.13.1、pnpm 12.10.1。首次执行 pnpm install --frozen-lockfile，然后 pnpm dev 启动可热更新的开发预览。

中文 http://127.0.0.1:43121/templates/deformo/site ，英文追加 /en，前台 Ctrl+C 停止。联系和订阅仅本地交互演示。需要生产预览时再运行 pnpm run build 和 pnpm start。

日常修改后查看受影响页面即可；逻辑或配置变更按需运行测试或构建。无需每次全站截图、打包、提交或填写验收报告。

通用模块引用方式见 [docs/INTEGRATION.md](docs/INTEGRATION.md)。
