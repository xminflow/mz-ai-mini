# Latte · 咖啡与烘焙

独立 Next.js / React / TypeScript 模板。首次使用先读 [.tpl/README.md](.tpl/README.md)、[市场资料](.tpl/template.json)、[运行合同](.tpl/project.json)。

覆盖首页、新闻列表、五篇文章、联系页和三类政策，共 11 页、22 条中英文路由。照片轮播、图文交替菜单、精选新闻切换、本地演示表单，支持桌面、平板和手机。完整使用与许可边界见 `.tpl/docs/`。

源码仓库：https://github.com/weelume/latte-template。
