'use client';
import Link from 'next/link';
import {usePathname,useRouter} from 'next/navigation';
import {useState,type ReactNode} from 'react';
import {AnimatePresence,MotionConfig,motion,useReducedMotion} from 'framer-motion';
import {useConsutechHost} from '../host';
import {brand} from '../config/brand';
import {nav,ui,text,serviceData,type Locale} from '../content/data';
import {Reveal,RollingText,debug} from './Motion';
import '../theme.css';
import {href} from '../routing';
const MotionLink=motion.create(Link);
export function Button({children,to,white=false,outline=false}:{children:string;to:string;white?:boolean;outline?:boolean}){return <MotionLink href={to} initial="rest" whileHover="hover" whileTap={{scale:.98}} className={`ct-button${white?' ct-button-white':''}${outline?' ct-button-outline':''}`}><RollingText>{children}</RollingText></MotionLink>}
export function Header({basePath,locale,overlay=false}:{basePath:string;locale:Locale;overlay?:boolean}){
 const host=useConsutechHost(),pathname=usePathname(),router=useRouter(),[open,setOpen]=useState(false),reduced=useReducedMotion();
 const switchLocale=()=>{const match=basePath.endsWith('/en'),root=match?basePath.slice(0,-3):basePath;const suffix=pathname.slice(basePath.length).replace(/^\//,'');return href(locale==='zh'?root+'/en':root,suffix)};
 return <header className={`ct-header${overlay?' ct-header-overlay':''}`}><div className="ct-nav-bar"><Link href={href(basePath)} className="ct-brand" aria-label={host.brandName[locale]}><img src={host.lightLogo||host.logo} alt=""/>{host.brandName[locale]}</Link><nav aria-label={locale==='zh'?'主导航':'Main navigation'} className="ct-desktop-nav">{nav.map(([slug,key])=><Link key={key} aria-current={pathname===href(basePath,slug)?'page':undefined} href={href(basePath,slug)}>{text(ui[key],locale)}</Link>)}</nav><div className="ct-nav-actions"><Link href={switchLocale()} onClick={event=>{event.preventDefault();router.push(switchLocale()+window.location.search+window.location.hash)}} aria-label={text(ui.language,locale)} className="ct-language">{locale==='zh'?'EN':'中文'}</Link><span className="ct-nav-talk"><Button white to={href(basePath,'contact')}>{text(ui.talk,locale)}</Button></span><button className="ct-menu-toggle" aria-label={text(open?ui.close:ui.menu,locale)} aria-expanded={open} aria-controls="ct-mobile-menu" onClick={()=>{setOpen(!open);debug('navigation.toggle',{open:!open})}}>{open?'×':'☰'}</button></div></div><AnimatePresence>{open&&<motion.nav id="ct-mobile-menu" className="ct-mobile-nav" aria-label={locale==='zh'?'移动导航':'Mobile navigation'} initial={{opacity:0,y:reduced?0:-10}} animate={{opacity:1,y:0}} exit={{opacity:0,y:reduced?0:-10}} transition={{duration:.25,ease:'easeInOut'}}>{[...nav,['contact','contact'] as const].map(([slug,key])=><Link key={key} href={href(basePath,slug)} onClick={()=>setOpen(false)}>{text(ui[key],locale)}</Link>)}</motion.nav>}</AnimatePresence></header>
}
export function Footer({basePath,locale}:{basePath:string;locale:Locale}){
 const host=useConsutechHost();
 return <footer className="ct-footer"><div className="ct-container ct-footer-grid">
  <div><p>{text(ui.email,locale)}</p><Reveal><a className="ct-email" href={'mailto:'+brand.email}>{brand.email}</a></Reveal><p>{text(ui.footer,locale)}</p><small>© {brand.year} {host.brandName[locale]}</small></div>
  <div><h3>{locale==='zh'?'页面':'Pages'}</h3>{nav.map(([slug,key])=><Link key={key} href={href(basePath,slug)}>{text(ui[key],locale)}</Link>)}</div>
  <div><h3>{locale==='zh'?'解决方案':'Solutions'}</h3>{serviceData.slice(0,4).map(service=><Link key={service.slug} href={href(basePath,'services/'+service.slug)}>{text(service.title,locale)}</Link>)}</div>
  <div><h3>{locale==='zh'?'公司':'Company'}</h3>{[['about','about'],['contact','contact'],['privacy','policy'],['terms','terms'],['licenses','license']].map(([slug,key])=><Link key={slug} href={href(basePath,slug)}>{text(ui[key as keyof typeof ui],locale)}</Link>)}{host.marketplaceHref&&<Link href={host.marketplaceHref}>{host.marketplaceLabel?.[locale]}</Link>}</div>
  <div><h3>{locale==='zh'?'社交渠道':'Social'}</h3>{['Instagram','LinkedIn','Twitter','Facebook'].map(channel=><span className="ct-social-channel" key={channel}>{channel}</span>)}<small>{locale==='zh'?'演示渠道，尚未连接':'Demo channels, not connected'}</small></div>
 </div><div className="ct-container ct-footer-wordmark"><Reveal y="100%" delay={.5} duration={1.2}><span>{host.brandName[locale]}</span></Reveal></div><div className="ct-container ct-footer-filing">{host.filing}</div></footer>
}
export function Shell({children,basePath,locale,home=false}:{children:ReactNode;basePath:string;locale:Locale;home?:boolean}){const host=useConsutechHost();return <MotionConfig reducedMotion="user"><div data-template="consutech" className="ct-root" lang={locale==='zh'?'zh-CN':'en'}><a className="ct-skip" href="#ct-main">{locale==='zh'?'跳到正文':'Skip to content'}</a>{!home&&<Header basePath={basePath} locale={locale}/>}<main id="ct-main">{children}</main><Footer basePath={basePath} locale={locale}/>{host.marketplaceHref&&<Link className="ct-marketplace" href={host.marketplaceHref} aria-label={host.marketplaceAriaLabel?.[locale]}><img src={host.lightLogo||host.logo} alt=""/><span>{host.brandName[locale]}</span></Link>}</div></MotionConfig>}
export function PageIntro({eyebrow,title,description}:{eyebrow:string;title:string;description?:string}){return <section className="ct-page-intro ct-container"><p className="ct-eyebrow">{eyebrow}</p><Reveal><h1>{title}</h1></Reveal>{description&&<Reveal delay={.1}><p>{description}</p></Reveal>}</section>}
