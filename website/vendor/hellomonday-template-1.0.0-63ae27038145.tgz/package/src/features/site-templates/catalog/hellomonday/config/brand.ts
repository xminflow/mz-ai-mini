export const brand = { name: { zh: 'Hellomonday', en: 'Hellomonday' }, logo: '/templates/hellomonday/brand.svg', lightLogo: '/templates/hellomonday/brand-light.svg' }
