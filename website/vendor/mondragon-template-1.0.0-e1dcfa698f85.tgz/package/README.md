# Mondragon 数字创意机构模板

固定首读 `.tpl/README.md`、`.tpl/template.json`、`.tpl/project.json`；修改须遵守 `.tpl/docs/ARCHITECTURE.md`、`CUSTOMIZATION.md`、`VERIFICATION.md` 与 `LICENSE.md`。

独立 Next.js / React / TypeScript strict 网站，默认中文，英文 `/en`。覆盖首页、机构、项目列表、10 个案例、博客与 4 篇文章、联系、隐私、条款和 404。支持项目筛选和加载更多、六项服务、报价切换、FAQ、评价、图片灯箱、前后比较、视频和本地表单。

## 环境与运行

Node 22.13.1，pnpm 12.10.1。`pnpm install --frozen-lockfile` 安装；复制 `.env.example` 为 `.env` 按需配置 PORT。`pnpm dev` 启动 http://127.0.0.1:43284 ，Ctrl+C 停止当前服务。`pnpm build` 后 `pnpm start` 运行生产。`pnpm typecheck`、`pnpm lint`、`pnpm test` 分别检查类型、规范和素材/路由契约。`pnpm bundle` 生成固定运行包，`pnpm tpl:check` 检查协议；这些操作不推送、不发布。

## 限制

没有后端、数据库、账户、支付或真实表单发送。表单只在当前页面校验，不写浏览器存储。品牌、客户、成果、荣誉与报价均为演示。第三方图片、视频、英文内容与商标许可尚未确认，`listed=false`；不得据工具链许可推断素材可公开分发。

## 修改与交付

品牌在 config/brand.ts，双语正文在 content/，主题在 tokens.css 与 theme.css，公共组件在 components/，页面在 pages/，路由由 meta.ts 注册。以上路径相对 src/features/site-templates/catalog/mondragon。详情见修改指南。提交源码、包管理器生成的锁、.tpl 资料与素材；不提交缓存、依赖、秘密或日志。任何新增依赖、外部发送、发布动作均需接收方用户授权。

源码仓库：https://github.com/weelume/mondragon-template。
