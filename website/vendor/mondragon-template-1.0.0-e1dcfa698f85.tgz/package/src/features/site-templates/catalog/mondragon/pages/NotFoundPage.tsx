import type { SiteTemplatePageProps } from '../../../types'
import { Layout } from '../components/Layout'
import { More, PageTitle } from '../components/primitives'

export default function NotFoundPage({ locale = 'zh', basePath }: SiteTemplatePageProps) {
  return <Layout locale={locale} basePath={basePath}><PageTitle locale={locale} zh="这一页暂时迷路了" en="This page took a detour" eyebrow="404 / PAGE NOT FOUND" /><section className="md-section"><More basePath={basePath} slug="">{locale === 'zh' ? '回到首页' : 'Back home'}</More></section></Layout>
}
