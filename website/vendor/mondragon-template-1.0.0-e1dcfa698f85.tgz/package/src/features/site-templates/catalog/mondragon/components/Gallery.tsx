'use client'
import { useRef, useState } from 'react'
import type { Locale } from '../content/ui'
export function Gallery({ images, title, locale }: { images: readonly string[]; title: string; locale: Locale }) {
  const dialog = useRef<HTMLDialogElement>(null)
  const [index, setIndex] = useState(0)
  if (!images.length) return null
  const change = (delta: number) => setIndex(i => (i + delta + images.length) % images.length)
  return <div className="md-gallery"><div className="md-gallery-grid">{images.map((src, i) => <button key={src} onClick={() => { setIndex(i); dialog.current?.showModal() }} aria-label={locale === 'zh' ? `放大 ${title} 图片 ${i + 1}` : `Enlarge ${title} image ${i + 1}`}><img src={src} alt={locale === 'zh' ? `${title} 项目展示 ${i + 1}` : `${title} project view ${i + 1}`} loading={i > 0 ? 'lazy' : 'eager'} /><span aria-hidden>↗</span></button>)}</div><dialog ref={dialog} className="md-lightbox" onClick={e => { if (e.target === dialog.current) dialog.current.close() }} onKeyDown={e => { if (e.key === 'ArrowRight') change(1); if (e.key === 'ArrowLeft') change(-1) }}><button className="md-close" onClick={() => dialog.current?.close()} aria-label={locale === 'zh' ? '关闭图片' : 'Close image'}>×</button><img src={images[index]} alt={`${title} · ${index + 1}`} /><div className="md-controls"><button onClick={() => change(-1)} aria-label={locale === 'zh' ? '上一张图片' : 'Previous image'}>←</button><span>{index + 1} / {images.length}</span><button onClick={() => change(1)} aria-label={locale === 'zh' ? '下一张图片' : 'Next image'}>→</button></div></dialog></div>
}
