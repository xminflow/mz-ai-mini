'use client'
import Link from 'next/link'
import { motion, useReducedMotion } from 'framer-motion'
import { useMondragonHost } from '../host'
import { brand } from '../config/brand'
import type { Locale } from '../content/ui'
import { href, media } from '../utils'

const gallery = ['eo6206gxqn0TWBaWpGevapYsXAI.jpg', 'ExjgNuLGxJLw4fc3cmd8US8PYiM.jpg', 'eNhJYsLQJq7KsLDSp9OgbaPdsp0.jpg', 'Gp71a55WWD0asrAvP4akufH6S4c.jpg', 'QfMwTUitCfmObBe5s8PRyprbIGA.jpg', 'D7nAiPVvIx7l3PtKlUP6qIMuU6I.jpg']
export function Hero({ locale, basePath }: { locale: Locale; basePath: string }) {
  const host = useMondragonHost(), reduced = useReducedMotion(), zh = locale === 'zh'
  return <section className="md-hero"><div className="md-ribbon" aria-hidden>{Array.from({ length: 28 }, (_, i) => {
    const wave = Math.sin(i / 4.2)
    return <motion.div key={i} className="md-ribbon-tile" style={{ left: Number((i * 4.1 - 8).toFixed(3)) + '%', top: Number((i * 1.7 + wave * 6 - 2).toFixed(3)) + '%', rotateZ: Number((-34 + wave * 30).toFixed(3)), rotateY: i * 22, zIndex: 40 - i }} animate={reduced ? undefined : { rotateY: [i * 22, i * 22 + 30, i * 22] }} transition={{ duration: 14, repeat: Infinity, ease: 'easeInOut', delay: i * .1 }}><img src={media(gallery[i % gallery.length])} alt="" loading={i < 8 ? 'eager' : 'lazy'} /></motion.div>
  })}</div><aside className="md-book-card md-glass"><div><h2>{zh ? <>开始<br />一个项目</> : <>Start<br />a project</>}</h2><p>{zh ? '和项目经理聊聊你的下一个想法' : 'Let’s book & talk with our manager.'}</p><Link className="md-button" href={href(basePath, 'contact')}>{zh ? '预约沟通' : 'Book call'} ↗</Link></div><img src={media('F3t96ozC3GZuPhKwdm5VWtBIZwM.png')} alt={zh ? 'Kate，演示项目经理' : 'Kate, demo project manager'} /><div className="md-liked"><span>{zh ? '获得 50+ 位创始人认可' : 'Liked by 50+ founders'}</span><div>{['9GOx4VTT9JaOZMAJy4GdCXy3I.jpg', 'DblzQDsny541TSzeqAcowdaAXZk.jpg', 'rZeWINetTprjwMqCAeMugLOkjU.jpg'].map(f => <img key={f} src={media(f)} alt="" width={30} height={30} />)}</div></div></aside><div className="md-hero-caption"><h1>{zh ? '数字创意机构' : 'Digital creative agency'}</h1><div className="md-hero-wordmark" data-short={Boolean(host.brandName) && zh} aria-hidden>{host.brandName?.[locale] || brand.wordmark}</div><div className="md-hero-bottom md-mono"><span>{zh ? '策略 · 品牌 · 数字体验' : 'Strategy · Brand · Digital experiences'}</span><a href="#intro">{zh ? '向下探索' : 'Scroll to explore'} ↓</a></div></div></section>
}
