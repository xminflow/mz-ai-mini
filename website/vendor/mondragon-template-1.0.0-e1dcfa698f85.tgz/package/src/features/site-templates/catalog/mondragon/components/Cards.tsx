'use client'
import { useState } from 'react'
import Link from 'next/link'
import { projects } from '../content/projects'
import { articles } from '../content/articles'
import type { Locale } from '../content/ui'
import { categories } from '../content/categories'
import { href } from '../utils'

export function ProjectGrid({ locale, basePath, featured = false, exclude }: { locale: Locale; basePath: string; featured?: boolean; exclude?: string }) {
  const [category, setCategory] = useState('all'), [limit, setLimit] = useState(4)
  const available = projects.filter(p => p.slug !== exclude)
  const selected = featured ? (exclude ? available.slice(0, 3) : ['white-gate-hotel', 'fashionista', 'alta', 'lementa'].flatMap(slug => available.filter(p => p.slug === slug))) : available.filter(p => category === 'all' || p.tags.includes(category))
  const visible = featured ? selected : selected.slice(0, limit)
  return <div>{!featured && <div className="md-filters" aria-label={locale === 'zh' ? '项目分类' : 'Project categories'}>{categories.map(c => <button key={c.id} aria-pressed={category === c.id} onClick={() => { setCategory(c.id); setLimit(4); console.debug('[mondragon:projects] filter', c.id) }}>{c.label[locale]} <small>{c.id === 'all' ? available.length : available.filter(p => p.tags.includes(c.id)).length}</small></button>)}</div>}
    <div className="md-project-grid">{visible.map((p, i) => <Link key={p.slug} className="md-project" href={href(basePath, 'projects/' + p.slug)}><div className="md-project-image"><img src={p.images[0]} alt={p.title[locale]} loading="lazy" /><span aria-hidden>↗</span></div><div className="md-project-caption"><h3>{p.title[locale]}</h3><span className="md-mono">[{String(i + 1).padStart(2, '0')}]</span></div><div className="md-tags">{p.tags.map(tag => <span key={tag}>{categories.find(c => c.id === tag)?.label[locale]}</span>)}</div></Link>)}</div>
    {!featured && <div className="md-load-more"><p role="status">{locale === 'zh' ? `已展示 ${visible.length} / ${selected.length} 个项目` : `Showing ${visible.length} of ${selected.length} projects`}</p>{visible.length < selected.length && <button className="md-button" onClick={() => setLimit(n => n + 4)}>{locale === 'zh' ? '加载更多' : 'Load more'} +</button>}</div>}
  </div>
}
export function ArticleGrid({ locale, basePath, exclude, home = false }: { locale: Locale; basePath: string; exclude?: string; home?: boolean }) {
  const items = articles.filter(a => a.slug !== exclude).slice(0, home || exclude ? 3 : articles.length)
  return <div className="md-articles">{items.map((a, i) => <Link className="md-article-card" key={a.slug} href={href(basePath, 'blog/' + a.slug)}><div><img loading="lazy" src={a.images[0]} alt={locale === 'zh' ? a.title.zh + '主题图' : a.title.en + ' illustration'} /></div><span className="md-mono">[0{i + 1}] · {a.date}</span><h3>{a.title[locale]}</h3><p>{a.summary[locale]}</p><span className="md-more">[{locale === 'zh' ? '阅读全文' : 'Read more'}] ↗</span></Link>)}</div>
}
