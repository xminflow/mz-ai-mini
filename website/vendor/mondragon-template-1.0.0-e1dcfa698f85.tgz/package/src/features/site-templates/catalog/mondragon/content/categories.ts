import { bi } from './ui'
export const categories = [
  { id: 'all', label: bi('全部', 'All') }, { id: 'website', label: bi('网站', 'Website') },
  { id: 'mobile', label: bi('移动应用', 'Mobile app') }, { id: 'branding', label: bi('品牌', 'Branding') },
  { id: 'content', label: bi('内容', 'Content') }, { id: 'seo', label: bi('搜索优化', 'SEO') },
]
