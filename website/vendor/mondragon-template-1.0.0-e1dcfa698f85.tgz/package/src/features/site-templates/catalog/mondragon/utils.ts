export const media = (file: string) => '/templates/mondragon/media/' + file
export const href = (base: string, slug = '') => (base || '') + (slug ? '/' + slug : '/')
