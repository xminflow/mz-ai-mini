export type Locale = 'zh' | 'en'
export type Bilingual = { zh: string; en: string }
export const bi = (zh: string, en: string): Bilingual => ({ zh, en })
export const nav = [
  { slug: '', label: bi('首页', 'Home') },
  { slug: 'agency', label: bi('机构', 'Agency') },
  { slug: 'projects', label: bi('项目', 'Projects') },
  { slug: 'blog', label: bi('洞察', 'Blog') },
  { slug: 'contact', label: bi('联系', 'Contact') },
]
export const services = [
  { title: bi('网站设计', 'Web Design'), text: bi('用户体验、界面系统与可交互原型，让每一次访问更有意义。', 'UX/UI, design systems and prototypes. Make every visit meaningful.') },
  { title: bi('网站开发', 'Web Development'), text: bi('模块化网站、内容管理与性能优化，让好设计顺利上线。', 'Modular websites, content management and performance. Built to ship.') },
  { title: bi('品牌策略', 'Brand Strategy'), text: bi('厘清定位、受众与价值，找到品牌值得被记住的理由。', 'Positioning, audiences and values. Find a reason to be remembered.') },
  { title: bi('视觉识别', 'Visual Identity'), text: bi('从标志到字体与色彩，建立统一而鲜明的视觉语言。', 'Logo, typography and color. A distinctive and coherent visual language.') },
  { title: bi('动态与三维', 'Motion & 3D'), text: bi('动效、微交互与发布视觉，以恰到好处的动态传递信息。', 'Animation, micro-interactions and launch visuals. Motion with purpose.') },
  { title: bi('内容与艺术指导', 'Content & Art'), text: bi('文案、摄影与影像，用真实内容讲好品牌故事。', 'Copy, photography and film. Tell your story through authentic content.') },
]
export const steps = [
  [bi('发现', 'Discover'), bi('明确目标、受众与限制，梳理现有内容与数据，建立共同的成功标准。', 'Align goals, audiences and constraints. Review content and analytics to define shared success.'), bi('2–4 天', '2–4 days')],
  [bi('定义', 'Define'), bi('将目标转为范围、排期与衡量指标，让每一步的责任和取舍清晰可见。', 'Translate goals into scope, timeline and KPIs. Make responsibilities and trade-offs explicit.'), bi('2–4 天', '2–4 days')],
  [bi('设计', 'Design'), bi('探索创意方向，沉淀模块化界面与品牌工具包，通过每周评审完善细节。', 'Explore concepts and build a modular UI and brand toolkit. Refine through weekly reviews.'), bi('1–2 周', '1–2 weeks')],
  [bi('构建', 'Build'), bi('实现组件与内容结构，持续检查性能、可访问性和跨设备体验。', 'Implement components and content structures. Continuously check performance, accessibility and devices.'), bi('1–2 周', '1–2 weeks')],
  [bi('上线', 'Launch'), bi('检查链接、追踪、性能与交付清单，完成内容编辑培训与上线观察。', 'Check links, tracking and performance. Train your team and monitor the launch.'), bi('2–4 天', '2–4 days')],
  [bi('改进', 'Improve'), bi('围绕关键指标持续实验，以小步迭代积累长期价值。', 'Experiment against KPIs and improve through focused sprints. Small releases build lasting value.'), bi('2–3 周', '2–3 weeks')],
]
export const faq = [
  [bi('一个项目通常需要多久？', 'What’s the typical timeline?'), bi('简单落地页通常需要 2–4 周，完整企业网站约 8–12 周。复杂应用视范围确定；正式开始前会提供里程碑排期。', 'A landing page typically takes 2–4 weeks and a corporate website 8–12 weeks. Complex applications depend on scope. A milestone schedule is agreed before work begins.')],
  [bi('如何确定项目价格？', 'How do you price?'), bi('先明确目标与范围，再根据独立页面、功能和集成需求提供报价。展示价格仅供演示，不构成实际服务承诺。', 'We define goals and scope before pricing unique pages, features and integrations. Displayed prices are demonstrations, not a binding offer.')],
  [bi('开发由内部团队完成吗？', 'Do you develop in-house?'), bi('示例流程由策略、设计与开发角色协作完成。实际团队配置应在合作方案中明确。', 'The example workflow brings strategy, design and development together. Actual team composition should be confirmed in your proposal.')],
  [bi('可以与我们的品牌团队合作吗？', 'Can you work with our brand team?'), bi('可以。通过共享规范、定期评审与清晰的责任分工，让现有品牌体系延伸到数字体验。', 'Yes. Shared guidelines, regular reviews and clear responsibilities extend your brand into a consistent digital experience.')],
  [bi('开始前需要准备什么？', 'What do you need to start?'), bi('项目目标、目标受众、现有品牌规范与内容清单会很有帮助。尚未明确的部分可以在需求梳理中共同确认。', 'Goals, audiences, existing brand guidelines and a content inventory help. Discovery can clarify anything that is still open.')],
  [bi('上线后提供支持吗？', 'Do you support after launch?'), bi('可按双方确认的范围安排维护、内容更新与功能迭代。演示模板本身不包含托管或维护服务。', 'Maintenance, content updates and new features can be scoped separately. This demonstration template does not include hosting or maintenance services.')],
  [bi('如何衡量项目是否成功？', 'How do we measure success?'), bi('在项目开始时明确转化率、线索质量或任务完成率等指标，再以真实数据评估。这里的成果数据均为演示。', 'Agree metrics such as conversion, qualified leads or task success at the start, then evaluate with real data. All results shown here are illustrative.')],
]
export const testimonials = [
  { name: 'Maya Patel', role: 'Head of Growth · Finch Systems', text: bi('团队从结果出发思考问题。我们获得了清晰的设计系统、内容指南和能衡量价值的网站。', 'From day one they spoke in outcomes. We got a design system, content guidelines and a build that measured what mattered.') },
  { name: 'Alex Chen', role: 'Founder · Nova AI', text: bi('他们帮助我们精简叙事，交付了营销团队真正能编辑的模块化网站。', 'The team challenged our assumptions, simplified the story and shipped a modular site our marketers can actually edit.') },
  { name: 'Leon Müller', role: 'COO · Helix Robotics', text: bi('流程清楚，沟通直接，每周演示让团队始终对齐。更快的页面让品牌故事更有说服力。', 'Clear process and crisp communication. Weekly demos kept us aligned, with faster pages and a story our team rallies behind.') },
  { name: 'Dana Fox', role: 'VP Marketing · Orbit Labs', text: bi('模糊的想法变成清晰路线图。品牌找到了自己的声音，网站也按计划上线。', 'They brought structure to chaos. The brief became a roadmap, the brand had a voice and the site launched on schedule.') },
]
