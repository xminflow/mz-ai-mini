import type { SiteTemplatePageProps } from '../../../types'
import { Layout } from '../components/Layout'
import { PageTitle } from '../components/primitives'

import { ProjectGrid } from '../components/Cards'
import { projects } from '../content/projects'
export default function ProjectsPage({ locale = 'zh', basePath }: SiteTemplatePageProps) {
  return <Layout locale={locale} basePath={basePath}><PageTitle locale={locale} zh="创意落地的样子" en="Projects" eyebrow={`${String(projects.length).padStart(2, '0')} / ${locale === 'zh' ? '项目集' : 'Selected projects'}`} /><section className="md-section md-project-list"><ProjectGrid locale={locale} basePath={basePath} /></section></Layout>
}
