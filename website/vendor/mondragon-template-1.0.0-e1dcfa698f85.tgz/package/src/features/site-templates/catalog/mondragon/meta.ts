import { createElement } from 'react'
import type { SiteTemplate } from '../../types'
export const mondragonTemplate: SiteTemplate = { ...{
"gitUrl":"https://github.com/weelume/mondragon-template",
  "id": "mondragon",
  "name": "Mondragon · 数字创意机构",
  "localizedNames": {
    "en": "Mondragon · Digital creative agency"
  },
  "sceneId": "corporate-site",
  "listed": false,
  "tags": [
    "数字创意",
    "扭转图带",
    "浅灰极简",
    "中英文",
    "PC / iPad / H5"
  ],
  "summary": "以扭转图带与大字标呈现创意机构：10 个项目案例、4 篇设计文章、机构介绍、服务流程、报价与演示表单。",
  "accentColor": "#bacba8",
  "cover": "/templates/mondragon/screenshots/desktop-home.webp",
  "screenshots": [
    {
      "src": "/templates/mondragon/screenshots/desktop-home.webp",
      "alt": "Mondragon desktop home",
      "device": "desktop",
      "width": 1440,
      "height": 1000
    },
    {
      "src": "/templates/mondragon/screenshots/desktop-projects.webp",
      "alt": "Mondragon desktop projects",
      "device": "desktop",
      "width": 1440,
      "height": 1000
    },
    {
      "src": "/templates/mondragon/screenshots/desktop-blog.webp",
      "alt": "Mondragon desktop blog",
      "device": "desktop",
      "width": 1440,
      "height": 1000
    },
    {
      "src": "/templates/mondragon/screenshots/desktop-contact.webp",
      "alt": "Mondragon desktop contact",
      "device": "desktop",
      "width": 1440,
      "height": 1000
    },
    {
      "src": "/templates/mondragon/screenshots/tablet-home.webp",
      "alt": "Mondragon tablet home",
      "device": "tablet",
      "width": 834,
      "height": 1180
    },
    {
      "src": "/templates/mondragon/screenshots/tablet-projects.webp",
      "alt": "Mondragon tablet projects",
      "device": "tablet",
      "width": 834,
      "height": 1180
    },
    {
      "src": "/templates/mondragon/screenshots/tablet-blog.webp",
      "alt": "Mondragon tablet blog",
      "device": "tablet",
      "width": 834,
      "height": 1180
    },
    {
      "src": "/templates/mondragon/screenshots/tablet-contact.webp",
      "alt": "Mondragon tablet contact",
      "device": "tablet",
      "width": 834,
      "height": 1180
    },
    {
      "src": "/templates/mondragon/screenshots/mobile-home.webp",
      "alt": "Mondragon mobile home",
      "device": "mobile",
      "width": 390,
      "height": 844
    },
    {
      "src": "/templates/mondragon/screenshots/mobile-projects.webp",
      "alt": "Mondragon mobile projects",
      "device": "mobile",
      "width": 390,
      "height": 844
    },
    {
      "src": "/templates/mondragon/screenshots/mobile-blog.webp",
      "alt": "Mondragon mobile blog",
      "device": "mobile",
      "width": 390,
      "height": 844
    },
    {
      "src": "/templates/mondragon/screenshots/mobile-contact.webp",
      "alt": "Mondragon mobile contact",
      "device": "mobile",
      "width": 390,
      "height": 844
    }
  ]
}, surfaces: [{ id:'site', name:'创意机构官网',platform:'pc',locales:['zh','en'],pages:[
{slug:"",title:"首页",localizedTitles:{en:"Home"},load:() => import('./pages/HomePage')},
{slug:"agency",title:"机构",localizedTitles:{en:"Agency"},load:() => import('./pages/AgencyPage')},
{slug:"projects",title:"项目",localizedTitles:{en:"Projects"},load:() => import('./pages/ProjectsPage')},
{slug:"blog",title:"洞察",localizedTitles:{en:"Blog"},load:() => import('./pages/BlogPage')},
{slug:"contact",title:"联系我们",localizedTitles:{en:"Contact"},load:() => import('./pages/ContactPage')},
{slug:"projects/lementa",title:"勒门塔",localizedTitles:{en:"Lementa"},load:async () => { const { default: Page } = await import('./pages/CasePage'); return { default: (props) => createElement(Page, { ...props, slug: 'lementa' }) } }},
{slug:"projects/adamant-inc",title:"坚石科技",localizedTitles:{en:"Adamant Inc."},load:async () => { const { default: Page } = await import('./pages/CasePage'); return { default: (props) => createElement(Page, { ...props, slug: 'adamant-inc' }) } }},
{slug:"projects/white-gate-hotel",title:"白门酒店",localizedTitles:{en:"White Gate Hotel"},load:async () => { const { default: Page } = await import('./pages/CasePage'); return { default: (props) => createElement(Page, { ...props, slug: 'white-gate-hotel' }) } }},
{slug:"projects/fashionista",title:"时尚风向",localizedTitles:{en:"Fashionista"},load:async () => { const { default: Page } = await import('./pages/CasePage'); return { default: (props) => createElement(Page, { ...props, slug: 'fashionista' }) } }},
{slug:"projects/levi-z55",title:"Levi Z55",localizedTitles:{en:"Levi Z55"},load:async () => { const { default: Page } = await import('./pages/CasePage'); return { default: (props) => createElement(Page, { ...props, slug: 'levi-z55' }) } }},
{slug:"projects/heaven",title:"云境",localizedTitles:{en:"Heaven"},load:async () => { const { default: Page } = await import('./pages/CasePage'); return { default: (props) => createElement(Page, { ...props, slug: 'heaven' }) } }},
{slug:"projects/holo-agency",title:"全息创意",localizedTitles:{en:"Holo Agency"},load:async () => { const { default: Page } = await import('./pages/CasePage'); return { default: (props) => createElement(Page, { ...props, slug: 'holo-agency' }) } }},
{slug:"projects/mellisa-clothings",title:"梅丽莎服饰",localizedTitles:{en:"Mellisa Clothings"},load:async () => { const { default: Page } = await import('./pages/CasePage'); return { default: (props) => createElement(Page, { ...props, slug: 'mellisa-clothings' }) } }},
{slug:"projects/alta",title:"阿尔塔集团",localizedTitles:{en:"Alta Group"},load:async () => { const { default: Page } = await import('./pages/CasePage'); return { default: (props) => createElement(Page, { ...props, slug: 'alta' }) } }},
{slug:"projects/wizard-from-trappist-1",title:"TRAPPIST-1 探索者",localizedTitles:{en:"Wizard from TRAPPIST-1"},load:async () => { const { default: Page } = await import('./pages/CasePage'); return { default: (props) => createElement(Page, { ...props, slug: 'wizard-from-trappist-1' }) } }},
{slug:"blog/fresh-visual-trends-in-2026",title:"2026 视觉设计新趋势",localizedTitles:{en:"Fresh Visual Trends in 2026"},load:async () => { const { default: Page } = await import('./pages/ArticlePage'); return { default: (props) => createElement(Page, { ...props, slug: 'fresh-visual-trends-in-2026' }) } }},
{slug:"blog/web-design-in-the-future",title:"网页设计的未来",localizedTitles:{en:"Web Design in the Future"},load:async () => { const { default: Page } = await import('./pages/ArticlePage'); return { default: (props) => createElement(Page, { ...props, slug: 'web-design-in-the-future' }) } }},
{slug:"blog/new-demensions-in-marketing",title:"营销的新维度",localizedTitles:{en:"New Demensions in Marketing"},load:async () => { const { default: Page } = await import('./pages/ArticlePage'); return { default: (props) => createElement(Page, { ...props, slug: 'new-demensions-in-marketing' }) } }},
{slug:"blog/beyond-screens-and-interfaces",title:"超越屏幕与界面",localizedTitles:{en:"Beyond Screens and Interfaces"},load:async () => { const { default: Page } = await import('./pages/ArticlePage'); return { default: (props) => createElement(Page, { ...props, slug: 'beyond-screens-and-interfaces' }) } }},
{slug:"privacy",title:"隐私说明",localizedTitles:{en:"Privacy policy"},load:async () => { const { default: Page } = await import('./pages/PolicyPage'); return { default: (props) => createElement(Page, { ...props, kind: 'privacy' }) } }},
{slug:"terms",title:"使用条款",localizedTitles:{en:"Terms of use"},load:async () => { const { default: Page } = await import('./pages/PolicyPage'); return { default: (props) => createElement(Page, { ...props, kind: 'terms' }) } }},
{slug:"404",title:"页面未找到",localizedTitles:{en:"Page not found"},load:() => import('./pages/NotFoundPage')}
]}]}
