'use client'
import { useState, type FormEvent } from 'react'
import Link from 'next/link'
import { href, media } from '../utils'
import type { Locale } from '../content/ui'

export function ContactForm({ locale, basePath, full = false }: { locale: Locale; basePath: string; full?: boolean }) {
  const zh = locale === 'zh'
  const [status, setStatus] = useState('')
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const data = new FormData(event.currentTarget)
    if (!String(data.get('name')).trim() || !String(data.get('message')).trim()) {
      setStatus(zh ? '姓名和项目介绍不能只包含空格。' : 'Name and message cannot contain only spaces.')
      console.debug('[mondragon:contact] validation rejected: blank required field')
      return
    }
    console.debug('[mondragon:contact] local validation completed; no request or storage')
    setStatus(zh ? '本地校验通过。演示表单尚未发送或保存任何信息。' : 'Local validation passed. This demo has not sent or saved any information.')
  }
  return <form className="md-form" onSubmit={submit} onChange={() => setStatus('')}>
    <label>{zh ? '你的姓名' : 'Your name'}<input name="name" autoComplete="name" required maxLength={80} /></label>
    <label>{zh ? '电子邮箱' : 'Your email'}<input name="email" type="email" autoComplete="email" required maxLength={254} /></label>
    {full && <><label>{zh ? '电话号码（选填）' : 'Phone number (optional)'}<input name="phone" type="tel" autoComplete="tel" maxLength={40} /></label><label>{zh ? '网站（选填）' : 'Your website (optional)'}<input name="website" type="url" placeholder="https://" autoComplete="url" /></label></>}
    <label className="md-wide">{zh ? '介绍你的项目' : 'Your message'}<textarea name="message" required rows={4} maxLength={4000} /></label>
    <p className="md-fine md-wide">{zh ? '仅做本地校验，不发送、不保存。' : 'Local validation only. Nothing is sent or saved.'} <Link href={href(basePath, 'terms')}>{zh ? '条款' : 'Terms'}</Link> · <Link href={href(basePath, 'privacy')}>{zh ? '隐私政策' : 'Privacy'}</Link></p>
    <button className="md-button md-wide" type="submit">{zh ? '检查项目信息' : 'Check message'} <span aria-hidden>↗</span></button>
    <p role="status" className="md-status md-wide">{status}</p>
  </form>
}
export function ContactSection({ locale, basePath }: { locale: Locale; basePath: string }) {
  const zh = locale === 'zh'
  return <section className="md-contact-section md-section" id="contact"><div><span className="md-mono">[{zh ? '一起开始' : 'Let’s talk'}]</span><h2>{zh ? <>让想法<br />成为现实</> : <>Start<br />a project</>}</h2><p>{zh ? '告诉我们你的目标，一起梳理范围与方向。' : 'Tell us about your goals. Let’s shape the scope and direction.'}</p><div className="md-manager"><img src={media('F3t96ozC3GZuPhKwdm5VWtBIZwM.png')} alt={zh ? '演示项目经理 Kate' : 'Kate, demo project manager'} width={72} height={88} /><div>Kate Wilington<br /><small>● {zh ? '项目沟通 · 演示' : 'Project manager · Demo'}</small></div></div></div><ContactForm locale={locale} basePath={basePath} /></section>
}
export function Newsletter({ locale }: { locale: Locale }) {
  const zh = locale === 'zh'
  const [status, setStatus] = useState('')
  return <form className="md-newsletter" onSubmit={e => { e.preventDefault(); setStatus(zh ? '邮箱格式有效。演示尚未订阅、发送或保存。' : 'Valid email. This demo has not subscribed, sent or saved anything.'); console.debug('[mondragon:newsletter] local email validation only') }}>
    <h3>{zh ? '订阅设计来信' : 'Subscribe to newsletter'}</h3><p>{zh ? '关于品牌、行业与增长的实用思考。仅演示校验。' : 'Practical notes on brands, industry and growth. Validation demo only.'}</p>
    <div><label className="md-sr" htmlFor="md-news-email">{zh ? '订阅邮箱' : 'Newsletter email'}</label><input id="md-news-email" type="email" required placeholder={zh ? '你的邮箱' : 'Your email'} /><button type="submit">{zh ? '检查邮箱' : 'Check email'} ↗</button></div><p role="status" className="md-status">{status}</p>
  </form>
}
