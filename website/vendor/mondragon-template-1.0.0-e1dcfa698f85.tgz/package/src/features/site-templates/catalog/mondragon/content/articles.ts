export const articles = [
  {
    "slug": "fresh-visual-trends-in-2026",
    "title": {
      "zh": "2026 视觉设计新趋势",
      "en": "Fresh Visual Trends in 2026"
    },
    "summary": {
      "zh": "系统、材质与恰到好处的动态，塑造更清晰的数字体验。",
      "en": "Flat UI stays, but surfaces gain depth via subtle texture, micro-noise, and soft specular highlights. Pair clean grids with “material cues” that hint at glass, fabric, or brushed metal. Keep contrast high and motion low."
    },
    "date": "2025-10-01",
    "images": [
      "/templates/mondragon/media/4d7UdHQpAcfXX9ahPJAV3G9Y.jpg",
      "/templates/mondragon/media/QOZL0EVj8u1C3BDIY5TvplAvtQ.jpg",
      "/templates/mondragon/media/JO1FXM5rs9QITJCmSgC1KGyCMI.jpg"
    ],
    "body": {
      "zh": [
        "平面界面仍然重要，但细腻纹理、微噪点与柔和高光让表面有了深度。以清晰网格承载玻璃、织物或金属的材质线索，保持足够对比度。",
        "紧凑字距与几何数字让数据、报价和工具界面更有秩序。展示字体与易读正文可以互相补充，较大的标题尤其需要考虑字形与行距。",
        "以深色基底搭配单一鲜明强调色，让状态与主要操作容易识别。先建立用途明确的主题变量，再定义不同背景的对比关系。",
        "微动效应解释因果关系：按下按钮，界面立即回应。尽量只改变位移与透明度，并为减少动态偏好提供静态体验。",
        "编辑式版面走进产品：更宽留白、引文与注释图片有助于引导阅读。保持文字层级一致，让形式服务于内容。",
        "渐变和三维场景适合提供语境，不应成为阅读负担。预先处理光照、控制资源体积，在移动设备上保持操作流畅。",
        "真实产品摄影强调光影、接口和材质。减少无目的修饰，让图像帮助用户判断真实细节。",
        "生成式内容需要透明标识与来源说明。把信任作为设计的一部分，让用户知道内容如何产生。"
      ],
      "en": [
        "Flat UI stays, but surfaces gain depth via subtle texture, micro-noise, and soft specular highlights. Pair clean grids with “material cues” that hint at glass, fabric, or brushed metal. Keep contrast high and motion low.",
        "Monospace-inspired grotesks with tight tracking and geometric numerals. Use for data, pricing, and code-adjacent brands. Mix one expressive weight with a humanist body font. Optical sizing on, letter-spacing negative on big heads.",
        "Two-tone palettes dominate: dark base + one saturated accent. Accent drives state, charts, and CTAs. Build tokens first; guard contrast in light/dark.",
        "Micro-transitions in 120–220 ms, physics eased. Emphasize causality: press → response. Respect reduced motion. Prefer transform/opacity only.",
        "Magazine layouts enter product: wide margins, pull quotes, annotated imagery. Use for onboarding, case studies, and feature launches. Keep typographic scale consistent.",
        "Low-frequency, GPU-friendly gradients with hue drift tied to app state or time. Avoid rainbow noise; pick a 20–40° hue arc. Export as CSS conic/linear where possible.",
        "Tiny GL scenes and billboarded depth for context, not spectacle. Prebake lighting, cap DPR, and fall back to video/Lottie on mobile. Use to explain mechanisms or space.",
        "Interfaces foreground metrics: sparklines, deltas, thresholds. Visual hierarchy follows signal strength. Charts blend with UI tokens, not libraries’ defaults.",
        "Hard light, crisp shadows, true-to-life color. Minimal retouch. Show grips, seams, ports—honest product storytelling.",
        "Small, purpose-built real-world cues: toggle notches, embossed stamps, stitched dividers. Use sparingly to guide affordance.",
        "Badges and frames that label generated/assisted content. Neutral iconography, timestamps, provenance links. Trust as a design layer."
      ]
    }
  },
  {
    "slug": "web-design-in-the-future",
    "title": {
      "zh": "网页设计的未来",
      "en": "Web Design in the Future"
    },
    "summary": {
      "zh": "从静态版面走向智能、可适应的跨设备体验。",
      "en": "Web design has always reflected the technology of its time. In the early days, static pages dominated. Then came dynamic sites, mobile responsiveness, and immersive visuals. Looking forward, the future of web design will extend beyond layouts and color schemes. It will become a field defined by intelligence, adaptability, and experiences that blur the line between digital and physical space."
    },
    "date": "2025-10-01",
    "images": [
      "/templates/mondragon/media/9GL4GngzfdEfKewdpKm1HmcGQ9Y.jpg",
      "/templates/mondragon/media/rCqn9N03eNlbjYfxf20lgyP9JAI.jpg",
      "/templates/mondragon/media/5ZvytFVvBM1RRRZPpuJjVcTQaV0.jpg"
    ],
    "body": {
      "zh": [
        "网页设计始终回应着技术变化。从静态页面到响应式体验，下一步不仅是新的版式，也包括更聪明的内容组织与交互规则。",
        "人工智能可以协助整理内容、探索布局与理解使用数据。设计师仍需判断目标、品牌与边界，避免把个性化变成不可解释的变化。",
        "增强现实与空间计算扩展了界面所在的位置。手势、视线和声音带来新机会，也要求我们认真对待安全、疲劳和可访问性。",
        "真正有用的个性化应尊重用户选择。字体、导航密度和内容推荐都需要清晰的设置、合理的默认值和可撤销的操作。",
        "轻量代码、优化媒体与克制动效降低资源消耗。可持续设计与清晰视觉并不冲突，两者往往相互促进。",
        "用户可能从手机开始，在平板继续，再到桌面完成任务。设计需要保持任务状态、语言和操作逻辑的连续。",
        "未来的网页应让更多人更容易完成目标。智能与新技术只有在提升可理解性时，才真正创造价值。"
      ],
      "en": [
        "Web design has always reflected the technology of its time. In the early days, static pages dominated. Then came dynamic sites, mobile responsiveness, and immersive visuals. Looking forward, the future of web design will extend beyond layouts and color schemes. It will become a field defined by intelligence, adaptability, and experiences that blur the line between digital and physical space.",
        "Artificial intelligence will no longer just automate small tasks like resizing images. AI will act as a co-designer, analyzing data, predicting user intent, and generating layouts optimized for both aesthetics and performance. Designers will shift from pushing pixels to setting rules and curating systems. A single website could automatically adapt its typography, imagery, and even tone of voice to suit each visitor.",
        "With the growth of AR and VR, web design will not be limited to flat screens. Websites may become three-dimensional spaces you can explore, similar to walking through a gallery or store. Interfaces will be spatial, navigated by gestures, gaze, or voice rather than clicks. This will require new design languages, blending architecture, storytelling, and interaction design.",
        "Today, personalization is mostly limited to recommendations or content filters. In the future, entire web experiences may be generated in real time for each individual. Fonts, navigation patterns, and interface density could all shift based on user preferences, accessibility needs, or even emotional states detected by sensors. The web will feel less like a single site and more like a living organism responding to its visitor.",
        "As awareness of digital carbon footprints grows, web design will embrace sustainability. Lightweight code, efficient animations, and optimized media will become a priority. Minimalist aesthetics will align with this trend, stripping away clutter not just for visual clarity but also for environmental responsibility.",
        "Websites will no longer be destinations but connective layers across devices. A user might start a task on a phone, continue on smart glasses, and finish on a car display—with seamless continuity. Design systems will need to adapt fluidly across screen sizes, input modes, and contexts of use.",
        "Despite all the technology, the essence of web design will remain human. The future will not be about replacing creativity but enhancing it—giving designers tools to tell better stories, build more inclusive experiences, and connect people in meaningful ways. The web will expand into new dimensions, but its success will still depend on empathy, clarity, and the ability to inspire trust."
      ]
    }
  },
  {
    "slug": "new-demensions-in-marketing",
    "title": {
      "zh": "营销的新维度",
      "en": "New Demensions in Marketing"
    },
    "summary": {
      "zh": "以系统连接数据、创意与用户的真实生活场景。",
      "en": "Design for moments, not media. Map the day into “before → during → after” and place messages at the lowest-attention point that still moves the metric. Use glanceable formats, short video, and utility content. Kill orphan campaigns that do not connect to a user moment."
    },
    "date": "2025-10-01",
    "images": [
      "/templates/mondragon/media/H4ABOyT4ztoCTj2INxaFu5Baqk.jpg",
      "/templates/mondragon/media/J5B8zW7ZQK3PHT8RcQih3QApcY.jpg",
      "/templates/mondragon/media/LzzymHdvlEFV5kCKDUAE2xRxW4A.jpg"
    ],
    "body": {
      "zh": [
        "为场景设计，而非只为渠道设计。理解用户在行动前、行动中与行动后的需求，在合适时刻提供有用信息。",
        "把获得同意的数据视为需要维护的资产。明确事件名称，减少不必要字段，用简单的价值交换建立长期信任。",
        "将创意拆成开场、主体和结尾等模块。小范围尝试不同表达方式，观察注意力和任务完成情况，而不只关注点击。",
        "跨搜索、社交与邮件保持统一目标和频率限制。不同触点应共同服务于用户旅程，而不是彼此独立的短期活动。",
        "从业务目标出发，逐步建立代理指标与诊断指标。注册量背后可能涉及页面速度、表单阻力和内容理解。",
        "模型可协助受众研究、文案草拟与数据总结。策略、边界和品牌语气仍需要人的判断，实验过程应可以追溯。",
        "长期投入可掌控的内容、站点性能与社区。明确解释个性化原因，并允许用户撤销选择。",
        "先定义场景和指标，再构建创意工具包，最后通过持续实验积累可复用的经验。"
      ],
      "en": [
        "Design for moments, not media. Map the day into “before → during → after” and place messages at the lowest-attention point that still moves the metric. Use glanceable formats, short video, and utility content. Kill orphan campaigns that do not connect to a user moment.",
        "Treat consented data like an asset with SLAs. Build simple value exchanges: account perks, calculators, trackers, waitlists. Unify IDs, define event names, and prune fields. Train models on your data, not rented audiences.",
        "Make modular assets: hooks, bodies, end cards. Generate variants fast, then let the system pick winners. Use small framing changes—lead with problem, proof, or demo. Measure attention per second and scroll-hold not only CTR.",
        "Automate placements across search, social, retail media, and email with one brief and shared IDs. Use server-side tagging, clean rooms where needed, and frequency caps across channels. Think “orchestrations,” not “bursts.”",
        "Define a ladder: business KPI → proxy metrics → diagnostics. Example for signup growth: new accounts → CTR, CVR → LCP, form friction, creative recall. Use incrementality tests, MMM light for budget, and lift studies per cohort.",
        "Use models for four jobs: audience discovery, creative drafting, bidding, and analytics summaries. Keep humans for strategy, guardrails, and brand tone. Log prompts and outcomes like experiments.",
        "Invest in properties you control: site speed (LCP ≤2.0s), content searchability (schema, clusters), community emails, and tools. Depend less on rented reach.",
        "Clear consent, visible reasons for personalization, and an undo for choices. Collect less, explain more. Reputation compounds faster than spend.",
        "Week 1–2: define moments, KPIs, event map.",
        "Week 3–6: build modular creative kit, launch first orchestrations.",
        "Week 7–10: instrument speed and form friction, run two lift tests.",
        "Week 11–13: reallocate budget by incrementality, publish learnings.",
        "New dimensions reward systems thinking: tighter loops between data, creative, and delivery; faster tests; clearer value. The brand that learns fastest wins."
      ]
    }
  },
  {
    "slug": "beyond-screens-and-interfaces",
    "title": {
      "zh": "超越屏幕与界面",
      "en": "Beyond Screens and Interfaces"
    },
    "summary": {
      "zh": "从排列像素，走向理解环境、行为与结果。",
      "en": "Screens are not the product. They are one surface of a larger system. As computation spreads into space, objects, and context, design shifts from arranging pixels to shaping behaviors, signals, and outcomes. This essay maps that shift and offers a practical playbook."
    },
    "date": "2025-10-01",
    "images": [
      "/templates/mondragon/media/jLJefSjQOJMlzbWUPlMjkdGmA.jpg",
      "/templates/mondragon/media/FVgtCdopSLfAjea3mAKoAUXHxC0.jpg",
      "/templates/mondragon/media/lRUT2GI16XSsXp8i1SSQxAvVBu4.jpg"
    ],
    "body": {
      "zh": [
        "屏幕只是系统的一种表面。随着计算走入空间、物体与日常场景，设计开始关注行为、信号与最终结果。",
        "人的注意力有限。好的体验应能适应环境，并在不需要时退到背景，让信息在恰当的位置被看见。",
        "从人与场所、设备与规则出发理解环境。上下文信号应经过安全、权限与性能边界，再转化为清晰行动。",
        "环境式体验可以提前呈现下一步，也必须允许暂停、恢复和关闭。能轻松撤销的操作让自动化更可信赖。",
        "空间界面需要考虑距离、遮挡、姿态与触达范围。信息不应无序堆叠，动态也不能影响舒适和安全。",
        "声音适合表达意图，屏幕适合比较选项。不同输入方式应互相补充，并为无法使用某种方式的人保留选择。",
        "设计的衡量标准仍然是减少错误、节省时间和完成任务。技术越复杂，呈现给人的体验越应该清楚。"
      ],
      "en": [
        "Screens are not the product. They are one surface of a larger system. As computation spreads into space, objects, and context, design shifts from arranging pixels to shaping behaviors, signals, and outcomes. This essay maps that shift and offers a practical playbook.",
        "+ Attention is scarce. Interfaces that demand focus lose to experiences that adapt and disappear.+ Sensors, APIs, and models now infer intent. Input moves from taps to presence, motion, and voice.+ Value accrues to systems that work across moments, not to single pages.",
        "Think in environments: people, places, devices, and rules. The interface becomes a negotiator between context and goals.",
        "Context signals: location, proximity, identity, time, activity, weather, device state.System rules: constraints, safety, permissions, brand voice, performance budgets.Outcomes: tasks completed, errors avoided, time saved, energy preserved.Design sets how signals meet rules to produce outcomes with minimal friction.",
        "Ambient UX reduces the need for active interaction.",
        "Proactive: surface the next best action before a tap.Peripheral: visible at the edge of attention; readable at a glance.Recoverable: easy to pause, resume, or dismiss without penalty.",
        "Patterns: glanceable cards, subtle badges, time-based nudges, automated state sync across devices.",
        "AR, wearables, and in-car systems add depth.",
        "Anchors: tie information to places or objects.Gestures: simple, low-effort inputs that do not require looking down.Occlusion and focus: avoid stacking text in 3D; stage information by distance.Safety: prioritize stability; respect motion sickness and light conditions.",
        "Treat space like layout. Use grids in meters, not pixels. Design for hand size, reach, and posture.",
        "Voice is efficient for intents; screens are better for choices.",
        "Use voice for commands, status, capture.Use screens for comparison, discovery, and confirmation.Always provide a silent path: tap, type, or glanceable cues.Keep latency under 300 ms for perceived responsiveness.Multimodal = user picks the channel; the system keeps state.",
        "Products and spaces become interactive without screens.",
        "Haptics: confirm actions with gentle pulses rather than sounds.Light: encode meaning in color, direction, cadence.Form: affordances signal function; edges, textures, and travel matter.Energy: design for low power; idle states are part of UX.When an object “just works,” UI becomes a last resort, not a first step.",
        "Beyond screens demands a mature data stance.",
        "Consent by design: clear scopes, revocation, and local processing where possible.Least privilege: collect the minimum; prune regularly.Explainability: show why the system acted; offer an undo.Safety rails: rate limits, anomaly detection, and human override.",
        "Trust is a feature. Loss of trust is technical debt.",
        "Start with moments, not pages. Map the day in episodes: before, during, after.",
        "Minimize the need to look. Favor audio, haptics, and glanceables.",
        "Predict, then ask. Offer a reasonable default; confirm only when risk is high.",
        "Keep identity and state portable. Users continue tasks across contexts.",
        "Budget motion and attention. Small, quiet, reversible changes first.",
        "Performance is safety. Latency limits and fallbacks are part of the spec.",
        "Accessibility by default. Contrast, captions, transcripts, reduced motion, tactile cues.",
        "Privacy as posture. On-device first; clear trails of what was used and why."
      ]
    }
  }
]
