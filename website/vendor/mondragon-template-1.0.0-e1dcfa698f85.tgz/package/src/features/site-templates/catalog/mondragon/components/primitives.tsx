'use client'
import { motion, useReducedMotion } from 'framer-motion'
import Link from 'next/link'
import { href } from '../utils'
import type { ReactNode } from 'react'
import type { Locale } from '../content/ui'

export function Reveal({ children, className = '' }: { children: ReactNode; className?: string }) {
  const reduced = useReducedMotion()
  return <motion.div className={className} initial={reduced ? false : { opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: .08 }} transition={{ duration: reduced ? 0 : .55 }}>{children}</motion.div>
}
export function SectionHead({ title, number, children }: { title: string; number?: string; children?: ReactNode }) {
  return <div className="md-section-head"><h2>{title}</h2>{number && <span className="md-mono">[{number}]</span>}{children}</div>
}
export function More({ basePath, slug, children }: { basePath: string; slug: string; children: ReactNode }) {
  return <Link className="md-more" href={href(basePath, slug)}>[{children}] <span aria-hidden>↗</span></Link>
}
export function PageTitle({ locale, zh, en, eyebrow }: { locale: Locale; zh: string; en: string; eyebrow?: string }) {
  return <div className="md-page-title"><p className="md-mono">{eyebrow || (locale === 'zh' ? '数字创意机构' : 'Digital creative agency')}</p><h1>{locale === 'zh' ? zh : en}<span aria-hidden>↘</span></h1></div>
}
