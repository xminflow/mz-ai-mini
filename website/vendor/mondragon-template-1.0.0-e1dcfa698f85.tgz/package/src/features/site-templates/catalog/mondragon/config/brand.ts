export const brand = {
  name: { zh: 'Mondragon', en: 'Mondragon' },
  wordmark: 'MONDRAGON',
  logo: '/templates/mondragon/logo.svg',
  email: 'studio@example.com',
  phone: '+44 20 7946 0123',
  address: { zh: '伦敦 · 英国（演示工作室）', en: 'London, United Kingdom · Demo studio' },
  year: 2026,
}
