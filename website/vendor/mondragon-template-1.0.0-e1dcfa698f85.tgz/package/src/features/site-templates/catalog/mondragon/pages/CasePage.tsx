import type { SiteTemplatePageProps } from '../../../types'
import { Layout } from '../components/Layout'
import { Gallery } from '../components/Gallery'
import { More, PageTitle, SectionHead } from '../components/primitives'

import { ProjectGrid } from '../components/Cards'
import { Packages } from '../components/Interactions'
import { ContactSection } from '../components/Forms'
import { projects } from '../content/projects'
import { categories } from '../content/categories'
export default function CasePage({ locale = 'zh', basePath, slug }: SiteTemplatePageProps & { slug: string }) {
  const project = projects.find(p => p.slug === slug)
  if (!project) throw new Error('Unknown project: ' + slug)
  const zh = locale === 'zh'
  return <Layout locale={locale} basePath={basePath}><div className="md-page-back"><More basePath={basePath} slug="projects">{zh ? '返回项目' : 'Back to projects'}</More></div><PageTitle locale={locale} zh={project.title.zh} en={project.title.en} eyebrow={zh ? '[01] / 项目案例' : '[01] / Case study'} /><section className="md-section md-case-intro"><p>{project.description[locale]}</p><dl>{[[zh ? '年份' : 'Year', '2025'], [zh ? '服务' : 'Services', project.tags.map(tag => categories.find(c => c.id === tag)?.label[locale]).join(' / ')], [zh ? '项目地点' : 'Location', zh ? '英国 · 伦敦' : 'London, UK'], [zh ? '项目周期' : 'Duration', zh ? '2 个月 · 演示' : '2 months · Demo']].map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl><p className="md-fine">{zh ? '案例、客户与成果均为模板演示，不代表实际商业合作。' : 'Cases, clients and outcomes are illustrative and do not represent actual commercial work.'}</p></section><section className="md-section md-case-gallery"><Gallery images={project.images} title={project.title[locale]} locale={locale} /></section><section className="md-section"><SectionHead title={zh ? '更多项目' : 'Other projects'} number="02" /><ProjectGrid locale={locale} basePath={basePath} featured exclude={slug} /></section><Packages locale={locale} basePath={basePath} /><ContactSection locale={locale} basePath={basePath} /></Layout>
}
