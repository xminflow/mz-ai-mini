import type { SiteTemplatePageProps } from '../../../types'
import { Layout } from '../components/Layout'
import { ArticleGrid } from '../components/Cards'
import { More, SectionHead } from '../components/primitives'

import { articles } from '../content/articles'
export default function ArticlePage({ locale = 'zh', basePath, slug }: SiteTemplatePageProps & { slug: string }) {
  const article = articles.find(a => a.slug === slug)
  if (!article) throw new Error('Unknown article: ' + slug)
  const zh = locale === 'zh'
  return <Layout locale={locale} basePath={basePath}><article className="md-editorial"><More basePath={basePath} slug="blog">{zh ? '返回洞察' : 'Back to blog'}</More><header><p className="md-mono"><time dateTime={article.date}>{article.date}</time> / {zh ? '设计笔记' : 'Design notes'}</p><h1>{article.title[locale]}</h1><p>{article.summary[locale]}</p></header><img className="md-editorial-cover" src={article.images[0]} alt={article.title[locale]} /><div className="md-prose">{article.body[locale].map((text, i) => <div key={i}>{i > 0 && i % 3 === 0 && article.images[Math.floor(i / 3)] && <img src={article.images[Math.floor(i / 3)]} alt={zh ? '文章配图' : 'Article illustration'} loading="lazy" />}<p>{text}</p></div>)}</div></article><section className="md-section"><SectionHead title={zh ? '继续阅读' : 'Other posts'} number="07" /><ArticleGrid locale={locale} basePath={basePath} exclude={slug} /></section></Layout>
}
