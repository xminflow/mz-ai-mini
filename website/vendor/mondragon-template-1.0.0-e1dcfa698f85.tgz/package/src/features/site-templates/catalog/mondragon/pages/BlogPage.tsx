import type { SiteTemplatePageProps } from '../../../types'
import { Layout } from '../components/Layout'
import { ArtHeader } from '../components/ArtHeader'

import { ArticleGrid } from '../components/Cards'
export default function BlogPage({ locale = 'zh', basePath }: SiteTemplatePageProps) {
  return <Layout locale={locale} basePath={basePath}><ArtHeader locale={locale} kind="blog" /><section className="md-section"><ArticleGrid locale={locale} basePath={basePath} /></section></Layout>
}
