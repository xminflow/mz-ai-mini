import type { SiteTemplatePageProps } from '../../../types'
import { Layout } from '../components/Layout'
import { ArtHeader } from '../components/ArtHeader'
import { ContactSection } from '../components/Forms'
import { Packages, Showreel } from '../components/Interactions'
import { SectionHead } from '../components/primitives'
import { media } from '../utils'
const team = [
  ['Jonas Meyer', '策略负责人', 'Strategy lead', 'zpWUReiAzwreDCjjRiNMPs6ux4.jpg'],
  ['Margaret Reed', '设计总监', 'Design director', 'kjENcO1QhcFAPwfyN0A0pakDkwI.jpg'],
  ['David Gibson', '技术负责人', 'Technical lead', 'J6SSGhVtYBQFGXm25vgQllcpM.jpg'],
  ['Maya Singh', '内容与艺术指导', 'Content & art direction', 'hBHG9t3usKiAromQc5nclWftbZw.jpg'],
  ['Kate Wilington', '客户经理', 'Clients manager', 'F3t96ozC3GZuPhKwdm5VWtBIZwM.png'],
]
export default function AgencyPage({ locale = 'zh', basePath }: SiteTemplatePageProps) {
  const zh = locale === 'zh'
  return <Layout locale={locale} basePath={basePath}><ArtHeader locale={locale} kind="agency" /><section className="md-section md-agency-intro"><div className="md-agency-image"><img src={media('gWj7VLKfar7KRz4lXdJXfgpU.jpg')} alt={zh ? '创意工作室空间' : 'Creative studio space'} /></div><div><span className="md-mono">[01]</span><h2>{zh ? '让清晰取代噪音' : 'Clarity over noise'}</h2><p>{zh ? '从策略到上线，我们规划、设计并构建完整体验。将定位、内容与模块化界面连接起来，让网站快速、易用，也便于持续编辑。' : 'From strategy to launch, we plan, design and build end to end — aligning positioning, content and modular UI into websites that are fast, accessible and easy to edit.'}</p><p>{zh ? '我们的工作方式：系统优先，责任明确，快速而有秩序。' : 'Our DNA: clarity over noise, systems over one-offs, speed with accountability.'}</p><div className="md-stats"><div><strong>+34%</strong><p>{zh ? '转化提升 · 演示' : 'Conversion · Demo'}</p></div><div><strong>+41%</strong><p>{zh ? '注册增长 · 演示' : 'Sign-ups · Demo'}</p></div></div></div></section><section className="md-section"><SectionHead title={zh ? '荣誉与认可' : 'Awards & recognition'} number="02" /><p className="md-fine">{zh ? '以下为参考站展示的示例荣誉，非真实获奖声明。' : 'Reference-inspired sample awards. These are not claims of actual recognition.'}</p><div className="md-awards">{[['2025', 'Awwwards — Site of the Day', 'Lementa'], ['2025', 'CSS Design Awards — Gold', 'Lementa'], ['2024', 'Webby Awards — Visual Design', 'Orbit Labs'], ['2024', 'European Design Awards — Branding', 'Finch Systems'], ['2023', 'ADC*E — Digital Experiences', 'Nova AI'], ['2022', 'Red Dot — Brand & Communication', 'Global Tech']].map(([year, title, client]) => <div key={title}><span>{year}</span><h3>{title}</h3><span>{client}</span></div>)}</div></section><section className="md-section"><SectionHead title={zh ? '认识团队' : 'Our team'} number="03" /><div className="md-team">{team.map(([name, cn, en, photo]) => <article key={name}><img src={media(photo)} alt={zh ? name + ' 演示肖像' : name + ', illustrative portrait'} loading="lazy" /><h3>{name}</h3><p>{zh ? cn : en}</p></article>)}</div></section><Showreel locale={locale} /><Packages locale={locale} basePath={basePath} /><ContactSection locale={locale} basePath={basePath} /></Layout>
}
