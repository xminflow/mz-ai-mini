'use client'
import { motion, useReducedMotion } from 'framer-motion'
import { media } from '../utils'
import type { Locale } from '../content/ui'
const images = ['eo6206gxqn0TWBaWpGevapYsXAI.jpg', 'ExjgNuLGxJLw4fc3cmd8US8PYiM.jpg', 'eNhJYsLQJq7KsLDSp9OgbaPdsp0.jpg', 'Gp71a55WWD0asrAvP4akufH6S4c.jpg', 'D7nAiPVvIx7l3PtKlUP6qIMuU6I.jpg', 'QfMwTUitCfmObBe5s8PRyprbIGA.jpg']
export function ArtHeader({ locale, kind }: { locale: Locale; kind: 'agency' | 'blog' }) {
  const reduced = useReducedMotion(), agency = kind === 'agency', zh = locale === 'zh'
  return <section className={'md-art-header md-art-' + kind}><p className="md-mono">{agency ? (zh ? '欢迎来到我们的创意机构' : 'Welcome to our creative agency') : (zh ? '思考下一种可能' : 'Notes from the creative frontier')}</p><h1>{agency ? (zh ? '小团队 大想法' : 'About agency') : (zh ? '灵感与思考' : 'Insights & ideas')}</h1><div className="md-orbit" aria-hidden>{Array.from({ length: agency ? 32 : 16 }, (_, i) => <motion.div key={i} className="md-orbit-image" style={{ left: Number((i * (agency ? 3.6 : 7) - 8).toFixed(3)) + '%', top: Number((agency ? 72 - i * 2 + Math.sin(i / 3) * 8 : 22 + Math.sin(i / 2.8) * 18).toFixed(3)) + '%', rotateZ: i * 8 }} animate={reduced ? undefined : { y: [0, -12, 0] }} transition={{ duration: 5 + i % 3, repeat: Infinity, delay: i / 10 }}><img src={media(images[i % images.length])} alt="" /></motion.div>)}</div><div className="md-art-wordmark" aria-hidden>{agency ? (zh ? <>创意<br />机构</> : <>About<br />agency</>) : (zh ? '设计洞察' : 'Blog')}</div></section>
}

