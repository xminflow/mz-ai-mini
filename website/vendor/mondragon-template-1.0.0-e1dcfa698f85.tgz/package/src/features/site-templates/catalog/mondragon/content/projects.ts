export const projects = [
  {
    "slug": "lementa",
    "title": {
      "zh": "勒门塔",
      "en": "Lementa"
    },
    "tags": [
      "website",
      "branding"
    ],
    "description": {
      "zh": "为时装品牌重建定位、视觉语言与电商体验。统一摄影、文案与商品说明，以清晰叙事和顺畅结算连接品牌与用户。",
      "en": "Lementa’s brand was rebuilt end to end: clearer positioning, a modular visual identity, and a streamlined e-commerce UX with faster pages and AA accessibility. Unified content (photo, copy, size/fit notes) and optimized checkout drive conversion and repeat purchase — cleaner story, smoother shopping, better results."
    },
    "images": [
      "/templates/mondragon/media/QfMwTUitCfmObBe5s8PRyprbIGA.jpg",
      "/templates/mondragon/media/rMxu5iAYNRxQ1r8b5IySNElXTk.jpg",
      "/templates/mondragon/media/OdMgdnwoOCUcWfAzwdlIGJCcmA.jpg",
      "/templates/mondragon/media/g3xEDH9Dk4iVtr2FaRoS61hvpc.jpg",
      "/templates/mondragon/media/NXJYiczoNdXKmBLkeZCBbjDEntA.jpg",
      "/templates/mondragon/media/0vD30g8QzeEKbSchPMbLmif3Qw.jpg"
    ]
  },
  {
    "slug": "adamant-inc",
    "title": {
      "zh": "坚石科技",
      "en": "Adamant Inc."
    },
    "tags": [
      "website",
      "content",
      "mobile"
    ],
    "description": {
      "zh": "以模块化页面、清晰产品说明和一致视觉系统，为科技品牌建立可信赖的数字门户。",
      "en": "Adamant — a futuristic fashion brand website built on a clean modular grid with cinematic visuals and ultra-fast performance. We paired a minimal identity with editorial layouts, 3D accents, and AA accessibility. Result: a crisp product story, seamless shopping, and launch-ready growth tools."
    },
    "images": [
      "/templates/mondragon/media/UGBN9061P8kDpqhRJ5lkRh7Jc.jpg",
      "/templates/mondragon/media/k7maiaqXXk9JAdkw2WAvPdebQDo.jpg",
      "/templates/mondragon/media/Z6U76LHjaMF2Lmvqt6nKTddwFg.jpg",
      "/templates/mondragon/media/3bSgXFvKkLexXeRTxnHHUxxqI.jpg"
    ]
  },
  {
    "slug": "white-gate-hotel",
    "title": {
      "zh": "白门酒店",
      "en": "White Gate Hotel"
    },
    "tags": [
      "website",
      "content",
      "mobile"
    ],
    "description": {
      "zh": "面向未来的酒店体验。可适应的灯光、安静的空间与融入建筑的家具，配合数字礼宾与尊重隐私的移动入住流程。",
      "en": "White Gate Hotel is a quiet gateway to the near future. Rooms reconfigure on demand, with adaptive lighting, acoustic zoning, and furniture that folds into the architecture. An AI concierge handles everything from check-in to local planning, while a privacy-first app keys doors and syncs preferences across stays. The building is energy-positive, full of biophilic materials and greywater loops, and its lobby doubles as a flexible work and cultural hub for the city."
    },
    "images": [
      "/templates/mondragon/media/sGS84bWyltfeRQTkd9e954KItjQ.jpg",
      "/templates/mondragon/media/Gp71a55WWD0asrAvP4akufH6S4c.jpg",
      "/templates/mondragon/media/osHrhq0hShOvK1eVbiVWhiyiSs.jpg",
      "/templates/mondragon/media/L6HdLf8OBad62NCebfeWqOM.jpg",
      "/templates/mondragon/media/7zWkxbNZj8yhapBrCjbFrDhDI.jpg",
      "/templates/mondragon/media/LEplNi2BXNfYxafcYWf5FiQYo.jpg"
    ]
  },
  {
    "slug": "fashionista",
    "title": {
      "zh": "时尚风向",
      "en": "Fashionista"
    },
    "tags": [
      "content",
      "branding",
      "seo"
    ],
    "description": {
      "zh": "用简洁网格、编辑式叙事和鲜明影像呈现当代时装。精简品牌识别与购物路径，让产品故事更清楚。",
      "en": "Fashionista — a contemporary fashion brand website with a clean modular grid, editorial storytelling, and seamless e-commerce. Minimal identity, high-impact imagery, and AA accessibility meet ultra-fast performance. Result: clearer product narrative and smoother conversions."
    },
    "images": [
      "/templates/mondragon/media/eNhJYsLQJq7KsLDSp9OgbaPdsp0.jpg",
      "/templates/mondragon/media/PVvcSHHsMD5UAkMQAGdnMGBZQ.jpg",
      "/templates/mondragon/media/XzVEjuLWzE04pK9W5qteeRjDxw.jpg",
      "/templates/mondragon/media/aEm2Pnr2ouQyut93Gdit3Kx4Fs.jpg",
      "/templates/mondragon/media/kHq1LCY1l156QObuOE9afeYgIA.jpg",
      "/templates/mondragon/media/hJdYzDu3wCqalZNRxJ4sR0dx1E.jpg"
    ]
  },
  {
    "slug": "levi-z55",
    "title": {
      "zh": "Levi Z55",
      "en": "Levi Z55"
    },
    "tags": [
      "website",
      "branding"
    ],
    "description": {
      "zh": "悬浮迷你音响的产品展示。电影感的三维视觉、深色光泽和微动效，让空间音频、电池与磁悬浮技术更易理解。",
      "en": "Levi Z55 — a product site for a levitating mini speaker with cinematic 3D and real-time physics. Clean modular layouts, dark glossy visuals, and micro-motion highlight spatial sound, battery, and magnetic levitation. Ultra-fast, AA accessible, and launch-ready with specs, reviews, and buy flow."
    },
    "images": [
      "/templates/mondragon/media/WxlDypFedA9LMEg4CPLGOIZNTg.jpg",
      "/templates/mondragon/media/2Uov9gTMX8ePZV5i8UWOdGZYwUI.jpg",
      "/templates/mondragon/media/T1DhmZDSQ0hJvD5UnjZ9Jgk1j44.jpg",
      "/templates/mondragon/media/AbnbpDccZbyLSDCwxLliqChPnBA.jpg"
    ]
  },
  {
    "slug": "heaven",
    "title": {
      "zh": "云境",
      "en": "Heaven"
    },
    "tags": [
      "website",
      "content"
    ],
    "description": {
      "zh": "以轻盈视觉和清晰信息层次，建立沉浸的品牌体验与顺畅的内容浏览路径。",
      "en": "Heaven Campaign — a travel campaign site with cinematic aerials, immersive stories, and a frictionless trip planner. Modular editorial layouts, multilingual content, and booking integrations drive discovery to conversion. Ultra-fast, AA accessible, analytics-ready for lift in sign-ups and bookings."
    },
    "images": [
      "/templates/mondragon/media/wXiVH161krzlU6zcdG8uYqhYFC8.jpg",
      "/templates/mondragon/media/9oaex7toyTI4hT5ahJf4AoPTrQs.jpg",
      "/templates/mondragon/media/Kv7OoJSqXnykjPPdbgXGm5tU.jpg",
      "/templates/mondragon/media/ASs99OOeekYYB0aMIiyscvPkOE.jpg"
    ]
  },
  {
    "slug": "holo-agency",
    "title": {
      "zh": "全息创意",
      "en": "Holo Agency"
    },
    "tags": [
      "branding",
      "website"
    ],
    "description": {
      "zh": "创意机构的数字形象，以大胆构图、模块化案例与动态视觉，呈现策略和执行的完整能力。",
      "en": "Digital agency website built for clarity and speed. Modular grid, sharp typography, and subtle motion frame case studies, services, and team. AA accessibility and ultra-fast performance come standard, with CMS, analytics, and lead capture wired in. Result: cleaner story, stronger credibility, and more qualified inquiries."
    },
    "images": [
      "/templates/mondragon/media/7whq9Ero4bQ4H4kiW35aVk2kg1Y.jpg",
      "/templates/mondragon/media/CFNuVET5GopVjsS1A9ZjqY6pCo.jpg",
      "/templates/mondragon/media/zY28UqqhE9p7MNy7uxuJFkmy5wc.jpg",
      "/templates/mondragon/media/LREs9MI6V9WYwBXceUrgrbo54.jpg"
    ]
  },
  {
    "slug": "mellisa-clothings",
    "title": {
      "zh": "梅丽莎服饰",
      "en": "Mellisa Clothings"
    },
    "tags": [
      "branding",
      "content",
      "seo"
    ],
    "description": {
      "zh": "服饰品牌的编辑式展示。聚焦材质、轮廓和真实穿着场景，用一致的内容语言连接系列与日常生活。",
      "en": "Mellisa Clothings — a futuristic fashion brand website for neon-lit apparel. Minimal identity, dark editorial layouts, and glow-accent visuals showcase smart lighting, fits, and care. Ultra-fast, AA accessible, with CMS, lookbook, and shop ready for launch."
    },
    "images": [
      "/templates/mondragon/media/okuuUUPZe16PlJhqxh1ABeOA4YY.jpg",
      "/templates/mondragon/media/k43M4kIHCCyS5nxGnt7WhZYxEs.jpg",
      "/templates/mondragon/media/qfWpBnVvWijMbyn0EARgGyrc.jpg",
      "/templates/mondragon/media/NbAIdSXrSEg6Np8JkGqNtGCHk.jpg"
    ]
  },
  {
    "slug": "alta",
    "title": {
      "zh": "阿尔塔集团",
      "en": "Alta Group"
    },
    "tags": [
      "branding",
      "content"
    ],
    "description": {
      "zh": "以品牌系统连接多元业务。简洁结构与清晰信息层级，让品牌定位、项目与团队故事形成整体。",
      "en": "Alta Group — a creative collective website built on a clean modular grid with bold typography and subtle motion. Case studies, services, and team are presented in editorial layouts with AA accessibility and ultra-fast performance. CMS, analytics, and lead capture are integrated for growth. Result: sharper story, stronger credibility, more qualified inquiries."
    },
    "images": [
      "/templates/mondragon/media/D7nAiPVvIx7l3PtKlUP6qIMuU6I.jpg",
      "/templates/mondragon/media/IL9e4xnhwpKmO1OK9Kg0JatgS2E.jpg",
      "/templates/mondragon/media/tgu9Fmk0feGMLSgddeFi2xY396c.jpg",
      "/templates/mondragon/media/iv4ogWVMYrVYogC2Bf0PW2MiNqs.jpg"
    ]
  },
  {
    "slug": "wizard-from-trappist-1",
    "title": {
      "zh": "TRAPPIST-1 探索者",
      "en": "Wizard from TRAPPIST-1"
    },
    "tags": [
      "website",
      "branding"
    ],
    "description": {
      "zh": "科技品牌的宇宙探索叙事。模块网格、鲜明字体与产品图解共同建立专业可信的数字体验。",
      "en": "A tech company website with a clean modular grid, sharp typography, and cosmic-lean visuals. It pairs product explainers with interactive diagrams, benchmarks, and case studies. Ultra-fast, AA accessible, CMS-driven, and analytics-ready. Result: clearer narrative, stronger credibility, and qualified leads."
    },
    "images": [
      "/templates/mondragon/media/Of7d4ZI8tTYzrpD57lat2MhejM.jpg",
      "/templates/mondragon/media/f5b1T94LbG92vYWOUxmVXniHGQ.jpg",
      "/templates/mondragon/media/S4X516g3gbqjvdkzb31l73ZVVlE.jpg",
      "/templates/mondragon/media/LP1IzMJFWWrCqrdcNedtDItwe8.jpg"
    ]
  }
]
