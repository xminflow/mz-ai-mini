import type { SiteTemplatePageProps } from '../../../types'
import { Layout } from '../components/Layout'
import { ContactForm } from '../components/Forms'
import { PageTitle } from '../components/primitives'
import { media } from '../utils'
import { brand } from '../config/brand'
export default function ContactPage({ locale = 'zh', basePath }: SiteTemplatePageProps) {
  const zh = locale === 'zh'
  return <Layout locale={locale} basePath={basePath}><PageTitle locale={locale} zh="聊聊下一个想法" en="Let’s talk" /><section className="md-section md-contact-page"><div><a className="md-more" href={'/templates/mondragon/brief-' + locale + '.txt'} download>{zh ? '下载项目需求清单（TXT）' : 'Download project brief (TXT)'} ↗</a><p>{zh ? '从初步想法到完整项目，我们一起找到方向。' : 'From first ideas to full projects, we’re here to help shape the direction.'}</p><a className="md-email" href={'mailto:' + brand.email}>{brand.email}</a><div className="md-contact-portrait"><img src={media('F3t96ozC3GZuPhKwdm5VWtBIZwM.png')} alt={zh ? '项目经理 Kate' : 'Kate, project manager'} /><div><span className="md-mono">● {zh ? '项目沟通 · 演示' : 'Project manager · Demo'}</span><h2>Kate Wilington</h2><p>{zh ? '告诉我们你的目标' : 'Tell us about your goals'}</p></div></div><div className="md-offices"><div><h3>{zh ? '英国' : 'United Kingdom'}</h3><p>{brand.address[locale]}</p></div><div><h3>{zh ? '美国' : 'United States'}</h3><p>{zh ? '洛杉矶 · 演示联络点' : 'Los Angeles · Demo contact point'}</p></div></div></div><div className="md-glass md-contact-panel"><h2>{zh ? '开始一个项目' : 'Start a project'}</h2><ContactForm locale={locale} basePath={basePath} full /></div></section></Layout>
}
