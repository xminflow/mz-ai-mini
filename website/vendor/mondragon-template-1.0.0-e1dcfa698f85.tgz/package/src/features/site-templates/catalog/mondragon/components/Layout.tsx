'use client'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { useRef, type ReactNode } from 'react'
import { brand } from '../config/brand'
import { nav, type Locale } from '../content/ui'
import { useMondragonHost } from '../host'
import { href } from '../utils'
import { Newsletter } from './Forms'
import '../tokens.css'
import '../theme.css'

export function Layout({ children, locale = 'zh', basePath }: { children: ReactNode; locale?: Locale; basePath: string }) {
  const host = useMondragonHost(), zh = locale === 'zh', pathname = usePathname(), router = useRouter()
  const menu = useRef<HTMLDialogElement>(null)
  const name = host.brandName?.[locale] || brand.name[locale]
  const logo = host.logo || brand.logo
  function switchLanguage() {
    // 端根路径来自宿主；切换只改变语言段，保留页面、查询与锚点。
    const root = basePath.replace(/\/en$/, '')
    const current = (pathname || '/').slice(basePath.length).replace(/^\//, '')
    const target = href(zh ? root + '/en' : root, current) + window.location.search + window.location.hash
    menu.current?.close()
    router.push(target)
    console.debug('[mondragon:locale]', { from: locale, to: zh ? 'en' : 'zh', page: current })
  }
  const links = (mobile = false) => nav.map(n => <Link key={n.slug} aria-current={pathname?.replace(/\/$/, '') === href(basePath, n.slug).replace(/\/$/, '') ? 'page' : undefined} href={href(basePath, n.slug)} onClick={() => mobile && menu.current?.close()}>{n.label[locale]}<span aria-hidden>↗</span></Link>)
  return <div className="md-root" lang={zh ? 'zh-CN' : 'en'}>
    <a className="md-skip" href="#md-main">{zh ? '跳到正文' : 'Skip to content'}</a>
    <header className="md-header"><Link className="md-brand" href={href(basePath)} aria-label={name}><img src={logo} alt="" width={24} height={30} /><span>{name}</span></Link><nav aria-label={zh ? '主导航' : 'Main navigation'}>{links()}</nav><div className="md-header-actions"><button className="md-locale" onClick={switchLanguage} aria-label={zh ? 'Switch to English' : '切换到中文'}>{zh ? 'EN' : '中文'}</button><button className="md-menu-button" onClick={() => menu.current?.showModal()} aria-label={zh ? '打开菜单' : 'Open menu'}><i /><i /><i /></button></div></header>
    <dialog ref={menu} className="md-menu" onClick={e => { if (e.target === menu.current) menu.current.close() }}><div><button className="md-close" onClick={() => menu.current?.close()} aria-label={zh ? '关闭菜单' : 'Close menu'}>×</button><p className="md-mono">{name} / {zh ? '导航' : 'Navigation'}</p><nav aria-label={zh ? '展开导航' : 'Expanded navigation'}>{links(true)}</nav><button className="md-more" onClick={switchLanguage}>{zh ? 'English ↗' : '中文 ↗'}</button></div></dialog>
    <main id="md-main">{children}</main>
    <footer className="md-footer"><p className="md-mono">{zh ? '让创意成为品牌的力量' : 'Creative clarity. Lasting impact.'}</p><div className="md-footer-wordmark" aria-hidden>{host.brandName ? name : brand.wordmark}</div><div className="md-footer-grid"><Newsletter locale={locale} /><div><h3>{zh ? '开始一个项目' : 'Start a project'}</h3><p>{zh ? '从一句想法开始' : 'It begins with an idea.'}</p><Link className="md-button" href={href(basePath, 'contact')}>{zh ? '联系项目经理' : 'Contact manager'} ↗</Link></div><nav aria-label={zh ? '页脚导航' : 'Footer navigation'}>{links()}</nav></div><div className="md-footer-bottom"><p>{brand.address[locale]}<br /><a href={'mailto:' + brand.email}>{brand.email}</a></p><div><Link href={href(basePath, 'terms')}>{zh ? '使用条款' : 'Terms'}</Link><Link href={href(basePath, 'privacy')}>{zh ? '隐私政策' : 'Privacy policy'}</Link>{host.marketplaceHref && <Link href={host.marketplaceHref}>{host.marketplaceLabel?.[locale]}</Link>}</div><p>© {brand.year} {name}<br />{zh ? '案例、人物与成果均为演示' : 'Illustrative cases, people and results'}</p></div>{host.filing}</footer>
    {host.marketplaceHref && <Link className="md-market" href={host.marketplaceHref} aria-label={host.marketplaceAriaLabel?.[locale]}><img src={host.lightLogo || logo} alt="" width={24} height={24} /><span>{name}</span></Link>}
  </div>
}
