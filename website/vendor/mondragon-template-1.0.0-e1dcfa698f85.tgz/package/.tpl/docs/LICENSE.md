# 权利边界

界面代码为独立实现；参考站 https://mondragon.framer.website/ 的结构、图片、视频、英文文字与第三方品牌权利归原权利人，未确认商业或再分发许可，仅作本地复刻评审。不得公开上架或商业再分发整包。参考站作者标注 Sabo Sugi，设计来源不因独立代码而变更。素材来源与 SHA256 见 ../asset-sources.json。字体 MiSans 与 Poppins 分别按 public/templates/mondragon/fonts 内保存的原许可与来源使用。Next.js、React、framer-motion 等工具链依赖适用其自身许可，与模板素材许可无关。
