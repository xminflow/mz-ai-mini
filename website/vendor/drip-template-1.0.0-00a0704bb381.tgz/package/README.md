# Drip 咖啡品牌手册

独立的 React / Next.js 品牌手册，默认中文，英文位于 `/en`。完整覆盖封面、目录、品牌介绍、标志、色彩、字体、摄影、品牌应用、资源九个锚点章节。桌面侧栏目录，平板双列卡片，手机折叠菜单。下载仅展示，不跳转、不下载。没有后端、数据库或发送服务。

## 运行

Node 24.16.0 与 pnpm 9.15.4；按 package.json 固定版本使用现有工具链。`pnpm install --frozen-lockfile` 后执行 `pnpm dev`，默认地址 `http://127.0.0.1:43312`；按 Ctrl+C 停止。可复制 `.env.example` 为 `.env` 修改端口和绑定地址，不提交私密配置。

## 验证与交付

`pnpm typecheck`、`pnpm lint`、`pnpm test`、`pnpm build`；生产运行 `pnpm start`。构建和依赖安装在本地 Linux 文件系统执行。`pnpm bundle` 输出可消费的固定运行包，不等于源码发布。

品牌改 `config/brand.ts`，文字改 `content.ts`，图片及双语说明改 `media.ts`，视觉改 `tokens.css` / `theme.css`；上述入口位于 `src/features/site-templates/catalog/drip/`。页面负责章节组合，公共组件维护目录、章节标题及图片。宿主可通过 `DripHostProvider` 注入自己的品牌与附加入口。

完整规则、素材来源和验收限制见 `.tpl/docs/`。参考图中的英文属于原始品牌作品，没有宣称已重绘为中文。模板未公开市场上架；图片和标志的商业及再分发许可待核实。源码仓库：https://github.com/weelume/drip-template 。公开源码不等于品牌素材的商业授权。
