'use client'
import { createContext, useContext, type ReactNode } from 'react'
import type { TemplateLocale } from '../../types'
export interface DripHostOptions {
  brandName?: Record<TemplateLocale, string>
  logo?: string
  lightLogo?: string
  marketplaceHref?: string
  marketplaceLabel?: Record<TemplateLocale, string>
  marketplaceAriaLabel?: Record<TemplateLocale, string>
  filing?: ReactNode
}
const Context = createContext<DripHostOptions>({})
/** 通用模块只接受宿主注入，不引用宿主配置、路径和组件。 */
export function DripHostProvider({ children, ...options }: DripHostOptions & { children: ReactNode }) {
  return <Context.Provider value={options}>{children}</Context.Provider>
}
export const useDripHost = () => useContext(Context)
