import type { ReactNode } from 'react'
import type { TemplateLocale } from '../../../types'
import { sections } from '../content'
export function Section({ index, locale, children }: { index: number; locale: TemplateLocale; children: ReactNode }) {
  const section = sections[index]
  const Heading = index === 0 ? 'h1' : 'h2'
  return <section id={section.id} className="dr-section"><header className="dr-heading"><span className="dr-number">{index + 1}</span><div><Heading>{section.heading[locale]}</Heading><p>{section.intro[locale]}</p></div></header><div className="dr-section-body">{children}</div></section>
}
