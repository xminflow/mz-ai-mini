import type { SiteTemplate } from '../../types'
export const dripTemplate: SiteTemplate = { ...{ "gitUrl": "https://github.com/weelume/drip-template",
  "id": "drip",
  "name": "Drip · 咖啡品牌手册",
  "localizedNames": {
    "en": "Drip · Café brand manual"
  },
  "sceneId": "corporate-site",
  "listed": false,
  "tags": [
    "咖啡品牌",
    "品牌规范",
    "中英文",
    "PC / iPad / H5"
  ],
  "summary": "九章节双语品牌手册，包含品牌介绍、标志、色彩、字体、摄影、应用与资源索引。",
  "accentColor": "#3D0202",
  "cover": "/templates/drip/screenshots/desktop-home.webp",
  "screenshots": [
    {
      "src": "/templates/drip/screenshots/desktop-home.webp",
      "alt": "Drip desktop home",
      "device": "desktop",
      "width": 1425,
      "height": 990
    },
    {
      "src": "/templates/drip/screenshots/desktop-colour.webp",
      "alt": "Drip desktop colour",
      "device": "desktop",
      "width": 1425,
      "height": 990
    },
    {
      "src": "/templates/drip/screenshots/desktop-photography.webp",
      "alt": "Drip desktop photography",
      "device": "desktop",
      "width": 1425,
      "height": 990
    },
    {
      "src": "/templates/drip/screenshots/desktop-resources.webp",
      "alt": "Drip desktop resources",
      "device": "desktop",
      "width": 1425,
      "height": 990
    },
    {
      "src": "/templates/drip/screenshots/tablet-home.webp",
      "alt": "Drip tablet home",
      "device": "tablet",
      "width": 819,
      "height": 1159
    },
    {
      "src": "/templates/drip/screenshots/tablet-colour.webp",
      "alt": "Drip tablet colour",
      "device": "tablet",
      "width": 819,
      "height": 1159
    },
    {
      "src": "/templates/drip/screenshots/tablet-photography.webp",
      "alt": "Drip tablet photography",
      "device": "tablet",
      "width": 819,
      "height": 1159
    },
    {
      "src": "/templates/drip/screenshots/tablet-resources.webp",
      "alt": "Drip tablet resources",
      "device": "tablet",
      "width": 819,
      "height": 1159
    },
    {
      "src": "/templates/drip/screenshots/mobile-home.webp",
      "alt": "Drip mobile home",
      "device": "mobile",
      "width": 375,
      "height": 812
    },
    {
      "src": "/templates/drip/screenshots/mobile-colour.webp",
      "alt": "Drip mobile colour",
      "device": "mobile",
      "width": 375,
      "height": 812
    },
    {
      "src": "/templates/drip/screenshots/mobile-photography.webp",
      "alt": "Drip mobile photography",
      "device": "mobile",
      "width": 375,
      "height": 812
    },
    {
      "src": "/templates/drip/screenshots/mobile-resources.webp",
      "alt": "Drip mobile resources",
      "device": "mobile",
      "width": 375,
      "height": 812
    }
  ]
}, surfaces: [{ id: 'site', name: '品牌手册', platform: 'pc', locales: ['zh', 'en'], pages: [{ slug: '', title: '品牌手册', localizedTitles: { en: 'Brand manual' }, load: () => import('./pages/ManualPage') }] }] }
