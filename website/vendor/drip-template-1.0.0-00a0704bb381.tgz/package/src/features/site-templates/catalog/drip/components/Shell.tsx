'use client'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useEffect, useState, type ReactNode } from 'react'
import { motion, useReducedMotion } from 'framer-motion'
import type { TemplateLocale } from '../../../types'
import { brand } from '../config/brand'
import { copy, sections } from '../content'
import { useDripHost } from '../host'
export function Shell({ locale, basePath, children }: { locale: TemplateLocale; basePath: string; children: ReactNode }) {
  const host = useDripHost(), reduced = useReducedMotion(), router = useRouter()
  const [open, setOpen] = useState(false), [active, setActive] = useState('cover')
  const name = host.brandName?.[locale] ?? brand.name[locale]
  const root = (basePath.replace(/\/en\/?$/, '') || '/')
  const languagePath = locale === 'zh' ? root.replace(/\/$/, '') + '/en' : root
  useEffect(() => {
    // 语言改变后章节高度也会改变，等字体就绪再对齐同一锚点。
    let cancelled = false
    void document.fonts.ready.then(() => {
      if (!cancelled && window.location.hash) document.getElementById(window.location.hash.slice(1))?.scrollIntoView({ behavior: 'instant', block: 'start' })
    })
    return () => { cancelled = true }
  }, [locale])
  useEffect(() => {
    // 以可见章节更新目录，保留原生锚点历史及键盘导航。
    const observer = new IntersectionObserver(entries => { for (const entry of entries) if (entry.isIntersecting) setActive(entry.target.id) }, { rootMargin: '-12% 0px -65% 0px' })
    sections.forEach(section => { const node = document.getElementById(section.id); if (node) observer.observe(node) })
    return () => observer.disconnect()
  }, [])
  useEffect(() => {
    if (!open) return
    const close = (event: KeyboardEvent) => { if (event.key === 'Escape') { setOpen(false); document.getElementById('dr-menu-toggle')?.focus() } }
    document.addEventListener('keydown', close)
    return () => document.removeEventListener('keydown', close)
  }, [open])
  return <div className="drip" lang={locale === 'zh' ? 'zh-CN' : 'en'}>
    <a className="dr-skip" href="#dr-main">{locale === 'zh' ? '跳至正文' : 'Skip to content'}</a>
    <aside className="dr-sidebar"><Link href={basePath || '/'} className="dr-brand" aria-label={name}><img src={host.logo ?? brand.logo} alt={name}/>{host.brandName && <span>{name}</span>}</Link><div className="dr-kicker">{copy.guidelines[locale]}</div>
      <div className="dr-controls"><Link href={languagePath} hrefLang={locale === 'zh' ? 'en' : 'zh'} onClick={event => { event.preventDefault(); router.push(languagePath + window.location.search + window.location.hash); setOpen(false) }}>{locale === 'zh' ? 'EN' : '中文'}</Link><button id="dr-menu-toggle" className="dr-menu-toggle" type="button" aria-controls="dr-index" aria-expanded={open} aria-label={open ? copy.close[locale] : copy.menu[locale]} onClick={() => setOpen(!open)}>{open ? '−' : '+'} {copy.index[locale]}</button></div>
      <nav id="dr-index" aria-label={copy.index[locale]} className={open ? 'is-open' : ''}><div className="dr-kicker">{copy.index[locale]}</div>{sections.map((section, index) => <a key={section.id} href={`#${section.id}`} aria-current={active === section.id ? 'location' : undefined} onClick={() => setOpen(false)}><span>{index + 1}</span>{section.title[locale]}</a>)}</nav>
    </aside>
    <motion.main id="dr-main" className="dr-main" initial={reduced ? false : { opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .45 }}>{children}<footer className="dr-footer"><a href={`mailto:${brand.email}`}>{brand.email}</a><span>© {brand.year} {name}. {copy.rights[locale]}.</span>{host.filing}</footer></motion.main>
    {host.marketplaceHref && <Link className="dr-market" href={host.marketplaceHref} aria-label={host.marketplaceAriaLabel?.[locale]}>{host.lightLogo && <img src={host.lightLogo} alt=""/>}<span>{name}</span></Link>}
  </div>
}
