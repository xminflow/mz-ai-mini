export const brand = {
  name: { zh: 'Drip', en: 'Drip' },
  email: 'brand@drip.example',
  year: 2026,
  updated: { zh: '2026 年 6 月', en: 'June 2026' },
  logo: '/templates/drip/logo.svg',
} as const
