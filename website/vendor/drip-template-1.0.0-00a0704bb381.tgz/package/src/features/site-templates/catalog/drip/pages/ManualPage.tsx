'use client'
import type { CSSProperties } from 'react'
import type { SiteTemplatePageProps, TemplateLocale } from '../../../types'
import { brand } from '../config/brand'
import { copy, gradients, palette, sections } from '../content'
import { Figure } from '../components/Figure'
import { Section } from '../components/Section'
import { Shell } from '../components/Shell'
import '../theme.css'
function Note({ locale, items }: { locale: TemplateLocale; items: readonly Record<TemplateLocale, string>[] }) {
  return <div className="dr-note"><span className="dr-kicker">{copy.rules[locale]}</span><div>{items.map((item, index) => <p key={index}>{item[locale]}</p>)}</div></div>
}
export default function ManualPage({ locale = 'zh', basePath }: SiteTemplatePageProps) {
  return <Shell locale={locale} basePath={basePath}>
    <Figure name="cover" locale={locale} className="dr-cover"/>
    <Section index={0} locale={locale}><Figure name="cup" locale={locale} className="dr-cup"/><p className="dr-updated">{copy.updated[locale]}: {brand.updated[locale]}</p></Section>
    <Section index={1} locale={locale}><div className="dr-contents">{sections.slice(2).map((section, index) => <a href={`#${section.id}`} key={section.id}><span>{index + 3}</span><span>{section.title[locale]}</span></a>)}</div><Figure name="contents" locale={locale}/></Section>
    <Section index={2} locale={locale}><div className="dr-mission"><span className="dr-kicker">{copy.missionLabel[locale]}</span><h3>{copy.mission[locale]}</h3></div><div className="dr-mission-notes">{copy.missionNotes.map((note, index) => <p key={index}>{note[locale]}</p>)}</div></Section>
    <Section index={3} locale={locale}><Figure name="logo" locale={locale}/><div className="dr-logo-sizes"><div><img src={brand.logo} alt="Drip"/><span>{copy.medium[locale]}</span></div><div><img src={brand.logo} alt="Drip"/><span>{copy.small[locale]}</span></div></div><p className="dr-kicker">{copy.alternative[locale]}</p><Figure name="lockup" locale={locale}/><Note locale={locale} items={copy.logoRules}/></Section>
    <Section index={4} locale={locale}><div className="dr-subheading"><span>5.1</span><h3>{copy.colourTitle[locale]}</h3><p>{copy.colourIntro[locale]}</p></div><div className="dr-palette">{palette.map(colour => <article key={colour.hex} className="dr-colour-card" style={{ '--swatch': colour.hex, '--swatch-ink': colour.hex === '#3D0202' ? '#fff' : '#1c1414' } as CSSProperties}><h4>{colour.name[locale]}</h4><dl>{[['HEX', colour.hex], ['RGB', colour.rgb], ['CMYK', colour.cmyk], ['HSL', colour.hsl], ['Pantone', colour.pantone]].map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl></article>)}</div>
      <div className="dr-subheading"><span>5.2</span><h3>{copy.gradients[locale]}</h3><p>{copy.gradientIntro[locale]}</p></div><div className="dr-gradients">{gradients.map(gradient => <article key={gradient.from} style={{ '--from': `rgb(${gradient.from})`, '--to': `rgb(${gradient.to})` } as CSSProperties}><div className="dr-gradient"/><h4>{gradient.name[locale]}</h4><p>RGB {gradient.from} → RGB {gradient.to}</p></article>)}</div>
      <div className="dr-subheading"><span>5.3</span><h3>{copy.gradientUse[locale]}</h3><p>{copy.gradientUseIntro[locale]}</p></div><div className="dr-two"><Figure name="sunrise" locale={locale}/><Figure name="espresso" locale={locale}/></div>
      <div className="dr-subheading"><span>5.4</span><h3>{copy.proportion[locale]}</h3><p>{copy.proportionIntro[locale]}</p></div><div className="dr-proportion" aria-label={copy.proportion[locale]}><span>{copy.base[locale]}</span><span/><span/><span>{copy.accents[locale]}</span></div><div className="dr-note"><span className="dr-kicker">{copy.space[locale]}</span><p>{copy.spaceNote[locale]}</p></div></Section>
    <Section index={5} locale={locale}><div className="dr-typefaces"><article><span className="dr-kicker">{copy.primary[locale]}</span><strong>{locale === 'zh' ? '字里有温度' : 'Poppins'}</strong></article><article><span className="dr-kicker">{copy.secondary[locale]}</span><strong>Poppins</strong></article></div><Note locale={locale} items={copy.typeRules}/><div className="dr-type-scale"><span className="dr-kicker">{copy.typeScale[locale]}</span><span className="dr-kicker">{copy.caption[locale]}</span><h3>{copy.headline[locale]}</h3><h4>{copy.sectionTitle[locale]}</h4><p>{copy.body[locale]}</p></div></Section>
    <Section index={6} locale={locale}><div className="dr-two"><Figure name="coldBrew" locale={locale}/><Figure name="layers" locale={locale}/></div><Figure name="texture" locale={locale} className="dr-texture"/></Section>
    <Section index={7} locale={locale}><div className="dr-two dr-application"><Figure name="cap" locale={locale}/><Figure name="cover" locale={locale}/></div><Figure name="poster" locale={locale} className="dr-poster"/><div className="dr-two dr-application"><Figure name="sunrise" locale={locale}/><Figure name="blue" locale={locale}/><Figure name="takeaway" locale={locale}/><Figure name="window" locale={locale}/></div></Section>
    <Section index={8} locale={locale}><div className="dr-resources">{copy.resourceNames.map((name, index) => <article key={index}><div><h3>{name[locale]}</h3><p>drip-logo-master — {index === 2 ? 'PDF' : 'ZIP / SVG / PNG'}</p></div><button type="button" aria-describedby="dr-download-note">{index === 2 ? copy.downloadPdf[locale] : copy.downloadZip[locale]}</button></article>)}</div><p className="dr-resource-note" id="dr-download-note">{copy.resourceNote[locale]}</p><a className="dr-back" href="#cover">{copy.back[locale]}</a></Section>
  </Shell>
}
