import type { TemplateLocale } from '../../../types'
import { media } from '../media'
export function Figure({ name, locale, className = '' }: { name: keyof typeof media; locale: TemplateLocale; className?: string }) {
  const image = media[name]
  return <figure className={`dr-figure ${className}`}><img src={`/templates/drip/${image.file}`} alt={image.caption[locale]} width={image.width} height={image.height} loading={name === 'cover' ? 'eager' : 'lazy'} decoding="async"/><figcaption>{image.caption[locale]}</figcaption></figure>
}
