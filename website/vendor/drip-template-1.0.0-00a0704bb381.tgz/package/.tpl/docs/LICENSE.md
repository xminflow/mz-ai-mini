# 权利边界

本项目为独立实现的品牌手册演示。参考站为 https://minimal-monstera-959750.framer.app/ 。图片和标志的原始权利属于各权利人，目前没有核实商业使用或公开再分发许可；不得将本实现或公开 Git 地址视为素材商业授权。保持 listed=false 与 redistributionAllowed=false。MiSans 和 Poppins 见运行素材中的许可来源文档；工具许可不替代品牌素材许可。
