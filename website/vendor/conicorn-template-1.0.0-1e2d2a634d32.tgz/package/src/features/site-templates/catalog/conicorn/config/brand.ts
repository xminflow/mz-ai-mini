export const brand = {
  name: { zh: 'Conicorn', en: 'Conicorn' },
  logo: '/templates/conicorn/brand.svg',
  lightLogo: '/templates/conicorn/brand-light.svg',
  copyrightYear: 2026,
}
