# 许可

模板源码、品牌、参考图片与截图没有统一的公开再分发授权。本工程保持 restricted、listed=false、redistributionAllowed=false；公开发布、市场上架或商业分发前应取得相应权利人许可。图片来源说明在 public/templates/deformo/sources.json 和 source-pages.json，保留原始权利声明。

本地 Poppins 遵循字体目录中的 OFL；MiSans 遵循小米字体许可说明，不视为 OFL。其他依赖遵循自身许可证。市场截图是模板渲染结果，不自动获得所含素材的再分发权。

仅 .tpl/tools 协议工具按该目录 LICENSE 的 MIT 许可，该许可不延伸到模板源码、品牌、图片和字体。
