import { brand } from '../config/brand'
import type { Copy } from '../data'

export const aboutBandContent = {
  aboutBrand: [`关于${brand.name}`, `About ${brand.name}`],
  independentThinkersOneSharedAmbition: ["有主张的团队\n有温度的创造", "Independent thinkers\nOne shared ambition"],
  differentBackgroundsInDesignTechnologyAndBusiness: ["我们汇聚设计、技术与商业的不同视角，把复杂的问题变成值得使用、值得记住的数字体验。", "Different backgrounds in design, technology, and business. A shared commitment to making digital experiences that are useful and memorable."],
  projectsDelivered: ["项目交付", "Projects delivered"],
  creativeSpecialists: ["跨领域伙伴", "Creative specialists"],
  clientGrowth: ["业务成长", "Client growth"],
  yourVisionRealized: ["让愿景成为现实", "Your vision, realized"],
  illustrativeTemplateDataNotAStatementOf: [`以上为模板演示数据，不代表${brand.name}实际经营业绩`, `Illustrative template data; not a statement of ${brand.name} business results.`],
} satisfies Record<string, Copy>

export const homeStats = [
  { value: '85', suffix: '+', label: aboutBandContent.projectsDelivered },
  { value: '25', suffix: '+', label: aboutBandContent.creativeSpecialists },
  { value: '1.47', suffix: '×', label: aboutBandContent.clientGrowth },
]
