import type { Copy } from '../data'

export const contactCTAContent = {
  getInTouch: ["开启对话", "Get in touch"],
  letSMakeSomethingWorthPuttingOut: ["一起创造\n值得骄傲的作品", "Let’s make something\nworth putting out there"],
  bringABriefAQuestionOrThe: ["从一个想法开始，让策略、设计与技术共同推动它发生。我们期待听见你的下一步。", "Bring a brief, a question, or the beginning of an idea. We would love to hear what you are thinking about."],
  startAProject: ["开始一个项目", "Start a project"],
  exploreOurWork: ["看看我们的作品", "Explore our work"],
} satisfies Record<string, Copy>
