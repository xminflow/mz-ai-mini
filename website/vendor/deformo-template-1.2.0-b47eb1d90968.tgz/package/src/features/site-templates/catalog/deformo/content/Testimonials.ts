import type { Copy } from '../data'

export const testimonialsContent = {
  clientStories: ["伙伴的声音", "Client stories"],
  goodPeopleGreatCollaborations: ["好的合作\n让想法走得更远", "Good people\nGreat collaborations"],
  illustrativeTestimonial: ["概念案例评价", "Illustrative testimonial"],
  previousTestimonial: ["上一条评价", "Previous testimonial"],
  previous: ["上一条", "Previous"],
  nextTestimonial: ["下一条评价", "Next testimonial"],
  next: ["下一条", "Next"],
} satisfies Record<string, Copy>
