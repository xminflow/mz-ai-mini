import type { SiteTemplatePageProps } from '../../../types'
import { ProjectView } from '../components/ProjectView'
import '../theme.css'
import { projects } from '../data'

const project = projects.find(item => item.slug === 'growthview')
if (!project) throw new Error('[deformo] Missing project: growthview')

export default function GrowthViewPage(props: SiteTemplatePageProps) {
  return <ProjectView {...props} project={project!} />
}

