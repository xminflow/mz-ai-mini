import type { Copy } from '../data'

export const contactViewContent = {
  startAProject: ["开始一个项目", "Start a project"],
  haveADefinedBriefOrJustAn: ["已经有完整需求，或只有一个模糊的想法？让我们一起找到起点。", "Have a defined brief or just an idea? Let’s find a useful starting point together."],
  partnerships: ["伙伴合作", "Partnerships"],
  designersStudiosAndTechnologistsThereMayBe: ["设计师、独立工作室与技术伙伴，欢迎探索一起创造的可能。", "Designers, studios, and technologists: there may be something worth making together."],
  pressMedia: ["媒体交流", "Press & media"],
  questionsAboutOurApproachIdeasOrWork: ["关于我们的工作方法、设计理念与作品，欢迎开启对话。", "Questions about our approach, ideas, or work? We are happy to share more."],
  generalInquiries: ["其他问题", "General inquiries"],
  notSureWhereToStartTellUs: ["还不确定从哪里开始？告诉我们你关心的问题。", "Not sure where to start? Tell us what you are thinking about."],
  contact: ["联系我们", "Contact"],
  oneConversationCouldStartSomethingGood: ["好的合作\n从一次对话开始", "One conversation\nCould start something good"],
  aProjectACollaborationOrAnIdea: ["一个项目、一段合作，或一个值得探索的想法。我们期待听见你的声音。", "A project, a collaboration, or an idea worth exploring. We would love to hear what is on your mind."],
  aCreativePartnerDiscussingAnIdea: ["创意伙伴正在交流工作想法", "A creative partner discussing an idea"],
  continueToTheForm: ["通过下方表单交流", "Continue to the form"],
  contactForm: ["分享你的想法", "Contact form"],
  aFirstStepForYourNextIdea: ["让一个想法\n迈出第一步", "A first step\nFor your next idea"],
  startWithAClearGoalExploreThe: ["用清晰的目标开启协作。你可以在这里体验完整的表单填写与校验流程。", "Start with a clear goal. Explore the complete form and validation experience here."],
  exploreOurWork: ["探索我们的作品", "Explore our work"],
} satisfies Record<string, Copy>

export const contacts: { title: Copy; description: Copy; symbol: string }[] = [
  { title: contactViewContent.startAProject, description: contactViewContent.haveADefinedBriefOrJustAn, symbol: '✎' },
  { title: contactViewContent.partnerships, description: contactViewContent.designersStudiosAndTechnologistsThereMayBe, symbol: '↔' },
  { title: contactViewContent.pressMedia, description: contactViewContent.questionsAboutOurApproachIdeasOrWork, symbol: '◈' },
  { title: contactViewContent.generalInquiries, description: contactViewContent.notSureWhereToStartTellUs, symbol: '↗' },
]
