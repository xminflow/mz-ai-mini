import { brand } from '../config/brand'
import type { Copy } from '../data'

export const demoLabelContent = {
  conceptCaseStudiesNotActualBrandClient: [`模板概念案例，非${brand.name}真实客户背书`, `Concept case studies; not actual ${brand.name} client endorsements.`],
} satisfies Record<string, Copy>
