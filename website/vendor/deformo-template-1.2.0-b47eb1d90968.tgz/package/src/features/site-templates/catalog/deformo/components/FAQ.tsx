'use client'

import { faqContent as content } from '../content/FAQ'

import { useCopy } from './locale'
import { Accordion } from './Accordion'
import { faqs } from '../data'

export function FAQ() {
  const { copy } = useCopy()
  return <div>
    <Accordion className="dm-faq" items={faqs.map(item => ({ id: item.question[1], title: copy(item.question), content: copy(item.answer) }))} />
    <p className="dm-demo-note">{copy(content.scopeAndTimelinesAreAgreedTogetherFor)}</p>
  </div>
}
