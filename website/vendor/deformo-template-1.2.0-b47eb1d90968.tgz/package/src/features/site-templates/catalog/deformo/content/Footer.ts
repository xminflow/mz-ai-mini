import { brand } from '../config/brand'
import type { Copy } from '../data'

export const footerContent = {
  brand: [`${brand.name}`, `${brand.name}`],
  aNewPerspectiveForYourNextChapter: ["让每一个好想法\n拥有独特的表达", "A new perspective\nfor your next chapter"],
  footerNavigation: ["页脚导航", "Footer navigation"],
  aConsideredNoteOnDesignIdeasAnd: ["订阅设计来信，获得新的灵感与思考", "A considered note on design, ideas, and what comes next."],
  yourEmailAddress: ["你的邮箱地址", "Your email address"],
  subscribe: ["订阅", "Subscribe"],
  iHaveReadAndAgreeToThe: ["我已阅读并同意", "I have read and agree to the "],
  termsOfService: ["服务条款", "Terms of Service"],
  and: ["与", " and "],
  privacyPolicy: ["隐私政策", "Privacy Policy"],
  demoOnlyLocalValidationNoDataIs: ["演示订阅仅在本地校验，不发送或保存数据", "Demo only: local validation; no data is sent or stored."],
  validatedLocallyThisDemoHasNotSent: ["校验通过。这是演示订阅，尚未发送或保存。", "Validated locally. This demo has not sent or stored your subscription."],
  brandAllRightsReserved: [`${brand.name} · 保留所有权利`, `${brand.name} · All rights reserved`],
  brandTemplateMarketplace: [`${brand.name}：模板市场`, `${brand.name}: Template marketplace`],
  brandHome: [`${brand.name}首页`, `${brand.name} home`],
  terms: ["服务条款", "Terms"],
  privacy: ["隐私政策", "Privacy"],
} satisfies Record<string, Copy>
