import type { Copy } from '../data'

export const policyViewContent = {
  privacyPolicy: ["隐私说明", "Privacy Policy"],
  termsOfService: ["服务条款", "Terms of Service"],
  legal: ["政策与条款", "Legal"],
  templateDemonstrationNoticeUpdatedOctober162026: ["模板演示说明 · 更新于 2026 年 10 月 16 日", "Template demonstration notice · Updated October 16, 2026"],
  onThisPage: ["本页目录", "On this page"],
  policyContents: ["政策目录", "Policy contents"],
  goToContact: ["前往联系页面", "Go to contact"],
} satisfies Record<string, Copy>
