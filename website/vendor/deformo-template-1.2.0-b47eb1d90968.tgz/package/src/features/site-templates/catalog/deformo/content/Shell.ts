import { brand } from '../config/brand'
import type { Copy } from '../data'

export const shellContent = {
  pageScrollbar: ["页面滚动条", "Page scrollbar"],
  brandTemplateMarketplace: [`${brand.name}：模板市场`, `${brand.name}: Template marketplace`],
  brandHome: [`${brand.name}首页`, `${brand.name} home`],
  brandTemplateHome: [`${brand.name}：模板首页`, `${brand.name}: Template home`],
  brand: [`${brand.name}`, `${brand.name}`],
} satisfies Record<string, Copy>
