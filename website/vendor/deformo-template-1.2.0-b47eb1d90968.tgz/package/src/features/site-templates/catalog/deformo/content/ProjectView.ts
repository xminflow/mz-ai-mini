import type { Copy } from '../data'

export const projectViewContent = {
  caseStudy: ["项目案例", "Case study"],
  industry: ["行业", "Industry"],
  timeline: ["项目时间", "Timeline"],
  timeframe: ["周期", "Timeframe"],
  theChallenge: ["项目挑战", "The challenge"],
  findTheQuestionThatMattersMost: ["找到真正值得\n解决的问题", "Find the question\nThat matters most"],
  fromVisualLanguageToEveryBrandTouchpoint: ["从视觉语言到每一个品牌触点", "From visual language to every brand touchpoint"],
  theSolution: ["解决方案", "The solution"],
  aCoherentDirectionAcrossTheWholeExperience: ["让策略与设计\n形成同一个答案", "A coherent direction\nAcross the whole experience"],
  illustrativeClientPerspective: ["伙伴反馈 · 演示", "Illustrative client perspective"],
  keepExploring: ["继续探索", "Keep exploring"],
  moreWorkDifferentPerspectives: ["发现更多作品", "More work, different perspectives"],
} satisfies Record<string, Copy>
