import { brand } from '../config/brand'
import type { Copy } from '../data'

export const navigationContent = {
  mainNavigation: ["主导航", "Main navigation"],
  brandHome: [`${brand.name}首页`, `${brand.name} home`],
  creativeCollective: ["独立创意团队", "Creative Collective"],
  contactUs: ["联系我们", "Contact us"],
  switchToChinese: ["切换到英文", "Switch to Chinese"],
  closeMenu: ["关闭菜单", "Close menu"],
  openMenu: ["打开菜单", "Open menu"],
  menu: ["菜单", "Menu"],
} satisfies Record<string, Copy>
