'use client'

import { brand } from '../config/brand'

import { heroContent as content } from '../content/Hero'

import { Reveal } from '../../../shared/Reveal'
import { useCopy } from './locale'
import { Button } from './UI'

export function Hero({ basePath }: { basePath: string }) {
  const { copy } = useCopy()
  return <section className="dm-hero dm-gradient">
    <div className="dm-hero-center">
      <Reveal>
        <p className="dm-hero-eyebrow">{brand.name}® — {copy(content.eyebrow)}</p>
        <h1>{copy(content.title)}</h1>
      </Reveal>
    </div>
    <div className="dm-hero-bottom dm-container">
      <p>{copy(content.description)}</p>
      <Button href={`${basePath}/contact`}>{copy(content.action)}</Button>
      <span className="dm-hero-scroll" aria-hidden="true">{copy(content.scrollHint)} ↓</span>
    </div>
  </section>
}
