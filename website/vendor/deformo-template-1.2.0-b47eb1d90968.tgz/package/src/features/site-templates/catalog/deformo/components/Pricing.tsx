'use client'

import { pricingContent as content, pricingPlans } from '../content/Pricing'

import { Reveal } from '../../../shared/Reveal'
import { useCopy } from './locale'
import { Button, Label, SectionTitle } from './UI'

export function Pricing({ basePath }: { basePath: string }) {
  const { copy } = useCopy()
  return <section className="dm-section dm-container" id="pricing">
    <SectionTitle number="07" label={content.waysToWorkTogether} title={content.clearExpectationsAConsideredInvestment} description={content.aFocusedProjectOrAContinuingDesign} />
    <div className="dm-pricing-grid">{pricingPlans.map((plan, index) => <Reveal key={plan.id} delay={index * .08}>
      <article className={`dm-price-card dm-glass${plan.featured ? ' dm-price-featured' : ''}`}>{plan.featured && <span className="dm-popular">{copy(content.designPartnership)} ↗</span>}
        <Label>{copy(plan.label)}</Label>
        <div className="dm-price">{plan.price}{plan.suffix && <span>{plan.suffix}</span>}</div>
        <p>{copy(plan.cadence)}</p>
        <span className="dm-price-status">
          <i />{copy(plan.status)}
        </span>
        <h3>{copy(plan.title)}</h3>
        <p>{copy(plan.description)}</p>
        <Button href={`${basePath}/contact?plan=${plan.id}`}>{copy(plan.action)}</Button>
      </article>
    </Reveal>)}</div>
  </section>
}
