import type { Copy } from '../data'

export const contactFormContent = {
  websiteDesign: ["网站设计", "Website Design"],
  productDesign: ["产品设计", "Product Design"],
  development: ["开发实现", "Development"],
  branding: ["品牌塑造", "Branding"],
  partnership: ["伙伴合作", "Partnership"],
  pressMedia: ["媒体交流", "Press & Media"],
  other: ["其他", "Other"],
  tellUsWhatYouHaveInMind: ["告诉我们你的想法", "Tell us what you have in mind"],
  aQuestionABriefOrTheBeginning: ["从一个问题，或一个尚未成形的灵感开始。", "A question, a brief, or the beginning of something new."],
  name: ["姓名", "Name"],
  yourName: ["你的姓名", "Your name"],
  email: ["邮箱", "Email"],
  yourEmailAddress: ["你的邮箱地址", "Your email address"],
  subject: ["你想聊聊", "Subject"],
  selectASubject: ["请选择项目类型", "Select a subject"],
  yourMessage: ["项目介绍", "Your message"],
  tellUsAboutYourGoalsIdeasAnd: ["简单介绍你的目标、想法与时间计划（至少 10 个字符）", "Tell us about your goals, ideas, and timeline (at least 10 characters)"],
  demoFormBrowserValidationOnlyYourInformation: ["演示表单：仅在浏览器本地校验，不发送、不保存你的信息。", "Demo form: browser validation only. Your information is not sent or stored."],
  validateRequest: ["校验并预览提交", "Validate request"],
  validationPassedThisIsADemoYour: ["校验通过。此为演示表单，你的消息尚未发送或保存。", "Validation passed. This is a demo: your message has not been sent or stored."],
} satisfies Record<string, Copy>

export const subjects: Copy[] = [contactFormContent.websiteDesign, contactFormContent.productDesign, contactFormContent.development, contactFormContent.branding, contactFormContent.partnership, contactFormContent.pressMedia, contactFormContent.other]
