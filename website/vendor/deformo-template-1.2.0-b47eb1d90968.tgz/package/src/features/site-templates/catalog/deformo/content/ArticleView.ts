import { brand } from '../config/brand'
import type { Copy } from '../data'

export const articleViewContent = {
  brandJournal: [`${brand.name}编辑部`, `${brand.name} Journal`],
  designDigitalExperience: ["设计与数字体验", "Design & Digital Experience"],
  onThisPage: ["文章目录", "On this page"],
  tableOfContents: ["文章目录", "Table of contents"],
  backToTheJournal: ["返回全部文章", "Back to the journal"],
  thankYouForReading: ["感谢阅读", "Thank you for reading"],
  shareYourPerspective: ["一起聊聊你的想法", "Share your perspective"],
  keepReading: ["继续阅读", "Keep reading"],
  moreIdeasToExplore: ["更多思考与灵感", "More ideas to explore"],
} satisfies Record<string, Copy>
