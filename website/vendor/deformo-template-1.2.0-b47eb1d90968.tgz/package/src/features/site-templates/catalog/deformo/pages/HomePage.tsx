import type { SiteTemplatePageProps } from '../../../types'
import { HomeView } from '../components/HomeView'
import '../theme.css'

export default function HomePage(props: SiteTemplatePageProps) {
  return <HomeView {...props} />
}

