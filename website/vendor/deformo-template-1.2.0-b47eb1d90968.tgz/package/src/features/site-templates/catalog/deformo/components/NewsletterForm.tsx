'use client'

import { useState } from 'react'
import Link from 'next/link'
import { footerContent as content } from '../content/Footer'
import { useCopy } from './locale'

export function NewsletterForm({ basePath }: { basePath: string }) {
  const { copy } = useCopy()
  const [submitted, setSubmitted] = useState(false)
  return <form className="dm-newsletter" onSubmit={event => { event.preventDefault(); setSubmitted(true); console.debug('[deformo] newsletter validation passed; demo only, no request sent') }}>
    <label htmlFor="dm-newsletter-email">{copy(content.aConsideredNoteOnDesignIdeasAnd)}</label>
    <div className="dm-newsletter-input">
      <input id="dm-newsletter-email" name="newsletter-email" type="email" autoComplete="email" required placeholder={copy(content.yourEmailAddress)} />
      <button type="submit">{copy(content.subscribe)}</button>
    </div>
    <label className="dm-consent">
      <input type="checkbox" required name="newsletter-consent" />
      <span>{copy(content.iHaveReadAndAgreeToThe)}
        <Link href={`${basePath}/legal/terms-of-service`}>{copy(content.termsOfService)}</Link>{copy(content.and)}
        <Link href={`${basePath}/legal/privacy-policy`}>{copy(content.privacyPolicy)}</Link>
      </span>
    </label>
    <p className="dm-demo-note">{copy(content.demoOnlyLocalValidationNoDataIs)}</p>{submitted && <p role="status">{copy(content.validatedLocallyThisDemoHasNotSent)}</p>}
  </form>
}
