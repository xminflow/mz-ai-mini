import type { SiteTemplatePageProps } from '../../../types'
import { ArticleView } from '../components/ArticleView'
import '../theme.css'
import { articles } from '../data'

const article = articles[1]

export default function AccessibilityAdvantagePage(props: SiteTemplatePageProps) {
  return <ArticleView {...props} article={article} />
}

