'use client'

import { contactFormContent as content, subjects } from '../content/ContactForm'

import { useState } from 'react'
import { useCopy } from './locale'
import { Button } from './UI'

export function ContactForm() {
  const { copy } = useCopy()
  const [submitted, setSubmitted] = useState(false)

  return <form className="dm-contact-form dm-glass" id="contact-form" onSubmit={event => { event.preventDefault(); setSubmitted(true); console.debug('[deformo] contact form validation passed; demo only, no request sent') }} onInput={() => { if (submitted) setSubmitted(false) }}>
    <h3>{copy(content.tellUsWhatYouHaveInMind)}</h3>
    <p>{copy(content.aQuestionABriefOrTheBeginning)}</p>
    <div className="dm-field-grid">
      <label htmlFor="dm-name">{copy(content.name)}
        <input id="dm-name" name="name" autoComplete="name" required maxLength={100} placeholder={copy(content.yourName)} />
      </label>
      <label htmlFor="dm-email">{copy(content.email)}
        <input id="dm-email" name="email" type="email" autoComplete="email" required maxLength={254} placeholder={copy(content.yourEmailAddress)} />
      </label>
    </div>
    <label htmlFor="dm-subject">{copy(content.subject)}
      <select id="dm-subject" name="subject" required defaultValue="">
        <option value="" disabled>{copy(content.selectASubject)}</option>{subjects.map(subject => <option value={subject[1]} key={subject[1]}>{copy(subject)}</option>)}
      </select>
    </label>
    <label htmlFor="dm-message">{copy(content.yourMessage)}
      <textarea id="dm-message" name="message" required minLength={10} maxLength={5000} rows={5} placeholder={copy(content.tellUsAboutYourGoalsIdeasAnd)} />
    </label>
    <p className="dm-demo-note">{copy(content.demoFormBrowserValidationOnlyYourInformation)}</p>
    <Button type="submit">{copy(content.validateRequest)}</Button>{submitted && <p className="dm-form-status" role="status">{copy(content.validationPassedThisIsADemoYour)}</p>}
  </form>
}
