'use client'

import { blogViewContent as content } from '../content/BlogView'

import type { SiteTemplatePageProps } from '../../../types'
import { PageHeader } from './UI'
import { Shell } from './Shell'
import { ArticleGrid } from './ArticleGrid'

export function BlogContent({ basePath }: { basePath: string }) {
  return <>
    <PageHeader label={content.theJournal} title={content.freshPerspectivesOnAChangingDigitalWorld} description={content.observationsOnDesignTechnologyAndDigitalExperiences} />
    <section className="dm-container dm-list-section">
      <ArticleGrid basePath={basePath} />
    </section>
  </>
}

export function BlogView(props: SiteTemplatePageProps) {
  return <Shell {...props}>
    <BlogContent basePath={props.basePath} />
  </Shell>
}
