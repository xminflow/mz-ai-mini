import type { Copy } from '../data'

export const projectsViewContent = {
  ourWork: ["精选作品", "Our work"],
  workWithAPointOfViewMade: ["不止于预期\n让想法成为作品", "Work with a point of view\nMade to stand apart"],
  everyBriefBringsADifferentQuestionExplore: ["每一个项目都有自己的问题，也值得拥有自己的答案。探索我们如何让策略与创意共同发生。", "Every brief brings a different question. Explore how strategy and creative thinking come together in our work."],
} satisfies Record<string, Copy>
