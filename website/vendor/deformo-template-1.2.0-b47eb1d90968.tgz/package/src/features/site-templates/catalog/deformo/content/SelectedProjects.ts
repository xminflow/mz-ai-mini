import type { Copy } from '../data'

export const selectedProjectsContent = {
  selectedProjects: ["精选作品", "Selected projects"],
  ideasMadeTangibleOurSelectedWork: ["好的想法\n在这里发生", "Ideas made tangible\nOur selected work"],
} satisfies Record<string, Copy>
