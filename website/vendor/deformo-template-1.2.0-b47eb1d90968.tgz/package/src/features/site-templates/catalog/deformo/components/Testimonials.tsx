'use client'

import { testimonialsContent as content } from '../content/Testimonials'

import { AnimatePresence } from 'framer-motion'
import { motion } from 'framer-motion'
import { useState } from 'react'
import { useCopy } from './locale'
import { SectionTitle } from './UI'
import { projects } from '../data'

export function Testimonials() {
  const { copy } = useCopy()
  const [active, setActive] = useState(0)
  const index = projects.length ? active % projects.length : 0
  const item = projects[index]
  if (!item) return null
  return <section className="dm-section dm-testimonials">
    <div className="dm-container">
      <SectionTitle number="06" label={content.clientStories} title={content.goodPeopleGreatCollaborations} />
      <div className="dm-testimonial-grid">
        <div className="dm-testimonial-brands">{projects.map((project, index) => <button key={project.slug} type="button" aria-pressed={active % projects.length === index} onClick={() => setActive(index)}>{project.name}</button>)}</div>
        <div className="dm-quote-wrap">
          <AnimatePresence mode="wait" initial={false}>
            <motion.figure className="dm-quote" key={index} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }}>
              <span className="dm-quote-mark" aria-hidden="true">“</span>
              <blockquote>{copy(item.quote)}</blockquote>
              <figcaption>
                <span>— {item.founder}</span>
                <span>{item.name} · {copy(content.illustrativeTestimonial)}</span>
              </figcaption>
            </motion.figure>
          </AnimatePresence>
          <div className="dm-carousel-controls">
            <button type="button" disabled={projects.length < 2} aria-label={copy(content.previousTestimonial)} onClick={() => setActive(current => (current % projects.length + projects.length - 1) % projects.length)}>{copy(content.previous)}</button>
            <span>{String(index + 1).padStart(2, '0')} / {String(projects.length).padStart(2, '0')}</span>
            <button type="button" disabled={projects.length < 2} aria-label={copy(content.nextTestimonial)} onClick={() => setActive(current => (current + 1) % projects.length)}>{copy(content.next)}</button>
          </div>
        </div>
      </div>
    </div>
  </section>
}
