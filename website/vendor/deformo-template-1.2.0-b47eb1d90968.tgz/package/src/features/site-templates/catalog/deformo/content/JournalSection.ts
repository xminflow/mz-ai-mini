import type { Copy } from '../data'

export const journalSectionContent = {
  fromTheJournal: ["设计洞察", "From the journal"],
  ideasWorthSharing: ["把思考分享出来", "Ideas worth sharing"],
} satisfies Record<string, Copy>
