'use client'

import { createContext, useContext } from 'react'
import type { TemplateLocale } from '../../../types'
import { text, type Copy } from '../data'

export const LocaleContext = createContext<TemplateLocale>('zh')
export function useCopy() {
  const locale = useContext(LocaleContext)
  return { locale, t: (zh: string, en: string) => locale === 'en' ? en : zh, copy: (value: Copy) => text(value, locale) }
}
