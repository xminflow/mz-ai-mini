import type { Copy } from '../data'

export const introContent = {
  curiosityIntentionAndCraft: ["保持好奇，认真创造", "Curiosity, intention, and craft"],
  curiousMindsConsideredIdeasCarefullyCraftedDigital: ["我们以好奇心看待每个问题\n用策略找到方向\n再以设计与技术，让想法发生", "Curious minds. Considered ideas.\nCarefully crafted digital work\nthat makes a lasting impression."],
  everyBrandHasAStoryWeHelp: ["每个品牌都有自己的故事。我们帮助它找到独特而清晰的表达。", "Every brand has a story. We help it find a clear and distinctive expression."],
} satisfies Record<string, Copy>
