import type { Copy } from '../data'

export const processSectionContent = {
  ourProcess: ["合作流程", "Our process"],
  fromTheFirstConversationToTheNext: ["从初次对话\n到共同创造", "From the first conversation\nTo the next chapter"],
} satisfies Record<string, Copy>
