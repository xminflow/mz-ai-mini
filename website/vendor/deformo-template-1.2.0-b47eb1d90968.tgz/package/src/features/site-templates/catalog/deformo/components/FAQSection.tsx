'use client'

import { fAQSectionContent as content } from '../content/FAQSection'

import { useCopy } from './locale'
import { Button, SectionTitle } from './UI'
import { FAQ } from './FAQ'

export function FAQSection({ basePath }: { basePath: string }) {
  const { copy } = useCopy()
  return <section className="dm-section dm-faq-section">
    <div className="dm-container">
      <SectionTitle number="09" label={content.frequentlyAskedQuestions} title={content.aFewThingsYouMightBeWondering} />
      <div className="dm-faq-grid">
        <div>
          <p>{copy(content.aLittleMoreAboutHowWeWork)}</p>
          <Button href={`${basePath}/contact`}>{copy(content.getInTouch)}</Button>
        </div>
        <FAQ />
      </div>
    </div>
  </section>
}
