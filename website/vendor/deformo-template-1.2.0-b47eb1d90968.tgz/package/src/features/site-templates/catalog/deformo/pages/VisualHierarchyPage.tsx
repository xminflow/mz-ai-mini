import type { SiteTemplatePageProps } from '../../../types'
import { ArticleView } from '../components/ArticleView'
import '../theme.css'
import { articles } from '../data'

const article = articles[0]

export default function VisualHierarchyPage(props: SiteTemplatePageProps) {
  return <ArticleView {...props} article={article} />
}

