import type { Copy } from '../data'

export const pricingContent = {
  waysToWorkTogether: ["合作方式", "Ways to work together"],
  clearExpectationsAConsideredInvestment: ["清晰的合作\n透明的投入", "Clear expectations\nA considered investment"],
  aFocusedProjectOrAContinuingDesign: ["一次聚焦的项目，或一段长期的设计伙伴关系。选择适合你当前阶段的方式。", "A focused project or a continuing design partnership. Choose the arrangement that fits your next step."],
  projectEngagement: ["按项目合作", "Project engagement"],
  perProjectIllustrativePricing: ["每个项目 · 演示报价", "Per project · illustrative pricing"],
  aConsideredResponseWithin48Hours: ["48 小时内响应需求", "A considered response within 48 hours"],
  focusedScopeThoughtfulDelivery: ["明确范围，专注交付", "Focused scope. Thoughtful delivery."],
  aDefinedScopeAndASharedTimeline: ["围绕一个清晰的目标，制定完整方案和交付计划。适合品牌升级、网站重构或新产品设计。", "A defined scope and a shared timeline for a brand refresh, a new website, or a focused product challenge."],
  discussAProject: ["聊聊你的项目", "Discuss a project"],
  designPartnership: ["长期伙伴", "Design partnership"],
  monthlyRetainer: ["按月合作", "Monthly retainer"],
  perMonthIllustrativePricing: ["每月 · 演示报价", "Per month · illustrative pricing"],
  aFlexibleContinuingCollaboration: ["灵活协作，持续推进", "A flexible, continuing collaboration"],
  aCreativeTeamByYourSide: ["和你的团队，一起向前", "A creative team by your side."],
  ongoingStrategyDesignAndDevelopmentSupportWith: ["持续获得策略、设计与开发支持。每月约 80 小时协作，范围与退出安排在实际合作前确认。", "Ongoing strategy, design, and development support, with an illustrative allocation of 80 hours per month. Terms are agreed before work begins."],
  exploreAPartnership: ["成为设计伙伴", "Explore a partnership"],
} satisfies Record<string, Copy>

export const pricingPlans = [
  { id: 'project', price: '$2,999', suffix: '+', featured: false, label: pricingContent.projectEngagement, cadence: pricingContent.perProjectIllustrativePricing, status: pricingContent.aConsideredResponseWithin48Hours, title: pricingContent.focusedScopeThoughtfulDelivery, description: pricingContent.aDefinedScopeAndASharedTimeline, action: pricingContent.discussAProject },
  { id: 'retainer', price: '$3,999', suffix: '', featured: true, label: pricingContent.monthlyRetainer, cadence: pricingContent.perMonthIllustrativePricing, status: pricingContent.aFlexibleContinuingCollaboration, title: pricingContent.aCreativeTeamByYourSide, description: pricingContent.ongoingStrategyDesignAndDevelopmentSupportWith, action: pricingContent.exploreAPartnership },
]
