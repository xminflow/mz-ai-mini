'use client'

import { policyViewContent as content } from '../content/PolicyView'

import Link from 'next/link'
import type { SiteTemplatePageProps } from '../../../types'
import { useCopy } from './locale'
import { Button, PageHeader } from './UI'
import { Shell } from './Shell'
import { type Copy } from '../data'
import { privacySections, termsSections } from '../content/legal'
export function PolicyContent({ basePath, kind }: { basePath: string; kind: 'privacy' | 'terms' }) {
  const { copy } = useCopy()
  const sections = kind === 'privacy' ? privacySections : termsSections
  const title: Copy = kind === 'privacy' ? content.privacyPolicy : content.termsOfService
  return <>
    <PageHeader centered label={content.legal} title={title} description={content.templateDemonstrationNoticeUpdatedOctober162026} />
    <div className="dm-container dm-policy-layout">
      <aside className="dm-toc">
        <p>{copy(content.onThisPage)}</p>
        <nav aria-label={copy(content.policyContents)}>{sections.map((section, index) => <Link key={section.title[1]} href={`#policy-${index + 1}`}>{copy(section.title)}</Link>)}</nav>
      </aside>
      <article className="dm-article-body">{sections.map((section, index) => <section id={`policy-${index + 1}`} key={section.title[1]}>
        <h2>{copy(section.title)}</h2>
        <p>{copy(section.body)}</p>
      </section>)}
        <Button href={`${basePath}/contact`}>{copy(content.goToContact)}</Button>
      </article>
    </div>
  </>
}

export function PolicyView(props: SiteTemplatePageProps & { kind: 'privacy' | 'terms' }) {
  return <Shell {...props}>
    <PolicyContent basePath={props.basePath} kind={props.kind} />
  </Shell>
}
