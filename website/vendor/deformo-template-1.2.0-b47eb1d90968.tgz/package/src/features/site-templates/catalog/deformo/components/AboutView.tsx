'use client'

import { aboutViewContent as content, principles, results } from '../content/AboutView'

import type { SiteTemplatePageProps } from '../../../types'
import { Reveal } from '../../../shared/Reveal'
import { useCopy } from './locale'
import { SectionTitle, PageHeader } from './UI'
import { Shell } from './Shell'
import { ProcessGrid } from './ProcessGrid'
import { photo, team } from '../data'

export function AboutContent() {
  const { t, copy } = useCopy()

  return <>
    <PageHeader centered label={content.aboutUs} title={content.independentMindsASharedCreativePurpose} description={content.weBringDesignStrategyAndTechnologyInto} />
    <div className="dm-container">
      <Reveal>
        <img className="dm-about-hero" src={photo('cxS3pdE2Am67jSPeaOJc4e6co.jpg')} width={1600} height={850} alt={copy(content.aCreativeCollectiveSharingAMomentTogether)} />
      </Reveal>
    </div>
    <section className="dm-section dm-container">
      <SectionTitle number="01" label={content.ourMission} title={content.makeThoughtfulDesignPartOfYourNext} />
      <div className="dm-editorial-grid">
        <div className="dm-mission-photos">
          <img src={photo('jGzOq8fxh4jGaf56T2sfiOPSZVA.jpg')} width={420} height={600} loading="lazy" alt={copy(content.anInformalCreativeConversation)} />
          <img src={photo('1kUPZCYcWQqsz0vRDou8EdaonwM.jpg')} width={420} height={600} loading="lazy" alt={copy(content.aCollaboratorAtWork)} />
        </div>
        <Reveal className="dm-editorial-copy">
          <p className="dm-lead">{copy(content.goodDesignBeginsWithTakingTheQuestion)}</p>
          <p>{copy(content.ambitiousTeamsDeserveAClearAndConfident)}</p>
          <p>{copy(content.strategyDesignAndEngineeringContributeTogetherFrom)}</p>
        </Reveal>
      </div>
    </section>
    <section className="dm-section dm-about-band">
      <div className="dm-container">
        <SectionTitle number="02" label={content.ourResults} title={content.careInTheProcessClarityInThe} />
        <div className="dm-results-grid">{results.map(item => <Reveal key={item.value}>
          <strong>{item.value}</strong>
          <p>{copy(item.label)}</p>
        </Reveal>)}</div>
        <p className="dm-demo-note">{copy(content.illustrativeDataForTheTemplateLayoutAnd)}</p>
      </div>
    </section>
    <section className="dm-section dm-container">
      <SectionTitle number="03" label={content.ourPhilosophy} title={content.threePrinciplesThatGuideUs} />
      <div className="dm-principles">{principles.map(item => <Reveal key={item.name[1]}>
        <article className="dm-glass">
          <span className="dm-principle-icon" aria-hidden="true">{item.symbol}</span>
          <h3>{copy(item.name)}</h3>
          <p>{copy(item.description)}</p>
        </article>
      </Reveal>)}</div>
    </section>
    <section className="dm-section dm-container">
      <SectionTitle number="04" label={content.theApproach} title={content.strategicThinkingRoomForTheUnexpected} />
      <ProcessGrid />
      <div className="dm-evolve dm-glass">
        <span aria-hidden="true">↻</span>
        <div>
          <h3>{copy(content.keepEvolving)}</h3>
          <p>{copy(content.deliveryIsOneMilestoneRealFeedbackAnd)}</p>
        </div>
      </div>
    </section>
    <section className="dm-section dm-team-section">
      <div className="dm-container">
        <SectionTitle number="05" label={content.theTeam} title={content.differentPerspectivesBetterWorkTogether} description={content.aCollectiveOfCreativeRolesTheProfiles} />
        <div className="dm-team-grid">{team.map(member => <Reveal key={member.name}>
          <article className="dm-team-card dm-glass">
            <img src={photo(member.image)} alt={t(`${member.name} 演示团队头像`, `${member.name}, illustrative team portrait`)} width={400} height={400} loading="lazy" />
            <div>
              <h3>{member.name}</h3>
              <p>{copy(member.role)}</p>
            </div>
            <span aria-hidden="true">↗</span>
          </article>
        </Reveal>)}</div>
      </div>
    </section>

  </>
}

export function AboutView(props: SiteTemplatePageProps) {
  return <Shell {...props}>
    <AboutContent />
  </Shell>
}
