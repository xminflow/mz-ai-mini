'use client'

import { aboutBandContent as content, homeStats } from '../content/AboutBand'

import { Reveal } from '../../../shared/Reveal'
import { useCopy } from './locale'
import { SectionTitle } from './UI'

export function AboutBand() {
  const { copy } = useCopy()
  return <section className="dm-section dm-about-band">
    <div className="dm-container">
      <SectionTitle number="02" label={content.aboutBrand} title={content.independentThinkersOneSharedAmbition} description={content.differentBackgroundsInDesignTechnologyAndBusiness} />
      <Reveal className="dm-stats">{homeStats.map(item => <div key={item.label[1]}>
        <strong>{item.value}
          <span>{item.suffix}</span>
        </strong>
        <h3>{copy(item.label)}</h3>
      </div>)}
        <div className="dm-stat-vision">
          <strong aria-hidden="true">✳</strong>
          <h3>{copy(content.yourVisionRealized)}</h3>
        </div>
      </Reveal>
      <p className="dm-demo-note">{copy(content.illustrativeTemplateDataNotAStatementOf)}</p>
    </div>
  </section>
}
