import type { Copy } from '../data'

export const heroContent = {
  eyebrow: ["独立创意团队", "INDEPENDENT CREATIVE COLLECTIVE"],
  title: ["用不一样的想法\n创造不一样的可能", "A different perspective\nA distinctive presence"],
  description: ["连接设计、技术与策略\n让好想法成为真正有影响力的作品", "Thoughtful strategy, distinctive design, and\ntechnology that brings your ideas to life."],
  action: ["与我们合作", "Work with us"],
  scrollHint: ["向下探索", "SCROLL TO EXPLORE"],
} satisfies Record<string, Copy>
