'use client'

import { philosophyContent as content } from '../content/Philosophy'

import { Reveal } from '../../../shared/Reveal'
import { useCopy } from './locale'
import { Button, Label } from './UI'

export function Philosophy({ basePath }: { basePath: string }) {
  const { copy } = useCopy()
  return <section className="dm-philosophy dm-gradient">
    <div className="dm-container">
      <Reveal>
        <Label number="04">{copy(content.ourPhilosophy)}</Label>
        <h2>{copy(content.thinkBoldlyStayAdaptableMakeItDistinct)}</h2>
        <p>{copy(content.makeRoomForUnexpectedIdeasGroundThem)}</p>
        <Button href={`${basePath}/about-us`}>{copy(content.getToKnowUs)}</Button>
      </Reveal>
      <span className="dm-philosophy-star" aria-hidden="true">✳</span>
    </div>
  </section>
}
