'use client'

import { useId, useState, type ReactNode } from 'react'
import { AnimatePresence, motion } from 'framer-motion'

interface AccordionItem {
  id: string
  title: ReactNode
  content: ReactNode
  symbol?: ReactNode
}

/** 服务与 FAQ 共享展开行为；样式差异由外部 className 控制。 */
export function Accordion({ items, className = '' }: { items: AccordionItem[]; className?: string }) {
  const id = useId()
  const [active, setActive] = useState<string | null>(items[0]?.id ?? null)
  return <div className={`dm-accordion ${className}`}>
    {items.map((item, index) => {
      const expanded = active === item.id
      const panelId = `${id}-panel-${index}`
      const buttonId = `${id}-button-${index}`
      return <div key={item.id} className={`dm-accordion-item${expanded ? ' dm-active' : ''}`}>
        <h3>
          <button id={buttonId} type="button" aria-expanded={expanded} aria-controls={panelId} onClick={() => setActive(expanded ? null : item.id)}>
            {item.symbol !== undefined && <span className="dm-service-symbol" aria-hidden="true">{item.symbol}</span>}
            <span>{item.title}</span>
            <span className="dm-accordion-plus" aria-hidden="true">{expanded ? '−' : '+'}</span>

          </button>
        </h3>
        <AnimatePresence initial={false}>{expanded && <motion.div id={panelId} aria-labelledby={buttonId} className="dm-accordion-panel" initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}>
          <p>{item.content}</p>
        </motion.div>}</AnimatePresence>

      </div>
    })}
  </div>
}
