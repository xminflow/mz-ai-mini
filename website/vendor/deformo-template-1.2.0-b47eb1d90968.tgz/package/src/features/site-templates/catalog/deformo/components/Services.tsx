'use client'

import { brand } from '../config/brand'

import { servicesContent as content } from '../content/Services'

import { Reveal } from '../../../shared/Reveal'
import { useCopy } from './locale'
import { SectionTitle } from './UI'
import { Accordion } from './Accordion'
import { services } from '../data'

export function Services() {
  const { copy } = useCopy()
  return <section className="dm-section dm-container" id="services">
    <SectionTitle number="01" label={content.services} title={content.complexChallengesConsideredSolutions} />
    <div className="dm-services-grid">
      <Reveal className="dm-service-art dm-glass">
        <span className="dm-art-orbit" aria-hidden="true">✳</span>
        <p>{copy(content.strategyDesignTechnology)}</p>
        <span className="dm-art-caption">{brand.name} — CREATIVE COLLECTIVE</span>
      </Reveal>
      <Accordion items={services.map(service => ({ id: service.title[1], title: copy(service.title), content: copy(service.description), symbol: service.symbol }))} />
    </div>
  </section>
}
