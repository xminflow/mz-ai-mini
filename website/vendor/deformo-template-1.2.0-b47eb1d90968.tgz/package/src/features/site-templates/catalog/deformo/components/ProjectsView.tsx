'use client'

import { projectsViewContent as content } from '../content/ProjectsView'

import type { SiteTemplatePageProps } from '../../../types'
import { PageHeader } from './UI'
import { projects } from '../data'
import { Shell } from './Shell'
import { ProjectCards } from './ProjectCards'
import { DemoLabel } from './DemoLabel'

export function ProjectsContent({ basePath }: { basePath: string }) {
  return <>
    <PageHeader label={content.ourWork} title={content.workWithAPointOfViewMade} description={content.everyBriefBringsADifferentQuestionExplore} />
    <section className="dm-container dm-list-section">
      <ProjectCards basePath={basePath} />
      <p className="dm-demo-note">{projects.map(project => project.name).join(' / ')} · <DemoLabel />
      </p>
    </section>
  </>
}

export function ProjectsView(props: SiteTemplatePageProps) {
  return <Shell {...props}>
    <ProjectsContent basePath={props.basePath} />
  </Shell>
}
