'use client'

import { contactViewContent as content, contacts } from '../content/ContactView'

import Link from 'next/link'
import type { SiteTemplatePageProps } from '../../../types'
import { Reveal } from '../../../shared/Reveal'
import { useCopy } from './locale'
import { Button, Label, PageHeader } from './UI'
import { Shell } from './Shell'
import { ContactForm } from './ContactForm'
import { photo } from '../data'

export function ContactContent({ basePath }: { basePath: string }) {
  const { copy } = useCopy()

  return <>
    <PageHeader label={content.contact} title={content.oneConversationCouldStartSomethingGood} description={content.aProjectACollaborationOrAnIdea} />
    <section className="dm-container">
      <div className="dm-contact-grid">
        <img className="dm-contact-photo" src={photo('JrgoIzVsm1U0hU8FTKbwYwnLuU.jpg')} width={600} height={900} alt={copy(content.aCreativePartnerDiscussingAnIdea)} />{contacts.map(item => <Reveal key={item.title[1]}>
          <article className="dm-contact-card dm-glass">
            <span aria-hidden="true">{item.symbol}</span>
            <h2>{copy(item.title)}</h2>
            <p>{copy(item.description)}</p>
            <Link href="#contact-form">{copy(content.continueToTheForm)}</Link>
          </article>
        </Reveal>)}
      </div>
    </section>
    <section className="dm-section dm-container dm-contact-form-section">
      <Reveal>
        <Label>{copy(content.contactForm)}</Label>
        <h2>{copy(content.aFirstStepForYourNextIdea)}</h2>
        <p>{copy(content.startWithAClearGoalExploreThe)}</p>
        <Button href={`${basePath}/projects`}>{copy(content.exploreOurWork)}</Button>
      </Reveal>
      <ContactForm />
    </section>
  </>
}

export function ContactView(props: SiteTemplatePageProps) {
  return <Shell {...props}>
    <ContactContent basePath={props.basePath} />
  </Shell>
}
