'use client'

import { demoLabelContent as content } from '../content/DemoLabel'

import { useCopy } from './locale'

export function DemoLabel() { const { copy } = useCopy(); return <>{copy(content.conceptCaseStudiesNotActualBrandClient)}</> }
