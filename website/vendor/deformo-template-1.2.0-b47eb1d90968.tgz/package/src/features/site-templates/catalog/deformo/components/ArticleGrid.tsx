'use client'

import { articleGridContent as content } from '../content/ArticleGrid'

import Link from 'next/link'
import { Reveal } from '../../../shared/Reveal'
import { useCopy } from './locale'
import { Label } from './UI'
import { articles, photo } from '../data'

export function ArticleGrid({ basePath, items = articles, showLink = false }: { basePath: string; items?: typeof articles; showLink?: boolean }) {
  const { copy } = useCopy()
  return <div className="dm-blog-layout">
    <aside>
      <p>{copy(content.latestArticlesFreshPerspectives)}</p>{showLink && <Link href={`${basePath}/blog`}>{copy(content.viewAllPosts)}</Link>}
    </aside>
    <div className="dm-blog-grid">{items.map(item => <Reveal key={item.slug}>
      <Link className="dm-blog-card" href={`${basePath}/blog/${item.slug}`}>
        <Label>{copy(item.category)}</Label>
        <h3>{copy(item.title)}</h3>
        <div className="dm-blog-image">
          <img src={photo(item.image)} alt={copy(item.title)} loading="lazy" width={800} height={560} />
        </div>
        <p>{copy(item.summary)}</p>
      </Link>
    </Reveal>)}</div>
  </div>
}
