'use client'

import { useEffect, useRef, useState } from 'react'
import { usePathname } from 'next/navigation'

export function OverlayScrollbar({ label }: { label: string }) {
  const pathname = usePathname()
  const [metrics, setMetrics] = useState({ viewport: 0, maximum: 0, position: 0 })
  const [dragging, setDragging] = useState(false)
  const drag = useRef<{ y: number; position: number } | null>(null)

  useEffect(() => {
    let frame = 0
    const measure = () => {
      cancelAnimationFrame(frame)
      frame = requestAnimationFrame(() => {
        const maximum = Math.max(0, document.documentElement.scrollHeight - window.innerHeight)
        setMetrics({ viewport: window.innerHeight, maximum, position: Math.max(0, Math.min(maximum, window.scrollY)) })
      })
    }
    const observer = new ResizeObserver(measure)
    observer.observe(document.body)
    window.addEventListener('scroll', measure, { passive: true })
    window.addEventListener('resize', measure)
    measure()
    return () => {
      cancelAnimationFrame(frame)
      observer.disconnect()
      window.removeEventListener('scroll', measure)
      window.removeEventListener('resize', measure)
    }
  }, [pathname])

  const height = Math.min(metrics.viewport, Math.max(42, metrics.viewport ** 2 / (metrics.viewport + metrics.maximum || 1)))
  const travel = metrics.viewport - height
  const top = metrics.maximum ? metrics.position / metrics.maximum * travel : 0
  const scrollTo = (position: number) => window.scrollTo({ top: Math.max(0, Math.min(metrics.maximum, position)), behavior: 'instant' })

  return <div className="dm-overlay-scrollbar" role="scrollbar" tabIndex={0} aria-label={label} aria-controls="dm-page" aria-orientation="vertical" aria-valuemin={0} aria-valuemax={Math.round(metrics.maximum)} aria-valuenow={Math.round(metrics.position)} hidden={!metrics.maximum} data-dragging={dragging}
    onPointerDown={event => {
      if (event.button !== 0 || !travel) return
      event.preventDefault()
      const y = event.clientY - event.currentTarget.getBoundingClientRect().top
      const position = y >= top && y <= top + height ? metrics.position : Math.max(0, Math.min(metrics.maximum, (y - height / 2) / travel * metrics.maximum))
      scrollTo(position)
      drag.current = { y: event.clientY, position }
      setDragging(true)
      event.currentTarget.setPointerCapture(event.pointerId)
    }}
    onPointerMove={event => { if (drag.current && travel) scrollTo(drag.current.position + (event.clientY - drag.current.y) / travel * metrics.maximum) }}
    onPointerUp={event => { if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId) }}
    onPointerCancel={() => { drag.current = null; setDragging(false) }}
    onLostPointerCapture={() => { drag.current = null; setDragging(false) }}
    onKeyDown={event => {
      const destinations: Record<string, number> = { ArrowDown: metrics.position + 40, ArrowUp: metrics.position - 40, PageDown: metrics.position + metrics.viewport, PageUp: metrics.position - metrics.viewport, Home: 0, End: metrics.maximum }
      if (event.key in destinations) { event.preventDefault(); scrollTo(destinations[event.key]) }
    }}
  ><span style={{ height, transform: `translateY(${top}px)` }} /></div>
}
