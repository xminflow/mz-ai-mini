'use client'

import { contactCTAContent as content } from '../content/ContactCTA'

import { Reveal } from '../../../shared/Reveal'
import { useCopy } from './locale'
import { Button, Label } from './UI'

export function ContactCTA({ basePath }: { basePath: string }) {
  const { copy } = useCopy()
  return <section className="dm-contact-cta dm-gradient">
    <div className="dm-container">
      <Reveal>
        <Label number="↗">{copy(content.getInTouch)}</Label>
        <h2>{copy(content.letSMakeSomethingWorthPuttingOut)}</h2>
        <p>{copy(content.bringABriefAQuestionOrThe)}</p>
        <div className="dm-actions">
          <Button href={`${basePath}/contact`}>{copy(content.startAProject)}</Button>
          <Button secondary href={`${basePath}/projects`}>{copy(content.exploreOurWork)}</Button>
        </div>
      </Reveal>
      <span className="dm-cta-star" aria-hidden="true">✳</span>
    </div>
  </section>
}
