'use client'

import { createContext, useContext, type ReactNode } from 'react'

interface DeformoHostOptions {
  marketplaceHref?: string
  filing?: ReactNode
}

const HostContext = createContext<DeformoHostOptions>({})

/** 宿主注入自己的市场入口和备案展示，通用页面不依赖宿主实现。 */
export function DeformoHostProvider({ children, ...options }: DeformoHostOptions & { children: ReactNode }) {
  return <HostContext.Provider value={options}>{children}</HostContext.Provider>
}

export function useDeformoHost() {
  return useContext(HostContext)
}
