'use client'

import { projectViewContent as content } from '../content/ProjectView'

import type { SiteTemplatePageProps } from '../../../types'
import { Reveal } from '../../../shared/Reveal'
import { useCopy } from './locale'
import { Label, SectionTitle } from './UI'
import { Shell } from './Shell'
import { ProjectCards } from './ProjectCards'
import { DemoLabel } from './DemoLabel'
import { photo, projects, type Project } from '../data'

export function ProjectContent({ basePath, project }: { basePath: string; project: Project }) {
  const { t, copy } = useCopy()
  return <>
    <header className="dm-case-header dm-container">
      <Label>{project.name} — {copy(content.caseStudy)}</Label>
      <h1>{copy(project.title)}</h1>
      <div className="dm-tags">{project.tags.map(tag => <span key={tag[1]}>{copy(tag)}</span>)}</div>
    </header>
    <div className="dm-container">
      <img className="dm-case-cover" src={photo(project.image)} alt={t(`${project.name} 品牌概念作品`, `${project.name} brand concept`)} width={1600} height={1000} />
      <section className="dm-case-intro">
        <dl>{[{ title: copy(content.industry), value: copy(project.industry) }, { title: copy(content.timeline), value: project.period }, { title: copy(content.timeframe), value: copy(project.duration) }].map(item => <div key={item.title}>
          <dt>{item.title}</dt>
          <dd>{item.value}</dd>
        </div>)}</dl>
        <div>
          <p>{copy(project.introduction)}</p>
          <p className="dm-demo-note">
            <DemoLabel />
          </p>
        </div>
      </section>
      <div className="dm-case-metrics">{project.metrics.map(metric => <Reveal key={metric.value}>
        <strong>{metric.value}</strong>
        <p>{copy(metric.label)}</p>
      </Reveal>)}</div>
      <section className="dm-case-section">
        <Label number="01">{copy(content.theChallenge)}</Label>
        <div>
          <h2>{copy(content.findTheQuestionThatMattersMost)}</h2>
          <p>{copy(project.challenge)}</p>
        </div>
      </section>{project.gallery.length > 0 && <div className="dm-case-gallery">{project.gallery.map((image, index) => <Reveal key={image}>
        <figure>
          <img src={photo(image)} width={1200} height={900} loading="lazy" alt={t(`${project.name} 品牌应用细节 ${index + 1}`, `${project.name} identity application ${index + 1}`)} />
          <figcaption>{copy(content.fromVisualLanguageToEveryBrandTouchpoint)} · 0{index + 1}</figcaption>
        </figure>
      </Reveal>)}</div>}
      <section className="dm-case-section">
        <Label number="02">{copy(content.theSolution)}</Label>
        <div>
          <h2>{copy(content.aCoherentDirectionAcrossTheWholeExperience)}</h2>
          <p>{copy(project.solution)}</p>
        </div>
      </section>
      <Reveal className="dm-case-quote dm-glass">
        <Label>{copy(content.illustrativeClientPerspective)}</Label>
        <blockquote>“{copy(project.quote)}”</blockquote>
        <p>— {project.founder} · {project.name}</p>
      </Reveal>
      <section className="dm-section">
        <SectionTitle label={content.keepExploring} title={content.moreWorkDifferentPerspectives} />
        <ProjectCards basePath={basePath} items={projects.filter(item => item.slug !== project.slug)} />
      </section>
    </div>
  </>
}

export function ProjectView(props: SiteTemplatePageProps & { project: Project }) {
  return <Shell {...props}>
    <ProjectContent basePath={props.basePath} project={props.project} />
  </Shell>
}
