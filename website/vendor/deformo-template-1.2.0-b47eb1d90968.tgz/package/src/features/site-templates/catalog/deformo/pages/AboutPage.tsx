import type { SiteTemplatePageProps } from '../../../types'
import { AboutView } from '../components/AboutView'
import '../theme.css'

export default function AboutPage(props: SiteTemplatePageProps) {
  return <AboutView {...props} />
}

