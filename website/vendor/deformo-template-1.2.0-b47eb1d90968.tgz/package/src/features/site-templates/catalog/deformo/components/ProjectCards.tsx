'use client'

import { projectCardsContent as content } from '../content/ProjectCards'

import Link from 'next/link'
import { Reveal } from '../../../shared/Reveal'
import { useCopy } from './locale'
import { photo, projects, type Project } from '../data'

export function ProjectCards({ basePath, items = projects }: { basePath: string; items?: Project[] }) {
  const { copy, t } = useCopy()
  return <div className="dm-projects">{items.map((project, index) => <Reveal key={project.slug}>
    <Link className="dm-project-card" href={`${basePath}/projects/${project.slug}`}>
      <img src={photo(project.image)} alt={t(`${project.name} 品牌设计作品`, `${project.name} brand design project`)} width={1600} height={1000} loading="lazy" />
      <div className="dm-project-shade" />
      <p className="dm-project-description">{copy(project.description)}</p>
      <div className="dm-project-meta">
        <div>
          <span className="dm-project-index">{String(index + 1).padStart(2, '0')} / {String(items.length).padStart(2, '0')}</span>
          <h3>{project.name}</h3>
          <div className="dm-tags">{project.tags.map(tag => <span key={tag[1]}>{copy(tag)}</span>)}</div>
        </div>
        <span className="dm-project-link">{copy(content.viewCaseStudy)}</span>
      </div>
    </Link>
  </Reveal>)}</div>
}
