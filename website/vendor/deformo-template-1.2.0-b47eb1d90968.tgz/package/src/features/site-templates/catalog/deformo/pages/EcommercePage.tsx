import type { SiteTemplatePageProps } from '../../../types'
import { ArticleView } from '../components/ArticleView'
import '../theme.css'
import { articles } from '../data'

const article = articles[5]

export default function EcommercePage(props: SiteTemplatePageProps) {
  return <ArticleView {...props} article={article} />
}

