'use client'

import { brand } from '../config/brand'

import { navigationContent as content } from '../content/Navigation'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useRouter } from 'next/navigation'
import { AnimatePresence } from 'framer-motion'
import { motion } from 'framer-motion'
import { useState } from 'react'
import { useEffect } from 'react'
import { useSyncExternalStore } from 'react'
import { useCopy } from './locale'
import { navigation } from '../data'
const subscribeScroll = (listener: () => void) => {
  window.addEventListener('scroll', listener, { passive: true })
  return () => window.removeEventListener('scroll', listener)
}
const scrollSnapshot = () => window.scrollY > 64
const serverScrollSnapshot = () => false

export function Navigation({ basePath, home }: { basePath: string; home: boolean }) {
  const { locale, copy } = useCopy()
  const pathname = usePathname() ?? basePath
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const scrolled = useSyncExternalStore(subscribeScroll, scrollSnapshot, serverScrollSnapshot)
  const light = home && !scrolled && !open
  const root = locale === 'en' ? basePath.replace(/\/en$/, '') : basePath
  const tail = pathname.startsWith(basePath) ? pathname.slice(basePath.length) : ''
  const languagePath = `${root}${locale === 'en' ? '' : '/en'}${tail}`
  useEffect(() => {
    const close = (event: KeyboardEvent) => { if (event.key === 'Escape') setOpen(false) }
    window.addEventListener('keydown', close)
    return () => window.removeEventListener('keydown', close)
  }, [])

  return <nav className={`dm-nav${light ? ' dm-nav-light' : ''}`} aria-label={copy(content.mainNavigation)}>
    <div className="dm-nav-bar">
      <Link href={basePath} className="dm-brand" onClick={() => setOpen(false)} aria-label={copy(content.brandHome)}>
        <img src={light ? brand.logo.light : brand.logo.dark} width={24} height={24} alt="" />
        <span>{brand.name}</span>
      </Link>
      <span className="dm-nav-caption">
        <span aria-hidden="true">•</span>{copy(content.creativeCollective)}
      </span>
      <div className="dm-nav-links">{navigation.slice(1, 4).map(item => <Link key={item.slug} href={`${basePath}/${item.slug}`} aria-current={pathname === `${basePath}/${item.slug}` ? 'page' : undefined}>{copy(item.title)}</Link>)}
        <Link className="dm-nav-contact" href={`${basePath}/contact`}>{copy(content.contactUs)}</Link>
      </div>
      <Link className="dm-language" href={languagePath} aria-label={copy(content.switchToChinese)} onClick={event => {
        if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return
        // 在客户端拼接当前查询与锚点，避免服务端读取浏览器状态造成水合差异。
        event.preventDefault()
        setOpen(false)
        router.push(`${languagePath}${window.location.search}${window.location.hash}`, { scroll: false })
      }}>{locale === 'en' ? '中文' : 'EN'}</Link>
      <button type="button" className="dm-menu-toggle" aria-expanded={open} aria-controls="deformo-menu" aria-label={open ? copy(content.closeMenu) : copy(content.openMenu)} onClick={() => setOpen(!open)}>{open ? '−' : '+'}
        <span>{copy(content.menu)}</span>
      </button>

    </div>
    <AnimatePresence>{open && <motion.div id="deformo-menu" className="dm-mobile-menu" initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}>{navigation.map((item, index) => <Link key={item.slug} href={`${basePath}${item.slug ? `/${item.slug}` : ''}`} onClick={() => setOpen(false)}>
      <span>0{index + 1}</span>{copy(item.title)}
    </Link>)}</motion.div>}</AnimatePresence>

  </nav>
}
