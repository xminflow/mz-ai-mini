import { brand } from '../config/brand'
import type { Copy } from '../data'

export const aboutViewContent = {
  bold: ["大胆", "Bold"],
  exploreAConfidentIdeaThenGiveIt: ["用有主张的想法打开新可能，再用扎实的执行让它发生。", "Explore a confident idea, then give it the craft and attention it needs to work."],
  adaptive: ["灵活", "Adaptive"],
  stayResponsiveToChangingNeedsWhileKeeping: ["保持开放，回应真实变化，让设计与业务共同成长。", "Stay responsive to changing needs while keeping the creative direction clear."],
  distinct: ["独特", "Distinct"],
  findThePerspectiveThatBelongsToThe: ["找到品牌独有的理由，让每一次表达都值得被记住。", "Find the perspective that belongs to the brand and give it a recognizable voice."],
  aboutUs: ["关于我们", "About us"],
  independentMindsASharedCreativePurpose: ["保持独立思考\n让创意有自己的方向", "Independent minds\nA shared creative purpose"],
  weBringDesignStrategyAndTechnologyInto: ["我们是一支连接设计、策略与技术的创意团队。相信有温度的协作，能够创造清晰、独特且经得起使用的数字体验。", "We bring design, strategy, and technology into one conversation. Thoughtful collaboration helps us create digital experiences with clarity, character, and purpose."],
  aCreativeCollectiveSharingAMomentTogether: ["创意团队在一起分享工作与生活", "A creative collective sharing a moment together"],
  ourMission: ["我们的使命", "Our mission"],
  makeThoughtfulDesignPartOfYourNext: ["让好的设计\n走进每一个有雄心的品牌", "Make thoughtful design\nPart of your next chapter"],
  anInformalCreativeConversation: ["团队交流中的灵感时刻", "An informal creative conversation"],
  aCollaboratorAtWork: ["专注工作的设计伙伴", "A collaborator at work"],
  goodDesignBeginsWithTakingTheQuestion: ["好的设计，始于认真理解一个问题。", "Good design begins with taking the question seriously."],
  ambitiousTeamsDeserveAClearAndConfident: ["我们相信，每个有想法的团队，都值得拥有清晰而有力量的品牌表达。设计的价值在于帮助人与业务建立真实连接，并让复杂的体验更容易理解。", "Ambitious teams deserve a clear and confident way to present themselves. We see design as a way to connect people to a business and make complicated experiences easier to understand."],
  strategyDesignAndEngineeringContributeTogetherFrom: ["在这里，策略、设计与工程共同参与。从最初的方向探索到最终的上线交付，我们保持直接沟通，让每一步都围绕真正重要的目标。", "Strategy, design, and engineering contribute together. From early exploration to release, we keep the conversation direct and the work connected to the outcomes that matter."],
  ourResults: ["成果与信任", "Our results"],
  careInTheProcessClarityInThe: ["用认真投入\n回应每一份信任", "Care in the process\nClarity in the outcome"],
  returningOrReferringClients: ["再次合作或推荐", "Returning or referring clients"],
  brandAndDigitalProjects: ["品牌与数字项目", "Brand and digital projects"],
  measurableClientValue: ["累计业务价值", "Measurable client value"],
  illustrativeDataForTheTemplateLayoutAnd: ["模板展示数据，仅用于说明版式与内容结构", "Illustrative data for the template layout and content structure."],
  ourPhilosophy: ["我们的理念", "Our philosophy"],
  threePrinciplesThatGuideUs: ["始终坚持的三件事", "Three principles that guide us"],
  theApproach: ["我们的方法", "The approach"],
  strategicThinkingRoomForTheUnexpected: ["理性的判断\n与自由的探索", "Strategic thinking\nRoom for the unexpected"],
  keepEvolving: ["持续进化", "Keep evolving"],
  deliveryIsOneMilestoneRealFeedbackAnd: ["交付不是终点。用真实反馈和持续学习，让作品随着业务不断向前。", "Delivery is one milestone. Real feedback and continued learning help the work evolve with the business."],
  theTeam: ["认识团队", "The team"],
  differentPerspectivesBetterWorkTogether: ["在一起\n让想法更完整", "Different perspectives\nBetter work together"],
  aCollectiveOfCreativeRolesTheProfiles: [`这是一支认真对待每个细节的创意团队。以下人物为模板演示，不代表${brand.name}真实员工。`, `A collective of creative roles. The profiles below are illustrative and do not represent actual ${brand.name} employees.`],
} satisfies Record<string, Copy>

export const principles: { name: Copy; description: Copy; symbol: string }[] = [
  { name: aboutViewContent.bold, description: aboutViewContent.exploreAConfidentIdeaThenGiveIt, symbol: '↗' },
  { name: aboutViewContent.adaptive, description: aboutViewContent.stayResponsiveToChangingNeedsWhileKeeping, symbol: '↔' },
  { name: aboutViewContent.distinct, description: aboutViewContent.findThePerspectiveThatBelongsToThe, symbol: '✳' },
]

export const results = [
  { value: '97%', label: aboutViewContent.returningOrReferringClients },
  { value: '85+', label: aboutViewContent.brandAndDigitalProjects },
  { value: '$10M', label: aboutViewContent.measurableClientValue },
]
