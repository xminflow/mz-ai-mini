'use client'

import { processSectionContent as content } from '../content/ProcessSection'

import { SectionTitle } from './UI'
import { ProcessGrid } from './ProcessGrid'

export function ProcessSection() {
  return <section className="dm-section dm-container" id="process">
    <SectionTitle number="05" label={content.ourProcess} title={content.fromTheFirstConversationToTheNext} />
    <ProcessGrid />
  </section>
}
