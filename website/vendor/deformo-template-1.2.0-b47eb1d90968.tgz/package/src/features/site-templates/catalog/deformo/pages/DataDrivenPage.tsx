import type { SiteTemplatePageProps } from '../../../types'
import { ArticleView } from '../components/ArticleView'
import '../theme.css'
import { articles } from '../data'

const article = articles[7]

export default function DataDrivenPage(props: SiteTemplatePageProps) {
  return <ArticleView {...props} article={article} />
}

