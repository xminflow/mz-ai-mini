import type { Copy } from '../data'

export const blogViewContent = {
  theJournal: ["设计洞察", "The journal"],
  freshPerspectivesOnAChangingDigitalWorld: ["新的视角\n让思考继续发生", "Fresh perspectives\nOn a changing digital world"],
  observationsOnDesignTechnologyAndDigitalExperiences: ["分享关于设计、技术与数字体验的观察。从具体问题出发，让每一篇思考都对下一次创造有所帮助。", "Observations on design, technology, and digital experiences. Practical questions and considered perspectives for the next thing you make."],
} satisfies Record<string, Copy>
