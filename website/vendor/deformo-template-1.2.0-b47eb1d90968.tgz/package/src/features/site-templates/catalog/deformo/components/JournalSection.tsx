'use client'

import { journalSectionContent as content } from '../content/JournalSection'

import { SectionTitle } from './UI'
import { ArticleGrid } from './ArticleGrid'
import { articles } from '../data'

export function JournalSection({ basePath }: { basePath: string }) {
  return <section className="dm-section dm-container">
    <SectionTitle number="08" label={content.fromTheJournal} title={content.ideasWorthSharing} />
    <ArticleGrid basePath={basePath} items={articles.slice(0, 2)} showLink />
  </section>
}
