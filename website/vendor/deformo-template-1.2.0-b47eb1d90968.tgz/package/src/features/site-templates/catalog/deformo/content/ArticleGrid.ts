import type { Copy } from '../data'

export const articleGridContent = {
  latestArticlesFreshPerspectives: ["最新文章\n新的思考", "Latest articles.\nFresh perspectives."],
  viewAllPosts: ["查看全部", "View all posts"],
} satisfies Record<string, Copy>
