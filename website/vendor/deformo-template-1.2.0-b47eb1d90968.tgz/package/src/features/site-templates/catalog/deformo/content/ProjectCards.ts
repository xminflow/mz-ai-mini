import type { Copy } from '../data'

export const projectCardsContent = {
  viewCaseStudy: ["查看项目", "View case study"],
} satisfies Record<string, Copy>
