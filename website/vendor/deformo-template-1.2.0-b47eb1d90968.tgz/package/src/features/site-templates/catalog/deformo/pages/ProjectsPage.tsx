import type { SiteTemplatePageProps } from '../../../types'
import { ProjectsView } from '../components/ProjectsView'
import '../theme.css'

export default function ProjectsPage(props: SiteTemplatePageProps) {
  return <ProjectsView {...props} />
}

