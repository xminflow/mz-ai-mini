'use client'

import { selectedProjectsContent as content } from '../content/SelectedProjects'

import { SectionTitle } from './UI'
import { ProjectCards } from './ProjectCards'

export function SelectedProjects({ basePath }: { basePath: string }) {
  return <section className="dm-section dm-container">
    <SectionTitle number="03" label={content.selectedProjects} title={content.ideasMadeTangibleOurSelectedWork} />
    <ProjectCards basePath={basePath} />
  </section>
}
