'use client'

import { brand } from '../config/brand'

import { shellContent as content } from '../content/Shell'

import Link from 'next/link'
import { MotionConfig } from 'framer-motion'
import { useState } from 'react'
import { useEffect } from 'react'
import type { ReactNode } from 'react'
import type { SiteTemplatePageProps } from '../../../types'
import { useDeformoHost } from '../host'
import { Navigation } from './Navigation'
import { Footer } from './Footer'
import { OverlayScrollbar } from './OverlayScrollbar'
import { ContactCTA } from './ContactCTA'
import { LocaleContext } from './locale'
import { text, type Copy } from '../data'
export function Shell({ basePath, locale = 'zh', children, home = false }: SiteTemplatePageProps & { children: ReactNode; home?: boolean }) {
  const host = useDeformoHost()
  const copy = (value: Copy) => text(value, locale)
  const [scrolling, setScrolling] = useState(false)

  useEffect(() => {
    let hideTimer: number | undefined
    const showScrollbar = () => {
      setScrolling(true)
      if (hideTimer !== undefined) window.clearTimeout(hideTimer)
      hideTimer = window.setTimeout(() => setScrolling(false), 650)
    }

    window.addEventListener('scroll', showScrollbar, { passive: true })
    return () => {
      window.removeEventListener('scroll', showScrollbar)
      if (hideTimer !== undefined) window.clearTimeout(hideTimer)
    }
  }, [])

  return <LocaleContext.Provider value={locale}>
    <MotionConfig reducedMotion="user">
      <div id="dm-page" className="dm-site" data-scroll-state={scrolling ? 'scrolling' : 'idle'}>
        <Navigation basePath={basePath} home={home} />
        <main id="dm-main">{children}
          <ContactCTA basePath={basePath} />
        </main>
        <Footer basePath={basePath} />
        <OverlayScrollbar label={copy(content.pageScrollbar)} />
        <Link className="dm-market-badge" href={host.marketplaceHref ?? basePath} title={host.marketplaceHref ? copy(content.brandTemplateMarketplace) : copy(content.brandHome)} aria-label={copy(content.brandTemplateHome)}>
          <img src={brand.logo.light} alt="" width={24} height={24} />
          <span>{copy(content.brand)}</span>
        </Link>
      </div>
    </MotionConfig>
  </LocaleContext.Provider>
}
