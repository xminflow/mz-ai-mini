import type { SiteTemplatePageProps } from '../../../types'
import { PolicyView } from '../components/PolicyView'
import '../theme.css'

export default function TermsPage(props: SiteTemplatePageProps) {
  return <PolicyView {...props} kind="terms" />
}

