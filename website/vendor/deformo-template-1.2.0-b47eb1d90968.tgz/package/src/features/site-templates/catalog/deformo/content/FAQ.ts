import type { Copy } from '../data'

export const faqContent = {
  scopeAndTimelinesAreAgreedTogetherFor: ["具体项目范围与排期会在沟通后共同确认", "Scope and timelines are agreed together for each engagement."],
} satisfies Record<string, Copy>
