'use client'

import type { SiteTemplatePageProps } from '../../../types'
import { Shell } from './Shell'
import { Services } from './Services'
import { Testimonials } from './Testimonials'
import { Hero } from './Hero'
import { Intro } from './Intro'
import { AboutBand } from './AboutBand'
import { SelectedProjects } from './SelectedProjects'
import { Philosophy } from './Philosophy'
import { ProcessSection } from './ProcessSection'
import { Pricing } from './Pricing'
import { JournalSection } from './JournalSection'
import { FAQSection } from './FAQSection'

export function HomeView(props: SiteTemplatePageProps) {
  return <Shell {...props} home>
    <Hero basePath={props.basePath} />
    <Intro />
    <Services />
    <AboutBand />
    <SelectedProjects basePath={props.basePath} />
    <Philosophy basePath={props.basePath} />
    <ProcessSection />
    <Testimonials />
    <Pricing basePath={props.basePath} />
    <JournalSection basePath={props.basePath} />
    <FAQSection basePath={props.basePath} />

  </Shell>
}
