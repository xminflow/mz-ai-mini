'use client'

import { articleViewContent as content } from '../content/ArticleView'

import Link from 'next/link'
import type { SiteTemplatePageProps } from '../../../types'
import { useCopy } from './locale'
import { Label, SectionTitle } from './UI'
import { Shell } from './Shell'
import { ArticleGrid } from './ArticleGrid'
import { articles, photo, type Article } from '../data'

export function ArticleContent({ basePath, article }: { basePath: string; article: Article }) {
  const { copy, locale } = useCopy()
  return <>
    <header className="dm-article-header dm-container">
      <Label>{copy(article.category)}</Label>
      <h1>{copy(article.title)}</h1>
      <time dateTime={article.date}>{new Intl.DateTimeFormat(locale === 'zh' ? 'zh-CN' : 'en-US', { year: 'numeric', month: 'long', day: 'numeric', timeZone: 'UTC' }).format(new Date(`${article.date}T00:00:00Z`))}</time>
      <p>{copy(article.summary)}</p>
      <div className="dm-author">
        <img src={photo('fYT9n8MmNxAqmnggbq0d9l4.png')} width={44} height={44} alt="" />
        <div>
          <span>{copy(content.brandJournal)}</span>
          <span>{copy(content.designDigitalExperience)}</span>
        </div>
      </div>
    </header>
    <div className="dm-container">
      <img className="dm-article-cover" src={photo(article.image)} width={1600} height={900} alt={copy(article.title)} />
      <div className="dm-article-layout">
        <aside className="dm-toc">
          <p>{copy(content.onThisPage)}</p>
          <nav aria-label={copy(content.tableOfContents)}>{article.sections.map((section, index) => <Link key={section.title[1]} href={`#section-${index + 1}`}>
            <span>0{index + 1}</span>{copy(section.title)}
          </Link>)}</nav>
          <Link className="dm-back-link" href={`${basePath}/blog`}>{copy(content.backToTheJournal)}</Link>
        </aside>
        <article className="dm-article-body">
          <p className="dm-lead">{copy(article.summary)}</p>{article.sections.map((section, index) => <section id={`section-${index + 1}`} key={section.title[1]}>
            <h2>{copy(section.title)}</h2>
            <p>{copy(section.body)}</p>
          </section>)}
          <div className="dm-article-end">
            <span>{copy(content.thankYouForReading)} ✳</span>
            <Link href={`${basePath}/contact`}>{copy(content.shareYourPerspective)}</Link>
          </div>
        </article>
      </div>
      <section className="dm-section">
        <SectionTitle label={content.keepReading} title={content.moreIdeasToExplore} />
        <ArticleGrid basePath={basePath} items={articles.filter(item => item.slug !== article.slug).slice(0, 2)} showLink />
      </section>
    </div>
  </>
}

export function ArticleView(props: SiteTemplatePageProps & { article: Article }) {
  return <Shell {...props}>
    <ArticleContent basePath={props.basePath} article={props.article} />
  </Shell>
}
