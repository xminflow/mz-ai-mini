import type { SiteTemplatePageProps } from '../../../types'
import { ProjectView } from '../components/ProjectView'
import '../theme.css'
import { projects } from '../data'

const project = projects.find(item => item.slug === 'colorado')
if (!project) throw new Error('[deformo] Missing project: colorado')

export default function ColoradoPage(props: SiteTemplatePageProps) {
  return <ProjectView {...props} project={project!} />
}

