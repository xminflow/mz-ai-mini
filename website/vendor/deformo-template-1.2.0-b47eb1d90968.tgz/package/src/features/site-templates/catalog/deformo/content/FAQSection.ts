import type { Copy } from '../data'

export const fAQSectionContent = {
  frequentlyAskedQuestions: ["常见问题", "Frequently asked questions"],
  aFewThingsYouMightBeWondering: ["在开始之前\n你可能想了解", "A few things\nYou might be wondering"],
  aLittleMoreAboutHowWeWork: ["关于合作方式、项目节奏与我们的工作方法，在这里找到答案。还有其他问题，欢迎随时联系。", "A little more about how we work, what to expect, and how to get started. We are happy to discuss anything else."],
  getInTouch: ["联系我们", "Get in touch"],
} satisfies Record<string, Copy>
