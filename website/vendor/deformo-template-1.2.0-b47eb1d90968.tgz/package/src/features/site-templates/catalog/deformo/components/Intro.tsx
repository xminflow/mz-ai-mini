'use client'

import { introContent as content } from '../content/Intro'

import { Reveal } from '../../../shared/Reveal'
import { useCopy } from './locale'
import { Label } from './UI'

export function Intro() {
  const { copy } = useCopy()
  return <section className="dm-intro dm-container">
    <Reveal>
      <Label>{copy(content.curiosityIntentionAndCraft)}</Label>
      <h2>{copy(content.curiousMindsConsideredIdeasCarefullyCraftedDigital)}</h2>
      <p>{copy(content.everyBrandHasAStoryWeHelp)}</p>
    </Reveal>
  </section>
}
