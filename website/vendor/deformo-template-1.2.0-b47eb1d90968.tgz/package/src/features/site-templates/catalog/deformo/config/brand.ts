/** 修改品牌名称与 Logo 的唯一运行时入口；市场展示资料另见 .tpl/template.json。 */
export const brand = {
  name: '微域生光',
  logo: {
    light: '/templates/deformo/logo/deformo-logo-light.svg',
    dark: '/templates/deformo/logo/deformo-logo-dark.svg',
  },
  copyrightYear: '2026',
}
