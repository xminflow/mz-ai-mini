import type { Copy } from '../data'

export const philosophyContent = {
  ourPhilosophy: ["我们的理念", "Our philosophy"],
  thinkBoldlyStayAdaptableMakeItDistinct: ["大胆想象\n灵活思考\n独特表达", "Think boldly.\nStay adaptable.\nMake it distinct."],
  makeRoomForUnexpectedIdeasGroundThem: ["让每一个设计决定都服务真实的目标，在清晰的策略与自由的探索之间，找到品牌独有的答案。", "Make room for unexpected ideas, ground them in a clear strategy, and shape an experience that feels unmistakably yours."],
  getToKnowUs: ["进一步了解我们", "Get to know us"],
} satisfies Record<string, Copy>
