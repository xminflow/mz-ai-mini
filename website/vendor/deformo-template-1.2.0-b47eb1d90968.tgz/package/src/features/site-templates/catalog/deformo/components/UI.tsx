'use client'

import Link from 'next/link'
import type { ComponentPropsWithoutRef, ReactNode } from 'react'
import { Reveal } from '../../../shared/Reveal'
import { useCopy } from './locale'
import { type Copy } from '../data'

type LinkButtonProps = { secondary?: boolean; href: string } & Omit<ComponentPropsWithoutRef<typeof Link>, 'href'>
type NativeButtonProps = { secondary?: boolean; href?: undefined } & ComponentPropsWithoutRef<'button'>
type ButtonProps = LinkButtonProps | NativeButtonProps

/** 显式类型守卫兼容消费方未开启 strictNullChecks 的 TypeScript 配置。 */
function isLinkButton(props: ButtonProps): props is LinkButtonProps {
  return typeof props.href === 'string'
}

function buttonClassName(secondary = false, className = '') {
  return `dm-button${secondary ? ' dm-button-secondary' : ''}${className ? ` ${className}` : ''}`
}

export function Button(props: ButtonProps) {
  if (isLinkButton(props)) {
    const { secondary, className, ...attributes } = props
    return <Link {...attributes} className={buttonClassName(secondary, className)} />
  }
  const { secondary, className, ...attributes } = props
  return <button {...attributes} type={attributes.type ?? 'button'} className={buttonClassName(secondary, className)} />
}

export function Label({ children, number }: { children: ReactNode; number?: string }) {
  return <div className="dm-label">{number ? <span className="dm-number">{number}</span> : <span className="dm-dot" aria-hidden="true" />}
    <span>{children}</span>
  </div>
}

export function SectionTitle({ number, label, title, description }: { number?: string; label: Copy; title: Copy; description?: Copy }) {
  const { copy } = useCopy()
  return <Reveal className="dm-section-heading">
    <Label number={number}>{copy(label)}</Label>
    <div className="dm-heading-row">
      <h2>{copy(title)}</h2>{description && <p>{copy(description)}</p>}
    </div>
  </Reveal>
}

export function PageHeader({ label, title, description, centered = false }: { label: Copy; title: Copy; description?: Copy; centered?: boolean }) {
  const { copy } = useCopy()
  return <header className={`dm-page-header dm-container${centered ? ' dm-centered' : ''}`}>
    <Reveal>
      <Label>{copy(label)}</Label>
      <div className="dm-heading-row">
        <h1>{copy(title)}</h1>{description && <p>{copy(description)}</p>}
      </div>
    </Reveal>
  </header>
}
