'use client'

import { brand } from '../config/brand'

import { footerContent as content } from '../content/Footer'

import Link from 'next/link'
import { NewsletterForm } from './NewsletterForm'
import { useDeformoHost } from '../host'
import { useCopy } from './locale'
import { navigation } from '../data'

export function Footer({ basePath }: { basePath: string }) {
  const { copy } = useCopy()
  const host = useDeformoHost()
  return <footer className="dm-footer">
    <div className="dm-container">
      <div className="dm-footer-top">
        <div>
          <Link href={basePath} className="dm-brand">
            <img src={brand.logo.light} width={24} height={24} alt="" />
            <span>{copy(content.brand)}</span>
          </Link>
          <h2>{copy(content.aNewPerspectiveForYourNextChapter)}</h2>
        </div>
        <nav aria-label={copy(content.footerNavigation)}>{navigation.map(item => <Link key={item.slug} href={`${basePath}${item.slug ? `/${item.slug}` : ''}`}>{copy(item.title)}</Link>)}</nav>
        <NewsletterForm basePath={basePath} />
      </div>
      <div className="dm-footer-wordmark" aria-hidden="true">{brand.name}
        <span>®</span>
      </div>
      <div className="dm-footer-bottom">
        <span>© {brand.copyrightYear} {copy(content.brandAllRightsReserved)}</span>
        <Link href={host.marketplaceHref ?? basePath}>{host.marketplaceHref ? copy(content.brandTemplateMarketplace) : copy(content.brandHome)}</Link>{host.filing}
        <Link href={`${basePath}/legal/terms-of-service`}>{copy(content.terms)}</Link>
        <Link href={`${basePath}/legal/privacy-policy`}>{copy(content.privacy)}</Link>
      </div>

    </div>

  </footer>
}
