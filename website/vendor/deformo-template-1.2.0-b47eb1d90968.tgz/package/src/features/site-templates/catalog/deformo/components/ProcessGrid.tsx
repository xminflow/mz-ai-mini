'use client'

import { Reveal } from '../../../shared/Reveal'
import { useCopy } from './locale'
import { process } from '../data'

export function ProcessGrid() {
  const { copy } = useCopy()
  return <div className="dm-process-grid">{process.map((step, index) => <Reveal key={step.title[1]} delay={index * .06}>
    <article className="dm-process-card dm-glass">
      <span className="dm-process-number">0{index + 1}
        <span aria-hidden="true">↘</span>
      </span>
      <h3>{copy(step.title)}</h3>
      <p>{copy(step.description)}</p>
    </article>
  </Reveal>)}</div>
}
