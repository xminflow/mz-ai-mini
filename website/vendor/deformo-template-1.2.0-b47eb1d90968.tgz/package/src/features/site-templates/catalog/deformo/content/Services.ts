import type { Copy } from '../data'

export const servicesContent = {
  services: ["我们的服务", "Services"],
  complexChallengesConsideredSolutions: ["让复杂的数字挑战\n拥有清晰的答案", "Complex challenges\nConsidered solutions"],
  strategyDesignTechnology: ["策略 × 设计 × 技术", "Strategy × Design × Technology"],
} satisfies Record<string, Copy>
