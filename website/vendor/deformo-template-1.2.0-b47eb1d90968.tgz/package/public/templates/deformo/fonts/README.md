# 本地字体

- MiSans：Normal 系列 Regular/Bold，400/700，保留 Unicode 分片。官方介绍及许可见 https://hyperos.mi.com/font/ ，适用小米的 MiSans 字体知识产权许可协议，并非 SIL OFL。CSS 使用 微域生光 MiSans 别名。
- Poppins：Copyright 2020 The Poppins Project Authors，https://github.com/itfoundry/Poppins 。拉丁子集提供 400/600/700，许可全文见 Poppins-OFL.txt。
- src/styles/brand-fonts.css 声明本地字体，字库由模板自身提供，运行时不访问外部字体服务。
