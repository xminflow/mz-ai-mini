import type { SiteTemplate } from '../../types';
export const cernoTemplate: SiteTemplate = { ...{
        "id": "cerno",
    "gitUrl": "https://github.com/weelume/cerno-template",
        "name": "Cerno · 品牌与数字设计",
        "localizedNames": {
            "en": "Cerno · Brand & digital studio"
        },
        "sceneId": "corporate-site",
        "listed": false,
        "tags": [
            "设计工作室",
            "深浅对比",
            "橙色点阵",
            "中英文",
            "PC / iPad / H5"
        ],
        "summary": "从策略到品牌与数字体验：山体首屏、五个沉浸式案例、四篇设计期刊、工作室介绍、服务报价与演示联系表单。",
        "accentColor": "#ff5a20",
        "cover": "/templates/cerno/screenshots/desktop-home.webp",
        "screenshots": [
            {
                "src": "/templates/cerno/screenshots/desktop-home.webp",
                "alt": "Cerno desktop home",
                "device": "desktop",
                "width": 1440,
                "height": 1000
            },
            {
                "src": "/templates/cerno/screenshots/desktop-work.webp",
                "alt": "Cerno desktop work",
                "device": "desktop",
                "width": 1440,
                "height": 1000
            },
            {
                "src": "/templates/cerno/screenshots/desktop-blog.webp",
                "alt": "Cerno desktop blog",
                "device": "desktop",
                "width": 1440,
                "height": 1000
            },
            {
                "src": "/templates/cerno/screenshots/desktop-contact.webp",
                "alt": "Cerno desktop contact",
                "device": "desktop",
                "width": 1440,
                "height": 1000
            },
            {
                "src": "/templates/cerno/screenshots/tablet-home.webp",
                "alt": "Cerno tablet home",
                "device": "tablet",
                "width": 834,
                "height": 1180
            },
            {
                "src": "/templates/cerno/screenshots/tablet-work.webp",
                "alt": "Cerno tablet work",
                "device": "tablet",
                "width": 834,
                "height": 1180
            },
            {
                "src": "/templates/cerno/screenshots/tablet-blog.webp",
                "alt": "Cerno tablet blog",
                "device": "tablet",
                "width": 834,
                "height": 1180
            },
            {
                "src": "/templates/cerno/screenshots/tablet-contact.webp",
                "alt": "Cerno tablet contact",
                "device": "tablet",
                "width": 834,
                "height": 1180
            },
            {
                "src": "/templates/cerno/screenshots/mobile-home.webp",
                "alt": "Cerno mobile home",
                "device": "mobile",
                "width": 390,
                "height": 844
            },
            {
                "src": "/templates/cerno/screenshots/mobile-work.webp",
                "alt": "Cerno mobile work",
                "device": "mobile",
                "width": 390,
                "height": 844
            },
            {
                "src": "/templates/cerno/screenshots/mobile-blog.webp",
                "alt": "Cerno mobile blog",
                "device": "mobile",
                "width": 390,
                "height": 844
            },
            {
                "src": "/templates/cerno/screenshots/mobile-contact.webp",
                "alt": "Cerno mobile contact",
                "device": "mobile",
                "width": 390,
                "height": 844
            }
        ]
    }, surfaces: [{ id: 'site', name: '设计工作室官网', platform: 'pc', locales: ['zh', 'en'], pages: [
                { slug: "", title: "首页", localizedTitles: { en: "Home" }, load: () => import('./pages/HomePage') },
                { slug: "work", title: "作品", localizedTitles: { en: "Work" }, load: () => import('./pages/WorkPage') },
                { slug: "about", title: "工作室", localizedTitles: { en: "About" }, load: () => import('./pages/AboutPage') },
                { slug: "blog", title: "设计期刊", localizedTitles: { en: "Journal" }, load: () => import('./pages/BlogPage') },
                { slug: "contact", title: "联系我们", localizedTitles: { en: "Contact" }, load: () => import('./pages/ContactPage') },
                { slug: "work/the-north-face", title: "The North Face", localizedTitles: { en: "The North Face" }, load: () => import('./pages/CasePage') },
                { slug: "work/adidas", title: "Adidas", localizedTitles: { en: "Adidas" }, load: () => import('./pages/CasePage') },
                { slug: "work/mclaren", title: "McLaren", localizedTitles: { en: "McLaren" }, load: () => import('./pages/CasePage') },
                { slug: "work/new-balance", title: "New Balance", localizedTitles: { en: "New Balance" }, load: () => import('./pages/CasePage') },
                { slug: "work/the-accel", title: "Accel", localizedTitles: { en: "Accel" }, load: () => import('./pages/CasePage') },
                { slug: "blog/when-a-rebrand-is-really-a-business-decision", title: "品牌重塑与业务决策", localizedTitles: { en: "When a rebrand is a business decision" }, load: () => import('./pages/ArticlePage') },
                { slug: "blog/why-some-brands-feel-distinctive-before-you-notice-the-logo", title: "Logo 之外的品牌识别", localizedTitles: { en: "Beyond the logo" }, load: () => import('./pages/ArticlePage') },
                { slug: "blog/what-restraint-actually-adds-to-a-design", title: "设计中的克制", localizedTitles: { en: "Restraint in design" }, load: () => import('./pages/ArticlePage') },
                { slug: "blog/the-homepage-doesnt-need-to-explain-everything", title: "首页的真正任务", localizedTitles: { en: "What a homepage is for" }, load: () => import('./pages/ArticlePage') },
                { slug: "legal/privacy-policy", title: "隐私政策", localizedTitles: { en: "Privacy policy" }, load: () => import('./pages/PolicyPage') },
                { slug: "legal/terms-of-service", title: "使用条款", localizedTitles: { en: "Terms of service" }, load: () => import('./pages/PolicyPage') }
            ] }] };
