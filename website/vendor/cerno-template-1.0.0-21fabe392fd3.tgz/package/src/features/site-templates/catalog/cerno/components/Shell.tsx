'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { MotionConfig, motion } from 'framer-motion';
import { useEffect, useState, type ReactNode } from 'react';
import type { SiteTemplatePageProps } from '../../../types';
import { brand } from '../config/brand';
import { t, ui } from '../content';
import { useCernoHost } from '../host';
import { ContactForm } from './ContactForm';
import { PageScrollbar } from '../../../shared/PageScrollbar';
import '../tokens.css';
import '../theme.css';
export function Action({ href, children, dark = false }: {
    href: string;
    children: ReactNode;
    dark?: boolean;
}) { return <Link className={`ce-button ${dark ? 'ce-button-dark' : ''}`} href={href}>{children}<span className="ce-dot-icon" aria-hidden="true">⠿</span></Link>; }
export function Shell({ basePath, locale = 'zh', children, cta = true }: SiteTemplatePageProps & {
    children: ReactNode;
    cta?: boolean;
}) {
    const host = useCernoHost(), pathname = usePathname() ?? basePath, router = useRouter(), [open, setOpen] = useState(false), [time, setTime] = useState('—:—');
    const name = host.brandName?.[locale] ?? brand.name[locale], logo = host.lightLogo ?? brand.logo;
    const root = locale === 'en' ? basePath.slice(0, -3) : basePath;
    const languagePath = `${locale === 'en' ? root : root + '/en'}${pathname.slice(basePath.length)}` || '/';
    const nav = [['', ui.home], ['work', ui.work], ['about', ui.about], ['blog', ui.blog]] as const;
    useEffect(() => { const tick = () => setTime(new Intl.DateTimeFormat('en-GB', { hour: '2-digit', minute: '2-digit', timeZone: 'Europe/London' }).format(new Date())); tick(); const timer = setInterval(tick, 30000); return () => clearInterval(timer); }, []);
    useEffect(() => { if (!open)
        return; const escape = (e: KeyboardEvent) => { if (e.key === 'Escape')
        setOpen(false); }; document.addEventListener('keydown', escape); return () => document.removeEventListener('keydown', escape); }, [open]);
    return <MotionConfig reducedMotion="user"><div className="ce-site" id="ce-document" data-locale={locale}>
 <a className="ce-skip" href="#ce-main">{locale === 'zh' ? '跳到正文' : 'Skip to content'}</a>
 <header className="ce-header"><Link href={basePath || '/'} className={`ce-brand ${host.brandName ? 'is-host' : ''}`} aria-label={name}><img src={logo} alt=""/>{host.brandName && <span>{name}</span>}</Link>
 <nav id="ce-navigation" className={open ? 'ce-nav is-open' : 'ce-nav'} aria-label={locale === 'zh' ? '主导航' : 'Main navigation'}>{nav.map(([slug, label]) => <Link key={slug} onClick={() => setOpen(false)} aria-current={pathname === `${basePath}/${slug}` || slug === '' && pathname === (basePath || '/') ? 'page' : undefined} href={`${basePath}${slug ? '/' + slug : '/'}`}>{t(label, locale)}</Link>)}</nav>
 <div className="ce-header-right"><span className="ce-time">{time} <span>{locale === 'zh' ? '伦敦时间' : 'Local time'}</span></span><Link className="ce-language" href={languagePath} aria-label={locale === 'zh' ? '切换为英文' : 'Switch to Chinese'} onClick={e => { if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey)
        return; e.preventDefault(); router.push(languagePath + location.search + location.hash); setOpen(false); }}>{locale === 'zh' ? 'EN' : '中文'}</Link><span className="ce-header-contact"><Action href={`${basePath}/contact`}>{t(ui.contact, locale)}</Action></span><button type="button" className="ce-menu-toggle" aria-controls="ce-navigation" aria-expanded={open} aria-label={locale === 'zh' ? '切换导航菜单' : 'Toggle navigation menu'} onClick={() => setOpen(!open)}>{open ? '✕' : '☰'}</button></div></header>
 <main id="ce-main">{children}</main>
 {cta && <section className="ce-cta ce-wrap"><span className="ce-eyebrow">{locale === 'zh' ? '下一步 / 一起出发' : 'NEXT / LET’S BUILD'}</span><h2>{t(ui.footerTitle, locale)}</h2><div><p>{t(ui.footerIntro, locale)}</p><Action dark href={`${basePath}/contact`}>{t(ui.contact, locale)}</Action></div></section>}
 <footer className="ce-footer"><div className="ce-wrap"><div className="ce-footer-top"><Link className="ce-brand" href={basePath || '/'}><img src={logo} alt=""/><span>{name}</span></Link><nav aria-label={locale === 'zh' ? '页脚导航' : 'Footer navigation'}>{[...nav, ['contact', ui.contact] as const].map(([slug, label]) => <Link key={slug} href={`${basePath}${slug ? '/' + slug : '/'}`}>{t(label, locale)}</Link>)}</nav><p>{brand.phone}<br />{brand.address[locale]}<br /><small>{locale === 'zh' ? '联系方式为演示信息' : 'Demo contact details'}</small></p></div>
 <div className="ce-footer-contact"><div><h2>{locale === 'zh' ? '准备好创造新的可能？' : 'Ready to build something bold?'}</h2><a href={`mailto:${brand.email}`}>{brand.email}</a><Availability locale={locale}/></div><ContactForm locale={locale} compact basePath={basePath}/></div>
 <div className="ce-footer-legal"><span>© {brand.year} {name}</span><Link href={`${basePath}/legal/privacy-policy`}>{locale === 'zh' ? '隐私政策' : 'Privacy policy'}</Link><Link href={`${basePath}/legal/terms-of-service`}>{locale === 'zh' ? '使用条款' : 'Terms of service'}</Link>{host.marketplaceHref && <Link href={host.marketplaceHref}>{host.marketplaceLabel?.[locale] ?? name}</Link>}{host.filing}</div>
 <div className="ce-footer-word" aria-hidden="true">{host.brandName ? name : brand.wordmark}</div><div className="ce-footer-end"><span>©{brand.year}</span><span>[ CR®-00 ]</span></div></div></footer>
 {host.marketplaceHref && <Link className="ce-marketplace" href={host.marketplaceHref} aria-label={host.marketplaceAriaLabel?.[locale] ?? name}><img src={logo} alt=""/><span>{name}</span></Link>}
 <PageScrollbar className="ce-page-scrollbar" controlsId="ce-document" label={locale === 'zh' ? '页面滚动' : 'Page scroll'} autoHide/>
 </div></MotionConfig>;
}
export function Availability({ locale = 'zh' }: Pick<SiteTemplatePageProps, 'locale'>) { return <div className="ce-availability"><span>© {brand.year}</span><span>Q4</span><i aria-hidden="true"/><span>{locale === 'zh' ? `剩余 ${brand.availability} 个合作名额` : `${brand.availability} slots left`}</span></div>; }
export function BrandPanel({ locale, image }: {
    locale: 'zh' | 'en';
    image: string;
}) { const host = useCernoHost(); return <section className="ce-brand-panel" style={{ backgroundImage: `linear-gradient(#0005,#0008),url(${image})` }}><p>{locale === 'zh' ? '目的清晰\n设计鲜明' : 'Clean in purpose.\nDistinct by design.'}</p><span>{host.brandName?.[locale] ?? brand.wordmark}</span></section>; }
export function Reveal({ children, className = '' }: {
    children: ReactNode;
    className?: string;
}) { return <motion.div className={className} initial={{ opacity: 0, y: 22 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: .04 }} transition={{ duration: .55 }}>{children}</motion.div>; }
