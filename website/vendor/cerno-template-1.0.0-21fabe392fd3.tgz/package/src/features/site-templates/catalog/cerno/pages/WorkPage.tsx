import type { SiteTemplatePageProps } from '../../../types';
import { copy, ui } from '../content';
import { pageImages } from '../data';
import { Shell, Availability, Action } from '../components/Shell';
import { Hero } from '../components/Hero';
import { ProjectCards, SectionHead } from '../components/Sections';
export default function WorkPage(props: SiteTemplatePageProps) { const locale = props.locale ?? 'zh'; return <Shell {...props}><Hero title={copy('精选作品', 'Our Work')} description={ui.workIntro} image={pageImages['/work'][0]} locale={locale}/><section className="ce-section ce-wrap"><SectionHead number="01" label={locale === 'zh' ? '作品' : 'WORK'} title={locale === 'zh' ? '策略与设计\n共同创造价值' : 'Selected work,\nbuilt to perform.'} intro={locale === 'zh' ? '品牌识别、数字产品，以及将它们连接在一起的系统。客户名称与数据均为参考案例演示。' : 'Selected projects across brand identity, digital product, and the systems that hold them together. Reference case studies are demo content.'}><Action dark href={`${props.basePath}/contact`}>{locale === 'zh' ? '开启一个项目' : 'Start a project'}</Action></SectionHead><Availability locale={locale}/><ProjectCards {...props}/></section></Shell>; }
