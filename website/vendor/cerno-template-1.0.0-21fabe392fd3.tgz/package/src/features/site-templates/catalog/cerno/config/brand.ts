export const brand = {
    name: { zh: 'Cerno', en: 'Cerno' },
    wordmark: 'CERNO',
    logo: '/templates/cerno/logo.svg',
    email: 'hello@example.com',
    phone: '+44 20 7946 0123',
    address: { zh: '伦敦 · 英国（示例工作室）', en: 'London, United Kingdom · Demo studio' },
    year: 2026,
    availability: 3,
};
