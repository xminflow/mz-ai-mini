'use client';
import { useRef, useState, useEffect } from 'react';
import type { TemplateLocale } from '../../../types';
export function Gallery({ images, locale, name }: {
    images: string[];
    locale: TemplateLocale;
    name: string;
}) { const dialog = useRef<HTMLDialogElement>(null), [active, setActive] = useState(0), [open, setOpen] = useState(false); useEffect(() => { if (!open)
    return; const previous = document.body.style.overflow; document.body.style.overflow = 'hidden'; const key = (e: KeyboardEvent) => { if (e.key === 'ArrowRight')
    setActive(a => (a + 1) % images.length); if (e.key === 'ArrowLeft')
    setActive(a => (a - 1 + images.length) % images.length); }; document.addEventListener('keydown', key); return () => { document.body.style.overflow = previous; document.removeEventListener('keydown', key); }; }, [open, images.length]); if (!images.length)
    return null; const close = () => { dialog.current?.close(); setOpen(false); }; return <><div className="ce-case-gallery">{images.map((src, i) => <button type="button" key={src} aria-label={`${locale === 'zh' ? '放大图片' : 'Enlarge image'} ${i + 1}`} onClick={() => { setActive(i); setOpen(true); dialog.current?.showModal(); }}><img src={src} alt={`${name} — ${i + 1}`} loading="lazy"/><span aria-hidden="true">↗</span></button>)}</div><dialog ref={dialog} className="ce-lightbox" aria-label={locale === 'zh' ? '案例图片浏览' : 'Case image viewer'} onCancel={() => setOpen(false)} onClick={e => { if (e.target === e.currentTarget)
    close(); }}><button className="ce-lightbox-close" type="button" onClick={close} aria-label={locale === 'zh' ? '关闭图片' : 'Close image'}>✕</button><img src={images[active]} alt={`${name} — ${active + 1}`}/><div><button type="button" disabled={images.length < 2} aria-label={locale === 'zh' ? '上一张图片' : 'Previous image'} onClick={() => setActive((active - 1 + images.length) % images.length)}>←</button><span>{active + 1} / {images.length}</span><button type="button" disabled={images.length < 2} aria-label={locale === 'zh' ? '下一张图片' : 'Next image'} onClick={() => setActive((active + 1) % images.length)}>→</button></div></dialog></>; }
