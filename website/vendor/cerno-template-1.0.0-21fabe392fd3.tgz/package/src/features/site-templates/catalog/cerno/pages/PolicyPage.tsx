'use client';
import { usePathname } from 'next/navigation';
import type { SiteTemplatePageProps } from '../../../types';
import { copy, t, ui } from '../content';
import { pageImages } from '../data';
import { Shell } from '../components/Shell';
import { Hero } from '../components/Hero';
import { brand } from '../config/brand';
const privacy = [
    [copy('这是一份演示说明', 'About this demo'), copy('本网站是设计工作室模板，不代表已注册的真实服务机构。这份说明反映当前演示功能，不作为正式业务隐私政策。', 'This is a design studio template, not a registered service provider. This notice describes its current demo behavior and is not a production privacy policy.')],
    [copy('表单信息', 'Form information'), copy('联系表单仅在当前页面使用浏览器原生规则校验。姓名、邮箱、预算与项目描述不会被发送到服务器，也不会保存到本地存储。离开页面后信息不保留。', 'Contact forms validate name, email, budget and message in the current page. They do not send data to a server or store it in browser storage. Data is not retained after leaving the page.')],
    [copy('技术信息与素材', 'Technical data and assets'), copy('页面图片和字体本地托管。模板不接入统计、广告、地图或邮件订阅服务。运行环境可能产生标准请求日志，由部署方管理。', 'Images and fonts are hosted locally. The template includes no analytics, advertising, embedded maps or newsletter service. The hosting environment may create standard request logs managed by its operator.')],
    [copy('Cookie 与浏览器存储', 'Cookies and browser storage'), copy('模板业务功能不写入追踪 Cookie 或持久化表单信息。语言由当前网址决定，菜单与筛选仅保留在当前页面状态。', 'Template functionality writes no tracking cookies or persistent form data. The URL determines language; menus and filters use current-page state.')],
    [copy('分享与第三方', 'Sharing and third parties'), copy('演示表单不会向第三方分享内容。点击邮箱链接可能打开你选择的邮件程序，由该程序的政策决定后续处理。', 'The demo form shares nothing with third parties. Email links may open your chosen email application, whose own policies govern subsequent processing.')],
    [copy('上线前的准备', 'Before production use'), copy('启用真实表单、统计或其他服务前，部署方需要明确处理目的、保存期限、服务商、适用规则和联系渠道，并重新编写相应政策。', 'Before enabling real forms, analytics or other services, the operator must define processing purposes, retention, providers, applicable rules and contact channels, and replace this notice accordingly.')],
];
const terms = [
    [copy('模板与使用范围', 'Template and scope'), copy('本网站用于展示品牌与数字设计工作室的页面结构及交互。报价、合作名额、荣誉、客户评价与案例统计均为演示资料。', 'This site demonstrates a brand and digital design studio experience. Pricing, availability, awards, testimonials and case study figures are demo content.')],
    [copy('没有在线交易或预约', 'No online transactions or bookings'), copy('表单校验不创建订单、预约或合作合同。任何真实合作应另行约定范围、交付、时间、费用与责任。', 'Form validation creates no order, booking or service agreement. Real work requires a separate agreement covering scope, deliverables, schedule, fees and responsibilities.')],
    [copy('知识产权', 'Intellectual property'), copy('参考图片、品牌名称、文章和字体可能受各自权利人许可约束。请在公开发布或再分发前核实许可，不因本地可访问而推定可商用。', 'Reference imagery, brand names, articles and fonts may be subject to their owners’ licenses. Verify permissions before publication or redistribution; local availability does not establish commercial rights.')],
    [copy('合理使用', 'Acceptable use'), copy('请勿滥用网站、尝试未授权访问或干扰正常运行。替换为真实业务内容时，应保证所提供信息与素材有权使用。', 'Do not misuse the site, attempt unauthorized access or interfere with normal operation. Ensure you have rights to any business content and assets you add.')],
    [copy('真实项目与保密', 'Real projects and confidentiality'), copy('模板未提供账户、支付、持久化或保密文件交换能力。请勿在演示表单填写秘密或真实项目敏感信息。', 'The template provides no accounts, payments, persistence or confidential file exchange. Do not enter secrets or sensitive project information in demo forms.')],
    [copy('变更与联系', 'Changes and contact'), copy('部署方可以根据真实服务调整页面，并应同步更新政策与日期。当前邮箱为示例，不是正式客服渠道。', 'An operator may adapt these pages for real services and should update policies and dates together. The current email is a sample, not a live support channel.')],
];
export default function PolicyPage(props: SiteTemplatePageProps) { const locale = props.locale ?? 'zh', isPrivacy = (usePathname() ?? '').endsWith('privacy-policy'), title = isPrivacy ? copy('隐私政策', 'Privacy Policy') : copy('使用条款', 'Terms of Service'); return <Shell {...props}><Hero title={title} description={ui.legalIntro} image={pageImages['/contact'][0]} locale={locale}/><section className="ce-section ce-wrap ce-policy"><aside><span className="ce-eyebrow">{locale === 'zh' ? '最后更新' : 'LAST UPDATED'}</span><p>2026 / 10 / 20</p><span className="ce-eyebrow">{locale === 'zh' ? '示例邮箱' : 'DEMO EMAIL'}</span><p>{brand.email}</p></aside><div>{(isPrivacy ? privacy : terms).map(([heading, body], i) => <section key={i}><h2>{i + 1}. {t(heading, locale)}</h2><p>{t(body, locale)}</p></section>)}</div></section></Shell>; }
