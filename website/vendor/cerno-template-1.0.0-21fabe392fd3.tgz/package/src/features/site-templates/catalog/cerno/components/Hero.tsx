'use client';
import { useState } from 'react';
import { brand } from '../config/brand';
import { principles, t, ui, type Copy } from '../content';
import type { TemplateLocale } from '../../../types';
import { Availability } from './Shell';
import { useCernoHost } from '../host';
export function Hero({ title, description, image, locale, home = false, subtitle }: {
    title: Copy;
    description: Copy;
    image: string;
    locale: TemplateLocale;
    home?: boolean;
    subtitle?: string;
}) {
    const [active, setActive] = useState(0), item = principles[active], host = useCernoHost();
    return <section className={`ce-hero ${home ? 'ce-hero-home' : ''}`}><img className="ce-hero-bg" src={image} alt="" fetchPriority="high"/><div className="ce-hero-shade"/><div className="ce-dots" aria-hidden="true">{Array.from({ length: 15 }, (_, i) => <i key={i}/>)}</div>
 <div className="ce-hero-content ce-wrap"><h1 className={home ? `ce-wordmark ${host.brandName ? 'is-host' : ''}` : ''}>{home ? (host.brandName?.[locale] ?? brand.wordmark) : t(title, locale)}</h1><p className="ce-hero-intro">{t(description, locale)}</p>{subtitle && <span className="ce-hero-subtitle">{subtitle}</span>}
 {home && <><Availability locale={locale}/>{item && <div className="ce-principle"><div role="group" aria-label={locale === 'zh' ? '设计理念' : 'Design principles'}>{principles.map((_, i) => <button key={i} type="button" aria-pressed={i === active} aria-label={(locale === 'zh' ? '理念 ' : 'Principle ') + (i + 1)} onClick={() => setActive(i)}>{String(i + 1).padStart(2, '0')}</button>)}<span>/ {String(principles.length).padStart(2, '0')}</span></div><h2>{t(item.title, locale)}</h2><p>{t(item.body, locale)}</p></div>}<span className="ce-hero-caption">{t(ui.hero, locale)}</span></>}
 </div></section>;
}
