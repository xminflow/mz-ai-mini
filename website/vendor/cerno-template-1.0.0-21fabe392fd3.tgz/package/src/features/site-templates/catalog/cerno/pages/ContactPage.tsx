import type { SiteTemplatePageProps } from '../../../types';
import { copy, ui, t } from '../content';
import { pageImages } from '../data';
import { brand } from '../config/brand';
import { Shell } from '../components/Shell';
import { Hero } from '../components/Hero';
import { SectionHead, FaqSection } from '../components/Sections';
import { ContactForm } from '../components/ContactForm';
export default function ContactPage(props: SiteTemplatePageProps) { const locale = props.locale ?? 'zh'; return <Shell {...props} cta={false}><Hero title={copy('联系我们', 'Contact Us')} description={ui.contactIntro} image={pageImages['/contact'][0]} locale={locale}/><section className="ce-section ce-wrap" id="enquiry"><SectionHead number="01" label={locale === 'zh' ? '联系' : 'CONTACT'} title={t(ui.contact, locale)} intro={locale === 'zh' ? '你正在创造什么，希望去往哪里？从一次清楚而坦诚的对话开始。' : 'Have a project in mind? Tell us what you’re building, where you want to go, and how we can help make it happen.'}/><div className="ce-contact-grid"><div><span className="ce-eyebrow">{locale === 'zh' ? '电话（示例）' : 'PHONE · DEMO'}</span><p>{brand.phone}</p><span className="ce-eyebrow">{locale === 'zh' ? '邮箱（示例）' : 'EMAIL · DEMO'}</span><p><a href={`mailto:${brand.email}`}>{brand.email}</a></p><img src={pageImages['/contact'][1]} alt={locale === 'zh' ? '伦敦城市风景' : 'London cityscape'} loading="lazy"/><p>{brand.address[locale]}<br />{locale === 'zh' ? '与各地团队远程协作' : 'Working with teams worldwide.'}</p></div><ContactForm {...props}/></div></section><FaqSection {...props}/></Shell>; }
