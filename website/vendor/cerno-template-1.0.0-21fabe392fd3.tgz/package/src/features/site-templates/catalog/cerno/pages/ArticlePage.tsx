'use client';
import { usePathname } from 'next/navigation';
import type { SiteTemplatePageProps } from '../../../types';
import { articles } from '../data';
import { t } from '../content';
import { Shell, Action } from '../components/Shell';
import { Gallery } from '../components/Gallery';
import { JournalSection } from '../components/Sections';
export default function ArticlePage(props: SiteTemplatePageProps) { const locale = props.locale ?? 'zh', pathname = usePathname() ?? '', article = articles.find(a => pathname.endsWith('/' + a.slug)); if (!article)
    return <Shell {...props}><section className="ce-section ce-wrap"><h1>{locale === 'zh' ? '文章未找到' : 'Article not found'}</h1><Action dark href={`${props.basePath}/blog`}>{locale === 'zh' ? '返回期刊' : 'Back to journal'}</Action></section></Shell>; return <Shell {...props}><article><header className="ce-article-header ce-wrap"><div className="ce-eyebrow"><span>{t(article.category, locale)}</span><time dateTime={article.date}>{article.date}</time><span>{article.minutes} {locale === 'zh' ? '分钟阅读' : 'MIN READ'}</span></div><h1>{t(article.title, locale)}</h1><p>{t(article.intro, locale)}</p></header><div className="ce-article-cover"><img src={article.images[0]} alt={t(article.title, locale)}/></div><div className="ce-article-body ce-wrap"><aside><span className="ce-eyebrow">{locale === 'zh' ? '设计期刊' : 'JOURNAL'}</span><p>{t(article.title, locale)}</p><Action dark href={`${props.basePath}/blog`}>{locale === 'zh' ? '返回全部文章' : 'All insights'}</Action></aside><div>{locale === 'zh' ? article.sections.map((s, i) => <section key={i}><h2>{s.title}</h2>{s.paragraphs.map((p, j) => <p key={j}>{p}</p>)}{article.images[i + 1] && <Gallery images={[article.images[i + 1]]} locale={locale} name={s.title}/>}</section>) : article.english.map((p, i) => p.length < 55 ? <h2 key={i}>{p}</h2> : <p key={i}>{p}</p>)}</div></div></article><JournalSection {...props}/></Shell>; }
