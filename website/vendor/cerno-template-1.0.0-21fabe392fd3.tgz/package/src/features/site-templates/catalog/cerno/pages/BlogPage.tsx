'use client';
import { useState } from 'react';
import type { SiteTemplatePageProps } from '../../../types';
import { copy, ui } from '../content';
import { pageImages } from '../data';
import { Shell } from '../components/Shell';
import { Hero } from '../components/Hero';
import { SectionHead, JournalCards, categories } from '../components/Sections';
export default function BlogPage(props: SiteTemplatePageProps) { const locale = props.locale ?? 'zh', [filter, setFilter] = useState('all'); return <Shell {...props}><Hero title={copy('设计期刊', 'Insights')} description={ui.blogIntro} image={pageImages['/blog'][0]} locale={locale}/><section className="ce-section ce-wrap"><SectionHead number="01" label={locale === 'zh' ? '期刊' : 'INSIGHTS'} title={locale === 'zh' ? '关于设计的\n不同视角' : 'A collection of perspectives.'}/><div className="ce-filters" role="group" aria-label={locale === 'zh' ? '文章分类' : 'Article categories'}>{categories.map(([id, zh, en]) => <button type="button" key={id} aria-pressed={filter === id} onClick={() => setFilter(id)}>{locale === 'zh' ? zh : en}</button>)}</div><JournalCards {...props} filter={filter}/></section></Shell>; }
