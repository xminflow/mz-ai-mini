'use client';
import { useId, useState } from 'react';
import Link from 'next/link';
import type { SiteTemplatePageProps } from '../../../types';
import { services, t, ui } from '../content';
export function ContactForm({ locale = 'zh', basePath, compact = false }: SiteTemplatePageProps & {
    compact?: boolean;
}) {
    const [submitted, setSubmitted] = useState(false), id = useId();
    const zh = locale === 'zh';
    return <form className={`ce-form ${compact ? 'ce-form-compact' : ''}`} onSubmit={e => { e.preventDefault(); setSubmitted(true); }} onChange={() => setSubmitted(false)}>
 <p className="ce-form-notice">{t(ui.demo, locale)}</p>
 <div className="ce-form-row"><label htmlFor={`${id}-name`}>{zh ? '姓名 *' : 'Name *'}<input id={`${id}-name`} name="name" autoComplete="name" required maxLength={100}/></label><label htmlFor={`${id}-email`}>{zh ? '邮箱 *' : 'Email *'}<input id={`${id}-email`} name="email" type="email" autoComplete="email" required maxLength={254}/></label></div>
 <div className="ce-form-row"><label htmlFor={`${id}-service`}>{zh ? '服务 *' : 'Services *'}<select id={`${id}-service`} name="service" required defaultValue=""><option value="" disabled>{zh ? '请选择' : 'Select…'}</option>{services.map((s, i) => <option key={i} value={i}>{t(s.name, locale)}</option>)}</select></label><label htmlFor={`${id}-budget`}>{zh ? '预算 *' : 'Budget *'}<select id={`${id}-budget`} name="budget" required defaultValue=""><option value="" disabled>{zh ? '请选择' : 'Select…'}</option>{['$3,000–$10,000', '$10,000–$25,000', '$25,000+'].map(v => <option key={v}>{v}</option>)}</select></label></div>
 <label htmlFor={`${id}-message`}>{zh ? '项目想法 *' : 'Message *'}<textarea id={`${id}-message`} name="message" rows={compact ? 3 : 5} required maxLength={5000}/></label>
 <div className="ce-form-bottom"><button className="ce-button ce-submit" type="submit">{zh ? '校验项目需求' : 'Validate enquiry'}<span className="ce-dot-icon" aria-hidden="true">⠿</span></button><small>{zh ? '提交前请阅读' : 'Please read our'} <Link href={`${basePath}/legal/terms-of-service`}>{zh ? '条款' : 'Terms'}</Link> {zh ? '与' : 'and'} <Link href={`${basePath}/legal/privacy-policy`}>{zh ? '隐私说明' : 'Privacy policy'}</Link></small></div>
 <p role="status" className="ce-form-status">{submitted ? (zh ? '校验通过。这是演示表单，信息未发送或保存。' : 'Validation passed. This is a demo; nothing was sent or saved.') : ''}</p>
 </form>;
}
