// 本地素材及可编辑案例数据；统计与客户引言仅作演示。
export const projects = [
    {
        "slug": "the-north-face",
        "name": "The North Face",
        "year": "2025",
        "scope": {
            "zh": "数字策略 + 用户体验",
            "en": "DIGITAL STRATEGY + UX/UI"
        },
        "title": {
            "zh": "把探索的精神带入数字体验",
            "en": "Building a digital experience with altitude"
        },
        "intro": {
            "zh": "我们以运动、探索与自信为核心，重塑 The North Face 的线上体验，让产品发现成为下一次远行的起点。",
            "en": "We reimagined The North Face digital experience around the same sense of movement, exploration and confidence that defines the brand. Every page now invites people further in, turning product discovery into the first step of their next expedition."
        },
        "industry": {
            "zh": "户外服装与装备",
            "en": "Outdoor Apparel & Equipment"
        },
        "services": {
            "zh": "数字策略 · UX/UI · 开发",
            "en": "Digital Strategy · UX/UI · Development"
        },
        "deliverables": {
            "zh": "网站 · 设计系统 · 编辑模板",
            "en": "Website · Design System · Editorial Templates"
        },
        "images": [
            "/templates/cerno/images/k8HPjFVskU8SdjLrpoTbdzI6l4M.jpg",
            "/templates/cerno/images/XHI79ZfThCfRBe3KyNrarx18jCw.jpg",
            "/templates/cerno/images/KGcTyz3fMlWJGMmpuTntg3aiY.jpg",
            "/templates/cerno/images/EMGeitW0AePFPcV9vUK65KK9s.jpg",
            "/templates/cerno/images/yfZiWVr5xcy8i0gdENeGFIsM.jpg",
            "/templates/cerno/images/EMfwugg7P8Mq0ipmVmphp36nXek.jpg",
            "/templates/cerno/images/KHAhHd9voSPhridxJspxwLEYeQ.jpg",
            "/templates/cerno/images/BP0gTk5eNAt2GpjiN7lf9ZBCQ.jpg",
            "/templates/cerno/images/jh4M6CgAzHKyhEiT2wIJRVY9SwA.jpg",
            "/templates/cerno/images/RgshzWNljgpJiDRbM1GYRSMXb8s.jpg",
            "/templates/cerno/images/O5r8t37CW7hPjTMMaqBb6rnxPw.jpg",
            "/templates/cerno/images/AMavaJkrZ3RqdXIhiOlmxZ2BFfE.jpg",
            "/templates/cerno/images/AUujUfF6meJZLYQFHZhkYkdy0zY.jpg",
            "/templates/cerno/images/FqvvQ3NghGXAeGTVahPz1CRBts.jpg",
            "/templates/cerno/images/qbMrxXIJ7uQ13yLfCbl30d1YuI.jpg",
            "/templates/cerno/images/nMFR0hNwgVghewEb51H16bql1M.jpg"
        ],
        "sections": [
            {
                "title": {
                    "zh": "从山野精神出发",
                    "en": "The introduction"
                },
                "paragraphs": {
                    "zh": [
                        "品牌服务于登山、滑雪、跑步与热爱户外的广泛人群。数字体验需要兼顾不同目的，同时保留一致的探索精神。",
                        "我们从策略与视觉方向入手，将产品、活动与编辑内容整合为清楚的体验。"
                    ],
                    "en": [
                        "The North Face has spent decades outfitting people who go further — its digital experience needed to feel the same way.",
                        "From expedition gear to everyday outerwear, The North Face speaks to a wide audience: mountaineers, skiers, runners and people who simply love being outside. Online, that range had turned into a crowded experience where product, campaign and editorial content competed for attention.",
                        "We partnered with the team to rethink the experience from UX strategy and visual direction through to responsive design and development, with one goal: make every visit feel as purposeful as a day in the mountains."
                    ]
                }
            },
            {
                "title": {
                    "zh": "让优秀内容重新被看见",
                    "en": "The challenge"
                },
                "paragraphs": {
                    "zh": [
                        "信息越多，越需要清晰的优先级。原有内容相互竞争，让有价值的产品与故事难以被发现。",
                        "挑战是简化路径，同时保留户外品牌的力量感与情绪。"
                    ],
                    "en": [
                        "Great products and powerful stories were there, but they were buried in a journey that felt heavier than the brand.",
                        "Years of campaigns, seasonal launches and regional content had left the site fragmented. Product pages, athlete stories and editorial features each followed their own rules, making it hard for visitors to move between inspiration and gear.",
                        "The challenge was to bring structure without losing spirit — a system that could carry bold imagery and storytelling while making it far easier to find, compare and buy.",
                        "STRUCTURE",
                        "Untangle product, campaign and editorial content into one clear, connected journey.",
                        "IMMERSION",
                        "Let imagery and athlete stories lead without slowing people down.",
                        "SCALE",
                        "Give regional teams a system they can launch every season with."
                    ]
                }
            },
            {
                "title": {
                    "zh": "以探索为线索组织体验",
                    "en": "The solution"
                },
                "paragraphs": {
                    "zh": [
                        "以真实的使用场景组织导航，通过鲜明影像、紧凑文字与统一组件建立层次。",
                        "模块化设计系统让新产品与活动内容能够持续扩展，保持跨设备的一致体验。"
                    ],
                    "en": [
                        "“Cerno understood that our customers don’t just buy jackets, they plan adventures. The new experience finally reflects that, and it’s made every launch since easier to tell.”",
                        "Elena Marsh",
                        "Director of Digital Experience",
                        "We built a sharper, more immersive experience across product, campaign and editorial content — designed to move like the brand.",
                        "We started with the journey, mapping how people move from inspiration to product and back again. Navigation was rebuilt around activities and conditions, so a skier, a climber and a commuter could each find their path in a few taps.",
                        "The visual direction puts full-bleed photography and confident typography up front, with motion used sparingly to add a sense of momentum rather than decoration.",
                        "Underneath, a modular design system covers everything from product grids to long-form stories, giving the internal team reusable components for every launch, season and market."
                    ]
                }
            },
            {
                "title": {
                    "zh": "为下一次远行打开入口",
                    "en": "The impact"
                },
                "paragraphs": {
                    "zh": [
                        "更清晰的结构帮助访客更快理解内容，也让团队拥有可以长期维护的设计基础。",
                        "以下数据来自参考案例，仅作模板展示。"
                    ],
                    "en": [
                        "A clearer content structure and a more immersive visual system helped people explore products and stories with less friction.",
                        "With the journey reorganised around how people actually explore, visitors spent more time with both products and stories, and moved between them far more naturally.",
                        "The new system also changed how the team works: seasonal campaigns now launch from shared components, keeping every market consistent without slowing anyone down.",
                        "+38% ENGAGEMENT",
                        "A clearer content structure and more immersive visual system helped users explore products and stories with less friction.",
                        "+27% PRODUCT DISCOVERY",
                        "More visitors moved from editorial stories into product pages.",
                        "−19% BOUNCE RATE",
                        "Activity-led navigation kept more first-time visitors exploring.",
                        "2.1× LAUNCH SPEED",
                        "Seasonal campaigns shipped faster from shared components."
                    ]
                }
            }
        ],
        "metrics": [
            "+38%",
            "+56%",
            "−22%",
            "2.1×"
        ]
    },
    {
        "slug": "adidas",
        "name": "Adidas",
        "year": "2026",
        "scope": {
            "zh": "活动创意 + 视觉识别",
            "en": "CAMPAIGN + VISUAL IDENTITY"
        },
        "title": {
            "zh": "打造充满运动张力的活动系统",
            "en": "Building a campaign system that performs"
        },
        "intro": {
            "zh": "围绕运动、压力与表现力，我们为 Adidas 建立灵活的视觉语言，让影片、社交媒体与零售中的每一次发布都属于同一场比赛。",
            "en": "For adidas, we developed a campaign system built around movement, pressure and performance. One flexible visual language now carries every launch across film, social and retail, so each format feels like part of the same race."
        },
        "industry": {
            "zh": "运动服饰与竞技",
            "en": "Sportswear & Performance"
        },
        "services": {
            "zh": "活动方向 · 视觉识别 · 艺术指导",
            "en": "Campaign Direction · Visual Identity · Art Direction"
        },
        "deliverables": {
            "zh": "活动系统 · 视觉工具包 · 素材指南",
            "en": "Campaign System · Visual Toolkit · Asset Guidelines"
        },
        "images": [
            "/templates/cerno/images/AhERw7L700ojTjj1sp4Vf9fzBI.jpg",
            "/templates/cerno/images/nwDSak8ct51vCD2o1TVCWlI5g.jpg",
            "/templates/cerno/images/hwv8UP6iFT0T3APDh7Ea62d4mk.jpg",
            "/templates/cerno/images/Nknv2G4V6hpE2IpQEukK2wgi1Qg.jpg",
            "/templates/cerno/images/pzqPEJKoQD0rUcd6cxdZote1s.jpg",
            "/templates/cerno/images/cMNbccAP1MZBucBT2RI00TihIU.jpg",
            "/templates/cerno/images/9sCToSfR5BLNbJ97BUFdPmMDN8.jpg",
            "/templates/cerno/images/ZmjMP1HOJFweuCT8PuGGi60Go.jpg",
            "/templates/cerno/images/UOV70XR0WEMuVY4WzDNjX3DT5N8.jpg",
            "/templates/cerno/images/MWrVM62bicK5rg4Gi7V2VV28yH4.jpg",
            "/templates/cerno/images/y3MjbRg8boSsbYUajHDqJMF3E.jpg",
            "/templates/cerno/images/cZ4vQ6ncyUinMmWPGVa7SLJG40.jpg",
            "/templates/cerno/images/JJRiQh0r7yVjFbEdfMDGEeO3H4.jpg",
            "/templates/cerno/images/M7JmUa56ouPzV8y2Iwj6HAR4.jpg",
            "/templates/cerno/images/I73c69mLTQ1OKhrhAWoABehU.jpg",
            "/templates/cerno/images/46eFUGrMOaK5o9fLFydagW4A46s.jpg",
            "/templates/cerno/images/9Nijc1lf1TpjsI5JGuZEqRUBffY.jpg",
            "/templates/cerno/images/q6PQh6icZVDA0twDeHX4YRzj4.jpg"
        ],
        "sections": [
            {
                "title": {
                    "zh": "让运动的力量贯穿每个触点",
                    "en": "The introduction"
                },
                "paragraphs": {
                    "zh": [
                        "Adidas 讲述运动员突破极限的故事，每个触点都需要传递同样的强度。",
                        "原有活动在不同市场和媒介中分别制作，识别度与制作效率都受到影响。"
                    ],
                    "en": [
                        "adidas tells stories about athletes at their limit — its campaigns needed to carry that intensity everywhere they appear.",
                        "Every season adidas launches products and athlete stories across retail, social, digital and out-of-home. Each touchpoint was being designed almost from scratch, which made campaigns slower to produce and harder to recognise.",
                        "We were asked to create a campaign system built around movement, pressure and performance — one that could flex across formats while always feeling unmistakably adidas."
                    ]
                }
            },
            {
                "title": {
                    "zh": "世界级影像需要共同的语言",
                    "en": "The challenge"
                },
                "paragraphs": {
                    "zh": [
                        "不同团队缺少共享的视觉规则，格式切换时常常需要重新设计。",
                        "我们需要在一致性和创作自由之间建立明确的边界。"
                    ],
                    "en": [
                        "The imagery was world-class, but every format told the story a little differently.",
                        "Campaign assets were produced by many teams and agencies across markets. Without a shared visual language, type, crops and layouts drifted from format to format, and the strongest moments often got lost.",
                        "The challenge was to define a system strict enough to stay consistent, yet loose enough for creative teams to push each story further.",
                        "CONSISTENCY",
                        "Bring every format, from billboards to stories, into one recognisable visual language.",
                        "INTENSITY",
                        "Keep the raw energy of athletic imagery at the centre of every layout.",
                        "SPEED",
                        "Help teams produce and adapt assets faster across markets."
                    ]
                }
            },
            {
                "title": {
                    "zh": "从影像出发构建视觉系统",
                    "en": "The solution"
                },
                "paragraphs": {
                    "zh": [
                        "先定义运动影像的裁切、构图与动态模糊，再让大胆的字体与简洁网格共同工作。",
                        "通过模板与素材指南，团队可以在竖屏故事、零售画面与体育场屏幕间快速适配。"
                    ],
                    "en": [
                        "“The system gave every team the same starting line. Our campaigns look stronger, ship faster, and you can recognise them from across a stadium.”",
                        "Marcus Lehmann",
                        "Global Brand Creative Lead",
                        "We built a flexible visual language around strong athletic imagery and bold type, giving the brand a sharper way to tell product and athlete stories.",
                        "We started from the image: rules for crops, framing and motion blur that keep the athlete’s movement at the heart of every composition.",
                        "Bold typography and a simple grid sit on top, with clear rules for how headlines, product and stats interact across formats, from vertical stories to stadium screens.",
                        "Everything is packaged in a visual toolkit with templates and asset guidelines, so teams in every market can adapt a campaign in hours instead of days."
                    ]
                }
            },
            {
                "title": {
                    "zh": "更鲜明，也更高效",
                    "en": "The impact"
                },
                "paragraphs": {
                    "zh": [
                        "共同的视觉语言让活动更容易被识别，运动员故事也更有力量。",
                        "参考案例展示活动互动、制作效率与品牌记忆的变化，数据仅作演示。"
                    ],
                    "en": [
                        "A more focused visual system helped campaign content feel stronger, faster and more consistent across formats.",
                        "With a shared language in place, campaigns became instantly recognisable across retail, social and out-of-home, and athlete stories landed with more impact.",
                        "Production became faster too: teams adapted master assets instead of rebuilding them, freeing time for the ideas that matter.",
                        "+64% CAMPAIGN ENGAGEMENT",
                        "A more focused visual system helped campaign content feel stronger, faster and more consistent across formats.",
                        "3× FASTER ADAPTATION",
                        "Teams adapted master assets for new formats in hours instead of days.",
                        "+41% BRAND RECALL",
                        "Campaigns were recognised more often across touchpoints.",
                        "119+ FORMATS",
                        "One system covered every format, from stories to stadium screens."
                    ]
                }
            }
        ],
        "metrics": [
            "+64%",
            "3×",
            "+41%",
            "119+"
        ]
    },
    {
        "slug": "mclaren",
        "name": "McLaren",
        "year": "2025",
        "scope": {
            "zh": "数字体验 + 动效",
            "en": "DIGITAL EXPERIENCE + MOTION"
        },
        "title": {
            "zh": "让数字体验跟上赛道节奏",
            "en": "Building a digital experience at race pace"
        },
        "intro": {
            "zh": "电影感影像、鲜明的编辑布局与精确动效，让车迷走近工程、车手，以及决定比赛的每一个瞬间。",
            "en": "For McLaren, we built a digital experience around the feeling of speed. Cinematic imagery, sharp editorial layouts and precise motion bring fans closer to the engineering, the drivers and the split seconds that decide a race."
        },
        "industry": {
            "zh": "赛车与汽车",
            "en": "Motorsport & Automotive"
        },
        "services": {
            "zh": "数字体验 · 艺术指导 · 动效设计",
            "en": "Digital Experience · Art Direction · Motion"
        },
        "deliverables": {
            "zh": "网站 · 动效系统 · 编辑模板",
            "en": "Website · Motion System · Editorial Templates"
        },
        "images": [
            "/templates/cerno/images/uuKYtMmPXhUHEkjE83JALqc8cI.jpg",
            "/templates/cerno/images/F3XUnQAbIfEzQBxazGr4Pe9CxQ.jpg",
            "/templates/cerno/images/Bgl6mQF8QxXXKZmQPuodL9WdRHI.jpg",
            "/templates/cerno/images/O7Q1aEITM8ruqH14JnVWuiqqn0.jpg",
            "/templates/cerno/images/6LCIyeGQrUMI3IdYwDGBwPbeaA.jpg",
            "/templates/cerno/images/b4I9m2OFAfwp4ymqoNLQvQIak.jpg",
            "/templates/cerno/images/OHwBGVnLj9bbUVTMe7gmiYpGg8.jpg",
            "/templates/cerno/images/NGjtcEPJF7nvNQTUJxB6wkXPdVw.jpg",
            "/templates/cerno/images/oKCfRsSV0yyYlageY48zlwvKBTs.jpg",
            "/templates/cerno/images/DD24HzqcFASKTxw2eggTrAcwI.jpg",
            "/templates/cerno/images/EJC1alBCjkfsbKME7VpoadCM4.jpg",
            "/templates/cerno/images/M34GpTKW97kU3AirBRmmxiRB9qg.jpg",
            "/templates/cerno/images/37zg1XGAa460t5mopZXyLOQnc.jpg",
            "/templates/cerno/images/jTtlSFS7668MVQI4HSoInY8uU.jpg"
        ],
        "sections": [
            {
                "title": {
                    "zh": "将工程精度带入每次浏览",
                    "en": "The introduction"
                },
                "paragraphs": {
                    "zh": [
                        "McLaren 的故事跨越比赛周末、技术突破与悠久历史。数字体验应当与赛道上的激情相呼应。",
                        "我们用更完整的结构把团队、工程与赛事内容连接起来。"
                    ],
                    "en": [
                        "McLaren is defined by engineering precision and a relentless pursuit of speed — its digital experience needed to feel the same.",
                        "For fans, McLaren is a story told across race weekends, engineering breakthroughs and decades of heritage. Online, that story was spread thin across pages that felt static next to the drama on track.",
                        "We set out to build an experience that combines cinematic race imagery, sharp editorial layouts and motion-led interactions to bring the brand’s engineering mindset into every scroll, transition and detail."
                    ]
                }
            },
            {
                "title": {
                    "zh": "品牌在疾驰，体验也要向前",
                    "en": "The challenge"
                },
                "paragraphs": {
                    "zh": [
                        "内容随着赛事不断增长，却缺少串联历史、新闻与伙伴故事的清晰路径。",
                        "我们要提升发现效率，同时让网站拥有品牌特有的速度感。"
                    ],
                    "en": [
                        "The brand moves at over 300 km/h, but the website felt like it was standing still.",
                        "Content had grown race by race, with little structure tying heritage, team news and partner stories together. Visitors came for a result or a headline and left without exploring further.",
                        "The challenge was to turn a news-driven site into an immersive world, without sacrificing the speed and clarity fans expect on race day.",
                        "MOMENTUM",
                        "Make the experience feel fast, precise and alive, like the cars themselves.",
                        "DEPTH",
                        "Connect race news, engineering and heritage into one explorable world.",
                        "PERFORMANCE",
                        "Deliver rich motion without compromising load times on race day."
                    ]
                }
            },
            {
                "title": {
                    "zh": "速度感与阅读节奏的平衡",
                    "en": "The solution"
                },
                "paragraphs": {
                    "zh": [
                        "电影感的赛车影像与清晰的编辑网格结合，通过精确而克制的动效建立节奏。",
                        "统一的内容模板帮助团队快速发布赛事内容，减少重复制作。"
                    ],
                    "en": [
                        "“It feels like our cars: precise, fast and full of detail. Fans now stay for the story, not just the result.”",
                        "James Whitfield",
                        "Head of Digital Content",
                        "We combined cinematic imagery, sharp editorial layouts and motion-led interactions into one system built for speed.",
                        "We restructured the content into connected worlds — team, cars, heritage and partners — so every story leads naturally to the next.",
                        "Art direction leans on cinematic race imagery and motion blur, framed by a precise editorial grid. Transitions are tuned like a car setup: quick, controlled and never decorative.",
                        "A dedicated motion system defines timing, easing and choreography for every interaction, keeping the experience consistent as new content goes live every race weekend."
                    ]
                }
            },
            {
                "title": {
                    "zh": "让车迷更接近比赛",
                    "en": "The impact"
                },
                "paragraphs": {
                    "zh": [
                        "更清晰的内容组织让车迷愿意继续探索，视觉与动效共同传递工程精神。",
                        "结果数据来自参考展示，不构成真实业务承诺。"
                    ],
                    "en": [
                        "A stronger visual hierarchy and more immersive storytelling helped fans explore more of the McLaren world.",
                        "Fans now move from race results into engineering features, heritage stories and partner content, spending far longer in the McLaren world than before.",
                        "The motion system and modular templates also made race-weekend publishing faster, so the team can react to every result as it happens.",
                        "2.4× CONTENT ENGAGEMENT",
                        "A stronger visual hierarchy and more immersive storytelling helped users explore more of the McLaren world.",
                        "+46% PAGES PER VISIT",
                        "Connected stories led fans deeper into the site.",
                        "−32% LOAD TIME",
                        "A lighter build kept motion smooth even at race-day traffic peaks.",
                        "+58% RETURN VISITS",
                        "Fans came back more often across the race season."
                    ]
                }
            }
        ],
        "metrics": [
            "+58%",
            "+43%",
            "−26%",
            "2.4×"
        ]
    },
    {
        "slug": "new-balance",
        "name": "New Balance",
        "year": "2026",
        "scope": {
            "zh": "电商体验 + 品牌平台",
            "en": "E-COMMERCE + BRAND PLATFORM"
        },
        "title": {
            "zh": "为每一种跑者找到合适的起点",
            "en": "Building a home for every kind of runner"
        },
        "intro": {
            "zh": "围绕脚感、工艺与跑者重建数字店铺，以产品选择引导和丰富故事，帮助每个人找到适合自己的那双鞋。",
            "en": "For New Balance, we rebuilt the digital storefront around fit, craft and the people who run in it. A guided product finder and richer storytelling help every runner land on the right pair, whatever distance they’re chasing."
        },
        "industry": {
            "zh": "鞋履与跑步",
            "en": "Footwear & Running"
        },
        "services": {
            "zh": "电商策略 · UX/UI · 艺术指导",
            "en": "E-commerce Strategy · UX/UI · Art Direction"
        },
        "deliverables": {
            "zh": "线上店铺 · 选鞋工具 · 内容系统",
            "en": "Storefront · Product Finder · Content System"
        },
        "images": [
            "/templates/cerno/images/9c6szFx03TMYeJZ5hLjwBHjQg8.jpg",
            "/templates/cerno/images/BlfosWSUThDKhlam5H3dTkXgvI.jpg",
            "/templates/cerno/images/Lt474NCkRfRSjbKdk8KPCMpws.jpg",
            "/templates/cerno/images/oLLGyBccjhOv8EZZQKvX3LRLs0.jpg",
            "/templates/cerno/images/uMgn3YLjSVFgyx45kSBTLrAADxg.jpg",
            "/templates/cerno/images/moBl7DcYS1ENJzmS1lgyRzRK5g0.jpg",
            "/templates/cerno/images/iLGnFZM1LP0TkcnaOdF7bFMUBg.jpg",
            "/templates/cerno/images/EmrYKOKA8jdRwA6GB9HxVqXSlw.jpg",
            "/templates/cerno/images/Lpj948WLMHL84jVqTpJrUi6F8w.jpg",
            "/templates/cerno/images/lPvhUdGVWwtL3gGftrGfw3RGg1M.jpg",
            "/templates/cerno/images/nIH8YFceKuUgDMnJB9MMLh6K0.jpg",
            "/templates/cerno/images/kKc0udjaIC8MpOl9H4nLUr7YsDI.jpg",
            "/templates/cerno/images/8wdlDGE6hm1ttMRyGwUOi5w1eCY.jpg",
            "/templates/cerno/images/MnQBkac0gkxhDj301uHg47ZBl4s.jpg",
            "/templates/cerno/images/E3I2emyT1TJ5sVm3Im2ZaciuM.jpg",
            "/templates/cerno/images/jm5qxkAkfw2ukAyDUKLg4zM.jpg",
            "/templates/cerno/images/XxpaWojAqmTZApmCDkSmw0DgXC0.jpg",
            "/templates/cerno/images/zJ5PXclfRH2YPsSHusqVeUvAk84.jpg"
        ],
        "sections": [
            {
                "title": {
                    "zh": "让在线选择同样周到",
                    "en": "The introduction"
                },
                "paragraphs": {
                    "zh": [
                        "从日常经典到比赛用鞋，New Balance 服务于广泛的人群。相似的型号与分散的技术信息，让线上选择变得困难。",
                        "数字店铺需要兼顾合脚建议、产品工艺与跑步文化。"
                    ],
                    "en": [
                        "New Balance is built on fit, craftsmanship and a long running heritage — its storefront needed to feel just as considered.",
                        "From everyday classics to race-day carbon plates, New Balance makes shoes for a remarkably wide range of people. Online, that range had become hard to navigate: dozens of similar-looking models, technical details hidden away and little help choosing the right one.",
                        "We partnered with the team to rebuild the storefront around how people actually shop for shoes — by feel, by purpose and by fit — while giving the brand’s craft and heritage room to shine."
                    ]
                }
            },
            {
                "title": {
                    "zh": "选对鞋，不应依赖猜测",
                    "en": "The challenge"
                },
                "paragraphs": {
                    "zh": [
                        "生活方式鞋款与竞速跑鞋曾采用相似的展示方式，尺码、缓震和用途说明分散在各处。",
                        "关键是让选择更清楚，而不是把品牌变成一张参数表。"
                    ],
                    "en": [
                        "Customers loved the shoes, but finding the right pair online felt like guesswork.",
                        "Product listings treated a heritage lifestyle sneaker and a marathon racer the same way. Fit guidance, cushioning details and use cases were scattered across pages, and too many orders ended in returns for the wrong size or model.",
                        "The challenge was to make choosing easier and more confident, without turning a brand known for craft into a spec sheet.",
                        "FIT",
                        "Help customers find the right model and size the first time.",
                        "CLARITY",
                        "Make the differences between similar shoes obvious at a glance.",
                        "CRAFT",
                        "Bring materials, heritage and the people behind the shoes into the shopping experience."
                    ]
                }
            },
            {
                "title": {
                    "zh": "围绕脚感与用途重新组织",
                    "en": "The solution"
                },
                "paragraphs": {
                    "zh": [
                        "选鞋工具先了解跑步目的、距离与场地，再推荐少量合适的型号。",
                        "产品页优先呈现缓震、支撑与合脚感，工艺故事和材料信息则随时可达。"
                    ],
                    "en": [
                        "“Our customers finally shop the way they talk about shoes, by how they feel. Fewer returns, happier runners, and a site that looks like us.”",
                        "Hannah Cole",
                        "VP Digital Commerce",
                        "We built a storefront that guides people to the right pair, with the brand’s craft and running culture woven through every step.",
                        "A guided product finder asks how, where and how far you run, then narrows hundreds of options to a handful, with fit notes drawn from real customer feedback.",
                        "Product pages were redesigned around feel: cushioning, support and fit come first, shown through clear visuals rather than tables, with heritage stories and materials one tap away.",
                        "Underneath, a modular content system lets the team pair product drops with editorial, athlete and community stories, so every launch feels like part of a bigger running culture."
                    ]
                }
            },
            {
                "title": {
                    "zh": "更自信的选择，更长久的关系",
                    "en": "The impact"
                },
                "paragraphs": {
                    "zh": [
                        "清晰的引导帮助访客更快找到适合的鞋款，内容系统也让每次发布成为完整的故事。",
                        "转化与退货等数值为参考案例展示数据。"
                    ],
                    "en": [
                        "A guided, more human storefront helped customers choose with confidence and come back for their next pair.",
                        "With the product finder and clearer product pages in place, more visitors found the right shoe quickly, and far fewer sent it back.",
                        "The new content system also turned launches into stories, giving every drop a stronger stage across the site and social.",
                        "+47% CONVERSION",
                        "Guided discovery helped more visitors find and buy the right pair.",
                        "−29% RETURNS",
                        "Better fit guidance meant fewer wrong sizes and models.",
                        "+52% FINDER ENGAGEMENT",
                        "Most new visitors used the product finder to narrow their choice.",
                        "1.6× REPEAT PURCHASES",
                        "Customers came back more often for their next pair."
                    ]
                }
            }
        ],
        "metrics": [
            "+47%",
            "−29%",
            "+52%",
            "1.6×"
        ]
    },
    {
        "slug": "the-accel",
        "name": "Accel",
        "year": "2026",
        "scope": {
            "zh": "品牌识别 + 网站设计",
            "en": "BRAND IDENTITY + WEB DESIGN"
        },
        "title": {
            "zh": "构建更清晰的数字品牌",
            "en": "Building a clearer digital presence"
        },
        "intro": {
            "zh": "我们帮助充满活力的户外品牌 Accel 建立轻松、鲜明、随时出发的数字体验。",
            "en": "We helped Accel turn an energetic outdoor brand into a digital experience that feels effortless, distinctive, and built to move."
        },
        "industry": {
            "zh": "户外生活与体验",
            "en": "Outdoor Lifestyle & Experiences"
        },
        "services": {
            "zh": "策略 · 品牌方向 · UX/UI · 网站设计",
            "en": "Strategy · Brand Direction · UX/UI · Web Design"
        },
        "deliverables": {
            "zh": "识别系统 · 网站 · 数字工具包",
            "en": "Identity System · Website · Digital Toolkit"
        },
        "images": [
            "/templates/cerno/images/1pygO4QSsrNpgL6Qpz5owTqU.jpg",
            "/templates/cerno/images/fq6ybL6sNZ92D5wtwz7fhbJnSE0.jpg",
            "/templates/cerno/images/WduPXUH5jHfGWJPswhcN414ckXk.jpg",
            "/templates/cerno/images/6UhcqDofmwhD5Gf5a3Q6vBVnk.jpg",
            "/templates/cerno/images/5ovg2BuoaYgllJroi0krxum7A.jpg",
            "/templates/cerno/images/j69KpEEDKjDAE60CEEEUvgIYic.jpg",
            "/templates/cerno/images/881R7OhV8byxt6Hx5YS38yreSI.jpg",
            "/templates/cerno/images/8xZtCEqCbmMN18pNIAFOBeEyIOQ.jpg",
            "/templates/cerno/images/Umxs7aZqsQDml4E6qhlUhkeR7A0.jpg",
            "/templates/cerno/images/aUMkZqmwgkFvZADJeUbGqTmgNo.jpg",
            "/templates/cerno/images/i07yxAJddNs5ljaYaAgNoCQIQs0.jpg",
            "/templates/cerno/images/msD3pvcRafa5Lej7MhX51LYXE6Y.jpg"
        ],
        "sections": [
            {
                "title": {
                    "zh": "让日常探险变得轻松",
                    "en": "The introduction"
                },
                "paragraphs": {
                    "zh": [
                        "Accel 为希望更多走向户外的人们创造产品与体验。随着业务发展，线上形象需要表达同样的自由感与活力。",
                        "我们将品牌识别与网站共同考虑，建立新的设计依据。"
                    ],
                    "en": [
                        "Accel is an outdoor lifestyle brand built to make movement, exploration, and everyday adventure feel effortless.",
                        "Accel creates products and experiences for people who want to spend more time outside. As the brand grew, its digital presence struggled to communicate that same sense of freedom, energy, and simplicity.",
                        "We partnered with Accel to reshape its identity and website around a clearer, more flexible system — combining bold imagery, confident typography, and intuitive navigation to create an experience that feels as effortless as the brand itself."
                    ]
                }
            },
            {
                "title": {
                    "zh": "让体验跟上品牌成长",
                    "en": "The challenge"
                },
                "paragraphs": {
                    "zh": [
                        "原有网站的导航与触点逐渐失去一致性，优秀影像与鲜明个性没有形成整体。",
                        "挑战是简化路径，同时保留品牌的性格与能量。"
                    ],
                    "en": [
                        "Accel had the energy of a growing brand, but its digital experience wasn’t keeping pace with where the business was heading.",
                        "As Accel expanded, the website had become harder to navigate and less consistent across key touchpoints. Strong photography and personality were there, but the experience lacked the structure needed to communicate the brand clearly.",
                        "The challenge was to simplify the journey without stripping away its character — creating a system that could feel expressive and energetic while making products, content, and actions easier to discover.",
                        "CLARITY",
                        "Simplify the experience so visitors can understand Accel and find what matters faster.",
                        "CONSISTENCY",
                        "Bring typography, imagery, layout, and interaction into one cohesive visual system.",
                        "CONVERSION",
                        "Create clearer pathways from exploration to meaningful actions throughout the website."
                    ]
                }
            },
            {
                "title": {
                    "zh": "一个清晰而灵活的系统",
                    "en": "The solution"
                },
                "paragraphs": {
                    "zh": [
                        "先按用户真正需要的信息重组内容，再用生活方式影像、自信的字体和充分留白建立视觉方向。",
                        "细微动效服务于理解，模块化系统支持未来产品、活动与内容扩展。"
                    ],
                    "en": [
                        "“Cerno gave us more than a new website. They created a system that finally feels like us — clear, energetic, and much easier for our audience to navigate.”",
                        "David Finn",
                        "CEO",
                        "We turned Accel’s fragmented digital presence into one clear, flexible system built around movement, simplicity, and brand character.",
                        "We began by restructuring the experience around the information users actually needed. Navigation was simplified, content was prioritised, and each page was given a clearer purpose so the journey felt more intuitive from the first interaction.",
                        "The visual direction combined bold lifestyle photography, confident typography, generous spacing, and subtle motion. Rather than overwhelming the experience with effects, every interaction was designed to reinforce Accel’s sense of energy and movement.",
                        "Behind the visuals, we created a modular design system that could grow with the brand — giving the internal team consistent components, layouts, and patterns they could reuse across new products, campaigns, and content."
                    ]
                }
            },
            {
                "title": {
                    "zh": "为成长留下空间",
                    "en": "The impact"
                },
                "paragraphs": {
                    "zh": [
                        "新的系统让品牌更容易被理解，访客可以更顺畅地进入下一步。",
                        "团队获得统一的组件与布局，后续迭代也更高效。展示数据源于参考案例。"
                    ],
                    "en": [
                        "The new experience gave Accel a clearer identity, a smoother journey, and a stronger foundation for growth.",
                        "With a more focused structure and a consistent visual system, visitors could understand the brand faster and move through the site with less friction. The experience felt more intentional, while still keeping the energy that made Accel distinctive.",
                        "The redesign also gave the team a flexible system they could build on — making future campaigns, product launches, and content easier to roll out without losing consistency.",
                        "+42% CONVERSION",
                        "More visitors moved from exploration into meaningful actions.",
                        "+31% ENGAGEMENT",
                        "Users spent longer interacting with key pages and content.",
                        "−24% BOUNCE RATE",
                        "A clearer structure helped more visitors stay and explore.",
                        "1.8× KEY ACTIONS",
                        "More users completed the actions that mattered most to the business."
                    ]
                }
            }
        ],
        "metrics": [
            "+42%",
            "+31%",
            "−24%",
            "1.8×"
        ]
    }
];
export const articles = [
    {
        "slug": "when-a-rebrand-is-really-a-business-decision",
        "title": {
            "zh": "品牌重塑，其实是一次业务决定",
            "en": "When a rebrand is really a business decision"
        },
        "category": {
            "zh": "策略",
            "en": "STRATEGY"
        },
        "date": "2026-09-17",
        "minutes": 6,
        "intro": {
            "zh": "有效的品牌重塑，往往先解决定位、定价与业务方向的问题，再决定如何呈现。",
            "en": "MOST REBRANDS ARE FRAMED AS A VISUAL PROBLEM. THE ONES THAT WORK ARE USUALLY SOLVING SOMETHING FURTHER UPSTREAM — IN POSITIONING, IN PRICING, OR IN WHAT THE COMPANY HAS QUIETLY BECOME."
        },
        "images": [
            "/templates/cerno/images/2GF5O17rgzepyYf1gxiPW98agsA.jpg",
            "/templates/cerno/images/siPbhJ0ZmcV2WdENZLYZm0nyTg.jpg",
            "/templates/cerno/images/jYfZ8f8QCyHJUe9DkLPTS55bq0.jpg",
            "/templates/cerno/images/AXUw6dUpX7zioBCKO4xlbflRj2A.jpg",
            "/templates/cerno/images/ZvRlFZoErW53EKUTshpWEhQKJ3g.jpg",
            "/templates/cerno/images/3hIdrqOMBvAQxnPz4rG4ziA.jpg"
        ],
        "sections": [
            {
                "title": "从标志之外开始",
                "paragraphs": [
                    "企业很少只是想换一个标志。销售反复解释、提案难以达成共识、网站描述落后于现实，这些信号说明业务已经成长，品牌却仍停留在过去。",
                    "先问业务发生了什么，再决定设计需要改变什么。"
                ]
            },
            {
                "title": "读懂变化的信号",
                "paragraphs": [
                    "销售团队开始使用不同的语言，每场提案都重新制作材料。内部不同角色对公司价值的理解也逐渐分散。",
                    "这些看似表达的问题，通常是策略尚未形成共同结论的表现。"
                ]
            },
            {
                "title": "用业务语言建立理由",
                "paragraphs": [
                    "更短的销售周期、更高的成交率、更明确的市场位置，能够帮助团队评估品牌投资。",
                    "设计让真实的价值更容易被看见，但不能替代可靠的产品和明确的方向。"
                ]
            },
            {
                "title": "让共识成为基础",
                "paragraphs": [
                    "品牌重塑迫使团队回答长期悬而未决的问题：最重要的客户是谁，业务的未来在哪里，以及我们真正提供什么。",
                    "视觉变化只是结果，更持久的价值来自这些共同决定。"
                ]
            },
            {
                "title": "持续维护品牌系统",
                "paragraphs": [
                    "上线只是一个节点。团队能否独立应用规则，定位能否经受真实市场对话，决定了投入是否持续产生价值。",
                    "像维护其他基础设施一样定期检查、扩展和调整品牌。"
                ]
            }
        ],
        "english": [
            "Beyond the logo",
            "A rebrand rarely begins with design — it begins with a business that has outgrown the way it describes itself.",
            "Companies rarely wake up wanting a new logo. They arrive at it sideways: after a year of losing deals they should have won, or explaining themselves twice in every meeting, or watching a competitor take a position they assumed was theirs.",
            "By the time the conversation reaches design, the real problem has usually been building for a while. The market has shifted, the product has broadened, the audience has changed, or the company has acquired something that no longer fits under the old story.",
            "That is why the most useful first question in a rebrand is not what it should look like. It is what has changed about the business that the current brand can no longer carry.",
            "Reading the signals",
            "The symptoms show up in sales conversations long before they show up in the design.",
            "There are recognisable signs that a brand has fallen out of step. Sales teams start inventing their own language because the official version does not land. Decks get rebuilt for every pitch. The website describes a company that existed three years ago.",
            "Internally, the same drift appears as disagreement. Ask five people what the company does and you get five answers, each of them partly right. That is not a communication failure — it is a strategy question surfacing as a branding one.",
            "Pricing is another signal. When a company cannot command the premium its work deserves, it is often because the brand is positioning it in the wrong category entirely.",
            "None of these are design problems. But all of them become visible through design, which is why the brand is usually where they finally get addressed.",
            "Making the case",
            "Rebrands get approved on business outcomes, not on aesthetics.",
            "The hardest part of a rebrand is rarely the work itself. It is securing the mandate — persuading a board that the investment returns something measurable rather than simply looking more current.",
            "That case is easier to make in the language of the business. Shorter sales cycles. Higher win rates on competitive deals. Less time spent explaining. Easier recruitment. Clearer routes into adjacent markets.",
            "The question is never whether the brand looks dated. It is what the current brand costs you every quarter you keep it.",
            "Framed that way, a rebrand stops being a cost centre and becomes a lever. It also changes who needs to be in the room — finance, sales and product all have a stake in the outcome, and each holds information the design work depends on.",
            "It is worth being honest about the limits. A rebrand will not repair a weak product, a confused roadmap, or a culture that does not believe its own story. Design makes things legible; it does not make them true.",
            "The bigger picture",
            "“The identity is the easy part. What takes time is getting a company to agree on what it is.”",
            "The best rebrands settle an argument the company has been having with itself.",
            "Every company carries a few unresolved questions. Which customer matters most. Which part of the business is the future. Whether to lead with the product or the expertise behind it.",
            "These can stay open for years without obvious cost. A rebrand forces them closed, because you cannot design a coherent identity around a position nobody has agreed on.",
            "That is uncomfortable, and it is also the point. The work done in those conversations usually outlasts anything produced visually — the sharpened positioning, the decision about who to stop selling to, the agreement on what the company is actually for.",
            "Teams often describe the result as clarity rather than newness. The brand did not just change appearance; it made a decision visible.",
            "Looking ahead",
            "Treat the brand as infrastructure, not as a campaign with an end date.",
            "Launch day is the least important one. What determines whether a rebrand holds is the twelve months afterwards — whether teams can apply it without asking permission, and whether the positioning survives contact with real sales conversations.",
            "Brands that stay sharp are maintained like any other system. They are reviewed, extended and occasionally corrected, rather than rebuilt from scratch every five years.",
            "DIAGNOSE",
            "Find what changed in the business before deciding what changes in the design.",
            "JUSTIFY",
            "Make the case in commercial terms — win rates, cycle length, pricing power.",
            "SUSTAIN",
            "Ship the system, not just the launch. Maintenance is what protects the investment.",
            ""
        ]
    },
    {
        "slug": "why-some-brands-feel-distinctive-before-you-notice-the-logo",
        "title": {
            "zh": "还没看到 Logo，为何就能认出品牌",
            "en": "Why some brands feel distinctive before you notice the logo"
        },
        "category": {
            "zh": "品牌",
            "en": "BRANDING"
        },
        "date": "2026-09-15",
        "minutes": 5,
        "intro": {
            "zh": "识别通常从颜色、节奏、结构与语气开始。人们会先感受到这些线索，再有意识地读出品牌名称。",
            "en": "RECOGNITION RARELY STARTS WITH THE MARK. IT STARTS WITH COLOUR, PACE, STRUCTURE AND TONE — THE CUES AN AUDIENCE ABSORBS BEFORE THEY CONSCIOUSLY IDENTIFY ANYTHING."
        },
        "images": [
            "/templates/cerno/images/TQdZMltgFd6eG5lkpbWoGsMQI.jpg",
            "/templates/cerno/images/J4qHWEbL6FqslsBvRqz6FUPJvco.jpg",
            "/templates/cerno/images/bxTUJtLwIKJFiYYENwbwc5ehqE.jpg",
            "/templates/cerno/images/xY7ciHb1LJWCsXAz88LPqaYNI.jpg",
            "/templates/cerno/images/bcdZk8gPcCknPIipEZsgjV2utU.jpg",
            "/templates/cerno/images/MtJiwuomUOgJQOzRbl5O0dD5HbM.jpg"
        ],
        "sections": [
            {
                "title": "第一印象先于阅读",
                "paragraphs": [
                    "在滚动页面时，颜色关系、影像裁切与排版节奏，往往比标志更早告诉你这是谁。",
                    "标志确认身份，而周围的系统已经建立了第一印象。"
                ]
            },
            {
                "title": "真正承载识别的细节",
                "paragraphs": [
                    "颜色传递最快，字体更持久，摄影方向和语言语气则在反复使用中形成记忆。",
                    "这些经常出现的细节，需要和标志一样受到认真对待。"
                ]
            },
            {
                "title": "一致性需要承诺",
                "paragraphs": [
                    "鲜明来自长期重复的选择。一次有效的决定，只有在不同页面、不同媒介中被持续使用，才会变成品牌资产。",
                    "系统既要明确边界，也要允许内容变化。"
                ]
            },
            {
                "title": "从真实触点检验",
                "paragraphs": [
                    "把标志暂时隐藏，观察受众是否仍能从颜色、排版与语言认出品牌。",
                    "在真实广告、产品界面和社交内容中检验设计，避免只在展示稿里成立。"
                ]
            },
            {
                "title": "建立可以持续的规则",
                "paragraphs": [
                    "记录可执行的原则、典型组合和不适合的做法，让团队不依赖某个设计师也能保持辨识度。",
                    "让每一次新内容都成为对同一个品牌的积累。"
                ]
            }
        ],
        "english": [
            "First impressions",
            "You recognise most brands long before you read them.",
            "Think about scrolling past something and knowing whose it is before any name appears. That recognition is not coming from the logo. It is coming from a colour relationship, a crop, a particular way of setting type, a rhythm in the layout.",
            "Logos do important work, but they do it late. They confirm an identity that has usually already been established by everything surrounding them.",
            "Which means distinctiveness is mostly built in the parts of a system that are easiest to treat as secondary — the spacing, the photography direction, the way a sentence is written.",
            "The real carriers",
            "Distinctiveness lives in the assets that repeat most, not the ones that matter most on paper.",
            "Colour is the fastest signal. A specific, committed colour relationship is recognised across a room, at speed, in peripheral vision — long before a mark resolves.",
            "Typography is slower but more durable. A typeface used with conviction, at consistent weights and sizes, becomes a voice. Most brands undermine this by using too many.",
            "Composition is the one teams underestimate. Where things sit, how much space they are given, whether the grid is tight or loose — these read as personality even when nobody can name what they are responding to.",
            "Language belongs on the same list. Sentence length, vocabulary and rhythm are as recognisable as any visual cue, and they travel into places design cannot reach.",
            "Consistency and its limits",
            "Repetition builds recognition — but only when there is something specific enough to repeat.",
            "Consistency is usually prescribed as the answer, and it is half of one. Repeating a generic system produces a generic brand, only more reliably.",
            "The other half is commitment: choosing something specific enough to be noticed, then holding it long past the point where the internal team has grown tired of it.",
            "Teams get bored of their own brand roughly three years before their audience starts recognising it.",
            "This is why brand systems tend to weaken from the inside. The people closest to the work want variation, and each individual departure seems reasonable. Collectively they erase the pattern that recognition depends on.",
            "The discipline is not avoiding change. It is knowing which elements are load-bearing, and holding those steady while everything else flexes.",
            "The bigger picture",
            "“Safe choices are not neutral. They cost you the thing you were trying to buy.”",
            "Distinctiveness is a commercial asset, not a matter of taste.",
            "Brands that are recognised quickly buy attention more cheaply. Their advertising works harder, their content compounds, and their audiences need fewer exposures to remember who they are.",
            "This has been measured repeatedly, and it consistently favours brands that are distinctive over brands that are merely well executed. Being good is not the same as being identifiable.",
            "The trap is that distinctiveness often tests poorly in research. Unfamiliar choices feel wrong precisely because they are unfamiliar — which is the same quality that makes them memorable later.",
            "Committing to something specific means accepting early discomfort in exchange for later recognition. Most organisations struggle with that trade, which is exactly why it stays available.",
            "Looking ahead",
            "Audit what your audience would recognise with the name removed.",
            "It is a useful exercise. Strip the logo from a handful of your assets and ask whether anything remains that could only be you. Most brands find the honest answer is very little.",
            "What survives that test is the real identity. Everything else is decoration that happens to be on-brand.",
            "COMMIT",
            "Choose assets specific enough to be noticed, not merely inoffensive.",
            "REPEAT",
            "Recognition is earned through repetition long after the team has tired of it.",
            "PROTECT",
            "Know which elements are load-bearing and hold them while the rest flexes.",
            ""
        ]
    },
    {
        "slug": "what-restraint-actually-adds-to-a-design",
        "title": {
            "zh": "设计中的克制，究竟增加了什么",
            "en": "What restraint actually adds to a design"
        },
        "category": {
            "zh": "设计",
            "en": "DESIGN"
        },
        "date": "2026-09-12",
        "minutes": 4,
        "intro": {
            "zh": "克制更像编辑：主动移除与核心目的竞争的内容，为真正重要的部分留出空间。",
            "en": "RESTRAINT IS OFTEN MISTAKEN FOR MINIMALISM. IT IS CLOSER TO EDITING — THE DELIBERATE REMOVAL OF EVERYTHING THAT COMPETES WITH WHAT THE WORK IS ACTUALLY FOR."
        },
        "images": [
            "/templates/cerno/images/kg7tRB10UnlBXY4V48y2C5LMHnM.jpg",
            "/templates/cerno/images/BhCP3bluhWqTpwfaEAhxqc07Kqk.jpg",
            "/templates/cerno/images/2acoeVGo8H0G8tTnNqFNAvApwk.jpg",
            "/templates/cerno/images/BoertJEsPp4SG2Bj1XH7bIZbjs.jpg",
            "/templates/cerno/images/1oKjPc1fgQ7THhjOJqgDQlCveVI.jpg",
            "/templates/cerno/images/oZRoF9UezsZ8AG9UyHrIxJFGv0.jpg"
        ],
        "sections": [
            {
                "title": "克制不是没有想法",
                "paragraphs": [
                    "极简是一种风格，克制是一种关于重点的判断。它同样适用于丰富、热烈和具有装饰性的设计。",
                    "留下的每个元素都应该承担明确的任务。"
                ]
            },
            {
                "title": "注意力是一种有限资源",
                "paragraphs": [
                    "每加入一个元素，都会消耗其他内容原本可以获得的注意力。",
                    "清楚的焦点与合理的对比，让用户不必自己整理页面优先级。"
                ]
            },
            {
                "title": "从编辑开始",
                "paragraphs": [
                    "先找到核心任务，再移除次优的创意。优秀的想法也可能因为当前场景不合适而需要舍弃。",
                    "减少重复信息，明确阅读顺序，用真实内容检查布局。"
                ]
            },
            {
                "title": "为体验保留呼吸",
                "paragraphs": [
                    "留白、停顿和简洁的交互不是空缺，而是理解内容所需要的时间。",
                    "每次动效和视觉强调，都应该帮助用户知道接下来做什么。"
                ]
            },
            {
                "title": "坚持有理由的选择",
                "paragraphs": [
                    "最终的判断不是页面有多空，而是它是否更容易理解、更容易使用。",
                    "克制让设计的意图清晰可见。"
                ]
            }
        ],
        "english": [
            "A common misreading",
            "Restraint is not the absence of ideas. It is the refusal to show all of them at once.",
            "Restraint gets confused with minimalism, and the two are not the same. Minimalism is a style with a look. Restraint is a decision about emphasis, and it can apply to work that is dense, loud or highly decorated.",
            "A restrained design is not one with less in it. It is one where everything present is doing something, and where the things that matter most are given room to be seen first.",
            "The discipline is subtractive. It comes from removing the second-best idea, not from never having had one.",
            "What it buys you",
            "Every element you add spends attention that something else no longer receives.",
            "Attention is finite and it does not scale. A page with one clear focal point directs it; a page with six competes with itself and lands nowhere.",
            "Restraint also buys hierarchy. Contrast only works relatively — when everything is emphasised, nothing reads as important, and the viewer is left to sort it out themselves.",
            "There is a durability argument too. Work that leans on fewer devices tends to age more slowly, because it has less surface area exposed to whatever the current fashion happens to be.",
            "And it buys flexibility. Systems built from a small number of well-chosen parts extend further than systems assembled from many specific ones.",
            "Where it goes wrong",
            "Restraint practised without a point of view becomes blandness.",
            "The failure mode is real. Removing things is easy to do and easy to mistake for rigour, and it is possible to edit a design all the way down to nothing in particular.",
            "The difference is whether something was protected in the process. Restraint should concentrate force, not dissipate it — if the result is quieter but no clearer, the editing went the wrong way.",
            "Subtraction is only useful when you know what you are protecting.",
            "This is why restraint is hard to brief and harder to review. It looks like less work, and the reasoning behind each omission is invisible by definition.",
            "The honest test is not whether a design feels clean. It is whether removing one more thing would damage it. If not, keep going.",
            "The bigger picture",
            "“Nobody gets credit for what they left out, which is why so little gets left out.”",
            "Most organisations add because adding is easier to justify than removing.",
            "Every stakeholder has something they need represented, and each request is individually reasonable. The accumulated result is a page nobody designed and nobody can defend.",
            "Removal has no natural advocate. Nobody is rewarded for the banner that was not added or the feature that stayed off the homepage, even when those omissions are what made the rest work.",
            "That asymmetry is structural, not a failure of taste. Which means restraint has to be built into the process rather than left to whoever happens to be designing.",
            "In practice that looks like constraints agreed in advance — a fixed number of messages, a limited palette, a rule about what earns a place above the fold — so that additions have to displace something rather than simply accumulate.",
            "Looking ahead",
            "Build the constraint into the brief, not into the review.",
            "Restraint applied at the end is damage control. Applied at the start, it shapes what gets made — and it is far easier to defend a limit agreed before anyone was attached to their contribution.",
            "The teams that manage this well tend to treat limits as creative material rather than as an obstacle.",
            "PROTECT",
            "Decide what the work is for before deciding what to remove.",
            "CONSTRAIN",
            "Agree limits in the brief, where they shape the work instead of trimming it.",
            "TEST",
            "If removing one more element would not hurt, it has not been edited enough.",
            ""
        ]
    },
    {
        "slug": "the-homepage-doesnt-need-to-explain-everything",
        "title": {
            "zh": "首页，不必解释所有事情",
            "en": "The homepage doesn’t need to explain everything"
        },
        "category": {
            "zh": "数字体验",
            "en": "DIGITAL"
        },
        "date": "2026-09-09",
        "minutes": 5,
        "intro": {
            "zh": "表现良好的首页通常做得更少：让人迅速确认方向，再引导他们进入真正需要的页面。",
            "en": "HOMEPAGES ARE ASKED TO SERVE EVERY AUDIENCE AT ONCE. THE ONES THAT PERFORM USUALLY DO LESS — ORIENTING QUICKLY, THEN GETTING OUT OF THE WAY."
        },
        "images": [
            "/templates/cerno/images/a4PAWFdrz4Q6ciEyGCXRtgfn3wo.jpg",
            "/templates/cerno/images/uzbORx6dpFP9ijOhUP3OAPnD0.jpg",
            "/templates/cerno/images/zv8ZyHfrG7WFHslhWBqO6dxoA.jpg",
            "/templates/cerno/images/B3bzD29mHCgRTKUVZULgK77aU.jpg",
            "/templates/cerno/images/o4DK3I1rxbtOsOt0xGkb3otAfo.jpg",
            "/templates/cerno/images/Q4kN3w3tG06NdEVDfnyHOaDmvI.jpg"
        ],
        "sections": [
            {
                "title": "所有内容都想占据首页",
                "paragraphs": [
                    "销售希望展示案例，产品希望推广新功能，招聘希望介绍文化。每个诉求都合理，但放在一起就可能失去重点。",
                    "首页应围绕访客目标，而不是内部组织结构来安排。"
                ]
            },
            {
                "title": "首页真正的任务",
                "paragraphs": [
                    "告诉访客你是谁、是否与他相关，以及接下来该去哪里。",
                    "更详细的内容交给专门页面，让每一条路径服务于明确的目标。"
                ]
            },
            {
                "title": "建立清楚的信息层级",
                "paragraphs": [
                    "先表达最重要的价值，再提供足够的证据，最后给出清晰的行动入口。",
                    "不要把所有板块设置成同样的视觉权重。"
                ]
            },
            {
                "title": "通过真实路径来判断",
                "paragraphs": [
                    "观察访客是否能快速找到作品、服务或联系方式，而不是仅仅计算页面放了多少内容。",
                    "手机上的阅读节奏和主要操作，尤其需要单独检查。"
                ]
            },
            {
                "title": "让内容拥有自己的位置",
                "paragraphs": [
                    "减少首页承担的责任，能够让其他页面获得更明确的目的。",
                    "优秀的首页是一个清楚的路口，让每位访客找到适合自己的下一步。"
                ]
            }
        ],
        "english": [
            "The pressure to cover everything",
            "A homepage is the only page every team believes belongs to them.",
            "Sales wants the proof points. Product wants the new release. Recruitment wants the culture section. Leadership wants the positioning statement. All of it is legitimate, and all of it lands on the same page.",
            "The result is a homepage built by negotiation rather than by intent — long, evenly weighted, and organised around internal structure instead of what a visitor is trying to do.",
            "It is worth remembering that most visitors do not read a homepage. They scan it long enough to decide whether they are in the right place, then leave for somewhere more specific.",
            "What it is actually for",
            "The homepage is a junction, not a destination.",
            "Its job is orientation. Who this is, whether it is relevant, and where to go next. Three things, answered quickly, in roughly that order.",
            "Everything beyond that is better handled by pages built for a single purpose, where the content can be as detailed as the audience needs without competing for space.",
            "This is also how people actually arrive. A meaningful share of traffic enters through search, a shared link or a campaign, landing deep in the site and never seeing the homepage at all.",
            "Designing the homepage as if it were the only entrance overweights it. Designing it as a junction makes the whole site work harder.",
            "The cost of over-explaining",
            "Length is not thoroughness — past a point it reads as uncertainty.",
            "A page that explains everything signals that nothing could be left out, which tends to read as a lack of confidence rather than a wealth of substance.",
            "It also flattens hierarchy. When every section carries the same weight, visitors cannot tell what matters, and the page stops making an argument at all.",
            "If the homepage has to explain everything, the problem is usually the positioning, not the page.",
            "Most over-long homepages are compensating for an unresolved question further upstream. When a company cannot say what it does in a sentence, the page ends up trying every version at once.",
            "Fixing that is not a design task. But the homepage is where the absence becomes impossible to ignore, which is often what finally forces the decision.",
            "The bigger picture",
            "“Nothing is being cut. It is being given somewhere it can actually be read.”",
            "Editing a homepage is mostly an organisational exercise.",
            "The design decisions are rarely the difficult part. Deciding whose content comes off the page is, because it means telling a team their priority is being handled somewhere else.",
            "That conversation goes better when it is framed around the visitor’s sequence rather than internal hierarchy — not whose section matters, but what someone needs to know before they need to know anything else.",
            "It also helps to make the alternative concrete. Content is not being deleted; it is moving to a page where it can be more thorough than the homepage would ever allow.",
            "Teams that get this right review the homepage on a schedule and treat removal as routine maintenance, rather than as a negotiation reopened every time something new ships.",
            "Looking ahead",
            "Judge the homepage on what happens next, not on how much it contains.",
            "The useful measure is whether visitors move, and whether they move somewhere relevant. A short page that routes people accurately is doing its job better than a long one that holds them without direction.",
            "That reframing also settles most internal arguments, because it replaces an aesthetic debate with a question the analytics can answer.",
            "ORIENT",
            "Say who this is and whether it is relevant, quickly.",
            "ROUTE",
            "Send people to pages built for one purpose, where detail belongs.",
            "MEASURE",
            "Judge the page on onward movement, not on length or coverage.",
            ""
        ]
    }
];
export const pageImages: Record<string, string[]> = {
    "/": [
        "/templates/cerno/images/uyM3BWCzFmEZ6t95LPvvuAtNlyk.jpg",
        "/templates/cerno/images/37reJJWklvZtDDOnnhAFAKxDoJE.jpg",
        "/templates/cerno/images/Yp9gqyxsIr9D3zwwBovfBlsp8Q.jpg",
        "/templates/cerno/images/rDJEpptQXhfhEbRJTRuq7aVt8.jpg",
        "/templates/cerno/images/wdJZIYlKvb6JdAC60Tn4XF5OBsM.jpg",
        "/templates/cerno/images/NASQTV9vphmOBs1pMLmEJ6kYMs.jpg",
        "/templates/cerno/images/vIJddu4FF9beN6BHoKizqE4dj0.jpg",
        "/templates/cerno/images/GbyP9bvpmalb3u2KCkK1Qy8Hxfs.jpg",
        "/templates/cerno/images/9gjrsm3sPw7XRCSemL0ylk4CIc4.jpg",
        "/templates/cerno/images/blDvYLqm9iPqwAmvbZYAb5Pt8pw.jpg",
        "/templates/cerno/images/FrgDOxicTFJcAU7CDOlvaE1dFA.jpg",
        "/templates/cerno/images/ZdNqQBgYdi0fW9RJRDoZOkWtI.jpg",
        "/templates/cerno/images/VAGPNYbiLbqgBq8E6btyjcewbeM.jpg",
        "/templates/cerno/images/YFXZdnYBEUalI9SHJLvlAQAc.jpg",
        "/templates/cerno/images/QD5e9M2OcQ6WVWJ2d8l7vt3E.jpg",
        "/templates/cerno/images/li6EGGo7LAbYzJmNyo8SR1Ydg.jpg",
        "/templates/cerno/images/6G4vSnNJaV9dWSXlDFnv7tEe48.jpg",
        "/templates/cerno/images/fOYO4VgPZzXjCW9qLyOhsKAxZ5Y.jpg",
        "/templates/cerno/images/HPLEhxfVGEoIq40oDsJGfdROPM.jpg",
        "/templates/cerno/images/3bfW9nXRs2okrSADBkjU2sM3VA.jpg",
        "/templates/cerno/images/wMhfOQwCbpP2RkfRvaEL2S5ozA.jpg",
        "/templates/cerno/images/C7Mld9mJByDDqEB3vaS0ZlbUHU.jpg",
        "/templates/cerno/images/FUT6kOexTHpAmvKqP99W8IHI.jpg",
        "/templates/cerno/images/zImKpy5Z3lNFvh1KL8OePFvrYk.jpg",
        "/templates/cerno/images/tWE2Bo6WOufq0xu217cvMBaKig.jpg",
        "/templates/cerno/images/p9sXmKPUieGy3WFDsMweiqNybLM.jpg",
        "/templates/cerno/images/mRFQo9WU67q9207Dt0EkPo9lL84.jpg",
        "/templates/cerno/images/3bqW4hQrand2qEBngUsr0f7V5N8.jpg",
        "/templates/cerno/images/njEetCoqKgzJtkv6m4g1wOaKU.jpg",
        "/templates/cerno/images/hHYuyXZQEg3b9p1tWC3meJGzok.jpg",
        "/templates/cerno/images/E3wVdzoRG8c8f0evPClylm4GkA.jpg",
        "/templates/cerno/images/AhERw7L700ojTjj1sp4Vf9fzBI.jpg",
        "/templates/cerno/images/AhERw7L700ojTjj1sp4Vf9fzBI.jpg",
        "/templates/cerno/images/9c6szFx03TMYeJZ5hLjwBHjQg8.jpg",
        "/templates/cerno/images/9c6szFx03TMYeJZ5hLjwBHjQg8.jpg",
        "/templates/cerno/images/1pygO4QSsrNpgL6Qpz5owTqU.jpg",
        "/templates/cerno/images/1pygO4QSsrNpgL6Qpz5owTqU.jpg",
        "/templates/cerno/images/N562tf0SmnvpI1y38ilTKj72NI.png",
        "/templates/cerno/images/F0jhtbZaoJzz02F6O8DpxTy1NTQ.jpg",
        "/templates/cerno/images/Jl4vgS6VQHdePzBn8PJDuPNMnQ.jpg",
        "/templates/cerno/images/wXwidQunAD72scxoDkM5PYkPpI.jpg",
        "/templates/cerno/images/nA6VpxGpIdTH7JGN98R8iD4fHlk.jpg",
        "/templates/cerno/images/gJYI04RK58qUbAe2EPWolJOyGoE.jpg",
        "/templates/cerno/images/t3ZUVlCb8mQKBwjfznIqvC5Gu80.png",
        "/templates/cerno/images/SyVXwUDB4KFi2mzAdIHmWwslI.jpg",
        "/templates/cerno/images/JphhXnTGe54D1Y92Vt3u0uC8Ks.jpg",
        "/templates/cerno/images/wwcBxxIrRgcBCEzz83yu3oXro.png",
        "/templates/cerno/images/0RoeppOv7z45sMwSJ0qJItFrbE.jpg",
        "/templates/cerno/images/BE8nTed23oQrpIlMvXCwe97JMU.jpg",
        "/templates/cerno/images/rv99WxXgkphEDWjq0dXFo2Lj8g.jpg",
        "/templates/cerno/images/A2zPnkGFG6tkA63HnWmhZuHOU.jpg",
        "/templates/cerno/images/hj7UcBmGgRWYz8GlakBnC1qlK4s.jpg",
        "/templates/cerno/images/xXNF1XPcdGVtHBVASiEeosmvXQ.jpg",
        "/templates/cerno/images/2GF5O17rgzepyYf1gxiPW98agsA.jpg",
        "/templates/cerno/images/TQdZMltgFd6eG5lkpbWoGsMQI.jpg",
        "/templates/cerno/images/kg7tRB10UnlBXY4V48y2C5LMHnM.jpg",
        "/templates/cerno/images/a4PAWFdrz4Q6ciEyGCXRtgfn3wo.jpg",
        "/templates/cerno/images/eVTWkIBoFsAA4oYFcBbXDxZg8Nw.jpg",
        "/templates/cerno/images/eaZ6ZIfKTCqeNvtAkV1mZmGq7xs.jpg"
    ],
    "/work": [
        "/templates/cerno/images/njEetCoqKgzJtkv6m4g1wOaKU.jpg",
        "/templates/cerno/images/k8HPjFVskU8SdjLrpoTbdzI6l4M.jpg",
        "/templates/cerno/images/AhERw7L700ojTjj1sp4Vf9fzBI.jpg",
        "/templates/cerno/images/uuKYtMmPXhUHEkjE83JALqc8cI.jpg",
        "/templates/cerno/images/9c6szFx03TMYeJZ5hLjwBHjQg8.jpg",
        "/templates/cerno/images/1pygO4QSsrNpgL6Qpz5owTqU.jpg",
        "/templates/cerno/images/eaZ6ZIfKTCqeNvtAkV1mZmGq7xs.jpg"
    ],
    "/about": [
        "/templates/cerno/images/0cWQlaP0ApIfeiXh9nLGxXRVff0.jpg",
        "/templates/cerno/images/YxmO3buoCCc0WXrXRCTxMxhiiQ.jpg",
        "/templates/cerno/images/cC7IViouOiy7uSxtTdzixMhGvAM.jpg",
        "/templates/cerno/images/F0jhtbZaoJzz02F6O8DpxTy1NTQ.jpg",
        "/templates/cerno/images/Jl4vgS6VQHdePzBn8PJDuPNMnQ.jpg",
        "/templates/cerno/images/wXwidQunAD72scxoDkM5PYkPpI.jpg",
        "/templates/cerno/images/nA6VpxGpIdTH7JGN98R8iD4fHlk.jpg",
        "/templates/cerno/images/gJYI04RK58qUbAe2EPWolJOyGoE.jpg",
        "/templates/cerno/images/VMhzbILbHz1oUMBxU9yFXOM40.jpg",
        "/templates/cerno/images/2GF5O17rgzepyYf1gxiPW98agsA.jpg",
        "/templates/cerno/images/TQdZMltgFd6eG5lkpbWoGsMQI.jpg",
        "/templates/cerno/images/kg7tRB10UnlBXY4V48y2C5LMHnM.jpg",
        "/templates/cerno/images/a4PAWFdrz4Q6ciEyGCXRtgfn3wo.jpg",
        "/templates/cerno/images/eVTWkIBoFsAA4oYFcBbXDxZg8Nw.jpg",
        "/templates/cerno/images/eaZ6ZIfKTCqeNvtAkV1mZmGq7xs.jpg"
    ],
    "/blog": [
        "/templates/cerno/images/kXFfzuxbuJh4baBNrr3UKKoVo.jpg",
        "/templates/cerno/images/2GF5O17rgzepyYf1gxiPW98agsA.jpg",
        "/templates/cerno/images/TQdZMltgFd6eG5lkpbWoGsMQI.jpg",
        "/templates/cerno/images/kg7tRB10UnlBXY4V48y2C5LMHnM.jpg",
        "/templates/cerno/images/a4PAWFdrz4Q6ciEyGCXRtgfn3wo.jpg",
        "/templates/cerno/images/eaZ6ZIfKTCqeNvtAkV1mZmGq7xs.jpg"
    ],
    "/contact": [
        "/templates/cerno/images/IKQ0jnczUVdWltsBW45OR0izo.jpg",
        "/templates/cerno/images/cS6XhtpvOS2ZEfEGZIQEYAxlqoY.jpg",
        "/templates/cerno/images/eVTWkIBoFsAA4oYFcBbXDxZg8Nw.jpg",
        "/templates/cerno/images/eaZ6ZIfKTCqeNvtAkV1mZmGq7xs.jpg"
    ],
    "/legal/privacy-policy": [
        "/templates/cerno/images/eaZ6ZIfKTCqeNvtAkV1mZmGq7xs.jpg"
    ],
    "/legal/terms-of-service": [
        "/templates/cerno/images/eaZ6ZIfKTCqeNvtAkV1mZmGq7xs.jpg"
    ],
    "/work/adidas": [
        "/templates/cerno/images/AhERw7L700ojTjj1sp4Vf9fzBI.jpg",
        "/templates/cerno/images/nwDSak8ct51vCD2o1TVCWlI5g.jpg",
        "/templates/cerno/images/hwv8UP6iFT0T3APDh7Ea62d4mk.jpg",
        "/templates/cerno/images/Nknv2G4V6hpE2IpQEukK2wgi1Qg.jpg",
        "/templates/cerno/images/pzqPEJKoQD0rUcd6cxdZote1s.jpg",
        "/templates/cerno/images/cMNbccAP1MZBucBT2RI00TihIU.jpg",
        "/templates/cerno/images/9sCToSfR5BLNbJ97BUFdPmMDN8.jpg",
        "/templates/cerno/images/ZmjMP1HOJFweuCT8PuGGi60Go.jpg",
        "/templates/cerno/images/UOV70XR0WEMuVY4WzDNjX3DT5N8.jpg",
        "/templates/cerno/images/MWrVM62bicK5rg4Gi7V2VV28yH4.jpg",
        "/templates/cerno/images/y3MjbRg8boSsbYUajHDqJMF3E.jpg",
        "/templates/cerno/images/cZ4vQ6ncyUinMmWPGVa7SLJG40.jpg",
        "/templates/cerno/images/JJRiQh0r7yVjFbEdfMDGEeO3H4.jpg",
        "/templates/cerno/images/M7JmUa56ouPzV8y2Iwj6HAR4.jpg",
        "/templates/cerno/images/I73c69mLTQ1OKhrhAWoABehU.jpg",
        "/templates/cerno/images/46eFUGrMOaK5o9fLFydagW4A46s.jpg",
        "/templates/cerno/images/9Nijc1lf1TpjsI5JGuZEqRUBffY.jpg",
        "/templates/cerno/images/q6PQh6icZVDA0twDeHX4YRzj4.jpg",
        "/templates/cerno/images/eaZ6ZIfKTCqeNvtAkV1mZmGq7xs.jpg"
    ],
    "/work/new-balance": [
        "/templates/cerno/images/9c6szFx03TMYeJZ5hLjwBHjQg8.jpg",
        "/templates/cerno/images/BlfosWSUThDKhlam5H3dTkXgvI.jpg",
        "/templates/cerno/images/Lt474NCkRfRSjbKdk8KPCMpws.jpg",
        "/templates/cerno/images/oLLGyBccjhOv8EZZQKvX3LRLs0.jpg",
        "/templates/cerno/images/uMgn3YLjSVFgyx45kSBTLrAADxg.jpg",
        "/templates/cerno/images/moBl7DcYS1ENJzmS1lgyRzRK5g0.jpg",
        "/templates/cerno/images/iLGnFZM1LP0TkcnaOdF7bFMUBg.jpg",
        "/templates/cerno/images/EmrYKOKA8jdRwA6GB9HxVqXSlw.jpg",
        "/templates/cerno/images/Lpj948WLMHL84jVqTpJrUi6F8w.jpg",
        "/templates/cerno/images/lPvhUdGVWwtL3gGftrGfw3RGg1M.jpg",
        "/templates/cerno/images/nIH8YFceKuUgDMnJB9MMLh6K0.jpg",
        "/templates/cerno/images/kKc0udjaIC8MpOl9H4nLUr7YsDI.jpg",
        "/templates/cerno/images/8wdlDGE6hm1ttMRyGwUOi5w1eCY.jpg",
        "/templates/cerno/images/MnQBkac0gkxhDj301uHg47ZBl4s.jpg",
        "/templates/cerno/images/E3I2emyT1TJ5sVm3Im2ZaciuM.jpg",
        "/templates/cerno/images/jm5qxkAkfw2ukAyDUKLg4zM.jpg",
        "/templates/cerno/images/XxpaWojAqmTZApmCDkSmw0DgXC0.jpg",
        "/templates/cerno/images/zJ5PXclfRH2YPsSHusqVeUvAk84.jpg",
        "/templates/cerno/images/eaZ6ZIfKTCqeNvtAkV1mZmGq7xs.jpg"
    ],
    "/work/the-accel": [
        "/templates/cerno/images/1pygO4QSsrNpgL6Qpz5owTqU.jpg",
        "/templates/cerno/images/fq6ybL6sNZ92D5wtwz7fhbJnSE0.jpg",
        "/templates/cerno/images/WduPXUH5jHfGWJPswhcN414ckXk.jpg",
        "/templates/cerno/images/6UhcqDofmwhD5Gf5a3Q6vBVnk.jpg",
        "/templates/cerno/images/5ovg2BuoaYgllJroi0krxum7A.jpg",
        "/templates/cerno/images/j69KpEEDKjDAE60CEEEUvgIYic.jpg",
        "/templates/cerno/images/881R7OhV8byxt6Hx5YS38yreSI.jpg",
        "/templates/cerno/images/8xZtCEqCbmMN18pNIAFOBeEyIOQ.jpg",
        "/templates/cerno/images/Umxs7aZqsQDml4E6qhlUhkeR7A0.jpg",
        "/templates/cerno/images/5ovg2BuoaYgllJroi0krxum7A.jpg",
        "/templates/cerno/images/j69KpEEDKjDAE60CEEEUvgIYic.jpg",
        "/templates/cerno/images/aUMkZqmwgkFvZADJeUbGqTmgNo.jpg",
        "/templates/cerno/images/5ovg2BuoaYgllJroi0krxum7A.jpg",
        "/templates/cerno/images/j69KpEEDKjDAE60CEEEUvgIYic.jpg",
        "/templates/cerno/images/881R7OhV8byxt6Hx5YS38yreSI.jpg",
        "/templates/cerno/images/aUMkZqmwgkFvZADJeUbGqTmgNo.jpg",
        "/templates/cerno/images/i07yxAJddNs5ljaYaAgNoCQIQs0.jpg",
        "/templates/cerno/images/msD3pvcRafa5Lej7MhX51LYXE6Y.jpg",
        "/templates/cerno/images/eaZ6ZIfKTCqeNvtAkV1mZmGq7xs.jpg"
    ],
    "/blog/when-a-rebrand-is-really-a-business-decision": [
        "/templates/cerno/images/2GF5O17rgzepyYf1gxiPW98agsA.jpg",
        "/templates/cerno/images/siPbhJ0ZmcV2WdENZLYZm0nyTg.jpg",
        "/templates/cerno/images/jYfZ8f8QCyHJUe9DkLPTS55bq0.jpg",
        "/templates/cerno/images/AXUw6dUpX7zioBCKO4xlbflRj2A.jpg",
        "/templates/cerno/images/ZvRlFZoErW53EKUTshpWEhQKJ3g.jpg",
        "/templates/cerno/images/3hIdrqOMBvAQxnPz4rG4ziA.jpg",
        "/templates/cerno/images/eaZ6ZIfKTCqeNvtAkV1mZmGq7xs.jpg"
    ],
    "/blog/why-some-brands-feel-distinctive-before-you-notice-the-logo": [
        "/templates/cerno/images/TQdZMltgFd6eG5lkpbWoGsMQI.jpg",
        "/templates/cerno/images/J4qHWEbL6FqslsBvRqz6FUPJvco.jpg",
        "/templates/cerno/images/bxTUJtLwIKJFiYYENwbwc5ehqE.jpg",
        "/templates/cerno/images/xY7ciHb1LJWCsXAz88LPqaYNI.jpg",
        "/templates/cerno/images/bcdZk8gPcCknPIipEZsgjV2utU.jpg",
        "/templates/cerno/images/MtJiwuomUOgJQOzRbl5O0dD5HbM.jpg",
        "/templates/cerno/images/eaZ6ZIfKTCqeNvtAkV1mZmGq7xs.jpg"
    ],
    "/blog/what-restraint-actually-adds-to-a-design": [
        "/templates/cerno/images/kg7tRB10UnlBXY4V48y2C5LMHnM.jpg",
        "/templates/cerno/images/BhCP3bluhWqTpwfaEAhxqc07Kqk.jpg",
        "/templates/cerno/images/2acoeVGo8H0G8tTnNqFNAvApwk.jpg",
        "/templates/cerno/images/BoertJEsPp4SG2Bj1XH7bIZbjs.jpg",
        "/templates/cerno/images/1oKjPc1fgQ7THhjOJqgDQlCveVI.jpg",
        "/templates/cerno/images/oZRoF9UezsZ8AG9UyHrIxJFGv0.jpg",
        "/templates/cerno/images/eaZ6ZIfKTCqeNvtAkV1mZmGq7xs.jpg"
    ],
    "/blog/the-homepage-doesn%E2%80%99t-need-to-explain-everything": [
        "/templates/cerno/images/a4PAWFdrz4Q6ciEyGCXRtgfn3wo.jpg",
        "/templates/cerno/images/uzbORx6dpFP9ijOhUP3OAPnD0.jpg",
        "/templates/cerno/images/zv8ZyHfrG7WFHslhWBqO6dxoA.jpg",
        "/templates/cerno/images/B3bzD29mHCgRTKUVZULgK77aU.jpg",
        "/templates/cerno/images/o4DK3I1rxbtOsOt0xGkb3otAfo.jpg",
        "/templates/cerno/images/Q4kN3w3tG06NdEVDfnyHOaDmvI.jpg",
        "/templates/cerno/images/eaZ6ZIfKTCqeNvtAkV1mZmGq7xs.jpg"
    ],
    "/work/the-north-face": [
        "/templates/cerno/images/k8HPjFVskU8SdjLrpoTbdzI6l4M.jpg",
        "/templates/cerno/images/XHI79ZfThCfRBe3KyNrarx18jCw.jpg",
        "/templates/cerno/images/KGcTyz3fMlWJGMmpuTntg3aiY.jpg",
        "/templates/cerno/images/EMGeitW0AePFPcV9vUK65KK9s.jpg",
        "/templates/cerno/images/yfZiWVr5xcy8i0gdENeGFIsM.jpg",
        "/templates/cerno/images/EMfwugg7P8Mq0ipmVmphp36nXek.jpg",
        "/templates/cerno/images/KHAhHd9voSPhridxJspxwLEYeQ.jpg",
        "/templates/cerno/images/BP0gTk5eNAt2GpjiN7lf9ZBCQ.jpg",
        "/templates/cerno/images/jh4M6CgAzHKyhEiT2wIJRVY9SwA.jpg",
        "/templates/cerno/images/RgshzWNljgpJiDRbM1GYRSMXb8s.jpg",
        "/templates/cerno/images/O5r8t37CW7hPjTMMaqBb6rnxPw.jpg",
        "/templates/cerno/images/AMavaJkrZ3RqdXIhiOlmxZ2BFfE.jpg",
        "/templates/cerno/images/AUujUfF6meJZLYQFHZhkYkdy0zY.jpg",
        "/templates/cerno/images/FqvvQ3NghGXAeGTVahPz1CRBts.jpg",
        "/templates/cerno/images/qbMrxXIJ7uQ13yLfCbl30d1YuI.jpg",
        "/templates/cerno/images/nMFR0hNwgVghewEb51H16bql1M.jpg",
        "/templates/cerno/images/KGcTyz3fMlWJGMmpuTntg3aiY.jpg",
        "/templates/cerno/images/EMGeitW0AePFPcV9vUK65KK9s.jpg",
        "/templates/cerno/images/eaZ6ZIfKTCqeNvtAkV1mZmGq7xs.jpg"
    ],
    "/work/mclaren": [
        "/templates/cerno/images/uuKYtMmPXhUHEkjE83JALqc8cI.jpg",
        "/templates/cerno/images/F3XUnQAbIfEzQBxazGr4Pe9CxQ.jpg",
        "/templates/cerno/images/Bgl6mQF8QxXXKZmQPuodL9WdRHI.jpg",
        "/templates/cerno/images/O7Q1aEITM8ruqH14JnVWuiqqn0.jpg",
        "/templates/cerno/images/6LCIyeGQrUMI3IdYwDGBwPbeaA.jpg",
        "/templates/cerno/images/b4I9m2OFAfwp4ymqoNLQvQIak.jpg",
        "/templates/cerno/images/OHwBGVnLj9bbUVTMe7gmiYpGg8.jpg",
        "/templates/cerno/images/NGjtcEPJF7nvNQTUJxB6wkXPdVw.jpg",
        "/templates/cerno/images/oKCfRsSV0yyYlageY48zlwvKBTs.jpg",
        "/templates/cerno/images/DD24HzqcFASKTxw2eggTrAcwI.jpg",
        "/templates/cerno/images/EJC1alBCjkfsbKME7VpoadCM4.jpg",
        "/templates/cerno/images/M34GpTKW97kU3AirBRmmxiRB9qg.jpg",
        "/templates/cerno/images/37zg1XGAa460t5mopZXyLOQnc.jpg",
        "/templates/cerno/images/jTtlSFS7668MVQI4HSoInY8uU.jpg",
        "/templates/cerno/images/O7Q1aEITM8ruqH14JnVWuiqqn0.jpg",
        "/templates/cerno/images/F3XUnQAbIfEzQBxazGr4Pe9CxQ.jpg",
        "/templates/cerno/images/Bgl6mQF8QxXXKZmQPuodL9WdRHI.jpg",
        "/templates/cerno/images/6LCIyeGQrUMI3IdYwDGBwPbeaA.jpg",
        "/templates/cerno/images/eaZ6ZIfKTCqeNvtAkV1mZmGq7xs.jpg"
    ]
};
