import type { TemplateLocale } from '../../types';
export type Copy = {
    zh: string;
    en: string;
};
export const copy = (zh: string, en: string): Copy => ({ zh, en });
export const t = (value: Copy, locale: TemplateLocale) => value[locale];
export const ui = {
    home: copy('首页', 'Home'), work: copy('作品', 'Work'), about: copy('工作室', 'About'), blog: copy('期刊', 'Journal'), contact: copy('聊聊项目', 'Get in touch'),
    hero: copy('在每一次转变中\n塑造品牌的下一步', 'Made to be noticed, built to last'),
    intro: copy('我们与处于转变时刻的企业同行。当品牌、网站或产品已无法承载新的方向，我们用清晰的策略与设计，帮助你塑造下一步。', 'We work with companies at moments of change. When the brand, website, or product no longer fits where the business is heading, we help shape what comes next.'),
    workIntro: copy('从品牌到数字产品，让策略、视觉与交互协同工作。我们用清晰、鲜明而有效的设计，回应每一次新的挑战。', 'Selected work across brand, digital and product. Projects that bring strategy, identity, and interaction together to build brands that are clear, distinctive, and made to perform.'),
    aboutIntro: copy('小而专注的工作室，清晰而坚定的观点。我们将策略、设计与远见结合，为有抱负的团队打造自信、周全、长久的品牌。', 'A small studio with a clear point of view. We bring strategy, design, and vision together to help ambitious teams build brands that feel confident, considered, and built to last.'),
    blogIntro: copy('记录好设计如何发生。关于策略、字体、系统，以及那些让品牌与产品更清晰、更实用、更持久的决定。', 'Notes on how good work actually gets made. We write about strategy, typography, systems, and the decisions behind brands and products that stay clear, useful, and built to last.'),
    contactIntro: copy('好项目始于一次对话。告诉我们你的品牌、产品或正在面对的问题，我们一起寻找值得迈出的下一步。', 'Every good project starts with a conversation. Tell us about your brand, your product, or the problem in front of you, and we will come back with honest thoughts on where to start next.'),
    legalIntro: copy('把细则说清楚。了解本演示网站如何处理信息、如何使用内容，以及你可以期待的使用体验。', 'The small print, kept plain. How this demo handles information, how its content may be used, and what you can expect when using this site.'),
    aboutTitle: copy('我们相信的设计', 'What we stand for'),
    aboutBody: copy('当企业的外观、表达与线上体验跟不上发展，我们帮助它们找到更清晰的品牌方向，建立更好的网站。理解问题，精简信息，把每个细节做到恰到好处。', 'We work with companies that have outgrown the way they look, speak, or show up online — then help shape the next version with a clearer brand and a better website.'),
    processTitle: copy('把重要的决定\n放在正确的顺序', 'How we work'),
    processIntro: copy('从定义到上线，让每一步都清晰。核心团队始终参与，解释设计背后的判断，让你知道现在在做什么，以及下一步是什么。', 'A clear process, with the important decisions made in the right order. We keep the senior team close, explain the thinking behind the work, and make sure you always know what comes next.'),
    pricingTitle: copy('找到适合你的合作方式', 'Ways to work with us'),
    pricingIntro: copy('围绕团队的实际需求安排合作。无论是阶段性的设计支持，还是持续的创意伙伴，保持清晰、灵活，并随业务共同成长。', 'Flexible engagements built around your goals — whether you need focused design support or an ongoing creative partner.'),
    faqTitle: copy('开始之前\n先说清楚', 'Before we get started'),
    faqIntro: copy('好的合作始于明确的期待。这里整理了客户在项目开始前最关心的问题。', 'Good work starts with clear expectations. Here are the questions clients usually ask before we begin working together.'),
    journalTitle: copy('值得分享的想法', 'Our ideas worth sharing'),
    journalIntro: copy('设计、品牌、策略，以及塑造优秀作品的每一个决定。', 'Thoughts on design, branding, strategy, and the decisions that shape how good work gets made.'),
    footerTitle: copy('你的下一篇章\n从这里开始', 'Your next chapter starts here.'),
    footerIntro: copy('无论你正在开启新的事业，还是重新思考已有的品牌，我们期待参与接下来的故事。', "Whether you’re launching something new or ready to rethink what you already have, we’d love to be part of what comes next."),
    case: copy('查看案例', 'View case study'), explore: copy('探索我们的作品', 'Explore our work'), meet: copy('认识工作室', 'Meet our studio'), all: copy('查看全部期刊', 'Explore all insights'),
    demo: copy('演示表单：仅在本页校验，不发送、不保存任何信息。', 'Demo form: validation happens on this page. Nothing is sent or saved.'),
};
export const principles = [
    { title: copy('清晰，始终优先', 'Clarity first'), body: copy('让复杂的想法变得简单，让每一个设计决定都有清楚的理由。', "Great design isn’t about decoration — it’s about making complex ideas feel simple.") },
    { title: copy('细节，决定感受', 'Craft in the details'), body: copy('认真对待每一个像素、词语和交互，因为细微之处最能被感知。', 'Every pixel, word and interaction is considered, because the small things are what people feel.') },
    { title: copy('为长久而设计', 'Built to last'), body: copy('建立可以持续使用和扩展的系统，让作品在上线之后继续创造价值。', 'We design systems, not one-offs — work that keeps performing long after launch day.') },
];
export const process = [
    { title: copy('定义', 'Define'), body: copy('理解业务、受众与需要改变的问题，再明确定位、信息和创意方向，为整个项目建立共同依据。', 'We start by understanding the business, the audience, and what needs to change. From there, we define the position, message, and creative direction that will guide the rest of the project.'), tags: copy('调研 · 优先级 · 方向', 'Discovery · Priorities · Direction') },
    { title: copy('设计', 'Design'), body: copy('将方向转化为品牌、网站与关键触点上的视觉系统，让每个决定都帮助人们更容易识别和理解你的业务。', 'We turn that direction into a clear visual system across the identity, website, and key touchpoints. Every decision should make the business easier to recognize and understand.'), tags: copy('概念发展 · 探索 · 打磨', 'Concept development · Exploration · Refinement') },
    { title: copy('构建', 'Build'), body: copy('让设计、开发、动效和内容共同推进，在真实网页中不断打磨细节，确保设计意图得以完整呈现。', 'Once the direction is set, we bring it to life and refine the details as we go. Design, development, motion, and content stay connected instead of being handed between separate teams.'), tags: copy('制作 · 实现 · 质量控制', 'Production · Implementation · Quality control') },
    { title: copy('上线', 'Launch'), body: copy('测试最终版本，准备交付素材，在上线前确认每个环节符合预期。我们持续参与，让交接从容有序。', 'We test the final build, prepare the assets, and make sure everything works as intended before going live. We stay involved through launch so the handover feels smooth, not rushed.'), tags: copy('最终审核 · 上线准备 · 交接', 'Final review · Launch preparation · Handover') },
];
export const services = [
    { name: copy('策略', 'Strategy'), items: copy('品牌定位|信息表达|受众研究|创意方向', 'Positioning|Messaging|Audience|Creative direction') },
    { name: copy('品牌识别', 'Brand identity'), items: copy('视觉识别|字体系统|品牌指南|艺术指导', 'Visual identity|Typography|Brand guidelines|Art direction') },
    { name: copy('网站与产品', 'Websites & product'), items: copy('用户体验|界面设计|设计系统|网站开发', 'UX strategy|Interface design|Design systems|Development') },
    { name: copy('上线与支持', 'Launch & support'), items: copy('上线准备|内容系统|持续迭代|团队交接', 'Launch preparation|Content systems|Ongoing support|Handover') },
];
export const plans = [
    { name: copy('基础合作', 'Essential'), monthly: 2999, yearly: 2499, body: copy('为小型团队提供可靠的创意支持，无需组建完整的内部设计团队。', 'For smaller teams that need reliable creative support without building an in-house design team.'), features: copy('品牌与视觉设计|落地页设计|社交与活动素材|设计优化|2 项并行需求|每周沟通', 'Brand & visual design|Landing page design|Social & campaign assets|Design refinements|2 active requests|Weekly check-ins') },
    { name: copy('成长合作', 'Growth'), monthly: 4699, yearly: 3799, body: copy('适合需要跨渠道持续设计、同时推进多个项目的成长型品牌。', 'Built for growing brands that need consistent design across multiple channels and ongoing projects.'), features: copy('基础合作全部内容|网站与产品设计|创意指导|活动概念|3 项并行需求|优先交付', 'Everything in Essential|Website & product design|Creative direction|Campaign concepts|3 active requests|Priority turnaround') },
    { name: copy('长期伙伴', 'Partner'), monthly: 6999, yearly: 5599, body: copy('更深入的策略参与、更完整的项目支持，以及持续的创意方向管理。', 'For ambitious teams looking for deeper strategic involvement, larger projects, and ongoing creative direction.'), features: copy('成长合作全部内容|品牌策略|完整网站构建|艺术与创意指导|不限需求队列|专属设计负责人', 'Everything in Growth|Brand strategy|Full website build|Art & creative direction|Unlimited request queue|Dedicated design lead') },
];
export const faqs = [
    [copy('你们承接哪些类型的项目？', 'What types of projects do you take on?'), copy('我们覆盖策略、品牌识别、网站、数字产品与上线支持，可以解决一个具体问题，也可以整合为完整项目。', 'We work across strategy, brand identity, websites, digital products, and launch support. Projects can cover one focused need or bring several of those together.')],
    [copy('通常与哪些团队合作？', 'Who do you typically work with?'), copy('主要服务于创始人主导的企业、成熟业务和产品团队，支持新品发布、品牌升级、重新定位和新的成长阶段。', 'Mostly founder-led companies, established businesses, and product teams going through a launch, rebrand, repositioning, or new stage of growth.')],
    [copy('项目流程是怎样的？', 'What does a typical project process look like?'), copy('通常经过定义、设计、构建和上线四个阶段。你会清楚知道每一步的决定、下一步安排，以及何时需要参与。', 'Most projects move through four stages: define, design, build, and launch. You’ll always know what’s being decided, what comes next, and where your input is needed.')],
    [copy('一个项目通常需要多久？', 'How long does a project usually take?'), copy('小范围合作通常需要几周，完整品牌与网站项目一般需要 8–12 周，具体取决于范围与决策节奏。', 'Focused engagements can take a few weeks, while larger brand and website projects typically run for 8–12 weeks. Timing depends on scope and how quickly decisions can be made.')],
    [copy('如何确定项目费用？', 'How much does a project cost?'), copy('页面报价为演示数据，分别展示基础、成长和长期合作方式。真实项目应根据范围、周期与支持需求单独报价。', 'The pricing cards show demo Essential, Growth and Partner engagements. Real projects require a separate quote based on scope, timing and support needs.')],
    [copy('可以基于我们现有品牌继续设计吗？', 'Can you work with our existing brand?'), copy('可以。我们会保留已经有效的部分，将精力投入真正需要改变的地方。', 'Yes. Not every project needs a full rebrand — we can strengthen what already works and focus on the areas that need to change.')],
    [copy('我们需要投入多少时间？', 'How involved will our team need to be?'), copy('我们会在关键节点邀请你参与，让会议与反馈保持聚焦，无需由你每天管理项目。', 'We’ll need your input at key decision points, but the process is designed to keep meetings and feedback focused. You won’t need to manage the project day to day.')],
    [copy('你们支持跨地区合作吗？', 'Do you work with clients internationally?'), copy('支持远程协作，会议时间会根据双方所在地区与项目需求安排。', 'Yes. We work remotely with clients across different countries and time zones, with meetings scheduled around the needs of each project.')],
    [copy('上线后还有哪些支持？', 'What happens after the project launches?'), copy('可以将完整资料交接给内部团队，也可以继续合作，涵盖活动、网站更新、产品迭代和创意指导。', 'We can hand everything over to your team or stay involved through an ongoing partnership. That can cover new campaigns, website updates, product work, or continued creative direction.')],
];
export const testimonials = [
    { name: 'David Finn', role: copy('联合创始人', 'Co-founder'), quote: copy('团队让复杂的想法变得简单。每个决定都有依据，每次交互都服务于目标，最终成果让品牌与愿景重新对齐。', 'Great design makes complex ideas feel simple. Every decision felt intentional, every interaction had purpose, and the result brought our brand and vision together.') },
    { name: 'Maya Chen', role: copy('品牌副总裁', 'VP, Brand'), quote: copy('我们需要的不只是新的外观，而是清晰的表达。新的品牌与网站自信、专注，也为下一步做好了准备。', 'The studio brought clarity to a brand that had outgrown its original story. The new identity and website feel focused, confident, and ready for what’s next.') },
    { name: 'Elliot Brooks', role: copy('首席产品官', 'Chief product officer'), quote: copy('策略、产品思考与视觉设计紧密结合。我们获得了更清楚的信息，以及客户乐于使用的数字体验。', 'The team connected strategy, product thinking and visual design. We left with a sharper message and a digital experience our customers enjoy using.') },
    { name: 'Nora Velez', role: copy('创始人兼 CEO', 'Founder & CEO'), quote: copy('从一开始就问对了问题，再把答案变成每天都能使用的系统。品牌终于跟上了业务的步伐。', 'They asked the right questions early, then turned the answers into a clear system we can use every day. Our brand finally keeps pace with the business.') },
    { name: 'Samir Patel', role: copy('市场总监', 'Marketing director'), quote: copy('每个决定背后都有清晰的理由。一场复杂的改版，也能变得周全、协作而有序。', 'From the first workshop through launch, every decision had a reason. A complex redesign felt considered, collaborative and straightforward.') },
    { name: 'Clay Jensen', role: copy('增长负责人', 'Head of growth'), quote: copy('新的体验鲜明、易用，并且留出了持续演进的空间。它给我们带来了更好的起点。', 'We needed a clearer way to show up. The result is distinctive, easy to navigate, and built to keep evolving with us.') },
];
