# Cerno 模板

独立 Next.js 工程，16 页、中英文共 32 条路由。参考 Cerno 的深色影像首屏、橙色点阵、分段导航、沉浸式作品、工作室、服务、报价、期刊、FAQ 与联系页面。

固定 Node 22.13.1、pnpm 12.10.1。安装：`pnpm install --frozen-lockfile`；开发：`pnpm dev`，默认 http://127.0.0.1:43282；中文 /，英文 /en。生产先 `pnpm build`，再 `pnpm start`。Ctrl+C 停止本次服务，构建与开发勿同时写 .next。

检查：`pnpm typecheck`、`pnpm lint`、`pnpm test`、`pnpm build`。已启动服务后运行 `pnpm verify:browser`，CERNO_ORIGIN 可覆盖验收地址，CHROME_PATH 指定已安装 Chrome。`pnpm bundle` 生成通用运行包；完整源码通过独立 Git 交付。

首读 .tpl/README.md、template.json、project.json。品牌见 config/brand.ts，通用双语内容见 content.ts，案例与文章见 data.ts，样式见 tokens.css/theme.css，路径均位于 src/features/site-templates/catalog/cerno。更改数据集合时注意空、单、多项。

表单仅在本页校验，不发送、不保存、不创建预约。没有账户、数据库、支付、统计、外部地图或密钥。示例邮箱、电话、客户、引言、荣誉、价格与指标不代表真实服务或合作。英文参考内容保留结构，中文按同主题重新编写；政策反映本地演示实际行为，不能直接用于真实业务。

素材和字体本地托管，来源摘要见 public/templates/cerno/sources.json，字体许可随文件保存。公开仓库：https://github.com/weelume/cerno-template。参考素材与正文的商业使用及再分发授权仍需核实；公开可读取不等于获得素材授权，许可约束见 .tpl/docs/LICENSE.md。listed=false 表示未上架模板市场，stage=ready 表示本地工程与协议资料已完成。后续推送、发布或部署按用户明确授权执行。
